import sys
import os
import numpy as np
from pathlib import Path
ROOT_DIR = Path(__file__).parent.parent.absolute()
sys.path.append(str(ROOT_DIR))
from object_detection.yolo_detect import detect_objects
import cv2

def run_object_detection(inference_image, yolo_model,quad_max_size=2500,conf_thresh = 0.6):
    inference_image = np.array(inference_image)
    h, w = inference_image.shape[:2]
    quad_thresh = 2500
    if h>quad_thresh or w>quad_thresh:
        mode = 'quad' #Image is to large, split into 4 subimages and do inference
    else:
        mode = 'normal'
    inference_image = cv2.cvtColor(inference_image, cv2.COLOR_BGR2GRAY) # Convert to grayscale
    inference_image = cv2.merge([inference_image, inference_image, inference_image]) # Keep 3 channels

    detections = detect_objects(yolo_model, inference_image, mode = mode,
                                conf_thresh = 0.6,
                                iou_threshold=0.60,
                                agnostic_nms=True,
                                quad_max_size=quad_max_size)
    

    return detections
    # results = model(img, agnostic_nms=False, rect=True, conf=0.6, iou=0.6)
    # detections = []
 
    # for result in results:
    #     # Get boxes, confidence scores, and class information
    #     boxes = result.boxes.xyxy.cpu().numpy() if result.boxes is not None else []
    #     confidences = result.boxes.conf.cpu().numpy() if result.boxes is not None else []
    #     classes = result.boxes.cls.cpu().numpy() if result.boxes is not None else []
    #     class_names = result.names if hasattr(result, 'names') else {}
        
    #     # Format the detections
    #     for idx, (box, conf, cls_id) in enumerate(zip(boxes, confidences, classes)):
    #         cls_id = int(cls_id)
    #         class_name = class_names.get(cls_id, f"class_{cls_id}")
    #         x1, y1, x2, y2 = box.astype(int)


            
    #         detection = {
    #             "box": [x1, y1, x2, y2],
    #             "confidence": float(conf),
    #             "class_id": cls_id,
    #             "class_name": class_name
    #         }
    #         detections.append(detection)

    