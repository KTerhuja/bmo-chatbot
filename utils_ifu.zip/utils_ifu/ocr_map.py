def get_ocr_map():

    ocr_mapping = { "EC_REP":"EC_REP",
                    "GB_REP":"GB_REP",
                    "STERILE_R":"STERILE_R",
                    "STERILE_A":"STERILE_A",
                    "CH_REP":"CH_REP",
                    "Distributed_by":"Distributed_by",
                    "EC_MD": "EC_MD"

                        

                        }
    
    return ocr_mapping