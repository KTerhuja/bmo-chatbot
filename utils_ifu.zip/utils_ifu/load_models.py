from pathlib import Path
import sys
from dotenv import load_dotenv
import os
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from ultralytics import YOLO
from typing import Union

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 


load_dotenv()

def load_llm(gpt_version="gpt-5.1"):
    if gpt_version == "gpt-5.1":
        llm = AzureChatOpenAI(openai_api_base ="https://genaiapimna.jnj.com/openai-gpt-5/openai/deployments/gpt-5.1/",
                            openai_api_key = os.getenv('OPENAI_API_GPT5', ''),
                            openai_api_version = "2024-10-21")
        llm_structured = AzureChatOpenAI(openai_api_base ="https://genaiapimna.jnj.com/openai-gpt-5/openai/deployments/gpt-5.1/",
                            openai_api_key = os.getenv('OPENAI_API_GPT5', ''),
                            openai_api_version = "2024-10-21",
                            response_format= { "type": "json_object" })
    elif gpt_version == "gpt-4.1":
        
        MODEL_CONFIG = {
                            "llm": {
                                "temperature": 0,
                                "timeout": None,
                                "max_retries": 2,
                                "openai_api_base": f"{os.getenv('OPENAI_API_BASE', '')}deployments/gpt-4.1/",
                                "openai_api_version": '2024-10-21',
                                "openai_api_key": os.getenv('OPENAI_API_GPT5', ''),
                                "openai_api_type": os.getenv('OPENAI_API_TYPE', 'azure'),
                            }
        }
                            
        llm =  AzureChatOpenAI(**MODEL_CONFIG["llm"])

        MODEL_STRUCTURED_CONFIG = {

                            "llm": {
                                "temperature": 0,
                                "timeout": None,
                                "max_retries": 2,
                                "openai_api_base": f"{os.getenv('OPENAI_API_BASE', '')}deployments/gpt-4.1/",
                                "response_format": { "type": "json_object" },
                                "openai_api_version": os.getenv('OPENAI_API_VERSION', '2024-10-21'),
                                "openai_api_key": os.getenv('OPENAI_API_GPT5', ''),
                                "openai_api_type": os.getenv('OPENAI_API_TYPE', 'azure'),
                            }
        }
                            
        llm_structured =  AzureChatOpenAI(**MODEL_STRUCTURED_CONFIG["llm"])

    EMBEDDING_CONFIG = {
                            "embeddings": [
                                {
                                    "model": os.getenv("OPENAI_EMBEDDING_VERSION", "text-embedding-3-large"),
                                    "openai_api_base": f"{os.getenv('OPENAI_EMBEDDING_BASE', '')}deployments/{os.getenv('EMBEDDINGS_MODEL', 'text-embedding-3-large')}/",
                                    "openai_api_version": os.getenv("OPENAI_EMBEDDING_VERSION", "2022-12-01"),
                                    "openai_api_key": os.getenv("OPENAI_EMBEDDING_KEY", ""),
                                    "openai_api_type": os.getenv("OPENAI_API_TYPE", "azure"),
                                }
                            ]
                        }
                                
    client_embed = AzureOpenAIEmbeddings(**EMBEDDING_CONFIG["embeddings"][0])

    return llm, llm_structured, client_embed

def load_ocr():
    key = os.getenv('DI_API_KEY')
    endpoint = os.getenv('DI_ENDPOINT')

    client_ocr = DocumentIntelligenceClient(
    endpoint=endpoint, credential=AzureKeyCredential(key)
    )

    return client_ocr

def load_yolo_model(weights_path: Union[str, Path], mode='normal') -> YOLO:
    """
    Load a YOLOv11l model from the specified weights file.
    
    Args:
        weights_path: Path to the weights file
        mode: normal or quad
        
    Returns:
        A loaded YOLO model ready for inference
    """
    try:
        # normal or quad mode - both use standard YOLO
        # Load the model with the specified weights
        model = YOLO(weights_path)
        print(f"Model loaded successfully from {weights_path}")
        return model
    except Exception as e:
        print(f"Error loading model: {e}")
        raise