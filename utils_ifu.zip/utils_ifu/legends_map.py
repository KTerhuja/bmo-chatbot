def get_legends_map():

    class_legend_mapping = {
                            "0009 - i book GEN11":"Consult Instructions for use",
                            'MR_SAFE': 'MR Safe',
                            "GB_REP":"United Kingdom Responsible Person",
                            "CH_REP":"Authorised representative for Switzerland",
                            "Distributed_by": "Distributed by",
                            "0068 - Peel Here Arrow": 'Peel here',
                            'PEEL': "PEEL/LIFT/OPEN HERE", # 
                            'TEAR': 'TEAR HERE',
                            'Type CF applied part': 'Type CF applied part',
                            'Patient information website': 'Patient information website / for implant card: Information website for patients',
                            'Do not re-use': 'Do not re-use',
                            'Do not resterilize': 'Do not resterilize',
                            'Do not use if package is damaged and erconsult instructions for use': 'Do not use if package is damaged and consult instructions for use',
                            'Sterilized using ethylene oxide': 'Sterilized using ethylene oxide',
                            'Sterilized using irradiation': 'Sterilized using irradiation',
                            'Batch code': 'Batch code',
                            'Catalogue number': 'Catalogue number',
                            'CAUTION': 'Caution',
                            'CONTROL RELEASE™': 'CONTROL RELEASE™',
                            "MD": "Medical Device",
                            "EC_MD":"Medical Device in the European Community / Union",
                            "NO_RESTERILIZE": "Do not resterilize",
                            "PKG_DMG": "Do not use if package is damaged and consult instructions for use",
                            "NO_REUSE": "Do not re-use",
                            "REF": "Catalogue number",
                            "EXPIRY": "Use-by date",
                            "MANUFACTURER": "Manufacturer",
                            "STERILE_EO": "Sterilized using ethylene oxide",
                            "MANUFACTURING_DATE": "Date of manufacture",
                            "LOT": "Batch code",
                            "UDI": "Unique Device Identifier",
                            "N_PC": "Packaging unit",
                            'CONT_HAZ': 'Contains hazardous substances',
                            "CONT_MED": "Contains a medicinal substance",
                            "SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE": "Undyed - Absorbable - Monofilament- Uncoated- Suture",
                            "ANTIBACTERIAL": "Antibacterial",
                            "TEMP_UP": "Upper limit of temperature",
                            "MS_X":"Multi-strand",
                            "CR_X":"CONTROL RELEASE™",
                            "SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE":"Dyed - Absorbable - Monofilament - Uncoated - Suture",
                            "IFU": "Consult instructions for use or consult electronic instructions for use",
                            "RX_ONLY": "Caution: Federal law restricts this device to sale by or on the order of a licensed healthcare practitioner.",
                            "EC_REP": "Authorized Representative in the European Community/ European Union",
                            "SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDUNI":"Undyed – Unidirectional – Barbed - Absorbable – Knotless Tissue Control Device",
                            "Refer to instruction manual_285": "Refer to instruction manual/booklet (blue color represents a mandatory action)",
                            "NON_STERILE": "Non-sterile",
                            "0034 - Type CF applied part": "Type CF applied part",
                            "CE": "CE-mark and Identification number of Notified Body. The product meets the essential requirements of Medical Device Directive 93/42/EEC",
                            "N_UNITS": "Number of Units",
                            'PEEL2': 'Open here',
                            'MR_TRIANGLE': 'MR Conditional',#
                            'MR_UNSAFE': 'MR Unsafe',#
                            'CONT_ANIMAL': 'Contains biological material of animal origin',#
                            'CONT_BLOOD': 'Contains blood products',#      
                            'CONT_HUMAN': 'Contains biological material of human origin',#
                            'ETHILOCK': 'Ethilock-Fixierclips',#               
                            'KEEP_COOL': 'Keep away from heat',#
                            'KEEP_DRY': 'Keep dry',#
                            'CONT_LATEX': 'latex',#
                            'LIMIT_HUMID': 'Humidity limitation',#
                            'MR_SAFE_BL': '',
                            'NEEDLES': 'Needle',
                            'NON_PYRO': 'Non-pyrogenic',#
                            'NP_BP': 'Blunt Point',#
                            'NP_CEC': 'Conventional Cutting',#
                            'NP_CER': 'Reverse Cutting',#Not included as it has a reversible version
                            'NP_BPE': 'ETHIGUARD™ Bottle-nosed Taperpoint Needle',#
                            'NP_BPD': 'ETHIGUARD BPD Point',#
                            'NP_CEPC': 'PC PRIME™ Conventional Cutting Needle',#
                            'NP_CEPR': 'PRIME™ Reverse Cutting Needle',#Not included as it has a reversible version
                            'NP_CESC': 'Conventional Spatula Needle',#
                            'NP_CESCP': 'Center Point Spatula Needle',#
                            'NP_CESR+': 'Reverse Spatula+ Needle',#
                            'NP_CESR': 'Reverse Spatula Needle',#Not included as it has a reversible version
                            'NP_CEUR': 'CS ULTIMA reverse',#Not included as it has a reversible version
                            'NP_TC': 'TAPERCUT™ Needle',#
                            'NP_fTC': 'TAPERCUT (old version)',#
                            'NP_TCC': 'TAPERCUT™ Needle',#
                            'NP_TP': 'Taperpoint Needle',#
                            'NP_TPP': 'Taperpoint Plus Needle',#
                            'NP_TR': 'Trocar point',#
                            'PHONE': 'Telephone',#
                            'CONT_PHT': 'PHT',#
                            'CONT_PHT_DEHP': 'Contains or presence of phthalate',#
                            'PKG_DMG': 'Do not use if package is damaged and consult instructions for use',#
                            'PLED_RD_FIRM': 'Pierced firm round cornered pledget',#
                            'PLED_RD_FIRM_TH': 'Firm round corner - Needlestack suture',#
                            'PLED_RD_SOFT': 'Pierced soft round cornered pledget',#
                            'PLED_RD_SOFT_TH': 'Soft round corner - Needlestack suture',#
                            'PLED_SQ_FIRM': 'Pierced firm square cornered pledget',#
                            'PLED_SQ_FIRM_TH': 'Firm square corner - Needlestack suture',#
                            'PLED_SQ_SOFT': 'Pierced soft square cornered pledget',#
                            'PLED_SQ_SOFT_TH': 'Soft square corner - Needlestack suture',#
                            'SA_DYED_COATED_BRAIDED_ABSORBABLE': 'Dyed - Absorbable - Braided - Coated - Suture',#
                            'SA_DYED_COATED_BRAIDED_NONABSORBABLE': 'Dyed - Non-absorbable - Braided - Uncoated - Suture',#
                            'SA_DYED_COATED_MONOFILAMENT_ABSORBABLE': 'Dyed - Absorbable - Monofilament - Suture',#
                            'SA_DYED_COATED_MONOFILAMENT_NONABSORBABLE': 'Dyed - Non-absorbable - Monofilament - Suture',#
                            'SA_DYED_COATED_TWISTED_ABSORBABLE': 'Dyed - Absorbable - Twisted - Suture',#
                            'SA_DYED_COATED_TWISTED_NONABSORBABLE': 'Dyed - Non-absorbable - Twisted - Suture',#
                            'SA_DYED_UNCOATED_BRAIDED_ABSORBABLE': 'Dyed - Absorbable - Braided - Uncoated - Suture',#
                            'SA_DYED_UNCOATED_BRAIDED_NONABSORBABLE': 'Dyed - Non-absorbable - Braided - Uncoated - Suture',#
                            'SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE': 'Dyed - Absorbable - Monofilament - Suture',#
                            'SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDBI': 'Dyed - Absorbable - Monofilament - Bidirectional Barbs - Device',#
                            'SA_DYED_UNCOATED_MONOFILAMENT_NONABSORBABLE_BARBEDBI': 'Dyed - Non-absorbable - Monofilament - Bidirectional Barbs - Device',#
                            'SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDUNI': 'Dyed - Absorbable - Monofilament - Unidirectional Barbs - Device',#
                            'SA_DYED_UNCOATED_MONOFILAMENT_NONABSORBABLE_BARBEDUNI': 'Dyed - Non-absorbable - Monofilament - Unidirectional Barbs - Device',#
                            'SA_DYED_UNCOATED_MONOFILAMENT_NONABSORBABLE': 'Dyed - Non-absorbable - Monofilament - Suture',#
                            'SA_DYED_UNCOATED_TWISTED_ABSORBABLE': 'Dyed - Absorbable - Twisted - Suture',#
                            'SA_DYED_UNCOATED_TWISTED_NONABSORBABLE': 'Dyed - Non-absorbable - Twisted - Suture',#
                            'SA_UNDYED_COATED_BRAIDED_ABSORBABLE': 'Undyed - Absorbable - Braided - Coated - Suture',#
                            'SA_UNDYED_COATED_BRAIDED_NONABSORBABLE': 'Undyed - Non-absorbable - Braided - Coated - Suture',#
                            'SA_UNDYED_COATED_MONOFILAMENT_ABSORBABLE': 'Undyed - Absorbable - Monofilament - Coated - Suture',#
                            'SA_UNDYED_COATED_MONOFILAMENT_NONABSORBABLE': 'Undyed - Non-absorbable - Monofilament - Coated - Suture',#
                            'SA_UNDYED_COATED_TWISTED_ABSORBABLE': 'Undyed - Absorbable - Twisted - Coated - Suture',#
                            'SA_UNDYED_COATED_TWISTED_NONABSORBABLE': 'Undyed - Non-absorbable - Twisted - Coated - Suture',#
                            'SA_UNDYED_UNCOATED_BRAIDED_ABSORBABLE': 'Undyed - Absorbable - Braided - Uncoated - Suture',#
                            'SA_UNDYED_UNCOATED_BRAIDED_NONABSORBABLE': 'Undyed - Non-absorbable - Braided - Uncoated - Suture',#
                            'SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE': 'Undyed - Absorbable - Monofilament - Suture',#
                            'SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDBI': 'Undyed - Absorbable - Monofilament - Bidirectional Barbs - Device',#
                            'SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDUNI': 'Undyed - Absorbable - Monofilament - Unidirectional Barbs - Device',#
                            'SA_UNDYED_UNCOATED_MONOFILAMENT_NONABSORBABLE': 'Undyed - Non-absorbable - Monofilament - Suture',#
                            'SA_UNDYED_UNCOATED_TWISTED_ABSORBABLE': 'Undyed - Absorbable - Twisted - Suture',#
                            'SA_UNDYED_UNCOATED_TWISTED_NONABSORBABLE': 'Undyed - Non-absorbable - Twisted - Suture',#
                            'SB_DOUBLE': 'Double sterile barrier system',#
                            'SB_IN': 'Single sterile barrier system with protective packaging outside',#
                            'SB_OUT': 'Single sterile barrier system with protective packaging inside',#
                            'SB_SINGLE': 'Single sterile barrier system',#
                            'SN': 'SN',
                            'TEMP': 'Temperature limit',#
                            'TEMP_LO': 'Temperature Lower Limit',#
                            'TEMP_UP': 'Temperature Upper Limit',#
                            'USA_REP' : 'USA REP',
                            "0308 - Patient information website": "Patient information website / for implant card: Information website for patients",
                            "0201 - Date": "Date / for implant card: Date of Implantation",
                            "STERILE_R": "Sterilized using irradiation"

                        }
    
    return class_legend_mapping