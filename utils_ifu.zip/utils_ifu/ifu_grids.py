"""Return mapfold grid cell bounding boxes from an open PDF document.

Python 3.10+. Only get_grid_bboxes is public; private helpers implement its
layout detection and content-clearance checks. No CLI or PDF-output code.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
import warnings

import numpy as np
import pymupdf as fitz

__all__ = ["get_grid_bboxes"]
_MM = 72 / 25.4


def _runs(values):
    """Half-open intervals of True values; includes runs at either boundary."""
    ends = np.flatnonzero(np.diff(np.r_[False, values, False]))
    return [(int(a), int(b)) for a, b in zip(ends[::2], ends[1::2])]


def _dilate(mask, radius):
    """Square dilation using rolling sums; no OpenCV/SciPy dependency."""
    out = mask
    for axis in (0, 1):
        pads = [(0, 0), (0, 0)]
        pads[axis] = (radius, radius)
        padded = np.pad(out, pads)
        sums = np.cumsum(padded, axis=axis, dtype=np.int32)
        pads[axis] = (1, 0)
        sums = np.pad(sums, pads)
        hi, lo = [slice(None)] * 2, [slice(None)] * 2
        hi[axis], lo[axis] = slice(2 * radius + 1, None), slice(None, -2 * radius - 1)
        out = (sums[tuple(hi)] - sums[tuple(lo)]) > 0
    return out


def _text_geometry(page):
    flags = fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES
    blocks = page.get_text("dict", flags=flags)["blocks"]
    spans, horizontal_lines = [], []
    for block in blocks:
        if block["type"] != 0:
            continue
        for line in block["lines"]:
            if abs(line["dir"][0]) > 0.95:
                horizontal_lines.append(line["bbox"])
            for span in line["spans"]:
                if span["text"].strip():
                    spans.append(span["bbox"])
    return np.asarray(spans, dtype=float).reshape(-1, 4), horizontal_lines


def _default_bounds(page, width):
    # TrimBox is in the MediaBox frame; extraction/drawing use CropBox-relative
    # coordinates. This subtraction is essential on the cropped CURRENT PDFs.
    pos = page.cropbox_position
    r = page.trimbox - fitz.Rect(pos.x, pos.y, pos.x, pos.y)
    r &= page.rect
    inset = width / 2 + 0.25
    r &= fitz.Rect(inset, inset, page.rect.width - inset, page.rect.height - inset)
    if r.is_empty:
        raise ValueError("TrimBox does not intersect the visible page")
    return r


def _infer_count(boxes, bounds, axis, guard, search, min_panel):
    """Choose the finest regular subdivision with text-free gutters.

    A coarse projection proposes geometry only. The renderer later checks ALL
    content, including outlined text, figures, tables, and annotations.
    """
    step = 0.25
    start, stop = bounds[axis], bounds[axis + 2]
    n_bins = int(math.ceil((stop - start) / step)) + 1
    delta = np.zeros(n_bins + 1)
    for b in boxes:
        if b[3 - axis] <= bounds[1 - axis] or b[1 - axis] >= bounds[3 - axis]:
            continue
        a = max(0, int(math.floor((b[axis] - guard - start) / step)))
        z = min(n_bins, int(math.ceil((b[axis + 2] + guard - start) / step)))
        if z > a:
            delta[a] += 1
            delta[z] -= 1
    profile = np.cumsum(delta[:-1])
    accepted = []
    for count in range(2, min(32, int((stop - start) / min_panel)) + 1):
        good = True
        for j in range(1, count):
            point = start + (stop - start) * j / count
            a = max(0, int((point - search - start) / step))
            b = min(n_bins, int((point + search - start) / step) + 1)
            if b <= a or profile[a:b].min() > 0:
                good = False
                break
        if good:
            accepted.append(count)
    return max(accepted, default=1)


def _projection_gaps(boxes, bounds, axis, minimum):
    """Whitespace intervals in native text, without assuming equal spacing."""
    merged = []
    for a, b in sorted((max(bounds[axis], r[axis]), min(bounds[axis+2], r[axis+2]))
                       for r in boxes if r[axis+2] > bounds[axis] and r[axis] < bounds[axis+2]
                       and r[3-axis] > bounds[1-axis] and r[1-axis] < bounds[3-axis]):
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(b, merged[-1][1])
        else:
            merged.append([a, b])
    return [(left[1], right[0]) for left, right in zip(merged, merged[1:])
            if right[0]-left[1] >= minimum]


def _body_lines(lines):
    # Large headings / production-sheet metadata may span several panels.
    # Exclude them only from margin estimation and fallback proposals. All
    # native spans and rendered ink are still checked before a line is used.
    if not lines:
        return []
    height = float(np.median([r[3]-r[1] for r in lines]))
    return [r for r in lines if r[3]-r[1] <= 1.5*height]


def _fit_gutter_pitch(gaps, minimum, search):
    """Fit repeated columns even when a heading hides some of the gutters."""
    centers = np.array([(a+b)/2 for a,b in gaps])
    if len(centers) < 3:
        return None
    differences = np.diff(centers)
    differences = differences[differences >= minimum]
    if len(differences) < 2:
        return None
    short = differences[differences <= np.percentile(differences, 60)*1.2]
    pitch = float(np.median(short))
    indices = np.rint((centers-centers[0])/pitch)
    close = abs(centers-(centers[0]+indices*pitch)) <= max(search, pitch*.08)
    if close.sum() < 3 or close.mean() < .7 or len(set(indices[close])) < 3:
        return None
    pitch, phase = np.polyfit(indices[close], centers[close], 1)
    if pitch < minimum:
        return None
    return float(phase), float(pitch)


def _inset_artwork_bounds(bounds, boxes, axis, phase, pitch):
    """Find artwork margins on a larger sheet using the measured panel pitch."""
    if not boxes:
        return bounds
    content_start = min(r[axis] for r in boxes)
    content_end = max(r[axis+2] for r in boxes)
    start = phase + math.floor((content_start-phase)/pitch)*pitch
    end = phase + math.ceil((content_end-phase)/pitch)*pitch
    result = fitz.Rect(bounds)
    if (content_start-bounds[axis] > .2*pitch and
            bounds[axis] < start < content_start):
        result[axis] = start
    if (bounds[axis+2]-content_end > .2*pitch and
            content_end < end < bounds[axis+2]):
        result[axis+2] = end
    return result


def _infer_columns(lines, bounds, guard, search, fit_bounds):
    minimum = 90
    body = _body_lines(lines)
    gaps = _projection_gaps(lines, bounds, 0, 2*guard)
    model = _fit_gutter_pitch(gaps, minimum, search)
    if model is None:
        model = _fit_gutter_pitch(_projection_gaps(body, bounds, 0, 2*guard), minimum, search)
    if model is None:
        count = _infer_count(lines, bounds, 0, guard, search, minimum)
        return bounds, [bounds.x0+bounds.width*j/count for j in range(1,count)]
    phase, pitch = model
    if fit_bounds:
        bounds = _inset_artwork_bounds(bounds, body, 0, phase, pitch)
    indices = range(math.floor((bounds.x0-phase)/pitch), math.ceil((bounds.x1-phase)/pitch)+1)
    positions = [phase+i*pitch for i in indices
                 if bounds.x0+.4*pitch < phase+i*pitch < bounds.x1-.4*pitch]
    return bounds, positions


def _infer_rows(lines, bounds, columns, guard, search, fit_bounds):
    minimum = 120
    count = _infer_count(lines, bounds, 1, guard, search, minimum)
    regular = [bounds.y0+bounds.height*j/count for j in range(1,count)]
    x = [bounds.x0, *columns, bounds.x1]
    candidates = []
    for a,b in _projection_gaps(lines, bounds, 1, 2*guard):
        center = (a+b)/2
        if center-bounds.y0 < minimum or bounds.y1-center < minimum:
            continue
        following = [r for r in lines if b-.1 <= r[1] <= b+minimum/3]
        support = sum(any(left <= (r[0]+r[2])/2 < right for r in following)
                      for left,right in zip(x,x[1:]))
        # A new row typically restarts text in several columns. This rejects
        # isolated footer notes while allowing sparse rows via the regular
        # fallback inferred from the entire page.
        if support >= max(2, math.ceil((len(x)-1)/2)):
            candidates.append((b-a, center))
    chosen = []
    for width, center in sorted(candidates, reverse=True):
        if all(abs(center-other) >= minimum for other in chosen):
            chosen.append(center)
    chosen.sort()
    # Retain a supported regular layout when gutter evidence does not reveal
    # additional rows. A wide blank area inside a sparse panel is not a reason
    # to shift its fold boundary to the middle of that area.
    if not chosen or len(chosen) <= len(regular):
        return bounds, regular
    if fit_bounds and len(chosen) >= 2:
        pitch = float(np.median(np.diff(chosen)))
        if max(np.diff(chosen))-min(np.diff(chosen)) <= .15*pitch:
            bounds = _inset_artwork_bounds(bounds, _body_lines(lines), 1, chosen[0], pitch)
    return bounds, chosen


def _safe_line(page, boxes, bounds, axis, nominal, search, clearance, width, dpi, min_segment):
    """Move a separator into a white corridor, then cut around any obstruction.

    axis=0: vertical; axis=1: horizontal. Source-only RGB strip rendering avoids
    rendering very large maps into RAM. Expanded text boxes and expanded raster
    ink form a UNION mask. Pixel origin comes from Pixmap.x/y, not from the
    requested clip; MuPDF rounds clip rectangles to device pixel boundaries.
    """
    scale = dpi / 72
    guard = clearance + width / 2
    radius = int(math.ceil(guard * scale)) + 2  # conservative raster error allowance
    pad = (radius + 4) / scale
    along = 1 - axis
    lo, hi = bounds[along], bounds[along + 2]
    clip = fitz.Rect(bounds)
    clip[axis] = nominal - search - pad
    clip[axis + 2] = nominal + search + pad
    clip[along] = lo - pad
    clip[along + 2] = hi + pad
    clip &= page.rect
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=clip,
                          colorspace=fitz.csRGB, alpha=False, annots=True)
    rgb = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, 3)
    # min(R,G,B) also catches bright cyan/magenta inks that gray thresholds miss.
    mask = rgb.min(axis=2) < 250
    origin = np.array([pix.x, pix.y], dtype=float) / scale
    for b in boxes:
        x0, y0 = np.floor((b[:2] - origin) * scale).astype(int)
        x1, y1 = np.ceil((b[2:] - origin) * scale).astype(int)
        x0, y0 = max(0, x0), max(0, y0)
        x1, y1 = min(pix.width, x1), min(pix.height, y1)
        if x1 > x0 and y1 > y0:
            mask[y0:y1, x0:x1] = True
    blocked = _dilate(mask, radius)
    if axis == 1:
        blocked = blocked.T  # all subsequent arrays are [along, across]
    positions = origin[axis] + (np.arange(blocked.shape[1]) + 0.5) / scale
    if search == 0:
        candidates = np.array([int(np.argmin(abs(positions - nominal)))])
    else:
        candidates = np.flatnonzero(abs(positions - nominal) <= search)
    a = max(0, int(math.floor((lo - origin[along]) * scale)))
    b = min(blocked.shape[0], int(math.ceil((hi - origin[along]) * scale)))
    if not len(candidates) or b <= a:
        raise ValueError("Invalid or empty separator search region")
    counts = blocked[a:b, :].sum(axis=0)
    minimum = int(counts[candidates].min())
    best_mask = np.zeros(blocked.shape[1], dtype=bool)
    best_mask[candidates[counts[candidates] == minimum]] = True
    corridors = _runs(best_mask)
    # Favor the widest safe corridor. If all of the search interval is white,
    # retain the nominal position instead of drifting into an arbitrary margin.
    c0, c1 = max(corridors, key=lambda r: (r[1] - r[0], -abs(positions[(r[0] + r[1] - 1) // 2] - nominal)))
    if c1 - c0 == len(candidates):
        index = int(candidates[np.argmin(abs(positions[candidates] - nominal))])
    else:
        index = (c0 + c1 - 1) // 2
    coord = float(positions[index]) if search else float(nominal)
    segments = []
    for u, v in _runs(~blocked[a:b, index]):
        # Retreat into the safe pixels at both ends. Full unobstructed lines
        # use exact requested endpoints so borders meet cleanly.
        start = lo if u == 0 else origin[along] + (a + u + 0.5) / scale
        end = hi if v == b - a else origin[along] + (a + v - 0.5) / scale
        if end - start >= min_segment:
            segments.append([float(start), float(end)])
    actual_length = sum(v - u for u, v in segments)
    return dict(axis="x" if axis == 0 else "y",
                coordinate_pt=coord, segments_pt=segments,
                omitted_length_pt=max(0.0, hi - lo - actual_length))


def _validate_geometry(lines, boxes, clearance, width):
    """Independent continuous-coordinate check against every text span box."""
    collisions = 0
    for line in lines:
        axis = 0 if line["axis"] == "x" else 1
        along = 1 - axis
        c = line["coordinate_pt"]
        for a, b in line["segments_pt"]:
            if not len(boxes):
                continue
            across = np.maximum(np.maximum(boxes[:, axis] - c, c - boxes[:, axis + 2]), 0)
            parallel = np.maximum(np.maximum(boxes[:, along] - b, a - boxes[:, along + 2]), 0)
            distance = np.hypot(across, parallel) - width / 2
            collisions += int(np.count_nonzero(distance < clearance - 1e-5))
    if collisions:
        raise ValueError(f"Safety check failed: {collisions} text-clearance violations")


def _validate_raster(page, lines, clearance, width, dpi):
    """Re-render the final guarded segments independently of the search masks."""
    guard = clearance + width / 2
    scale = dpi / 72
    for line in lines:
        c = line["coordinate_pt"]
        for a, b in line["segments_pt"]:
            rect = fitz.Rect(c - guard, a - guard, c + guard, b + guard) if line["axis"] == "x" else fitz.Rect(a - guard, c - guard, b + guard, c + guard)
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=rect & page.rect,
                                  colorspace=fitz.csRGB, alpha=False, annots=True)
            samples = np.frombuffer(pix.samples, np.uint8)
            collisions = int(np.count_nonzero(samples < 250))
            if collisions:
                raise ValueError(f"Independent raster check failed: {collisions} non-white channel values in a protected separator corridor")


def _page_settings(config, filename, page_number):
    result = dict(config.get("defaults", {}))
    doc = config.get("files", {}).get(filename, {})
    result.update({k: v for k, v in doc.items() if k != "pages"})
    result.update(doc.get("pages", {}).get(str(page_number), {}))
    return result


def _validate_settings(settings, page, width):
    unknown = set(settings) - {"bounds", "rows", "columns", "x", "y", "skip", "note", "search_pt"}
    if unknown:
        raise ValueError(f"Unknown layout settings: {sorted(unknown)}")
    bounds = fitz.Rect(settings["bounds"]) if "bounds" in settings else _default_bounds(page, width)
    if bounds.is_empty or bounds.is_infinite or not page.rect.contains(bounds):
        raise ValueError("Layout bounds must be a nonempty rectangle inside the unrotated page")
    for key in ("rows", "columns"):
        value = settings.get(key)
        if value is not None and (not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= 64):
            raise ValueError(f"{key} must be an integer from 1 to 64")
    for key, axis in (("x", 0), ("y", 1)):
        values = settings.get(key)
        if values is not None and (not isinstance(values, list) or
                any(not math.isfinite(v) or not bounds[axis] < v < bounds[axis + 2] for v in values) or
                values != sorted(set(values))):
            raise ValueError(f"{key} must be a sorted, unique list strictly inside bounds")
    return bounds


def _detect_grid_lines(page, settings, clearance_mm, width_pt, dpi, search_pt):
    """Compute final separators; reject unresolved layouts or failed checks."""
    boxes, body_lines = _text_geometry(page)
    bounds = _validate_settings(settings, page, width_pt)
    explicit = any(k in settings for k in ("columns", "rows", "x", "y"))
    if len(body_lines) < 100 and not explicit:
        raise ValueError("Too little native text for reliable grid inference; provide a layout")
    search = float(settings.get("search_pt", search_pt))
    if not math.isfinite(search) or search < 0 or search > 72:
        raise ValueError("search_pt must be between 0 and 72")
    guard = clearance_mm * _MM + width_pt / 2 + 0.5
    coordinates = []
    for axis, key, count_key, min_panel in ((0, "x", "columns", 90), (1, "y", "rows", 120)):
        internal = settings.get(key)
        if internal is None:
            count = settings.get(count_key)
            if count is None:
                if axis == 0:
                    bounds, internal = _infer_columns(body_lines, bounds, guard, search, 'bounds' not in settings)
                else:
                    bounds, internal = _infer_rows(body_lines, bounds, coordinates[0], guard, search, 'bounds' not in settings)
            else:
                internal = [bounds[axis] + (bounds[axis + 2] - bounds[axis]) * j / count
                            for j in range(1, count)]
        coordinates.append(internal)
    if not coordinates[0] and not explicit:
        raise ValueError("No confident column pattern; provide bounds/columns/x")
    lines = []
    for axis, internal in enumerate(coordinates):
        for coord, border in [(bounds[axis], True)] + [(v, False) for v in internal] + [(bounds[axis + 2], True)]:
            line = _safe_line(page, boxes, bounds, axis, coord, 0 if border else search,
                              clearance_mm * _MM, width_pt, dpi, 25)
            lines.append(line)
    _validate_geometry(lines, boxes, clearance_mm * _MM, width_pt)
    _validate_raster(page, lines, clearance_mm * _MM, width_pt, dpi)
    return lines


class GridLayoutWarning(UserWarning):
    """Logical cell boundaries include a separator interrupted around content."""


def _cell_bboxes(lines):
    """Use final separator centerlines, not the initial equally spaced guesses."""
    coordinates = []
    for axis in ("x", "y"):
        positions = [float(line["coordinate_pt"]) for line in lines if line["axis"] == axis]
        if len(positions) < 2 or any(not math.isfinite(v) for v in positions):
            raise ValueError("The grid must have at least two finite boundaries per axis")
        if any(b <= a for a, b in zip(positions, positions[1:])):
            raise ValueError("Adjusted grid boundaries overlap or cross; revise the layout or search range")
        coordinates.append(positions)
    x, y = coordinates
    return [[left, top, right, bottom]
            for top, bottom in zip(y, y[1:])
            for left, right in zip(x, x[1:])]


def _existing_grid_lines(page):
    """Read only this generator's named layer, ignoring other PDF table rules."""
    groups = {"x": {}, "y": {}}
    for drawing in page.get_drawings():
        if drawing.get("layer") != "Mapfold grid":
            continue
        for item in drawing["items"]:
            if item[0] != "l":
                continue
            p, q = item[1:3]
            if abs(p.x - q.x) < 1e-4 and abs(p.y - q.y) > 1e-4:
                axis, coord, segment = "x", float(p.x), sorted([float(p.y), float(q.y)])
            elif abs(p.y - q.y) < 1e-4 and abs(p.x - q.x) > 1e-4:
                axis, coord, segment = "y", float(p.y), sorted([float(p.x), float(q.x)])
            else:
                continue
            groups[axis].setdefault(coord, []).append(segment)
    if not groups["x"] and not groups["y"]:
        return []
    if len(groups["x"]) < 2 or len(groups["y"]) < 2:
        raise ValueError("Existing grid layer has incomplete outer boundaries")
    lines = []
    for axis in ("x", "y"):
        other = groups["y" if axis == "x" else "x"]
        low, high = min(other), max(other)
        for coord, segments in sorted(groups[axis].items()):
            merged = []
            for a, b in sorted(segments):
                a, b = max(low, a), min(high, b)
                if b <= a:
                    continue
                if merged and a <= merged[-1][1] + 1e-4:
                    merged[-1][1] = max(merged[-1][1], b)
                else:
                    merged.append([a, b])
            lines.append(dict(axis=axis, coordinate_pt=coord, segments_pt=merged,
                              omitted_length_pt=max(0.0, high-low-sum(b-a for a, b in merged))))
    return lines


def get_grid_bboxes(
    doc: fitz.Document,
    *,
    config: str | Path | dict | None = None,
    columns: int | None = None,
    rows: int | None = None,
    clearance_mm: float = 0.5,
    width_pt: float = 0.7,
    dpi: int = 300,
    search_pt: float = 9,
    strict: bool = False,
) -> dict[int, list[list[float]]]:
    """Return grid CELL bounding boxes from a caller-owned open PDF document.

    Example::

        import pymupdf as fitz
        from grid_ifu import get_grid_bboxes
        with fitz.open("leaflet.pdf") as doc:
            boxes = get_grid_bboxes(doc)
        # {0: [[x0, y0, x1, y1], ...], 1: [...], ...}

    Page keys are zero-based integers. Each box is [left, top, right, bottom]
    in PDF points (72 pt/inch), relative to the top-left of the UNROTATED
    visible page / CropBox. Values are floats and are not rounded. Cells are
    ordered row by row, left to right. Boxes use separator centerlines, not
    stroke extents, and are not tight bounding boxes of the enclosed text.

    For an original PDF, infer layout from its content and check clearance.
    No preset file, filename-specific layout or document-ID lookup is used
    by default. Repeated text gutters locate columns; broad gutters with
    text restarting across columns reveal unequal rows. Regular subdivisions
    remain a fallback for sparse panels. Artwork margins are inferred from
    the measured panel spacing. Optional config accepts only overrides you
    explicitly provide (a dict or JSON path). columns and rows
    override the configuration's corresponding count / explicit separators.

    For a PDF already generated by this script, read its 'Mapfold grid' layer
    directly. Layout overrides are rejected in this case: use the original
    PDF to compute a different layout. Only separators present in that layer
    can be recovered; completely omitted separators cannot be reconstructed.
    Existing grids are read as saved, without re-running the safety checks.

    Explicitly skipped pages, small appended sheets with sparse text and no
    column pattern, and pages with no grid in a generated PDF,
    return []. An original page whose layout cannot be inferred raises
    ValueError instead of silently returning an empty result. Clipped grids
    return logical rectangular cells and emit GridLayoutWarning: content can
    cross the omitted portions of their boundaries. strict=True rejects those
    grids with ValueError. Use these cells for layout, not as a guarantee that
    rectangular crops will never split content spanning multiple panels.

    The caller owns doc: this function never closes, saves, or modifies it.
    In-memory documents and unsaved edits are supported. Analysis uses a
    temporary in-memory copy to preserve the caller's page rotations, PDF
    objects, and dirty state, including renderer-induced changes. The copy
    reflects the current document, not the last saved version on disk.
    No output files are created.
    A non-Document argument raises TypeError. Closed, non-PDF, or still-locked
    documents raise ValueError, as do invalid options and failed checks.
    For an encrypted PDF, call doc.authenticate(password) before this function.
    Named and in-memory documents use the same automatic inference. Ambiguous
    layouts can still require explicit geometry; automatic inference is a
    heuristic, not a guarantee that every PDF's physical folds are recoverable.
    """
    if not isinstance(doc, fitz.Document):
        raise TypeError("doc must be an open fitz.Document; open it with fitz.open(pdfpath), then pass doc")
    if doc.is_closed:
        raise ValueError("doc is closed; pass an open PDF document")
    if not doc.is_pdf:
        raise ValueError("doc must be a PDF document")
    if doc.is_encrypted:
        raise ValueError("doc is locked; call doc.authenticate(password) before get_grid_bboxes(doc)")
    filename = Path(doc.name).name if doc.name else ""
    source_name = filename or "in-memory PDF"
    for name, value, limit in (("clearance_mm", clearance_mm, 20), ("width_pt", width_pt, 20)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= limit:
            raise ValueError(f"{name} must be a finite positive number no greater than {limit}")
    if isinstance(dpi, bool) or not isinstance(dpi, int) or not 150 <= dpi <= 1200:
        raise ValueError("dpi must be an integer between 150 and 1200")
    if isinstance(search_pt, bool) or not isinstance(search_pt, (int, float)) or not math.isfinite(search_pt) or not 0 <= search_pt <= 72:
        raise ValueError("search_pt must be between 0 and 72")
    for name, value in (("columns", columns), ("rows", rows)):
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 64):
            raise ValueError(f"{name} must be an integer between 1 and 64")
    if not isinstance(strict, bool):
        raise ValueError("strict must be a bool")
    if config is None:
        layouts = {}
    elif isinstance(config, (str, Path)):
        layouts = json.loads(Path(config).read_text(encoding="utf-8"))
    else:
        layouts = config
    if not isinstance(layouts, dict):
        raise ValueError("config must contain a JSON object / Python dict")
    result = {}
    if len(doc) == 0:
        return result
    # Rendering some PDFs dirties internal PDF objects even without explicit
    # edits. Analyze a snapshot of the caller's CURRENT document to isolate
    # these side effects and rotation normalization. Never close the caller.
    with fitz.open(stream=doc.tobytes(), filetype="pdf") as analysis_doc:
        generated = any(layer.get("name") == "Mapfold grid" for layer in analysis_doc.get_ocgs().values())
        largest_page = max(p.cropbox.get_area() for p in analysis_doc)
        if generated and (config is not None or columns is not None or rows is not None):
            raise ValueError("Existing grid layer found; use the original PDF to override its layout")
        for page in analysis_doc:
            index, rotation = page.number, page.rotation
            if rotation:
                page.set_rotation(0)
            try:
                if generated:
                    lines = _existing_grid_lines(page)
                    if not lines:
                        result[index] = []
                        continue
                else:
                    settings = _page_settings(layouts, filename, index + 1)
                    if settings.get("skip"):
                        result[index] = []
                        continue
                    for name, value, positions in (("columns", columns, "x"), ("rows", rows, "y")):
                        if value is not None:
                            settings[name] = value
                            settings.pop(positions, None)
                    # A small appended specification sheet is not a mapfold.
                    # Require both much smaller geometry and absence of a
                    # repeated column pattern; never use filenames or IDs.
                    if not settings and page.cropbox.get_area() < largest_page*.5:
                        _, small_lines = _text_geometry(page)
                        if len(small_lines) < 100:
                            _, small_columns = _infer_columns(small_lines, _default_bounds(page,width_pt),
                                clearance_mm*_MM+width_pt/2+.5, search_pt, True)
                            if not small_columns:
                                result[index] = []
                                continue
                    try:
                        lines = _detect_grid_lines(page, settings, clearance_mm, width_pt, dpi, search_pt)
                    except ValueError as exc:
                        raise ValueError(f"{source_name}, page {index + 1} (index {index}): {exc}") from exc
                clipped = any(line["omitted_length_pt"] > 0.01 for line in lines)
                if clipped:
                    message = (f"{source_name}, page {index + 1} (index {index}): grid separators are interrupted "
                               "around content; returned boxes are logical cells, and rectangular crops may split that content.")
                    if strict:
                        raise ValueError(message)
                    warnings.warn(message, GridLayoutWarning, stacklevel=2)
                result[index] = _cell_bboxes(lines)
            finally:
                if rotation:
                    page.set_rotation(rotation)
    return result
