import json
import re
import sys
import pandas as pd
from pathlib import Path
ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR))
from utils_ifu.utils import clean_non_arabic_newlines, parse_legends
from utils_ifu.processing import restructure_text
def fix_arabic_typos(llm_structured, text) -> str:
    prompt = f"""
    given an arabic text. your job is to correct all the typo, white spaces within characters and nothing else.
    if a text does not have any typos return the text as it is
    Fix the text if it has uncessary white spaces in the texts
    
    <text>
    {text}
    Return the results in a json format
    corrected: Corrected arabic text

            """
    
    try:
        response = llm_structured.invoke([prompt])
        output = json.loads(response.content)
        print(output)
        return output['corrected']
    except:
        print('error')

        return None


def translate_symbols(llm_structured, symbol_list, lang) -> str:
    prompt = f"""
    given to you a list of medical symbol list in english, your job is to translate these symbol names to the this language: {lang}
    
    <symbol_list>
    {symbol_list}
    </symbol_list>
    Return the results in a json format
    translated: translated symbol list

            """
    
    try:
        response = llm_structured.invoke([prompt])
        output = json.loads(response.content)
        print(output)
        return output['translated']
    except:
        return symbol_list

    

def translate_text(llm, content: str, target_lang: str) -> str:

    try:

        if target_lang == 'sr':

            target_lang = 'sr (latin)'     

        prompt = f"""

        Given to you are texts from Instruction for Use (IFU) medical manuals, 
        Your Task is to translate each and very, lines from english to {target_lang}:

                Task:

                Step 1: Translate the given text from english to {target_lang}, ensuring that 
                        the meaning (semantics) of the original text is preserved as closely as possible.
                Step 2: Do not translate any text containing "trademark symbols" (™ or ®). 
                        Keep these parts as is

                Step 3: If user inputs only symbols or numbers return as it is 

                Below is the text for translation:
                """
        
        response = llm.invoke([prompt, content])
        print(response.content)
        return response.content


    except:
        return ''



def scoring_(llm_structured, text1, text2) -> str:
    prompt = f"""

    
    You are given two text, your job is to provide a score between 1-5. 
    1-2 if the only difference are synonymn 
    3-4 if there are some minor semantic difference between the texts
    5 if there are some significant difference between the texts or if the two two texts are completely different 
    
    <text 1>
    {text1}

    <text 2>
    {text2}
    Return the results in a json format
        
    score:
    remark: give a short and concise discription in english of the differences
    category: categorise the difference in one word, Eg: missing words, semantic inconsistency ...

            """
    
    try:
        response = llm_structured.invoke([prompt])
        output = json.loads(response.content)
        return output['score'], output['remark'], output["category"]
    except:

        return None
    

def safe_scoring(llm_structured,row):
    try:
        score, remark, category = scoring_(llm_structured,row['translated'],row['vendor'])
        return pd.Series([score, remark, category])
    except:
        return pd.Series(["", ""])  # Return empty strings if error
    
def generate_translations(data_json, llm):
    
    translated_json = {}
    mapper_en_translated = {}

    # Restructure English text into line-separated format
    english_restructured = restructure_text(data_json['en']['text'])

    # Iterate through all target languages (excluding 'en' and 'misc')
    for to_lan in data_json.keys():
        if to_lan in ['en', 'misc']:
            continue

        # Prepare dataframe with original and translated text
        df_translated = pd.DataFrame(english_restructured.splitlines(), columns=['original'])
        df_translated['translated'] = df_translated['original'].apply(
            lambda text: translate_text(llm, text, to_lan)
        )

        # Store mapping
        mapper_en_translated[to_lan] = df_translated

        # Collect vendor and AI translations
        translated_texts = df_translated['translated'].tolist()
        if to_lan not in translated_json:
            translated_json[to_lan] = {"original":"", "vendor": "", "ai": ""}

        # Concatenate vendor and AI results (ensure they are strings)
        translated_json[to_lan]['original'] += english_restructured
        if to_lan == 'ar':
            translated_json[to_lan]['vendor'] += restructure_text(data_json[to_lan]['text'],'ar')
        else:
            translated_json[to_lan]['vendor'] += restructure_text(data_json[to_lan]['text'])
        translated_json[to_lan]['ai'] += "\n".join(translated_texts)

    return translated_json, mapper_en_translated

def restructure_arabic(text,llm_structured):
    arabic_pattern = re.compile(r'[\u0600-\u06FF]')

    segments = text.split(' / ')
    processed_segments = []

    for segment in segments:
        if '-ar' in segment:
            if arabic_pattern.search(segment):
            # clean_segment = segment.replace('-ar', '')
                arabic_split = segment.split('-ar')
                corrected_substring = ''
                for sub_text in arabic_split[1].split("\n"):
                    corrected_substring += sub_text[::-1]
                corrected_substring = corrected_substring.strip()
                full_corrected_text = arabic_split[0][::-1] + ' '+ corrected_substring
                full_corrected_text = fix_arabic_typos(llm_structured, full_corrected_text)
                

            else:
                full_corrected_text = segment.replace("-ar","")

            fixed_segment = f"ar-{full_corrected_text.strip()}"

            processed_segments.append(fixed_segment)
        else:
            processed_segments.append(segment)  


    return ' / '.join(processed_segments)      




def parse_table_grid(df, llm_structured):
    ISO_639_1 = [
    "aa","ab","ae","af","ak","am","an","ar","as","av","ay","az","ba","be",
    "bg","bh","bi","bm","bn","bo","br","bs","ca","ce","ch","co","cr","cs",
    "cu","cv","cy","da","de","dv","dz","ee","el","en","eo","es","et","eu",
    "fa","ff","fi","fj","fo","fr","fy","ga","gd","gl","gn","gu","gv","ha",
    "he","hi","ho","hr","ht","hu","hy","hz","ia","id","ie","ig","ii","ik",
    "io","is","it","iu","ja","jv","ka","kg","ki","kj","kk","kl","km","kn",
    "ko","kr","ks","ku","kv","kw","ky","la","lb","lg","li","ln","lo","lt",
    "lu","lv","mg","mh","mi","mk","ml","mn","mr","ms","mt","my","na","nb",
    "nd","ne","ng","nl","nn","no","nr","nv","ny","oc","oj","om","or","os",
    "pa","pi","pl","ps","pt","qu","rm","rn","ro","ru","rw","sa","sc","sd",
    "se","sg","si","sk","sl","sm","sn","so","sq","sr","ss","st","su","sv",
    "sw","ta","te","tg","th","ti","tk","tl","tn","to","tr","ts","tt","tw",
    "ty","ug","uk","ur","uz","ve","vi","vo","wa","wo","xh","yi","yo","za",
    "zh","zu","zh-ch","zh-tk"
    ]
    LANGS = "(?:" + "|".join(ISO_639_1) + ")"
    target = "CONTROL RELEASE™"

    try:
    
        df = df["table"]
        df = df.dropna(axis=1)
        df.loc[-1] = df.columns
        df = df.iloc[:,:2]
        df.index = df.index + 1
        df = df.sort_index().reset_index(drop=True)
        df.columns = ['symbol', 'description']
        
        values = df['description'].values

        text = values[0]

        # 3. Iterate through the remaining items
        for item in values[1:]:
            # Check if the current item starts with 2 characters followed by a hyphen
            # r'^\w{2}-' matches "01-", "AA-", "1b-", etc.
            if re.match(r'^\w{2}-', item):
                separator = ' / '
            else:
                separator = ' '
            
            # Append the separator and the item
            text += separator + item
        text = clean_non_arabic_newlines(text)

        pattern = rf"(?<!/)\s+(?={LANGS}(?:-[a-z]{{2}})?-)"
        text = re.sub(pattern, " / ", text)
        pattern = r'(zh-tw-[^\u0600-\u06FF]*?)\s+(?=[\u0600-\u06FF])'
        text = re.sub(pattern, r"\1 / ", text)
        pattern = r'(?<=[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF])ar(?=[\s/])'
        text = re.sub(pattern, '-ar', text)

        text = text.replace("/ /", "/")

        processed_string = restructure_arabic(text, llm_structured)
        
        if processed_string.count(target) == 1:
            processed_string = processed_string.replace(target, "")
            result = parse_legends(processed_string, target)

        else:
            result = parse_legends(processed_string)
        return result
    except:
        return None

def parse_legends_booklet(llm, TEXTS, CODES):
        prompt = f'''
            # Role
            You are a precise multilingual text-segmentation engine. You do NOT translate, rewrite,
            summarize, correct, reorder, or add to any text. You only split a block of concatenated
            translations into per-language segments and normalize whitespace.

            # Inputs
            1. TEXTS — a JSON array of strings. Each string contains the SAME underlying message
            rendered consecutively in several languages, stacked one after another and separated
            only by line breaks (\n). There is NO explicit marker between languages. One language's
            segment may span one or several lines; line breaks inside a segment are arbitrary
            hard-wraps, not boundaries.
            2. CODES — a single flat, ORDERED JSON array of language codes (e.g. "en", "fr",
            "zh-hans"). This list covers ALL of TEXTS combined, in reading order. The languages
            appear in the texts in exactly this order.

            # Mapping codes to texts
            - Treat CODES as ONE continuous queue.
            - Process the strings in TEXTS in order. Walk through the first string, identify each
            language segment in turn, and assign them CODES[0], CODES[1], ... Keep consuming from the
            same queue as you move into the next string, and so on, until every code is used.
            - The number of segments per string is NOT given — you must detect it. The total number of
            segments across all strings MUST equal len(CODES). If it does not, re-examine your
            segmentation before answering.

            # Finding segment boundaries
            - Every segment expresses the same message; a new segment begins where that message starts
            over from its beginning.
            - Use the ordered CODES as a guide: you always know the current language and the next one. A
            new segment starts at the first line that matches the NEXT expected code and no longer
            matches the current one. All earlier lines belong to the current segment.
            - Do NOT split by line count or sentence count — segment lengths vary.
            - For mutually intelligible or same-script neighbors (e.g. Serbian/Montenegrin/Croatian/
            Bosnian, Norwegian/Danish, Czech/Slovak), do NOT try to tell them apart by language alone.
            Rely on their fixed position in CODES; each occupies exactly one consecutive segment.

            # Cleaning each segment
            Produce a single-line string per segment:
            - Replace every internal line break with one regular space.
            - Collapse any run of spaces/tabs/newlines into a single space; trim the ends.
            - Otherwise preserve the text EXACTLY: keep all diacritics, punctuation, casing, and special
            characters such as soft hyphens (U+00AD) and narrow no-break spaces (U+202F). Do not "fix"
            spelling, hyphenation, or spacing inside words.

            # Output
            Return ONLY a JSON array — no prose, no markdown fences, no commentary. One object per input
            string (same order as TEXTS). Each object maps language code -> cleaned segment string, with
            keys in the order the codes were consumed. If a code genuinely has no matching segment, give
            it null rather than merging two languages into one value.

            # Example
            TEXTS:
            [
            "Hello world.\nThis is a test.\nBonjour le monde.\nCeci est un test.",
            "Hallo Welt.\nDies ist ein Test."
            ]
            CODES:
            ["en", "fr", "de"]

            OUTPUT:
            [
            dict("en": "Hello world. This is a test.", "fr": "Bonjour le monde. Ceci est un test."),
            dict()"de": "Hallo Welt. Dies ist ein Test.")
            ]

            # Now do the task
            TEXTS:
            {TEXTS}
            CODES:
            {CODES}
            '''
        
        last_error = None
        max_retries= 3
        for attempt in range(1, max_retries + 1):
            try:
                response = llm.invoke([prompt])
                content = response.content.strip()

                # strip ```json ... ``` or ``` ... ``` fences if the model added them
                content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content).strip()

                return json.loads(content)

            except json.JSONDecodeError as e:
                last_error = e
                print(f"[parse_legends_booklet] JSON parse failed on attempt {attempt}/{max_retries}: {e}")

        # all retries exhausted
        raise ValueError(
            f"Failed to parse valid JSON after {max_retries} attempts"
        ) from last_error

        # response = llm.invoke([prompt])
        # # print(response.content)
        # return json.loads(response.content)
def remove_footer(llm, content):

    try:

        prompt = f"""

                # ROLE
                You clean PDF extracted text of medical device Instructions for Use (IFU).
                Your only job is to delete page-level boilerplate. Everything else must survive
                byte-for-byte.

                # REMOVE — all occurrences, anywhere in the document
                1. Page markers standing on their own line: "1", "2", "3 of 7", "2 of 65", "Page 4", etc.
                2. The e-IFU validity notice, in full, including its line breaks:
                "The user must ensure that the latest version of the IFU is being used (which
                may be found at www.e-ifu.com). The IFU is only considered valid for the date
                when the document was initially opened or printed (whichever occurred first)."
                Delete it even if it is line-wrapped differently, hyphenated across lines,
                truncated, or the URL/wording varies slightly.
                3. Print/export timestamps on their own line: "2026-07-02 16:52:49", bare dates,
                bare times — any stamp that is not part of a sentence.
                4. Any other per-page running header/footer artifact: repeated document codes,
                revision numbers, repeated copyright lines, repeated company footers.
                5. remove texts of these type "Urinary Placement Catheter Clean copy IFU 4/30/2024"

                Test to apply: a line is boilerplate only if it would appear on every page
                regardless of that page's content. If in doubt, KEEP IT.

                # WHITESPACE
                Where a boilerplate block is removed, collapse the gap to a single blank line so
                the surrounding paragraph spacing matches the rest of the document. Do not rejoin
                sentences or paragraphs that were split across the page break — leave the split
                exactly as it is.

                # PRESERVE EXACTLY — do not touch
                - Every heading and section title (DESCRIPTION, WARNINGS, PRECAUTIONS, etc.)
                - Table captions ("Table 1. Diameter Comparison") and figure labels, including
                loose callout words scattered around a figure ("Green", "Stylet", "Exit Port")
                - All line breaks and mid-word hyphenation as they appear in the input
                (e.g. "non-\nabsorbable" stays broken)
                - All typos, misspellings and OCR errors — "sterle", "WANINGS", "intravescal",
                "Placemnt", "PRONOVATM". Do NOT correct them.
                - Trademark/superscript renderings, symbols, units, spacing
                - Numbered and bulleted list markers, plus their original indentation/padding
                - URLs that are part of body content (e.g. the EUDAMED link)
                - The two-letter language code line ("en")
                - The full SYMBOLS USED ON LABELING list

                # DO NOT
                Summarize, paraphrase, reorder, translate, correct, reformat, add markdown,
                add headings, add commentary, or truncate. Do not wrap the result in code fences.

                # OUTPUT
                The cleaned document text only, from first surviving line to last.

                <text>
                {content}
                </text>

            """
        
        response = llm.invoke([prompt, content])
        print(response.content)
        return response.content


    except:
        return content