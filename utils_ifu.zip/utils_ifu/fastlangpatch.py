import numpy as np
from contextlib import contextmanager
from fastlangid.langid import LID


@contextmanager
def numpy_patch():
    """Temporarily fixes NumPy 2.0 compatibility for fasttext."""
    original_array = np.array
    
    def _patched_array(*args, **kwargs):
        # If 'copy=False' is passed, we strip it to prevent the crash
        if kwargs.get('copy') is False:
            kwargs.pop('copy')
            return np.asarray(*args, **kwargs)
        return original_array(*args, **kwargs)
    
    # Apply the patch
    np.array = _patched_array
    try:
        yield
    finally:
        # Restore the original version immediately after use
        np.array = original_array
class IsolatedLID:
    def __init__(self):
        # We only patch during the 'init' phase where fasttext loads models
        with numpy_patch():
            self.model = LID()

    def predict(self, text):
        # We patch during prediction in case the model triggers np.array internally
        with numpy_patch():
            return self.model.predict(text)
