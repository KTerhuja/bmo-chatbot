import pandas as pd
import re
def compare_texts(original,vendor, translated):

    
    # def count_paragraphs(text):
    #     return text.count('\n\n') + 1 if text.strip() else 0

    def count_trademark_words(text):
        return sum(1 for word in text.split() if '™' in word)

    # Define a helper function to count bullet points
    def count_bullet_points(text):
        # Considering bullet points start with specific characters like '-', '*', etc.
        lines = text.split('\n')
        return sum(1 for line in lines if line.strip().startswith(('•',"")))

    # Define a helper function to count hyperlinks
    def count_hyperlinks(text):
        # Using regex to find URLs
        pattern = r'https?://[^\s]+'
        return len(re.findall(pattern, text))

    # Define a helper function to count each special symbol
    def count_special_symbol(text, symbol):
        return text.count(symbol)

    special_symbols = [
            "!", "@", "#", "$", "%", "^", "&", "*", "(", ")",
            "-", "—", "_", "=", "+", "[", "]", "{", "}", "\\",
            "|", ";", ":", "'", '"', ",", ".", "<", ">", "/",
            "?", "`", "~", "...", "©", "®", "™", "°", "€", "£",
            "¥", "¢", "±", "+/-", "×", "÷", "§", "¶", "•",
            "→", "←", "↑", "↓", "✓", "α", "β", "γ", "μ",
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
            "∞", "´", "ç", "Ç", "ª",
        ]

    text1 = original
    text_vendor = vendor
    text2 = translated

    # Count features for text1
    # paragraphs1 = count_paragraphs(text1)
    trademark_words1 = count_trademark_words(text1)
    bullet_points1 = count_bullet_points(text1)
    hyperlinks1 = count_hyperlinks(text1)
    special_symbols1 = [count_special_symbol(text1, char) for char in special_symbols]

    # paragraphs_vendor = count_paragraphs(text_vendor)
    trademark_words_vendor = count_trademark_words(text_vendor)
    bullet_points_vendor = count_bullet_points(text_vendor)
    hyperlinks_vendor = count_hyperlinks(text_vendor)
    special_symbols_vendor = [count_special_symbol(text_vendor, char) for char in special_symbols]

    # Count features for text2
    # paragraphs2 = count_paragraphs(text2)
    trademark_words2 = count_trademark_words(text2)
    bullet_points2 = count_bullet_points(text2)
    hyperlinks2 = count_hyperlinks(text2)
    special_symbols2 = [count_special_symbol(text2, char) for char in special_symbols]


    data = {
        'Original': [
             trademark_words1, bullet_points1, hyperlinks1, 
            *special_symbols1
        ],
        'Transtaled Vendor': [
             trademark_words_vendor, bullet_points_vendor, hyperlinks_vendor, 
            *special_symbols_vendor
        ],

        'Translated GPT': [
             trademark_words2, bullet_points2, hyperlinks2, 
            *special_symbols2
        ]
    }

    # Define the row names (criteria)
    index = [
        'Trademark Words', 'Bullet Points', 'Hyperlinks', 
        *special_symbols
    ]

    # Create the DataFrame
    df = pd.DataFrame(data, index=index)

    return df


def create_difference_report(df_orig, df_vendor):
    """
    Compares two dataframes by position. 
    Returns a report of numeric differences only.
    """
    diff_data = []

    # Iterate through rows and columns by index
    rows = min(df_orig.shape[0], df_vendor.shape[0])
    for row in range(rows):
        for col in range(df_orig.shape[1]):
            val1 = df_orig.iloc[row, col]
            val2 = df_vendor.iloc[row, col]

            # Convert to string and handle comma decimals (e.g., '1,5' -> '1.5')
            str_val1 = str(val1).replace(',', '.')
            str_val2 = str(val2).replace(',', '.')

            try:
                # Attempt to convert both to floats
                num1 = float(str_val1)
                num2 = float(str_val2)

                # If both are numeric, check for difference
                if num1 != num2:
                    diff_data.append({
                        'Column_Name': df_orig.columns[col],
                        'Original_Value': num1,
                        'Vendor_Value': num2,
                        
                    })
            except ValueError:
                continue

    return pd.DataFrame(diff_data)


# def create_difference_report_ifu_comp(df_orig, df_vendor, blank_repeats=True):
#     def to_number(val):
#         try:
#             return float(str(val).strip().replace(',', '.'))
#         except (ValueError, AttributeError):
#             return None

#     original_index = list(df_orig.index)
#     max_rows = max(df_orig.shape[0], df_vendor.shape[0])

#     def pad_with_empty_rows(df, target_rows):
#         if df.shape[0] < target_rows:
#             n_missing = target_rows - df.shape[0]
#             padding = pd.DataFrame('', index=range(n_missing), columns=df.columns)
#             df = pd.concat([df, padding], ignore_index=True)
#         return df

#     df_orig = pad_with_empty_rows(df_orig, max_rows)
#     df_vendor = pad_with_empty_rows(df_vendor, max_rows)
#     if len(original_index) < max_rows:
#         original_index += list(range(len(original_index), max_rows))

#     records, row_labels = [], []
#     for row in range(max_rows):
#         for col in range(df_orig.shape[1]):
#             val1 = df_orig.iloc[row, col]
#             val2 = df_vendor.iloc[row, col]
#             n1, n2 = to_number(val1), to_number(val2)

#             if n1 is not None and n2 is not None:
#                 dev = n1 - n2
#                 is_match = dev == 0
#                 deviation = '' if is_match else round(dev, 10)
#             else:
#                 is_match = val1 == val2
#                 deviation = ''

#             records.append({
#                 'row': original_index[row],
#                 'current': val1,
#                 'future': val2,
#                 'deviation': deviation,
#                 'Comparison Status': 'Match' if is_match else 'No Match',
#             })
#             # label shown once per original row, blank on the repeats
#             show_label = (col == 0) or not blank_repeats
#             row_labels.append(original_index[row] if show_label else '')

#     return pd.DataFrame(records, index=pd.Index(row_labels, name='row'))






def _canonical(text, decimal_separator_equivalent=True):
    """
    Key used for equality only -- never for display.

    With decimal_separator_equivalent=True, '1.2' and '1,2' collapse to the same
    key, so they compare as equal. Works on numbers embedded in longer strings
    too, e.g. '0,049mm' == '0.049mm'.
    """
    _DECIMAL_SEP = re.compile(r"(?<=\d)[.,](?=\d)")
    if not decimal_separator_equivalent:
        return text
    return _DECIMAL_SEP.sub(".", text)


def _fmt(value):
    """Render a single cell as the report displays it."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    # 1.0 -> "1", but 1.5 stays "1.5"
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _row_cells(row):
    return [_fmt(v) for v in row]


def _join(cells):
    return ", ".join(cells)


def _describe(current_cells, future_cells, decimal_separator_equivalent=True):
    """Return (deviation_text, status) for one aligned row."""
    if current_cells is None:
        return "Row present in future only (added)", "No Match"
    if future_cells is None:
        return "Row present in current only (removed)", "No Match"

    notes = []
    width = max(len(current_cells), len(future_cells))
    for i in range(width):
        cur = current_cells[i] if i < len(current_cells) else None
        fut = future_cells[i] if i < len(future_cells) else None

        if cur is None:
            notes.append(f"New value '{fut}' added in future")
        elif fut is None:
            notes.append(f"Value '{cur}' removed in future")
        elif _canonical(cur, decimal_separator_equivalent) != _canonical(
            fut, decimal_separator_equivalent
        ):
            notes.append(f"Current value of {cur} changed to {fut} in future")

    if not notes:
        return "None", "Match"
    return "; ".join(notes), "No Match"


def create_difference_report_ifu_comp(
    current,
    future,
    element_type="Tabular",
    compare_headers=True,
    spell_check=None,
    decimal_separator_equivalent=True,
):
    """
    Build the comparison report.

    current, future : pandas DataFrames to compare
    element_type    : label for the "Element Type" column
    compare_headers : if True, row 0 compares column names and data starts at row 1
    spell_check     : optional callable(future_cells: list[str]) -> str,
                      whatever it returns lands in the "Spell Check" column
    decimal_separator_equivalent :
                      if True, '1.2' and '1,2' are treated as the same value
                      (see _canonical for the caveat on thousands separators)
    """
    records = []

    def add(row_no, cur_cells, fut_cells):
        deviation, status = _describe(
            cur_cells, fut_cells, decimal_separator_equivalent
        )
        note = ""
        if spell_check is not None and fut_cells is not None:
            note = spell_check(fut_cells) or ""
        records.append(
            {
                "Element Type": element_type,
                "Row No.": row_no,
                "Current": _join(cur_cells) if cur_cells is not None else "",
                "Future": _join(fut_cells) if fut_cells is not None else "",
                "Deviation": deviation,
                "Comparison Status": status,
                "Spell Check": note,
            }
        )
    REPORT_COLUMNS = [
                    "Element Type",
                    "Row No.",
                    "Current",
                    "Future",
                    "Deviation",
                    "Comparison Status",
                    "Spell Check",
                ]
    offset = 0
    if compare_headers:
        add(0, [_fmt(c) for c in current.columns], [_fmt(c) for c in future.columns])
        offset = 1

    cur_rows = current.astype(object).values.tolist()
    fut_rows = future.astype(object).values.tolist()

    for i in range(max(len(cur_rows), len(fut_rows))):
        cur_cells = _row_cells(cur_rows[i]) if i < len(cur_rows) else None
        fut_cells = _row_cells(fut_rows[i]) if i < len(fut_rows) else None
        add(i + offset, cur_cells, fut_cells)

    return pd.DataFrame(records, columns=REPORT_COLUMNS)
