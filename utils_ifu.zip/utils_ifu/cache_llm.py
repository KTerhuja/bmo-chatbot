import functools, hashlib, json, os, pickle
from pathlib import Path

CACHE_DIR = Path(__file__).parent / ".llm_cache"
CACHE_DIR.mkdir(exist_ok=True)
ENABLED = os.getenv("LLM_CACHE", "on") != "off"

def _key(name, args, kwargs):
    blob = json.dumps([name, args, kwargs], sort_keys=True, default=str).encode()
    return hashlib.sha256(blob).hexdigest()

class CachedLLM:
    def __init__(self, inner, name):
        self._inner, self._name = inner, name

    def __getattr__(self, attr):
        target = getattr(self._inner, attr)
        if not callable(target) or not ENABLED:
            return target

        @functools.wraps(target)
        def wrapped(*args, **kwargs):
            path = CACHE_DIR / f"{_key(f'{self._name}.{attr}', args, kwargs)}.pkl"
            if path.exists():
                return pickle.loads(path.read_bytes())
            out = target(*args, **kwargs)
            path.write_bytes(pickle.dumps(out))
            return out
        return wrapped