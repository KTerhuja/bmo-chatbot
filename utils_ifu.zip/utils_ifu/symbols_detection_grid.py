"""Locate symbol legends inside existing mapfold grid cells (native PDFs)."""
from __future__ import annotations

import math
import re
import statistics
import pymupdf as fitz
import sys
import os
from pathlib import Path
ROOT_DIR = Path(__file__).parent.parent.absolute()
sys.path.append(str(ROOT_DIR))
from utils_ifu.ifu_grids import get_grid_bboxes

__all__ = ["get_symbol_legend_bboxes", "highlight_symbol_legends"]

_LAYERS = {"Mapfold grid", "Symbol legend highlights"}
_SYMBOL = re.compile(r"^(?:LOT|REF|UDI|MD|STERILE|EC\s*REP|CH\s*REP|CR/X|MS/X)$", re.I)


def _inside(box, region):
    return region.contains((box.tl + box.br) / 2)


def _components(rects, tolerance=0.6):
    """Join nearby pieces of an outlined icon without joining adjacent rows."""
    groups = []
    for rect, ink in sorted(rects, key=lambda r: r[0].y0):
        joined = []
        for i, (other, weight) in enumerate(groups):
            if (rect + (-tolerance, -tolerance, tolerance, tolerance)).intersects(other):
                rect = rect | other
                ink += weight
                joined.append(i)
        for i in reversed(joined):
            groups.pop(i)
        groups.append((rect, ink))
    return groups


def _page_features(page):
    words = [(fitz.Rect(w[:4]), w[4]) for w in page.get_text("words") if w[4].strip()]
    drawings = [d for d in page.get_drawings() if d.get("layer") not in _LAYERS]
    images = [fitz.Rect(im["bbox"]) for im in page.get_image_info()]
    return words, drawings, images


def _cell_evidence(cell, features):
    words, drawings, images = features
    words = [(r, t) for r, t in words if _inside(r, cell)]
    if not words:
        return []
    height = statistics.median(r.height for r, t in words)
    max_height = max(22, 5 * height)
    max_width = min(cell.width * .42, 10 * height)
    parts, verticals, horizontals = [], [], []
    for d in drawings:
        r = d["rect"]
        if not r.intersects(cell) and not _inside(r, cell):
            continue
        fill = d.get("fill")
        color = d.get("color")
        if (fill is None or min(fill) > .93) and (color is None or min(color) > .93):
            continue
        # Table rules are recorded independently of icon paths.
        for item in (d["items"] if len(d["items"]) <= 8 else []):
            edges = []
            if item[0] == "l":
                edges = [(item[1], item[2])]
            elif item[0] == "re":
                q = item[1]
                edges = [(q.tl, q.tr), (q.tr, q.br), (q.br, q.bl), (q.bl, q.tl)]
            for a, b in edges:
                if abs(a.x-b.x) < .15 and abs(a.y-b.y) >= 5:
                    verticals.append((a.x, min(a.y,b.y), max(a.y,b.y)))
                elif abs(a.y-b.y) < .15 and abs(a.x-b.x) >= 5:
                    horizontals.append((a.y, min(a.x,b.x), max(a.x,b.x)))
        if not (.15 < r.width <= max_width and .15 < r.height <= max_height and _inside(r, cell)):
            continue
        weight = len(d["items"]) if any(i[0] != "re" for i in d["items"]) else 0
        parts.append((r, weight))
    for r in images:
        if _inside(r, cell) and 2 < r.width <= max_width and 2 < r.height <= max_height:
            parts.append((r, 10))
    for r, t in words:
        if _SYMBOL.fullmatch(t):
            parts.append((r, 10))
    icons = [(r,n) for r,n in _components(parts) if n >= 3 and r.width >= 2 and r.height >= 2
             and r.width <= max_width and r.height <= max_height]
    # Remove outlines of ordinary text; some PDFs contain both outlines and
    # an invisible text layer for the same heading.
    icons = [(r,n) for r,n in icons if not any(
        not _SYMBOL.fullmatch(t) and (r & w).get_area() > .65*r.get_area()
        for w,t in words)]
    pairs = []
    for r,n in icons:
        cy = (r.y0+r.y1)/2
        for side in ("right", "left"):
            nearby = [(w,t) for w,t in words if w.y0-height*.25 <= cy <= w.y1+height*.25
                      and ((.4 <= w.x0-r.x1 <= cell.width*.65) if side=="right"
                           else (.4 <= r.x0-w.x1 <= cell.width*.65))]
            if not nearby:
                continue
            nearby.sort(key=lambda wt: wt[0].x0)
            # At least one genuine word/description, not a dimension or callout.
            if sum(sum(ch.isalpha() for ch in t) for _,t in nearby) < 3:
                continue
            edge = min(w.x0 for w,t in nearby) if side=="right" else max(w.x1 for w,t in nearby)
            pairs.append((r, side, edge))
    reasons = []
    # Repeated aligned icon + description rows support borderless legends and
    # table bodies. Alignment works with symbols on either side of the text.
    for r,side,edge in pairs:
        aligned = [q for q,s,e in pairs if s==side and abs(e-edge) <= max(3,height*.6)
                   and (min(q.x1,r.x1)-max(q.x0,r.x0) > 0)]
        ys = []
        for q in sorted(aligned, key=lambda q:q.y0):
            cy = (q.y0+q.y1)/2
            if not ys or cy-ys[-1] > height*.8:
                ys.append(cy)
        if len(ys) >= 3 and statistics.median(b-a for a,b in zip(ys,ys[1:])) <= 4*height:
            reasons.append("repeated aligned symbol-description rows")
            break
    # Single-row continuations need a ruled symbol column next to a wider
    # text column; mentioning a symbol in prose is insufficient.
    for r,n in icons:
        left = [v for v in verticals if r.x0- max_width <= v[0] < r.x0-.3 and v[1] <= r.y0+1 and v[2] >= r.y1-1]
        right = [v for v in verticals if r.x1+.3 < v[0] <= r.x1+max_width and v[1] <= r.y0+1 and v[2] >= r.y1-1]
        if not left or not right:
            continue
        l, m = max(left), min(right)
        top, bottom = max(l[1],m[1]), min(l[2],m[2])
        if m[0]-l[0] > max_width or bottom-top < r.height:
            continue
        for direction in (1, -1):
            outer = [v for v in verticals if (v[0]-m[0] if direction==1 else l[0]-v[0]) >= (m[0]-l[0])*1.25
                     and v[1] <= top+1 and v[2] >= bottom-1]
            if not outer:
                continue
            v = min(outer, key=lambda v: abs(v[0]-(m[0] if direction==1 else l[0])))
            x0,x1 = (l[0],v[0]) if direction==1 else (v[0],m[0])
            def has_rule(y):
                runs = sorted((a,b) for yy,a,b in horizontals if abs(yy-y)<1)
                end = x0
                for a,b in runs:
                    if a <= end+1 and b > end:
                        end = b
                return end >= x1-1
            if not (has_rule(top) and has_rule(bottom)):
                continue
            region = fitz.Rect(m[0] if direction==1 else v[0], top,
                               v[0] if direction==1 else l[0], bottom)
            text = " ".join(t for w,t in words if _inside(w,region))
            if sum(ch.isalpha() for ch in text) >= 15:
                reasons.append("ruled symbol column paired with a description")
                return sorted(set(reasons))
    return sorted(set(reasons))


def _validate(doc, grids):
    if not isinstance(doc, fitz.Document):
        raise TypeError("doc must be an open fitz.Document")
    if doc.is_closed or not doc.is_pdf or doc.is_encrypted:
        raise ValueError("doc must be an open, unlocked PDF")
    if grids is None:
        return get_grid_bboxes(doc)
    if not isinstance(grids, dict):
        raise TypeError("grid_bboxes must be a dictionary keyed by zero-based page index")
    result = {i: [] for i in range(len(doc))}
    for page, boxes in grids.items():
        if type(page) is not int or not 0 <= page < len(doc):
            raise ValueError("grid_bboxes contains an invalid page index")
        bounds = doc[page].rect * doc[page].derotation_matrix
        for box in boxes:
            if len(box) != 4 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in box):
                raise ValueError("Each bbox must contain four finite coordinates")
            r = fitz.Rect(box)
            if r.is_empty or not (bounds+(-.1,-.1,.1,.1)).contains(r):
                raise ValueError("Each bbox must be a valid rectangle inside the unrotated page")
            result[page].append(list(map(float,box)))
    return result


def get_symbol_legend_bboxes(doc, grid_bboxes=None, *, details=False):
    """Return grid cells containing symbol legends, keyed by zero-based page.

    Pass the result of get_grid_bboxes(doc) to avoid recomputing the grid.
    Boxes are [x0,y0,x1,y1], in unrotated CropBox-relative PDF points, and
    retain input cell order. Empty/skipped pages return []. details=True
    returns dictionaries with bbox, grid_index and detection reasons instead.

    Uses native vector/image geometry plus searchable text, supporting ruled
    tables, borderless LTR/RTL lists and one-row continuations. Image-only
    pages need OCR first and raise ValueError rather than silently returning
    no matches. Heuristic detection should be reviewed on new PDF families.
    The input document is never modified, saved or closed.
    """
    grids = _validate(doc, grid_bboxes)
    result = {i: [] for i in range(len(doc))}
    if not len(doc):
        return result
    with fitz.open(stream=doc.tobytes(), filetype="pdf") as copy:
        for p in copy:
            if not grids[p.number]:
                continue
            p.set_rotation(0)
            features = _page_features(p)
            if not features[0] and features[2]:
                raise ValueError(f"Page {p.number}: image-only page needs OCR before legend detection")
            for i, box in enumerate(grids[p.number]):
                reasons = _cell_evidence(fitz.Rect(box), features)
                if reasons:
                    result[p.number].append(dict(bbox=box, grid_index=i, reasons=reasons) if details else box)
    return result


def highlight_symbol_legends(doc, grid_bboxes=None, *, opacity=0.16):
    """Return a NEW PDF document with detected grid cells shaded green.

    The caller owns and must close the returned document. Source doc stays
    untouched. A toggleable 'Symbol legend highlights' layer contains the
    translucent fills; no new rules are drawn across text. Save the result
    using highlighted.save('output.pdf').
    """
    if isinstance(opacity,bool) or not isinstance(opacity,(int,float)) or not 0 < opacity <= 1:
        raise ValueError("opacity must be between 0 (exclusive) and 1")
    matches = get_symbol_legend_bboxes(doc,grid_bboxes)
    if not len(doc):
        return fitz.open()
    output = fitz.open(stream=doc.tobytes(),filetype="pdf")
    try:
        layer = output.add_ocg("Symbol legend highlights")
        for index, boxes in matches.items():
            page = output[index]
            rotation = page.rotation
            page.set_rotation(0)
            try:
                for box in boxes:
                    page.draw_rect(fitz.Rect(box),color=None,fill=(0,0.8,0.2),
                                   fill_opacity=opacity,overlay=True,oc=layer)
            finally:
                page.set_rotation(rotation)
        return output
    except Exception:
        output.close()
        raise
