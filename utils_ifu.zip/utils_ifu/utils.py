import unicodedata
import re
import base64
import numpy as np
import cv2
import fitz
from utils.blob_storage import read_pdf, read_file
from collections import Counter
from rapidfuzz import process, fuzz
import pandas as pd
from io import BytesIO
from utils.aspose_words import docx_to_pdf
from pathlib import Path
def filter_detections(detections, legends):
    """
    Filters detections based on the condition: 
    abs(x0 - 4 * x_legends0) < 300 for at least one legend.
    """
    filtered_list = []
    
    for det in detections:
        # Extract x0 from the detection box
        x0 = det['bbox'][0]
        
        match_found = any(abs(x0 - 4 * legend[0]) < 300 for legend in legends)
        
        if match_found:
            filtered_list.append(det)
            
    return filtered_list


def is_bbox_contained(inner_bbox, outer_bbox, tolerance=5):
    """
    Check if inner_bbox is contained inside outer_bbox, allowing a small
    overflow on each side defined by `tolerance` (in the same units as the bbox).
    """
    ix_min, iy_min, ix_max, iy_max = inner_bbox
    ox_min, oy_min, ox_max, oy_max = outer_bbox

    return (
        ix_min >= ox_min - tolerance and
        iy_min >= oy_min - tolerance and
        ix_max <= ox_max + tolerance and
        iy_max <= oy_max + tolerance
    )

def np_array_to_base64(img_array, image_format='.png'):
    # Encode image to memory buffer
    success, buffer = cv2.imencode(image_format, img_array)
    if not success:
        raise ValueError("Could not encode image.")
    
    # Convert to base64 string
    base64_str = base64.b64encode(buffer).decode('utf-8')
    return base64_str


def get_projection(arr, axis):
    total = arr.shape[1] if axis != 0 else arr.shape[0]
    projection = np.sum(arr, axis=axis) / total
    return (projection > 0.98).astype(np.uint8)  # 95% white threshold

def find_breaks(proj):
    breaks = []
    start = None
    min_gap =  8 # minimum gap size to consider
    
    for i in range(len(proj)):
        if proj[i] == 1 and start is None:
            start = i
        elif proj[i] == 0 and start is not None:
            if i - start >= min_gap:
                breaks.append((start, i))
            start = None
            
    if start is not None and len(proj) - start >= min_gap:
        breaks.append((start, len(proj)))
        
    return breaks

def is_bbox_similar(bbox1, bbox2, tolerance=50):

    total_diff = sum(abs(a - b) for a, b in zip(bbox1, bbox2))
    # print(total_diff)
    return total_diff <= tolerance

def get_doc(pdf_path, mode = "local"):
    if mode == "local" and ".pdf" in pdf_path:
        doc = fitz.open(pdf_path)
    elif mode == "local" and ".docx" in pdf_path:
        doc_bytes = Path(pdf_path).read_bytes()
        redline_rejected_bytes, doc_bytes, annotations = docx_to_pdf(doc_bytes)
        doc = fitz.open(stream=BytesIO(redline_rejected_bytes), filetype="pdf")
        
    elif mode == "blob" and ".pdf" in pdf_path:
        doc = read_pdf(pdf_path)
    elif mode == "blob" and ".docx" in pdf_path:
        doc_bytes = read_file(pdf_path)
        redline_rejected_bytes, doc_bytes, annotations = docx_to_pdf(doc_bytes)
        doc = fitz.open(stream=BytesIO(redline_rejected_bytes), filetype="pdf")

    return doc

def filter_by_y0(data, threshold=730):
    """
    Remove elements where y0 > threshold.
    
    Parameters:
        data (list of tuples)
        threshold (int or float)
    
    Returns:
        list of tuples
    """
    return [item for item in data if item[1] <= threshold]

def polygon_to_bbox(polygon):
    # Extract x coordinates (indices 0, 2, 4, 6) 
    # and y coordinates (indices 1, 3, 5, 7)
    x_coords = polygon[0::2]
    y_coords = polygon[1::2]
    
    min_x = min(x_coords)
    min_y = min(y_coords)
    max_x = max(x_coords)
    max_y = max(y_coords)
    
    # Return as [xmin, ymin, xmax, ymax]
    return [min_x, min_y, max_x, max_y]

def detect_outliers(data_list):
    # 1. Flatten the list of dictionaries into a list of (key, value) pairs
    # and a separate list of just the values for mode calculation
    all_pairs = []
    for entry in data_list:
        for key, val in entry.items():
            all_pairs.append((key, val))
    
    values_only = [pair[1][0] for pair in all_pairs]

    if not values_only:
        return None, []

    # 2. Calculate the mode using Counter
    # counts.most_common(1) returns the most frequent element
    counts = Counter(values_only)
    mode_value, frequency = counts.most_common(1)[0]
    
    # 3. Identify outliers (any key/value pair where value != mode)
    outliers = [pair for pair in all_pairs if pair[1][0] != mode_value]
    
    return outliers

def find_containing_bbox(target_bbox, bbox_list):
    """
    Finds which bounding box(es) from bbox_list contain the target_bbox.
    
    Args:
        target_bbox (tuple): (x1, y1, x2, y2) of the target.
        bbox_list (list): List of tuples (x1, y1, x2, y2) to check against.
        
    Returns:
        list: A list of bounding boxes that contain the target.
    """
    tx1, ty1, tx2, ty2 = target_bbox
    containing_boxes = []
    
    for bbox in bbox_list:
        bx1, by1, bx2, by2 = bbox
        if bx1 <= tx1 and by1 <= ty1 and bx2 >= tx2 and by2 >= ty2:
            containing_boxes.append(bbox)
            
    return containing_boxes

def split_lists_with_overlap(lst1, lst2, overlap=3, chunk_size=15):
    """
    Split two lists into parts with overlapping elements.
    The number of parts is based on the smaller of the two lists.

    Args:
        lst1, lst2 (list): Lists to split.
        overlap (int): Number of overlapping elements between consecutive parts.
        chunk_size (int): Approximate size of each part before overlap.

    Returns:
        tuple: (parts1, parts2) where each is a list of sublists.
    """
    len1, len2 = len(lst1), len(lst2)
    if len1 == 0 or len2 == 0:
        return [], []

    n_parts1 = max(1, len1 // chunk_size)
    n_parts2 = max(1, len2 // chunk_size)
    n_parts = min(n_parts1, n_parts2)

    part_size1 = len1 // n_parts
    part_size2 = len2 // n_parts

    parts1, parts2 = [], []

    for i in range(n_parts):
        start1 = max(0, i * part_size1 - overlap)
        end1 = (i + 1) * part_size1
        if i == n_parts - 1:
            end1 = len1

        start2 = max(0, i * part_size2 - overlap)
        end2 = (i + 1) * part_size2
        if i == n_parts - 1:
            end2 = len2

        parts1.append(lst1[start1:end1])
        parts2.append(lst2[start2:end2])

    return parts1, parts2

    
def split_list(lst, n_parts):
    k, m = divmod(len(lst), n_parts)
    return [lst[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(n_parts)]

def parse_legends(text, extra_key=None):
    text = text.strip().strip("'")
    items = re.split(r'\s*/\s*(?=(?:[a-z]{2}(?:-[a-z]{2})?-)|(?:.*?-[a-z]{2}(?:-[a-z]{2})?\s*(?:/|$)))', text)
    items = rearrange(items)
    lang_re = re.compile(r'^([a-z]{2}(?:-[a-z]{2})?)-(.*)$', re.DOTALL)

    output_data = {}
    current_en_key = None

    for item in items:
        m = lang_re.match(item.strip())
        if not m:
            continue
        lang_code = m.group(1)
        content = m.group(2).strip()

        if lang_code == 'en':
            current_en_key = content
            output_data[current_en_key] = {}
        elif current_en_key:
            output_data[current_en_key][lang_code] = content

    if extra_key:
        all_lang_codes = set()
        for translations in output_data.values():
            all_lang_codes.update(translations.keys())

        # Map each code to the extra_key string itself
        output_data[extra_key] = {lang: extra_key for lang in sorted(all_lang_codes)}

    return output_data

def rearrange(items, anchor='en-'):
    def lang_key(item):
        parts = item.split('-')
        # handle locale codes like 'zh-cn', 'zh-tw'
        if len(parts) >= 2 and parts[0] == 'zh':
            return f"{parts[0]}-{parts[1]}"
        return parts[0]
    groups, current, seen = [], [], set()
    for item in items:
        key = lang_key(item)
        if key in seen:                # cycle detected → new group
            groups.append(current)
            current, seen = [item], {key}
        else:
            current.append(item)
            seen.add(key)
    if current:
        groups.append(current)

    result = []
    for group in groups:
        anchors = [x for x in group if x.startswith(anchor)]
        others  = [x for x in group if not x.startswith(anchor)]
        result.extend(anchors + others)
    return result

def clean_non_arabic_newlines(text):
    
    arabic_pattern = r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]'
    
    # "Match a \n only if it is NOT preceded by an Arabic character"
    regex = rf'(?<!{arabic_pattern})\n'
    
    # Replace those matches with a space
    return re.sub(regex, ' ', text)


def merge_bboxes(bboxes):
    """
    Merge multiple bounding boxes into one.
    Each bbox should be a tuple/list of (x0, y0, x1, y1).
    Returns a tuple (min_x0, min_y0, max_x1, max_y1).
    """
    if not bboxes:
        return None

    x0 = min(b[0] for b in bboxes)
    y0 = min(b[1] for b in bboxes)
    x1 = max(b[2] for b in bboxes)
    y1 = max(b[3] for b in bboxes)

    return (x0, y0, x1, y1)



def normalize_text(s):
    if s is None:
        return ""
    # Unicode normalization + strip + collapse internal whitespace + casefold for robust comparison
    s = unicodedata.normalize("NFC", s)
    s = s.replace("\n", " ").replace("\r", " ")
    s = " ".join(s.strip().split())
    # s= s.lower()
    # For languages where case matters differently (e.g., not Latin), casefold may be harmless.
    return s

def words_from_text(s):
    """Return list of word-like tokens from s (keeps Unicode letters/digits)."""
    return re.findall(r"\w+", s, flags=re.UNICODE)

def find_exact_sequence_over_all(word_data, query_tokens):
    """
    Search the entire word_data for an exact contiguous sequence of query_tokens.
    Returns the union bbox if found, else None.
    """
    if not query_tokens:
        return None

    # Precompute normalized token for each word_data entry for quick exact comparsion
    normalized_tokens = [words_from_text(normalize_text(w[4]).lower()) for w in word_data]
    n = len(query_tokens)
    q_lower = [t.lower() for t in query_tokens]

    for i in range(len(normalized_tokens) - n + 1):
        ok = True
        for j in range(n):
            src_tokens = normalized_tokens[i + j]
            # require the target token to be exactly one of the source tokens
            if q_lower[j] not in src_tokens:
                ok = False
                break
        if ok:
            matched = word_data[i:i+n]
            all_x1 = [w[0] for w in matched]
            all_y1 = [w[1] for w in matched]
            all_x2 = [w[2] for w in matched]
            all_y2 = [w[3] for w in matched]
            return [min(all_x1), min(all_y1), max(all_x2), max(all_y2)]
    return None

def get_text_bbox(word_data, query_string, verbose=False):
    """
    Finds the bounding box for a query string within a list of word metadata.

    Behavior:
      - scans all sliding windows and remembers any substring-based candidate
      - after full scan, searches entire word list for an exact contiguous token sequence
      - returns exact match bbox if present, otherwise fallback to substring candidate

    Args:
        word_data (list): Tuples in the format (x1, y1, x2, y2, text, ...).
        query_string (str): The text sequence to find.
        verbose (bool): print debug information.

    Returns:
        list: [min_x, min_y, max_x, max_y] or None.
    """
    query_string = normalize_text(query_string)
    query_tokens = [normalize_text(t) for t in query_string.split()]
    n_tokens = len(query_tokens)
    if n_tokens == 0:
        return None

    substring_candidate_bbox = None
    substring_candidate_span = None  # (i, i+n-1)

    normalized_query_lower = [t.lower() for t in query_tokens]

    # 1) Sliding-window scan over contiguous word_data entries; DO NOT break early.
    for i in range(len(word_data) - n_tokens + 1):
        matched_words = []
        used_substring_match = False
        ok = True

        for j in range(n_tokens):
            entry = word_data[i + j]
            source_text = normalize_text(entry[4])
            src_tokens = words_from_text(source_text.lower())
            target = normalized_query_lower[j]

            # Exact token present among src_tokens?
            if target in src_tokens:
                # exact token match for this token
                matched_words.append(entry)
                continue

            # Otherwise, check substring (legacy behavior)
            if target in source_text.lower():
                used_substring_match = True
                matched_words.append(entry)
                continue

            ok = False
            break

        if ok:
            # compute bbox for this sliding window match
            all_x1 = [w[0] for w in matched_words]
            all_y1 = [w[1] for w in matched_words]
            all_x2 = [w[2] for w in matched_words]
            all_y2 = [w[3] for w in matched_words]
            candidate_bbox = [min(all_x1), min(all_y1), max(all_x2), max(all_y2)]

            if verbose:
                print(f"Sliding-window match at span ({i},{i+n_tokens-1}), substring_used={used_substring_match}, bbox={candidate_bbox}")

            # If this match used only exact token matches -> return immediately (best case)
            if not used_substring_match:
                if verbose:
                    print("Returning exact sliding-window match immediately.")
                return candidate_bbox

            # Otherwise record the first substring-based candidate, but keep scanning
            if substring_candidate_bbox is None:
                substring_candidate_bbox = candidate_bbox
                substring_candidate_span = (i, i + n_tokens - 1)
                if verbose:
                    print(f"Recorded substring candidate at span {substring_candidate_span} bbox={substring_candidate_bbox}")

    # 2) If we recorded a substring candidate, try a global exact contiguous search
    if substring_candidate_bbox is not None:
        if verbose:
            print("Searching the entire word list for an exact contiguous sequence...")
        exact_bbox = find_exact_sequence_over_all(word_data, query_tokens)
        if exact_bbox is not None:
            if verbose:
                print(f"Found exact contiguous sequence elsewhere, returning exact bbox: {exact_bbox}")
            return exact_bbox
        else:
            if verbose:
                print("No exact contiguous sequence found; falling back to substring candidate bbox.")
            return substring_candidate_bbox

    # 3) No match found at all
    if verbose:
        print("No match found.")
    return None

def scale_bbox_to_original(detected_bbox, crop_bbox):
    """
    detected_bbox: [x_min, y_min, x_max, y_max] in cropped image coords
    crop_bbox: [x_min, y_min, x_max, y_max] of crop region in original image
    """
    x_crop, y_crop = crop_bbox[0], crop_bbox[1]
    x_min, y_min, x_max, y_max = detected_bbox
    
    return [
        x_min + x_crop,
        y_min + y_crop,
        x_max + x_crop,
        y_max + y_crop
    ]

def merge_consecutive_by_y2(metadata, threshold=7):
    """
    metadata: list of tuples (x1, y1, x2, y2, text, idx, flag)
    Returns updated_metadata following the exact merging logic described.
    """
    if not metadata:
        return []

    updated_metadata = []
    i = 0
    n = len(metadata)

    while i < n:
        # If last element, just append and break
        if i == n - 1:
            updated_metadata.append(metadata[i])
            break

        # Compare y2 of i and i+1
        x1_i, y1_i, x2_i, y2_i, text_i, idx_i, flag_i = metadata[i]
        x1_j, y1_j, x2_j, y2_j, text_j, idx_j, flag_j = metadata[i + 1]

        if abs(y2_i - y2_j) >= threshold:
            # No merge: append index i as-is and move forward by 1
            updated_metadata.append(metadata[i])
            i += 1
            continue

        # Start a merged block with i and i+1
        merged_x1 = min(x1_i, x1_j)
        merged_y1 = min(y1_i, y1_j)
        merged_x2 = max(x2_i, x2_j)
        merged_y2 = max(y2_i, y2_j)
        merged_text = (text_i.strip() + " " + text_j.strip()).strip()
        merged_idx = idx_i   # keep the first index's idx (you can change if desired)
        merged_flag = flag_i # keep the first flag

        # Advance k to next index after i+1
        k = i + 2

        # While there is a next item and its y2 is within threshold of merged_y2, keep merging
        while k < n:
            x1_k, y1_k, x2_k, y2_k, text_k, idx_k, flag_k = metadata[k]
            if abs(merged_y2 - y2_k) < threshold:
                # merge k into merged
                merged_x1 = min(merged_x1, x1_k)
                merged_y1 = min(merged_y1, y1_k)
                merged_x2 = max(merged_x2, x2_k)
                merged_y2 = max(merged_y2, y2_k)
                merged_text = (merged_text + " " + text_k.strip()).strip()
                # keep merged_idx/flag as they were (from first element)
                k += 1
            else:
                break

        # Append the merged block
        updated_metadata.append((merged_x1, merged_y1, merged_x2, merged_y2,
                                 merged_text, merged_idx, merged_flag))

        # Continue from the next unprocessed index
        i = k

    return updated_metadata


def get_subset_text_grid(doc, bbox, page_no, lan):
    text_blocks = doc[page_no].get_text("blocks")
    subset_text = []
    for entry in text_blocks:
        x0, y0, x1, y1, text, *_ = entry
        if is_bbox_contained((x0, y0, x1, y1), bbox):
            subset_text.append(entry)

    
    if lan == 'ar':
        # Count x1 occurrences
        subset_text = merge_consecutive_by_y2(subset_text)
        x1_counts = Counter(round(entry[2], 2) for entry in subset_text)

        # Select only text with duplicate x1
        filtered = [entry for entry in subset_text if x1_counts[round(entry[2], 2)] > 1]
    else:
        # Count x1 occurrences
        x1_counts = Counter(round(entry[0], 2) for entry in subset_text)

        # Select only text with duplicate x1
        filtered = [entry for entry in subset_text if x1_counts[round(entry[0], 2)] > 1]

    return filtered


def get_subset_others(doc,page_no):
    page = doc[page_no]
    text_dict = page.get_text("blocks", clip=None)
    text_metadata = page.get_text('blocks')
    subset_texts = []
    for item in text_metadata:
        if 90< item[0] < 160 or 350 < item[0] < 410:
            subset_texts.append(item)

    return subset_texts

def get_subset_others_ar(doc,page_no):
    page = doc[page_no]
    threshold = 5

    text_metadata = page.get_text('blocks')
    subset_texts = []
    for item in text_metadata:
        if (200< item[2] < 240) or (500 < item[2] < 550):
            subset_texts.append(item)

    
    sorted_items = sorted(subset_texts, key=lambda x: x[1])

    merged = []
    # Start with the first item
    curr_x0, curr_y0, curr_x1, curr_y1, curr_text,_,_ = sorted_items[0]

    for i in range(1, len(sorted_items)):
        next_x0, next_y0, next_x1, next_y1, next_text,_,_ = sorted_items[i]

        # Check the absolute difference between y1 values
        if abs(next_y0 - curr_y1) < threshold:
            # Merge: Update coordinates to bounding box and join text
            curr_x0 = min(curr_x0, next_x0)
            curr_y0 = min(curr_y0, next_y0)
            curr_x1 = max(curr_x1, next_x1)
            curr_y1 = max(curr_y1, next_y1)
            curr_text += " " + next_text
        else:
            # Gap is too large, save current and start new group
            merged.append((curr_x0, curr_y0, curr_x1, curr_y1, curr_text))
            curr_x0, curr_y0, curr_x1, curr_y1, curr_text = next_x0, next_y0, next_x1, next_y1, next_text

    # Append the last remaining group
    merged.append((curr_x0, curr_y0, curr_x1, curr_y1, curr_text))

    return merged

def cluster_arabic_sentences_multiline(words_metadata):
    """
    Clusters Arabic words into multi-line sentences/paragraphs based on Block ID.
    
    Args:
        words_metadata (list): List of [x1, y1, x2, y2, text, block_id, line_id, word_id]
        
    Returns:
        list: [[bbox, text], ...] where bbox is the union box of the block
    """
    
    # Dictionary structure: blocks[block_id][line_id] = [word_row, word_row...]
    blocks = {}
    
    # Regex to identify words containing Arabic characters
    arabic_pattern = re.compile(r'[\u0600-\u06FF]')

    for row in words_metadata:
        text = row[4]
        
        # Filter for Arabic content
        if arabic_pattern.search(text):
            block_id = row[5]
            line_id = row[6]
            
            if block_id not in blocks:
                blocks[block_id] = {}
            
            if line_id not in blocks[block_id]:
                blocks[block_id][line_id] = []
            
            blocks[block_id][line_id].append(row)

    results = []

    # Process each Block
    for b_id, lines_dict in blocks.items():
        
        # 1. Sort Line IDs within the block Top-to-Bottom based on the Y1 coordinate of the first word
        # (This ensures lines are stitched in the correct reading order vertically)
        sorted_line_ids = sorted(
            lines_dict.keys(), 
            key=lambda lid: lines_dict[lid][0][1]
        )
        
        block_text_parts = []
        
        # Initialize union bounding box variables
        # Start with inverted infinity to ensure any coordinate will update them
        union_x1, union_y1 = float('inf'), float('inf')
        union_x2, union_y2 = float('-inf'), float('-inf')

        for lid in sorted_line_ids:
            words = lines_dict[lid]
            
            # 2. Sort words within the line Right-to-Left (Descending X1) for Arabic reading order
            words.sort(key=lambda w: w[0], reverse=True)
            
            # Construct the text for this specific line
            line_text = " ".join([w[4] for w in words])
            block_text_parts.append(line_text)
            
            # 3. Expand the bounding box to include this line
            for w in words:
                union_x1 = min(union_x1, w[0])
                union_y1 = min(union_y1, w[1])
                union_x2 = max(union_x2, w[2])
                union_y2 = max(union_y2, w[3])

        # Join all lines in the block with a space to form the full sentence/paragraph
        full_block_text = " ".join(block_text_parts)
        
        # Final Cluster Bbox
        cluster_bbox = [union_x1, union_y1, union_x2, union_y2]
        
        results.append([cluster_bbox, full_block_text])

    return results


def select_sections_by_bbox(data_list, target_bbox):
    """
    Selects items from a list whose bounding box is fully contained
    within the target bounding box.

    Args:
        data_list (list): The list of items, where each item's first four
                          elements are [x0, y0, x1, y1].
        target_bbox (tuple/list): The target bounding box (x0, y0, x1, y1).

    Returns:
        list: A new list containing only the selected items.
    """
    # Unpack the target bounding box coordinates
    target_x0, target_y0, target_x1, target_y1 = target_bbox

    filtered_list = []
    
    for item in data_list:
        # The word's bounding box is assumed to be the first 4 elements
        item_x0, item_y0, item_x1, item_y1 = item[0:4]

        # Check for full containment:
        # The item's top-left corner must be >= the target's top-left
        # AND the item's bottom-right corner must be <= the target's bottom-right
        is_contained = (item_x0 >= target_x0 and
                        item_y0 >= target_y0 and
                        item_x1 <= target_x1 and
                        item_y1 <= target_y1)

        if is_contained:
            filtered_list.append(item)
            
    return filtered_list


def find_best_match(options, query):
    """
    Finds the best match using a weighted ratio that handles 
    punctuation, reordering, and typos well.
    """
    # extractOne returns a tuple: (match, score, index)
    # fuzz.WRatio is excellent for handling partial matches and punctuation noise
    result = process.extractOne(query, options, scorer=fuzz.WRatio)
    
    return result


def bbox_relative(obj_bbox, subset_bbox):
    """
    Rescales an object's global bbox to the local coordinate system of a subset.
    
    Args:
        obj_bbox: [ymin, xmin, ymax, xmax] of the object
        subset_bbox: [ymin, xmin, ymax, xmax] of the subset/crop
        
    Returns:
        List of local coordinates [ymin, xmin, ymax, xmax]
    """
    # Unpack coordinates
    obj_ymin, obj_xmin, obj_ymax, obj_xmax = obj_bbox
    sub_ymin, sub_xmin, sub_ymax, sub_xmax = subset_bbox
    
    # Calculate local coordinates by subtracting the subset's origin
    local_ymin = obj_ymin - sub_ymin
    local_xmin = obj_xmin - sub_xmin
    local_ymax = obj_ymax - sub_ymin
    local_xmax = obj_xmax - sub_xmin
    
    return [local_ymin, local_xmin, local_ymax, local_xmax]


