import re
import numpy as np
import fitz
import os
import sys
from pathlib import Path
from PIL import Image
import pandas as pd
import io
ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 
from utils_ifu.utils import get_projection, find_breaks, get_doc
def restructure_text(text, lan='en'):
    # 1. Define a comprehensive list of common abbreviations (excluding the final dot)
    # This includes English, Latin, and equivalents in Spanish, French, German, and Italian.
    ABBREVIATIONS = [
        # General English/Latin
        'etc', 'viz', 'cf', 'i.e', 'e.g', 'vol', 'fig', 'vs',
        # Titles
        'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Gen', 'Rev', 'Capt',
        # Geographic/Business
        'St', 'Ave', 'Rd', 'Blvd', 'Inc', 'Corp', 'Ltd', 'Co',
        # Time
        'a.m', 'p.m', 'sec', 'min', 'hr',
        # Document Specific
        'Ph', 'Eur', 'No',
        # Multilingual Equivalents
        'Sra', 'Sr', 'Pág', 'Mme', 'M', 'Av',  # Spanish/French/Portuguese
        'Hr', 'sog',                         # German (Herr, sogenannt)
        'Sig', 'dott', 'Ex'                   # Italian/Portuguese (Signor, Dottore, Exemplo)
    ]

    # 2. Flatten the text
    flat_text = re.sub(r'\s+', ' ', text).strip()

    # 3. Construct the complex negative lookbehind pattern

    # A. Build the pattern for abbreviation exceptions
    # Each abbreviation requires its own fixed-width lookbehind `(?<!...)`
    abbr_lookbehinds = ''.join(f'(?<!{re.escape(abbr)})' for abbr in ABBREVIATIONS)

    # B. Build the special case lookbehinds
    # - (?<!\s[a-zA-Z]): Prevents splitting after single letters (e.g., " a.")
    # - (?<!\s\d): Prevents splitting after single digits (e.g., " 1.")
    # - (?<!\)n): Prevents splitting for the specific formula (C6H10O2)n.
    special_lookbehinds = r'(?<!\s[a-zA-Z])(?<!\s\d)(?<!\)n)'

    # C. Combine all lookbehinds and the split trigger (\.\s+)
    # Note: The order doesn't matter since they are separate fixed-width checks.
    split_pattern = f'{abbr_lookbehinds}{special_lookbehinds}\\.\\s+'

    
    
    if lan == 'ar':
        flat_text = ' '.join(text.splitlines()[::-1]).strip()
        processed_text = re.sub(split_pattern, '.\n', flat_text)
        final_list = processed_text.splitlines()[::-1]

        return '\n'.join(final_list)
    elif lan in ['zh-hans', 'zh-hant']:
        text = text.replace(r"\r\n", "\n").replace(r"\n", "\n")
        text = text.replace("\r\n", "\n").replace("\r", "\n")

        # Treat sentence-ending line breaks as likely paragraph boundaries.
        text = re.sub(
            r"""([。！？.!?]["'”’」』）)\]]*)[ \t]*\n+""",
            r"\1\n\n",
            text,
        )

        paragraphs = [
            re.sub(
                r"(?<=[\u3400-\u9fff]) +(?=[\u3400-\u9fff])",
                "",
                re.sub(r"[ \t]*\n[ \t]*", " ", block.strip()),
            )
            for block in re.split(r"\n[ \t]*\n+", text)
            if block.strip()]

        return '\n'.join(paragraphs)

    elif lan == 'th':
        text = text.replace("\r\n", "\n").replace("\r", "\n")

        THAI = r"\u0E00-\u0E7F"
        max_chars = 300  # target paragraph length; lower = smaller paragraphs

        # Treat sentence-ending line breaks as likely paragraph boundaries.
        text = re.sub(
            r"""([.!?๚๛]["'”’)\]]*)[ \t]*\n+""",
            r"\1\n\n",
            text,
        )

        paragraphs = []
        for block in re.split(r"\n[ \t]*\n+", text):
            if not block.strip():
                continue

            # Join wrapped lines: no space between Thai chars, space otherwise.
            block = re.sub(rf"(?<=[{THAI}])[ \t]*\n[ \t]*(?=[{THAI}])", "", block.strip())
            block = re.sub(r"[ \t]*\n[ \t]*", " ", block)
            block = re.sub(r"[ \t]{2,}", " ", block)

            # A space before a Thai char is a likely sentence boundary.
            sentences = re.split(rf"(?<=[{THAI}.!?\"'”’)\]])[ ]+(?=[{THAI}])", block)

            # Pack sentences into paragraphs of at most ~max_chars.
            current = ""
            for s in sentences:
                if current and len(current) + 1 + len(s) > max_chars:
                    paragraphs.append(current)
                    current = s
                else:
                    current = f"{current} {s}" if current else s
            if current:
                paragraphs.append(current)


        return "\n".join(paragraphs)

    else:
        # 4. Apply the split
        # We replace the safe split points with '.\n' to keep the period.
        processed_text = re.sub(split_pattern, '.\n', flat_text)
        # 5. Create the list
        final_list = processed_text.split('\n')


        return '\n'.join(final_list)
    
from statistics import median

def split_wide_boxes(bboxes, tol=1.4):
    """
    bboxes: list of [x0, y0, x1, y1]
    Splits any box that is much wider than the others into chunks
    whose width is copied from the normal boxes. Returns the full list.
    """
    try:
        widths = [b[2] - b[0] for b in bboxes]
        m = median(widths)
        ref = median([w for w in widths if w <= m])      # robust "normal" width

        out = []
        for (x0, y0, x1, y1), w in zip(bboxes, widths):
            n = round(w / ref) if w > tol * ref else 1   # how many normal cells fit
            if n <= 1:
                out.append([x0, y0, x1, y1])
                continue
            cuts = [x0 + i * ref for i in range(n)] + [x1]   # last chunk absorbs remainder
            out += [[cuts[i], y0, cuts[i + 1], y1] for i in range(n)]

        return sorted(out, key=lambda b: (b[1], b[0]))
    except:
        return bboxes
WHITE_THRESH = 245   
WHITE_RATIO  = 0.98   # row/col is a gutter if >=95% of pixels are white
MIN_GUTTER   = 3     
MAX_GUTTER   = 30     

LINE_COLOR   = (255, 0, 0)
LINE_WIDTH   = 2
DRAW_BORDER  = True
def find_gutters(white_mask_1d, min_w=MIN_GUTTER, max_w=MAX_GUTTER):
    """Given a 1D boolean array (True = white row/col), return list of
    (start, end, center) tuples for each contiguous gutter run."""
    gutters = []
    in_run, start = False, 0
    for i, is_white in enumerate(white_mask_1d):
        if is_white and not in_run:
            in_run, start = True, i
        elif not is_white and in_run:
            end = i - 1
            width = end - start + 1
            if min_w <= width <= max_w:
                gutters.append((start, end, (start + end) // 2))
            in_run = False
    if in_run:  # trailing gutter at edge
        end = len(white_mask_1d) - 1
        width = end - start + 1
        if min_w <= width <= max_w:
            gutters.append((start, end, (start + end) // 2))
    return gutters

def filter_gutters_by_spacing(gutters, tolerance=10,
                              expected_min=250, expected_max=380):
    """
    Find the first consecutive gutter pair whose spacing lies in
    [expected_min, expected_max] and use it as the reference. Then walk
    forward AND backward from that anchor, keeping gutters whose distance
    from the last-kept one is within `tolerance` of the reference width.
    """
    if len(gutters) < 2:
        return gutters

    # 1. Find the first consecutive pair whose spacing is in the expected range
    anchor_idx = None
    for i in range(len(gutters) - 1):
        diff = gutters[i + 1][2] - gutters[i][2]
        if expected_min <= diff <= expected_max:
            anchor_idx = i
            break

    if anchor_idx is None:
        # No pair matched - nothing trustworthy to anchor on
        return []

    width = gutters[anchor_idx + 1][2] - gutters[anchor_idx][2]

    # 2. Walk backward from the anchor to recover earlier valid gutters
    backward = [gutters[anchor_idx]]
    for i in range(anchor_idx - 1, -1, -1):
        diff = backward[-1][2] - gutters[i][2]
        if width - tolerance < diff < width + tolerance:
            backward.append(gutters[i])
    backward.reverse()

    # 3. Walk forward from the anchor+1
    filtered = backward + [gutters[anchor_idx + 1]]
    for i in range(anchor_idx + 2, len(gutters)):
        diff = gutters[i][2] - filtered[-1][2]
        if width - tolerance < diff < width + tolerance:
            filtered.append(gutters[i])

    return filtered
def filter_gutters_by_spacing(gutters, tolerance=10,
                              expected_min=250, expected_max=380):
    """
    Find the first consecutive gutter pair whose spacing lies in
    [expected_min, expected_max] and use it as the reference. Then walk
    forward AND backward from that anchor, keeping gutters whose distance
    from the last-kept one is within `tolerance` of the reference width.
    """
    if len(gutters) < 2:
        return gutters

    # 1. Find the first consecutive pair whose spacing is in the expected range
    anchor_idx = None
    for i in range(len(gutters) - 1):
        diff = gutters[i + 1][2] - gutters[i][2]
        if expected_min <= diff <= expected_max:
            anchor_idx = i
            break

    if anchor_idx is None:
        # No pair matched - nothing trustworthy to anchor on
        return []

    width = gutters[anchor_idx + 1][2] - gutters[anchor_idx][2]

    # 2. Walk backward from the anchor to recover earlier valid gutters
    backward = [gutters[anchor_idx]]
    for i in range(anchor_idx - 1, -1, -1):
        diff = backward[-1][2] - gutters[i][2]
        if width - tolerance < diff < width + tolerance:
            backward.append(gutters[i])
    backward.reverse()

    # 3. Walk forward from the anchor+1
    filtered = backward + [gutters[anchor_idx + 1]]
    for i in range(anchor_idx + 2, len(gutters)):
        diff = gutters[i][2] - filtered[-1][2]
        if width - tolerance < diff < width + tolerance:
            filtered.append(gutters[i])

    return filtered
def score_tolerance(gutters, tolerance, consistency_band=4,
                    expected_min=250, expected_max=380):
    filtered = filter_gutters_by_spacing(
        gutters, tolerance, expected_min, expected_max
    )
    if len(filtered) < 3:
        return 0, 0, filtered
    diffs = [filtered[i+1][2] - filtered[i][2] for i in range(len(filtered)-1)]
    median_diff = int(np.median(diffs))
    consistent = sum(1 for d in diffs if abs(d - median_diff) <= consistency_band)
    return consistent, median_diff, filtered


def filter_gutters_auto_tolerance(gutters, tol_range=range(7, 16),
                                  consistency_band=4,
                                  expected_min=250, expected_max=380):
    best = None
    for tol in tol_range:
        score, median_diff, filtered = score_tolerance(
            gutters, tol, consistency_band, expected_min, expected_max
        )
        candidate = (score, -tol, tol, median_diff, filtered)
        if best is None or candidate > best:
            best = candidate
    _, _, chosen_tol, chosen_median, chosen_filtered = best
    return chosen_filtered, chosen_tol, chosen_median
def gutters_to_bboxes(h_gutters, v_gutters, zoom=1,
                      min_cell_width=100, max_cell_width=450):
    """
    Convert filtered horizontal and vertical gutters into grid cell bboxes.
    Each bbox spans from one gutter center to the next.
    """
    # Extract centers (gutter tuples are (start, end, center))
    row_intersection = sorted({g[2] for g in h_gutters})
    col_intersection = sorted({g[2] for g in v_gutters})

    bbox = []
    for k in range(len(row_intersection) - 1):
        for j in range(len(col_intersection) - 1):
            x1 = zoom * col_intersection[j]
            y1 = zoom * row_intersection[k]
            x2 = zoom * col_intersection[j + 1]
            y2 = zoom * row_intersection[k + 1]

            if min_cell_width < abs(y1 - y2) < max_cell_width:
                bbox.append((x1, y1, x2, y2))

    # Sort by y1 (top) first, then by x1 (left) within the same row
    sorted_bboxes = sorted(bbox, key=lambda b: (b[1], b[0]))
    return sorted_bboxes

def extract_grid_bboxes(img, zoom=1):
    """Detect gutters in a page-grid image and return sorted cell bboxes."""
    img = img.convert("RGB")
    gray = np.array(img.convert("L"))
    h, w = gray.shape

    # Whiteness per row / column
    is_white = gray >= WHITE_THRESH
    row_white = is_white.mean(axis=1)
    col_white = is_white.mean(axis=0)

    # Raw gutters
    h_gutters = find_gutters(row_white >= WHITE_RATIO)
    v_gutters = find_gutters(col_white >= WHITE_RATIO)

    # Drop edge gutters (page margins)
    h_gutters = [g for g in h_gutters if g[0] > 0 and g[1] < h]
    v_gutters = [g for g in v_gutters if g[0] > 0 and g[1] < w]

    # Filter using spacing logic
    h_gutters, h_tol, h_median = filter_gutters_auto_tolerance(
        h_gutters, expected_min=250, expected_max=380
    )
    v_gutters = filter_gutters_by_spacing(
        v_gutters, tolerance=10, expected_min=146, expected_max=170
    )
    if h_gutters and h_gutters[0][2] > 100:
        h_gutters = [(1,1,1)] + h_gutters
    if v_gutters and v_gutters[0][2] > 100:
        v_gutters = [(1,1,1)] + v_gutters

    bottom = h
    h_gutters = list(h_gutters) + [(bottom, bottom, bottom)]
    corner = w
    v_gutters = list(v_gutters) + [(corner, corner, corner)]
    print(f"h gutters: {h_gutters} v_guttere: {v_gutters}" )

    return gutters_to_bboxes(h_gutters, v_gutters, zoom=zoom)

def extract_raw_grid_bboxes(img, zoom=1):
    """Detect gutters in a page-grid image and return sorted cell bboxes."""
    img = img.convert("RGB")
    gray = np.array(img.convert("L"))
    h, w = gray.shape

    # Whiteness per row / column
    is_white = gray >= WHITE_THRESH
    row_white = is_white.mean(axis=1)
    col_white = is_white.mean(axis=0)

    # Raw gutters
    h_gutters = find_gutters(row_white >= WHITE_RATIO)
    v_gutters = find_gutters(col_white >= WHITE_RATIO)

    return gutters_to_bboxes(h_gutters, v_gutters, zoom=zoom)

from collections import defaultdict

def fill_page_grid(grid, page_height):
    out = {}
    for page, cells in grid.items():
        rows = defaultdict(list)
        for x0, y0, x1, y1 in cells:
            rows[(y0, y1)].append((x0, x1))

        (top, bottom), cols = sorted(rows.items())[-1]   # last row = template
        h = bottom - top
        new, y = list(cells), bottom

        while page_height - y > 2:
            y2 = y + h
            if page_height - y2 < h / 2:                 # absorb thin leftover
                y2 = page_height
            new += [(x0, y, x1, y2) for x0, x1 in cols]
            y = y2

        out[page] = new
    return out
def extract_grids(pdf_path, mode="local"):
    zoom =1
    doc = get_doc(pdf_path, mode)  
    page_height = doc[0].rect.height     
    full_bbox = {}
    imgs = {}
    for i in range(len(doc)):
        page = doc[i]
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat)
        img_data = pix.tobytes("png")
        img = Image.open(io.BytesIO(img_data))
        imgs[i] = img
        grids = extract_grid_bboxes(img, zoom=1)

        if len(grids) <= 1 and len(doc) <=2:
            grids = extract_raw_grid_bboxes(img)
        full_bbox[i] = split_wide_boxes(grids)

    if 1 in full_bbox:
        if len(full_bbox[1]) < len(full_bbox[0])/2:
            full_bbox[1] = full_bbox[0]
    try:
        full_bbox = fill_page_grid(full_bbox, page_height)

    except:
        full_bbox = full_bbox
        

    return full_bbox


def fix_reversed_arabic(text):
    # Remove invisible formatting characters
    text = re.sub(r'[\u200e\u200f\u202a-\u202e]', '', text)
    # Reverse the order
    return text[::-1]

def replace_lang_code(match):
    separator = fix_reversed_arabic(match.group(1))
    content = fix_reversed_arabic(match.group(2).strip())
    lang_code = match.group(3)
    trailing = fix_reversed_arabic(match.group(4))
    
    return f'{separator}{lang_code}-{content}{trailing}'





