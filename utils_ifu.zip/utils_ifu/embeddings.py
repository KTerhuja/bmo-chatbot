import os
import sys
import numpy as np
from pathlib import Path
from typing import List, Tuple
import re
ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR))
from utils_ifu.load_models import load_llm

import time
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type

def chunk_list(lst, size=30):
    for i in range(0, len(lst), size):
        yield lst[i:i + size]

@retry(
    retry=retry_if_exception_type(Exception),
    wait=wait_exponential(multiplier=1, min=60, max=180), 
    stop=stop_after_attempt(5)
)
def get_embeddings(texts):
    _, _, client_embed = load_llm()
    results = []

    for chunk in chunk_list(texts, size=30): 
        results.extend(client_embed.embed_documents(chunk))
        time.sleep(1)

    return results



def cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0.0
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))

def generate_candidates(lst: List[str], max_span: int) -> Tuple[List[str], List[Tuple[int,int]]]:
    """
    Generate all contiguous concatenations up to max_span.
    Returns (texts, index_spans) where index_spans[i] = (start_idx, end_idx_inclusive).
    """
    n = len(lst)
    texts = []
    spans = []
    for start in range(n):
        for span_len in range(1, max_span + 1):
            end = start + span_len - 1
            if end >= n:
                break
            # join with a space (you can customize connector)
            combined = " ".join(lst[start:end+1])
            texts.append(combined)
            spans.append((start, end))
    return texts, spans

def filter_rows(row, threshold):
    l1 = len(row['translated'].split())
    l2 = len(row['vendor'].split())

    return abs(l1 -l2) < threshold
def match_lists_by_embeddings(
    lstA: List[str],
    lstB: List[str],
    max_span: int = 3,
    similarity_threshold: float = 0.70,
) -> List[Tuple[str, str]]:
    """
    Return list of (combinedA, combinedB) matched pairs.
    Algorithm:
      - build candidate concatenations (contiguous) up to max_span for both lists
      - embed candidates in batches
      - compute similarity matrix
      - collect candidate pair tuples with sim >= threshold
      - greedily pick highest-sim non-overlapping pairs
    """
    A_texts, A_spans = generate_candidates(lstA, max_span)
    B_texts, B_spans = generate_candidates(lstB, max_span)

    # get embeddings
    all_texts = A_texts + B_texts
    all_embs = get_embeddings(all_texts)
    A_embs = [np.array(v) for v in all_embs[:len(A_texts)]]
    B_embs = [np.array(v) for v in all_embs[len(A_texts):]]

    # compute similarity list (sparse collection only above threshold)
    pairs = []
    for i, a_emb in enumerate(A_embs):
        for j, b_emb in enumerate(B_embs):
            sim = cosine_sim(a_emb, b_emb)
            if sim >= similarity_threshold:
                pairs.append({
                    "sim": sim,
                    "a_idx": i,
                    "b_idx": j,
                    "a_span": A_spans[i],
                    "b_span": B_spans[j],
                    "a_text": A_texts[i],
                    "b_text": B_texts[j],
                })

    # sort by similarity descending
    pairs.sort(key=lambda x: x["sim"], reverse=True)

    # greedy selection ensuring no overlapping spans in A or B (preserve each index used once)
    used_A = set()
    used_B = set()
    selected = []
    for p in pairs:
        a_start, a_end = p["a_span"]
        b_start, b_end = p["b_span"]

        # check overlap with previously selected spans (simple: ensure none of the indices are used)
        if any(idx in used_A for idx in range(a_start, a_end + 1)):
            continue
        if any(idx in used_B for idx in range(b_start, b_end + 1)):
            continue

        # accept
        selected.append((p["a_text"], p["b_text"], p["sim"], p["a_span"], p["b_span"]))
        for idx in range(a_start, a_end + 1):
            used_A.add(idx)
        for idx in range(b_start, b_end + 1):
            used_B.add(idx)

    # final result as pairs (A_combined, B_combined)
    result = [(a, b) for (a, b, *_rest) in selected]
    return result


# Build index: compute embeddings for "translated" column (and optionally sentence-level chunks)
def build_index(df, text_col="translated", chunk_sentences=True):

    rows = []
    texts_to_embed = []

    for i, txt in enumerate(df[text_col].astype(str)):
        rows.append({"row_idx": i, "text": txt})
        texts_to_embed.append(txt)

        if chunk_sentences:
            chunks = [c.strip() for c in re.split(r'[.\n!?;]+', txt) if c.strip()]
            for c in chunks:
                if c and c != txt:
                    rows.append({"row_idx": i, "text": c})
                    texts_to_embed.append(c)

    # ---- Simplified embedding (only list responses supported) ----
    vecs = []
    B = 64

    for start in range(0, len(texts_to_embed), B):
        batch = texts_to_embed[start:start+B]

        # YOUR embedding call: returns plain list
        emb_resp =get_embeddings(batch)

        # emb_resp is already a list
        for e in emb_resp:
            if isinstance(e, dict) and "embedding" in e:
                vecs.append(np.array(e["embedding"], dtype=np.float32))
            else:
                vecs.append(np.array(e, dtype=np.float32))

    embeddings = np.vstack(vecs).astype(np.float32)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms[norms == 0] = 1e-12
    embeddings = embeddings / norms

    return {
        "rows": rows,
        "embeddings": embeddings,
        "df": df,
        "texts": texts_to_embed
    }


def batch_match_queries(df_query, query_col, index):
    """
    Fast vectorized search (works with chunked index produced by build_index).
    - df_query: DataFrame containing queries
    - query_col: column name in df_query with multilingual texts
    - index: dict from build_index() with keys: 'embeddings' (N_chunks, dim), 'rows' (list), 'df' (original df)
    - model: embedding model name (client.embeddings.create returns a plain list)
    Returns: df_query copy with columns 'best_english' and 'similarity' (top-1)
    """
    # 1) Batch embed queries (assumes client.embeddings.create returns a plain list)
    queries = df_query[query_col].astype(str).tolist()
    emb_resp = get_embeddings(queries)

    # Unpack embedding vectors into Q
    Q = []
    for e in emb_resp:
        if isinstance(e, dict) and "embedding" in e:
            Q.append(np.array(e["embedding"], dtype=np.float32))
        else:
            Q.append(np.array(e, dtype=np.float32))
    Q = np.vstack(Q).astype(np.float32)

    # Normalize Q
    q_norm = np.linalg.norm(Q, axis=1, keepdims=True)
    q_norm[q_norm == 0] = 1e-12
    Q = Q / q_norm   # (N_query, dim)

    # 2) Get index embeddings (chunk-level)
    E = index["embeddings"]   # (N_chunks, dim)

    # 3) Vectorized cosine similarity: (N_query, N_chunks)
    sim_matrix = Q @ E.T

    # 4) Best chunk per query (argmax over chunks)
    best_chunk_idx = np.argmax(sim_matrix, axis=1)       # indices into chunk array
    best_scores = np.max(sim_matrix, axis=1)

    # 5) Map chunk indices -> original row indices using index["rows"]
    # index["rows"][chunk_i]["row_idx"] gives the original df row index
    rows_meta = index["rows"]
    best_row_idx = []
    for ci in best_chunk_idx:
        ci = int(ci)
        if ci < 0 or ci >= len(rows_meta):
            # safety fallback: append -1 (no match)
            best_row_idx.append(-1)
        else:
            best_row_idx.append(int(rows_meta[ci]["row_idx"]))

    # 6) Map to English text (handle -1)
    df_source = index["df"].reset_index(drop=True)
    best_english = []
    for ridx in best_row_idx:
        if ridx == -1 or ridx < 0 or ridx >= len(df_source):
            best_english.append(None)
        else:
            best_english.append(df_source.iloc[ridx]["original"])

    # 7) Return augmented DataFrame
    out = df_query.copy()
    out["best_english"] = best_english
    out["similarity"] = best_scores

    return out

def prepare_A_side(lstA: List[str], max_span: int = 4):
    """
    Prepare candidate texts, spans, and embeddings for lstA.
    This is done only once.
    """
    A_texts, A_spans = generate_candidates(lstA, max_span)
    A_embs = get_embeddings(A_texts)
    A_embs = [np.array(v) for v in A_embs]

    return {
        "A_texts": A_texts,
        "A_spans": A_spans,
        "A_embs": A_embs,
        "max_span": max_span
    }
def match_with_new_B(
    A_data: dict,
    lstB: List[str],
    similarity_threshold: float = 0.70
):
    """
    lstA stays constant (preloaded in A_data)
    lstB changes every call
    """
    A_texts = A_data["A_texts"]
    A_spans = A_data["A_spans"]
    A_embs  = A_data["A_embs"]
    max_span = A_data["max_span"]

    # generate candidates for B for this run
    B_texts, B_spans = generate_candidates(lstB, max_span)
    B_embs = get_embeddings(B_texts)
    B_embs = [np.array(v) for v in B_embs]

    # compute similarity pairs
    pairs = []
    for i, a_emb in enumerate(A_embs):
        for j, b_emb in enumerate(B_embs):
            sim = cosine_sim(a_emb, b_emb)
            if sim >= similarity_threshold:
                pairs.append({
                    "sim": sim,
                    "a_span": A_spans[i],
                    "b_span": B_spans[j],
                    "a_text": A_texts[i],
                    "b_text": B_texts[j],
                })

    # sort by similarity
    pairs.sort(key=lambda x: x["sim"], reverse=True)

    # greedy non-overlapping span selection
    used_A = set()
    used_B = set()
    selected = []

    for p in pairs:
        a_start, a_end = p["a_span"]
        b_start, b_end = p["b_span"]

        if any(idx in used_A for idx in range(a_start, a_end + 1)): 
            continue
        if any(idx in used_B for idx in range(b_start, b_end + 1)):
            continue

        selected.append((p["a_text"], p["b_text"], p["sim"], p["a_span"], p["b_span"]))

        for idx in range(a_start, a_end + 1): 
            used_A.add(idx)
        for idx in range(b_start, b_end + 1): 
            used_B.add(idx)

    # final (A_text, B_text)
    return [(a, b) for (a, b, *_rest) in selected]


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a_norm = a / np.linalg.norm(a, axis=1, keepdims=True)
    b_norm = b / np.linalg.norm(b, axis=1, keepdims=True)
    return a_norm @ b_norm.T  # shape: (len(list1), len(list2))

def match_lists(list1, list2):
    print("Fetching embeddings...")
    embeddings1 = get_embeddings(list1)
    embeddings2 = get_embeddings(list2)

    similarities = cosine_similarity(embeddings1, embeddings2)
    results = []
    for i, item1 in enumerate(list1):
        best_idx = np.argmax(similarities[i])
        best_score = similarities[i][best_idx]
        best_match = list2[best_idx]
        results.append({
            "input": item1,
            "match": best_match,
            "score": round(float(best_score), 4)
        })

    return results


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Compute cosine similarity between two vectors."""
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))

def build_candidate_pairs(
    list_a: list[str],
    list_b: list[str],
    max_merge: int = 4
) -> list[dict]:
    """
    Build all candidate pairings, including merged consecutive strings.
    Returns candidates with their similarity scores.
    """
    # Pre-compute individual embeddings
    all_texts_a = list_a.copy()
    all_texts_b = list_b.copy()

    # Generate all possible consecutive merges for both lists
    # Key: (list_id, start_idx, end_idx) -> merged text
    merge_texts_a = {}
    merge_texts_b = {}

    for i in range(len(list_a)):
        for j in range(i + 1, min(i + max_merge + 1, len(list_a) + 1)):
            merged = " ".join(list_a[i:j])
            merge_texts_a[(i, j)] = merged  # [i, j) range

    for i in range(len(list_b)):
        for j in range(i + 1, min(i + max_merge + 1, len(list_b) + 1)):
            merged = " ".join(list_b[i:j])
            merge_texts_b[(i, j)] = merged

    # Collect all unique texts to embed
    all_texts = (
        list(merge_texts_a.values()) +
        list(merge_texts_b.values())
    )
    all_embeddings = get_embeddings(all_texts)

    # Map back to keys
    emb_a = {}
    idx = 0
    for key in merge_texts_a:
        emb_a[key] = np.array(all_embeddings[idx])
        idx += 1

    emb_b = {}
    for key in merge_texts_b:
        emb_b[key] = np.array(all_embeddings[idx])
        idx += 1

    return emb_a, emb_b, merge_texts_a, merge_texts_b


# ─── Step 3: Dynamic Programming Alignment ───
def align_lists(
    list_a: list[str],
    english: list[str],
    list_b: list[str],
    max_merge: int = 4,
    similarity_threshold: float = 0.95
) -> list[tuple[list[int], list[int], float]]:
    """
    Align two lists using DP, allowing consecutive merges.
    Returns list of (indices_from_a, indices_from_b, similarity_score).
    """
    n = len(list_a)
    m = len(list_b)

    print(f"Building candidate embeddings (max_merge={max_merge})...")
    emb_a, emb_b, texts_a, texts_b = build_candidate_pairs(list_a, list_b, max_merge)

    # DP table: dp[i][j] = best total similarity to align list_a[:i] with list_b[:j]
    # where i means we've consumed i elements from A, j from B
    dp = np.full((n + 1, m + 1), -np.inf)
    dp[0][0] = 0.0
    backtrack = {}  # (i, j) -> (prev_i, prev_j, consumed_a, consumed_b)

    print("Running alignment DP...")
    for i in range(n + 1):
        for j in range(m + 1):
            if dp[i][j] == -np.inf:
                continue

            # Try all possible merge combinations
            for da in range(1, min(max_merge + 1, n - i + 1)):
                for db in range(1, min(max_merge + 1, m - j + 1)):
                    key_a = (i, i + da)
                    key_b = (j, j + db)

                    if key_a in emb_a and key_b in emb_b:
                        sim = cosine_similarity(emb_a[key_a], emb_b[key_b])

                        # Penalize merges slightly to prefer 1:1 when similarity is close
                        merge_penalty = 0.01 * (da + db - 2)
                        score = dp[i][j] + sim - merge_penalty

                        if score > dp[i + da][j + db]:
                            dp[i + da][j + db] = score
                            backtrack[(i + da, j + db)] = (i, j, da, db, sim)

    # Trace back the optimal alignment
    alignment = []
    ci, cj = n, m

    if dp[n][m] == -np.inf:
        # Fallback: find best partial alignment
        best_score = -np.inf
        for i in range(n + 1):
            for j in range(m + 1):
                if dp[i][j] > best_score:
                    best_score = dp[i][j]
                    ci, cj = i, j

    while (ci, cj) != (0, 0) and (ci, cj) in backtrack:
        prev_i, prev_j, da, db, sim = backtrack[(ci, cj)]
        a_indices = list(range(prev_i, prev_i + da))
        b_indices = list(range(prev_j, prev_j + db))
        alignment.append((a_indices, b_indices, sim))
        ci, cj = prev_i, prev_j

    alignment.reverse()
    full_pair = []

    for pair_idx, (a_indices, b_indices, sim) in enumerate(alignment):
      

        a_text = " ".join([list_a[i] for i in a_indices])
        english_text =  " ".join([english[i] for i in a_indices])
        b_text = " ".join([list_b[j] for j in b_indices])

        result = {"original":english_text,
                   "vendor": b_text,
                   "translated": a_text}

        full_pair.append(result)

    return full_pair