import fitz
from io import BytesIO
 
from PIL import Image
import numpy as np
import pandas as pd
import copy
import pdfplumber
import fasttext
from io import BytesIO
from utils.aspose_words import docx_to_pdf
from utils.blob_storage import read_pdf
import os
import sys
from pathlib import Path
ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 

from utils_ifu.utils import get_doc, np_array_to_base64, polygon_to_bbox, is_bbox_similar, is_bbox_contained, filter_by_y0, detect_outliers, find_containing_bbox, get_subset_others_ar
from utils_ifu.processing import extract_grids
from utils_ifu.ifu_grids import get_grid_bboxes
from utils.blob_storage import read_file, write_img
from utils_ifu.genai import fix_arabic_typos, remove_footer
from utils_ifu.fastlangpatch import IsolatedLID
from utils_ifu.object_detection import run_object_detection
def ocr_extract_table(pdf_path, grid, page_no, client_ocr, mode="local"):
        doc = get_doc(pdf_path, mode)
        page = doc[page_no]
        zoom = 4  # decrease resolution
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat)
        img_data = pix.samples
        img_array = np.frombuffer(img_data, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
        if pix.n > 1:
                img_array = np.mean(img_array, axis=2).astype(np.uint8)
                
        x1,y1,x2,y2 = [x*zoom for x in grid]
        cropped_img = img_array[y1:y2, x1:x2]
        Image.fromarray(cropped_img)
        base64_arr = np_array_to_base64(cropped_img)

        analyze_request = {
        "base64Source": base64_arr
                        }
        

        poller = client_ocr.begin_analyze_document(
                "prebuilt-layout", body=analyze_request
                                )

        # Wait for the result to complete
        result = poller.result()
        poly= result.tables[0]['boundingRegions'][0]['polygon']
        bbox_table = polygon_to_bbox(poly)
        # The top-left corner of your crop in img_array coordinates
        shift_x = x1 
        shift_y = y1

        # If bbox_table is [xmin, ymin, xmax, ymax]
        rescaled_xmin = bbox_table[0] + shift_x
        rescaled_ymin = bbox_table[1] + shift_y
        rescaled_xmax = bbox_table[2] + shift_x
        rescaled_ymax = bbox_table[3] + shift_y

        bbox_on_img_array = [rescaled_xmin, rescaled_ymin, rescaled_xmax, rescaled_ymax]
        bbox_on_img_array_scaled = [x/zoom for x in bbox_on_img_array]

        data = result.tables[0]["cells"]
        # Convert to DataFrame
        df = pd.DataFrame(data)

        # Pivot to get a table format with rowIndex as index and columns as '0' and '1'
        df_pivot = df.pivot(index='rowIndex', columns='columnIndex', values='content')

        df_pivot.columns = df_pivot.iloc[0]
        df_pivot = df_pivot.drop(index=0).reset_index(drop=True)

        return df_pivot, bbox_on_img_array_scaled
def sort_tables(data_json):
    for lan in data_json.keys():
        if lan != 'misc':
            metadata = data_json[lan]['table']
            # Sorts by page_no, then x0 (bbox[0]), then y0 (bbox[1])
            metadata.sort(key=lambda x: (x['page_no'], x['table_bbox'][0], x['table_bbox'][1]))
            data_json[lan]['table'] = metadata
    return data_json


def pad_bbox(bbox, scale_factor=1.2):
    """
    Increases the size of a bounding box by a given scale factor.
    
    Args:
        bbox (list): [xmin, ymin, xmax, ymax]
        scale_factor (float): Factor to scale (1.2 = 20% increase)
        
    Returns:
        list: The scaled [xmin, ymin, xmax, ymax]
    """
    xmin, ymin, xmax, ymax = bbox
    
    # 1. Calculate current width and height
    width = xmax - xmin
    height = ymax - ymin
    
    # 2. Calculate the center point
    center_x = xmin + width / 2
    center_y = ymin + height / 2
    
    # 3. Calculate new dimensions
    new_width = width * scale_factor
    new_height = height * scale_factor
    
    # 4. Calculate new corner coordinates
    new_xmin = center_x - (new_width / 2)
    new_ymin = center_y - (new_height / 2)
    new_xmax = center_x + (new_width / 2)
    new_ymax = center_y + (new_height / 2)
    
    return [new_xmin, new_ymin, new_xmax, new_ymax]

def update_table_metadata(data_json, pdf_path, client_ocr, mode="local"):
    """
    Analyzes table consistency across different languages and re-extracts 
    outlier tables using OCR.
    """
    debug_table = {}
    doc = get_doc(pdf_path, mode)
    languages = [lan for lan in data_json.keys() if lan != 'misc']
    
    if not languages:
        return data_json

    # 1. Map metadata across languages to check for alignment
    # Assumes the number of tables is consistent with the first language entry
    num_tables = len(data_json[languages[0]]['table'])
    print('#'*8)
    for lan in languages:
        print(f"len of {lan}: {len(data_json[lan]['table'])} ")
    print('#'*8)
    if len(doc) > 5:
        try:
            languages = [lan for lan in data_json.keys() if lan not in ['misc', 'en']]
            en_table = data_json['en']['table']

            for lan in languages:
                lan_tables = data_json[lan]['table']

                if len(lan_tables) > len(en_table):
                    updated_table = []
                    for i in range(len(lan_tables)):
                        page_no = data_json[lan]['table'][i]['page_no']
                        target_bbox = data_json[lan]['table'][i]['table_bbox']
                        bbox_grid = pad_bbox(target_bbox, 2)
                        bbox_grid = [int(x) if x >= 0 else 0 for x in bbox_grid]

                        df, new_bbox = ocr_extract_table(
                                            pdf_path, 
                                            bbox_grid, 
                                            page_no, 
                                            client_ocr,
                                            mode
                                        )

                        updated_metadata = {"page_no": page_no,
                                            "table_bbox": new_bbox,
                                            "table": df}

                        updated_table.append(updated_metadata)

                    data_json[lan]['table'] = updated_table

        except:
            pass

    else:

        for i in range(num_tables):
            metadata = []
            
            for lan in languages:
                # Handle RTL (Right-to-Left) indexing for Arabic tables
                index = (num_tables - 1 - i) if lan == "ar" else i
            
                try:
                    table_entry = data_json[lan]['table'][index]
                except:
                    print(f"{lan}: {i}")
                table_shape = table_entry['table'].shape
                page_no = table_entry['page_no']
                
                metadata.append({lan: [table_shape, page_no]})
            
            debug_table[i] = metadata

        # 2. Get document structure
        doc = get_doc(pdf_path, mode)
        grids = get_grid_bboxes(doc)
        # grids = extract_grids(pdf_path, mode)

        # 3. Identify and correct mismatched tables
        for index, metadata_list in debug_table.items():
            outliers = detect_outliers(metadata_list)
            
            if outliers:
                for outlier in outliers:
                    lan, metadata = outlier
                    _, page_no = metadata

                    try:
                    
                        # Fetch target location and find the nearest grid boundary
                        target_bbox = data_json[lan]['table'][index]['table_bbox']
                        bbox_grid = find_containing_bbox(target_bbox, grids[page_no])
                        
                        # Re-run OCR extraction for the specific outlier area
                        df, new_bbox = ocr_extract_table(
                            pdf_path, 
                            bbox_grid[0], 
                            page_no, 
                            client_ocr,
                            mode
                        )
                        
                        # Update the master JSON with corrected data
                        data_json[lan]['table'][index]['table_bbox'] = new_bbox
                        data_json[lan]['table'][index]['table'] = df

                    except:
                        pass

    return data_json

def merge_to_lines_with_bbox(ocr_data, threshold=5):
    if not ocr_data:
        return []

    lines = []
    current_line_items = [ocr_data[0]]
    prev_x1 = ocr_data[0][1]

    def compute_line_bbox(items):
        # x0, y0, x1, y1
        min_x0 = min(item[0] for item in items)
        min_y0 = min(item[1] for item in items)
        max_x1 = max(item[2] for item in items)
        max_y1 = max(item[3] for item in items)
        text = " ".join(item[4] for item in items)
        return (min_x0, min_y0, max_x1, max_y1, text)

    for i in range(1, len(ocr_data)):
        curr_x1 = ocr_data[i][1]

        # Merge if x1 change is within threshold
        if abs(curr_x1 - prev_x1) <= threshold:
            current_line_items.append(ocr_data[i])
        else:
            lines.append(compute_line_bbox(current_line_items))
            current_line_items = [ocr_data[i]]

        prev_x1 = curr_x1

    # Add the final group
    if current_line_items:
        lines.append(compute_line_bbox(current_line_items))


    return lines

from statistics import median
 
 
def merge_lines_edge_case(lines, gap_threshold=None, gap_factor=0.6, sep=" "):

    clean = []
    for item in lines or []:
        try:
            x0, y0, x1, y1 = (float(item[0]), float(item[1]),
                              float(item[2]), float(item[3]))
        except (TypeError, ValueError, IndexError):
            continue  # skip items without valid coordinates
        text = ""
        if len(item) > 4 and item[4] is not None:
            text = str(item[4]).strip()
        clean.append([x0, y0, x1, y1, text])
 
    if not clean:
        return []
 
    # ---- 2. Sort by vertical position (then horizontal) -------------------
    clean.sort(key=lambda r: (r[1], r[0]))
 
    if len(clean) == 1:
        return [tuple(clean[0])]
 
    # ---- 3. Determine merge threshold --------------------------------------
    if gap_threshold is None:
        gaps = [b[1] - a[1] for a, b in zip(clean, clean[1:]) if b[1] - a[1] > 0.5]
        if gaps:
            gap_threshold = gap_factor * median(gaps)
        else:
            # Fallback: use the median box height
            gap_threshold = median(r[3] - r[1] for r in clean)
 
    # ---- 4. Merge -----------------------------------------------------------
    merged = []
    prev_y0 = None
    for cur in clean:
        if merged and prev_y0 is not None and (cur[1] - prev_y0) < gap_threshold:
            # Same logical line/paragraph -> union bbox + append text
            grp = merged[-1]
            grp[0] = min(grp[0], cur[0])  # x0
            grp[1] = min(grp[1], cur[1])  # y0
            grp[2] = max(grp[2], cur[2])  # x1
            grp[3] = max(grp[3], cur[3])  # y1
            if cur[4]:
                grp[4] = (grp[4] + sep + cur[4]) if grp[4] else cur[4]
        else:
            merged.append(cur[:])
        # Compare against the last RAW line, so chains of 3+ lines merge too
        prev_y0 = cur[1]
 
    return [tuple(r) for r in merged]

def merge_lines(lines, factor=1.2):
    if not lines:
        return []

    heights = sorted(l[3] - l[1] for l in lines)
    line_h = heights[len(heights) // 2]        # median text height
    y_threshold = line_h * factor

    merged = []
    current = list(lines[0])
    last_y0 = lines[0][1]                       # raw y0 of previous line

    for line in lines[1:]:
        if abs(line[1] - last_y0) <= y_threshold:
            current[0] = min(current[0], line[0])   # x0  (leftmost)
            current[1] = min(current[1], line[1])   # y0  (topmost)
            current[2] = max(current[2], line[2])   # x1  (rightmost)
            current[3] = max(current[3], line[3])   # y1  (bottommost)
            current[4] += ' ' + line[4]
        else:
            merged.append(tuple(current))
            current = list(line)
        last_y0 = line[1]

    merged.append(tuple(current))
    return merged

def bucket_spans_by_x1(data):
    """
    Buckets list of dictionaries into two lists based on x1 coordinate values.
    List 1: x1 between 300 and 350
    List 2: x1 >= 1500
    """
    bucket_list = []

    for item in data:
        # The first element in the polygon list is the x1 value
        x1 = item[0]

        if (75 <= x1 <= 110) or (350 <= x1 <= 420):
            bucket_list.append(item)

    return bucket_list

def is_inside(item_bbox, target):
    """
    Checks if item_bbox (x1, y1, x2, y2) is completely 
    contained within the target (tx1, ty1, tx2, ty2)
    """
    # item_bbox coordinates
    x1, y1, x2, y2 = item_bbox[0], item_bbox[1], item_bbox[2], item_bbox[3]
    # target coordinates
    tx1, ty1, tx2, ty2 = target
    
    return (x1 >= tx1 and y1 >= ty1 and x2 <= tx2 and y2 <= ty2)

def remove_x0_outliers(data):
    """
    Removes tuples from the list if their x0 value (index 0) 
    is a statistical outlier.
    """
    if not data:
        return []

    # 1. Extract all x0 values
    x0_values = [item[0] for item in data]
    
    # 2. Calculate IQR bounds


    # 2. Calculate IQR bounds
    q1 = np.percentile(x0_values, 25)
    q3 = np.percentile(x0_values, 75)

    lower_bound = q1 - 3 
    upper_bound = q3 + 3

    # 3. Filter the original list
    filtered_data = [
        item for item in data
        if lower_bound <= item[0] <= upper_bound
    ]

    removed_count = len(data) - len(filtered_data)
    print(f"Removed {removed_count} outliers. Bounds: ({lower_bound:.2f}, {upper_bound:.2f})")
    
    return filtered_data

def get_legends_others(page_no, doc, tables_metadata,lan):
    
    page = doc[page_no]
    data = page.get_text("words")

    if page_no in tables_metadata.keys():
        target_bbox = tables_metadata[page_no]
        # Filter the list: Keep items that are NOT inside the target bbox
        if len(target_bbox) >= 4:
            data = [item for item in data if not is_inside(item, target_bbox)]
    
    
    # Bucketing based on the first element (x1)
    left_list = [item for item in data if item[0] < 300]
    right_list = [item for item in data if item[0] > 300]
    sorted_left_list = sorted(left_list, key=lambda x: (x[1], x[0]))
    sorted_right_list = sorted(right_list, key=lambda x: (x[1], x[0]))

    merged_lines_left= merge_to_lines_with_bbox(sorted_left_list)
    merged_lines_right= merge_to_lines_with_bbox(sorted_right_list)

    if lan in ["th", "ko", 'zh-hans', 'zh-hant']:

        result_right = merge_lines_edge_case(merged_lines_right)
        result_left = merge_lines_edge_case(merged_lines_left)

    else:
        result_right = merge_lines(merged_lines_right)
        result_left = merge_lines(merged_lines_left)


    right_bucket = remove_x0_outliers(bucket_spans_by_x1(result_right))
    left_bucket = remove_x0_outliers(bucket_spans_by_x1(result_left))
    if len(right_bucket) == 1:
        right_bucket = []

    if len(left_bucket) == 1:
        left_bucket = []

    legends = left_bucket+right_bucket

    return legends


def get_legends_others_fallback(page_no, pdf_path, mode):
    memory_stream = _get_pdf_stream(pdf_path, mode)
    # pdf = pdfplumber.open(memory_stream)
    # page = pdf.pages[page_no]
    # words = page.extract_words()
    # data = [
    #     (
    #         word['x0'],       # x0
    #         word['top'],      # y0 (pdfplumber uses 'top' instead of 'y0')
    #         word['x1'],       # x1
    #         word['bottom'],   # y1 (pdfplumber uses 'bottom' instead of 'y1')
    #         word['text'],     # the word text
    #         0,                # block_no  (not available in pdfplumber)
    #         0,                # line_no   (not available in pdfplumber)
    #         0                 # word_no   (not available in pdfplumber)
    #     )
    #     for word in words
    # ]

    # # Bucketing based on the first element (x0)
    # left_list = [item for item in data if item[0] < 300]
    # right_list = [item for item in data if item[0] > 300]
    # sorted_left_list = sorted(left_list, key=lambda x: (x[1], x[0]))
    # sorted_right_list = sorted(right_list, key=lambda x: (x[1], x[0]))

    # merged_lines_left = merge_to_lines_with_bbox(sorted_left_list)
    # merged_lines_right = merge_to_lines_with_bbox(sorted_right_list)


    # result_right = merge_lines(merged_lines_right, 4)
    # result_left = merge_lines(merged_lines_left, 4)

    # right_bucket = remove_x0_outliers(bucket_spans_by_x1(result_right))
    # left_bucket = remove_x0_outliers(bucket_spans_by_x1(result_left))

    # if len(right_bucket) == 1:
    #     right_bucket = []

    # if len(left_bucket) == 1:
    #     left_bucket = []

    # legends = left_bucket + right_bucket

    # # Don't forget to close the PDF when done
    # pdf.close()

    # return legends


from collections import Counter
 
def group_text_lines(items, x_tolerance=100, line_gap_factor=1.25):
    if not items:
        return []
 
    # 1. Keep only fragments aligned to the dominant left margin (x0).
    main_x0 = Counter(round(it[0], 1) for it in items).most_common(1)[0][0]
    column = [it for it in items if abs(it[0] - main_x0) <= x_tolerance]
 
    # Build one (x0, y0, x1, y1, text) tuple from a group of fragments:
    # bbox is the union of the fragments' boxes, text is them joined.
    def _block(frags):
        return (min(f[0] for f in frags), min(f[1] for f in frags),
                max(f[2] for f in frags), max(f[3] for f in frags),
                " ".join(f[4] for f in frags))
 
    # 2. Sort top-to-bottom by y0.
    column.sort(key=lambda it: it[1])
    if len(column) == 1:
        return [_block(column)]
 
    # 3. Measure this document's line spacing = smallest step between lines.
    gaps = [column[i][1] - column[i - 1][1] for i in range(1, len(column))]
    threshold = min(gaps) * line_gap_factor
 
    # 4. Merge consecutive lines while the step stays within that spacing.
    blocks, current = [], [column[0]]
    for i in range(1, len(column)):
        if gaps[i - 1] <= threshold:
            current.append(column[i])              # same block
        else:
            blocks.append(_block(current))
            current = [column[i]]                  # new block
    blocks.append(_block(current))
    return blocks
def filter_by_x0(data, n):
    if n == 0:
        raise ValueError("n must be non-zero")
    return [row for row in data if (row[0] / n >= 0.22 and row[0]/n < 0.45) ]

# def filter_legends(items, x0_index=0, decimals=6, min_repeats=3):
#     # Round x0 values to group near-identical floats together
#     x0_values = [round(item[x0_index], decimals) for item in items]
#     counts = Counter(x0_values)

#     return [
#         item for item, x0 in zip(items, x0_values)
#         if counts[x0] < min_repeats
#     ]

def remove_symbol_words(data, case_sensitive=True):
    """Return a new list with tuples whose word (index 4) is in
    words_to_remove filtered out. The original list is left unchanged."""
    words_to_remove = {"D", "AXIS", "CYL", "DIA", "BC", "SYMBOLS", "KEYS", "L", "M","H", "LOW","MID", "HGH","MAX", "DESCRIPTION" }
    if case_sensitive:
        remove = set(words_to_remove)
        return [item for item in data if item[4] not in remove]
    remove = {w.lower() for w in words_to_remove}
    return [item for item in data if item[4].lower() not in remove]
def get_legends_others_standard(doc, page_no):
    merge_flag = False

    page = doc[page_no]
    width = page.rect.width 
    data = page.get_text("words")
    sorted_data = remove_symbol_words(sorted(data, key=lambda x: (x[1], x[0])))
    
    merged_data = merge_to_lines_with_bbox(sorted_data)
    legends = filter_by_x0(merged_data, width)
    for block in legends:
        if block[4][0].islower():
            merge_flag = True
            break
    if merge_flag:
        legends = group_text_lines(legends,line_gap_factor=1.1)
    else:
        try:
            main_x0 = Counter(round(it[0], 1) for it in legends).most_common(1)[0][0]
            legends = [it for it in legends if abs(it[0] - main_x0) <= 6]
        except:
            pass
    return legends

def filter_std_list(lst):
    if len(lst) < 2:
        return []
    max_gap = max(lst[i] - lst[i-1] for i in range(1, len(lst)))
    
    # 2. Determine the threshold 
    threshold = lst[-1] - max_gap
  
    filtered_lst = [x for x in lst[:-1] if x > threshold]
    
    return filtered_lst

def to_key(x):
    return tuple(to_key(i) for i in x) if isinstance(x, (list, tuple)) else x

def dedupe(arr):
    seen = set()
    return [x for x in arr if not (to_key(x) in seen or seen.add(to_key(x)))]

import math

def same_x0(blocks, tol=1e-6):
    """True if every block shares the same x0 (index 0), else False."""
    if not blocks:
        return True  # or False, depending on what you want for empty input
    first = blocks[0][0]
    return all(math.isclose(b[0], first, abs_tol=tol) for b in blocks)

def extract_table_images(yolo_model,
    pdf_path: str,
    data_json: dict,
    output_dir: str = "table_images",
    zoom: int = 4,
    mode: str = "local",
    pdf_type: str = "grid",

):
    """
    Extracts table regions from a PDF and saves them as images.

    Args:
        pdf_path (str): Path to the PDF file.
        data_json (dict): JSON containing table metadata (page_no, table_bbox).
        output_dir (str): Base directory to save extracted images.
        zoom (int): Zoom factor for rendering PDF pages.
    """

    # Open PDF
    print(f"mode:{mode}")
    doc = get_doc(pdf_path, mode)

    # Extract PDF filename without extension
    if mode == "local":
        pdf_name = os.path.splitext(os.path.basename(pdf_path))[0]

        # Create output directory: table_images/<pdf_name>/
        new_folder_path = os.path.join(output_dir, pdf_name)
        os.makedirs(new_folder_path, exist_ok=True)

        print(f"Folder created at: {new_folder_path}")

    elif mode == "blob":
        pdf_path = os.path.splitext(pdf_path)[0]
        new_folder_path = os.path.join(pdf_path, output_dir)

        print(f"Folder created at: {new_folder_path}")


    
    for lan in data_json.keys():
        tables = data_json[lan].get("table", [])

        if lan != 'misc':

            for i, table in enumerate(tables):

                page_nos = table["page_no"]

                bboxes = table["table_bbox"]

                # Ensure they are lists even if single-page

                if isinstance(page_nos, int):

                    page_nos, bboxes = [page_nos], [bboxes]
            
                img_parts = []
            
                for p_no, bbox in zip(page_nos, bboxes):

                    page = doc[p_no]

                    mat = fitz.Matrix(zoom, zoom)

                    pix = page.get_pixmap(matrix=mat)

                    # Pixmap to PIL Image

                    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

                    # Apply zoom to bbox: [x0, y0, x1, y1]

                    scaled_bbox = [coord * zoom for coord in bbox]

                    img_parts.append(img.crop(scaled_bbox))
            
                # Merge all parts (handles 1, 2, or many pages)

                if len(img_parts) > 1:

                    total_width = max(part.width for part in img_parts)

                    total_height = sum(part.height for part in img_parts)

                    final_img = Image.new('RGB', (total_width, total_height))

                    y_offset = 0

                    for part in img_parts:

                        final_img.paste(part, (0, y_offset))

                        y_offset += part.height

                else:

                    final_img = img_parts[0]

                image_name = f"{lan}_{i}.png"

                image_path = os.path.join(new_folder_path, image_name)
                image_path = image_path.replace("\\","/")

                if mode == "local":

                    final_img.save(image_path)

                elif mode == "blob":

                    write_img(image_path, np.array(final_img))

                data_json[lan]['table'][i]['image_path'] = image_path


        if pdf_type == "grid":
            if len(data_json["misc"]["table"]) < 2:

                if lan == 'ar':
                    page_no, bbox = data_json[lan]['metadata']['grids'][0]
                elif lan != "misc":
                    page_no, bbox = data_json[lan]['metadata']['grids'][-1]


                mat = fitz.Matrix(zoom, zoom)
                page = doc[page_no]
                pix = page.get_pixmap(matrix=mat)
                img_data = pix.samples
                img_array = np.frombuffer(img_data, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)

                # Convert to grayscale if needed
                if pix.n > 1:
                    img_array = np.mean(img_array, axis=2).astype(np.uint8)

                img = Image.fromarray(img_array).convert("RGB")

                scaled_grid = [zoom * x for x in bbox]
                cropped_img = img.crop(scaled_grid)
                    # File naming
                
                image_name = f"{lan}_symbols.png"

                image_path = os.path.join(new_folder_path, image_name)
                if mode == "local":
                    cropped_img.save(image_path, "PNG")

                elif mode == "blob":
                    cropped_img = np.array(cropped_img)
                    image_path = image_path.replace("\\","/")
                    print(image_path)
                    write_img(image_path, cropped_img)

                data_json[lan]['metadata']['image_path'] = image_path

            else:

                if lan == "misc":

                    for j in range(len(data_json[lan]['table'])):
                        page_no, grid = data_json['misc']['metadata']['grids'][j]
                        mat = fitz.Matrix(zoom, zoom)
                        page = doc[page_no]
                        pix = page.get_pixmap(matrix=mat)
                        img_data = pix.samples
                        img_array = np.frombuffer(img_data, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)

                        # Convert to grayscale if needed
                        if pix.n > 1:
                            img_array = np.mean(img_array, axis=2).astype(np.uint8)

                        img = Image.fromarray(img_array).convert("RGB")

                        scaled_grid = [zoom * x for x in grid]
                        cropped_img = img.crop(scaled_grid)
                            # File naming
                        
                        image_name = f"symbols_{j}.png"

                        image_path = os.path.join(new_folder_path, image_name)
                        if mode == "local":
                            cropped_img.save(image_path, "PNG")

                        elif mode == "blob":
                            cropped_img = np.array(cropped_img)
                            image_path = image_path.replace("\\","/")
                            print(image_path)
                            write_img(image_path, cropped_img)

                        data_json[lan]['table'][j]['image_path'] = image_path



        elif pdf_type == "others":
            
            page = doc[0]
            width = page.rect.width
            tables_metadata = {}

            for to_lan in data_json.keys():
                if to_lan not in ["misc", "en"]:
                    for x in data_json[to_lan]["table"]:
                        try:
                            page_no = x['page_no'][0]
                        except:
                            page_no = x['page_no']
                        tables_metadata[page_no] = x["table_bbox"]
            
            if len(data_json["misc"]["table"]) < 2:
                print(f"------------------{lan}")
                if lan != "misc":
                    page_nos = []
                    last_page_nos = data_json[lan]['metadata']['grids'][-3:]
                    start_page_nos = data_json[lan]['metadata']['grids'][:3]
                    last_page_nos = start_page_nos+last_page_nos

                    for page_no in last_page_nos:
                        legends = get_legends_others(page_no, doc, tables_metadata, lan)
                        if len(legends) >=2 :
                            page_nos.append(page_no)


                        legends_standard = get_legends_others_standard(doc, page_no)
                        
                        if width > 600 and ".docx" in pdf_path:
                            if len(legends_standard) >= 1:
                                page_nos.append(page_no)

                        else:
                            if len(legends_standard) >= 5:
                                page_nos.append(page_no)


                    if lan == 'ar':
                        page_nos.append(last_page_nos[-1])
                    
                else:
                    continue

                if len(page_nos) > 1:
                    print(f"{lan}: {page_nos}")
                
                image_paths = []
                page_nos = list(set(page_nos))
                print(f"debug extraction cell page_nos {page_nos}")
                for page_no in page_nos:
                    print(f"{lan}")
                    mat = fitz.Matrix(zoom, zoom)
                    page = doc[page_no]
                    pix = page.get_pixmap(matrix=mat)
                    img_data = pix.samples
                    img_array = np.frombuffer(img_data, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)

                    # Convert to grayscale if needed
                    if pix.n > 1:
                        img_array = np.mean(img_array, axis=2).astype(np.uint8)

                    img = Image.fromarray(img_array).convert("RGB")

                    symbols = run_object_detection(img, yolo_model)
                    legends = get_legends_others(page_no, doc, tables_metadata, lan)
                    
                    
                    legends_standard = get_legends_others_standard(doc, page_no)

                    if len(symbols) > 0:

                        image_name = f"{lan}_{page_no}_symbols.png"

                        image_path = os.path.join(new_folder_path, image_name)
                        
                        if mode == "local":
                            img.save(image_path, "PNG")
                            image_paths.append(image_path)

                        elif mode == "blob":
                            img = np.array(img)
                            image_path = image_path.replace("\\","/")
                            print(image_path)
                            write_img(image_path, img)
                            image_paths.append(image_path)

                    data_json[lan]['metadata']['image_path'] = image_paths

            elif len(data_json["misc"]["table"]) > 2:
                if lan == "misc":

                    page_nos = filter_std_list(data_json['misc']['metadata']['grids'])
                    data_json['misc']['metadata']['grids'] = page_nos
                    image_paths = []
                    for page_no in page_nos:
                        mat = fitz.Matrix(zoom, zoom)
                        page = doc[page_no]
                        pix = page.get_pixmap(matrix=mat)
                        img_data = pix.samples
                        img_array = np.frombuffer(img_data, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)

                        # Convert to grayscale if needed
                        if pix.n > 1:
                            img_array = np.mean(img_array, axis=2).astype(np.uint8)

                        img = Image.fromarray(img_array).convert("RGB")
                        
                        image_name = f"{lan}_{page_no}_symbols.png"

                        image_path = os.path.join(new_folder_path, image_name)
                        
                        if mode == "local":
                            img.save(image_path, "PNG")
                            image_paths.append(image_path)

                        elif mode == "blob":
                            img = np.array(img)
                            image_path = image_path.replace("\\","/")
                            print(image_path)
                            write_img(image_path, img)
                            image_paths.append(image_path)

                    data_json[lan]['metadata']['image_path'] = image_paths

    return data_json


language_code_mapper = {
  "ace_Arab": "ace",
  "ace_Latn": "ace",
  "acm_Arab": "ar",
  "ara_Arab": "ar",
  "acq_Arab": "ar",
  "aeb_Arab": "ar",
  "afr_Latn": "af",
  "ajp_Arab": "ar",
  "aka_Latn": "ak",
  "amh_Ethi": "am",
  "apc_Arab": "ar",
  "arb_Arab": "ar",
  "arb_Latn": "ar",
  "ars_Arab": "ar",
  "ary_Arab": "ar",
  "arz_Arab": "ar",
  "asm_Beng": "as",
  "ast_Latn": "ast",
  "awa_Deva": "awa",
  "ayr_Latn": "ay",
  "azb_Arab": "az",
  "azj_Latn": "az",
  "bak_Cyrl": "ba",
  "bam_Latn": "bm",
  "ban_Latn": "ban",
  "bel_Cyrl": "be",
  "bem_Latn": "bem",
  "ben_Beng": "bn",
  "bho_Deva": "bh",
  "bjn_Arab": "bjn",
  "bjn_Latn": "bjn",
  "bod_Tibt": "bo",
  "bos_Latn": "bs",
  "bug_Latn": "bug",
  "bul_Cyrl": "bg",
  "cat_Latn": "ca",
  "ceb_Latn": "ceb",
  "ces_Latn": "cs",
  "cjk_Latn": "cjk",
  "ckb_Arab": "ku",
  "crh_Latn": "crh",
  "cym_Latn": "cy",
  "dan_Latn": "da",
  "deu_Latn": "de",
  "dik_Latn": "din",
  "dyu_Latn": "dyu",
  "dzo_Tibt": "dz",
  "ell_Grek": "el",
  "eng_Latn": "en",
  "epo_Latn": "eo",
  "est_Latn": "et",
  "eus_Latn": "eu",
  "ewe_Latn": "ee",
  "fao_Latn": "fo",
  "fij_Latn": "fj",
  "fin_Latn": "fi",
  "fon_Latn": "fon",
  "fra_Latn": "fr",
  "fur_Latn": "fur",
  "fuv_Latn": "ff",
  "gla_Latn": "gd",
  "gle_Latn": "ga",
  "glg_Latn": "gl",
  "grn_Latn": "gn",
  "guj_Gujr": "gu",
  "hat_Latn": "ht",
  "hau_Latn": "ha",
  "heb_Hebr": "he",
  "hin_Deva": "hi",
  "hne_Deva": "hne",
  "hrv_Latn": "hr",
  "hun_Latn": "hu",
  "hye_Armn": "hy",
  "ibo_Latn": "ig",
  "ilo_Latn": "ilo",
  "ind_Latn": "id",
  "isl_Latn": "is",
  "ita_Latn": "it",
  "jav_Latn": "jv",
  "jpn_Jpan": "ja",
  "kab_Latn": "kab",
  "kac_Latn": "kac",
  "kam_Latn": "kam",
  "kan_Knda": "kn",
  "kas_Arab": "ks",
  "kas_Deva": "ks",
  "kat_Geor": "ka",
  "knc_Arab": "kr",
  "knc_Latn": "kr",
  "kaz_Cyrl": "kk",
  "kbp_Latn": "kbp",
  "kea_Latn": "kea",
  "khm_Khmr": "km",
  "kik_Latn": "ki",
  "kin_Latn": "rw",
  "kir_Cyrl": "ky",
  "kmb_Latn": "kmb",
  "kmr_Latn": "ku",
  "kon_Latn": "kg",
  "kor_Hang": "ko",
  "lao_Laoo": "lo",
  "lij_Latn": "lij",
  "lim_Latn": "li",
  "lin_Latn": "ln",
  "lit_Latn": "lt",
  "lmo_Latn": "lmo",
  "ltg_Latn": "ltg",
  "ltz_Latn": "lb",
  "lua_Latn": "lua",
  "lug_Latn": "lg",
  "luo_Latn": "luo",
  "lus_Latn": "lus",
  "lvs_Latn": "lv",
  "mag_Deva": "mag",
  "mai_Deva": "mai",
  "mal_Mlym": "ml",
  "mar_Deva": "mr",
  "min_Arab": "min",
  "min_Latn": "min",
  "mkd_Cyrl": "mk",
  "plt_Latn": "mg",
  "mlt_Latn": "mt",
  "mni_Beng": "mni",
  "khk_Cyrl": "mn",
  "mos_Latn": "mos",
  "mri_Latn": "mi",
  "mya_Mymr": "my",
  "nld_Latn": "nl",
  "nno_Latn": "nn",
  "nob_Latn": "no",
  "npi_Deva": "ne",
  "nso_Latn": "nso",
  "nus_Latn": "nus",
  "nya_Latn": "ny",
  "oci_Latn": "oc",
  "gaz_Latn": "om",
  "ory_Orya": "or",
  "pag_Latn": "pag",
  "pan_Guru": "pa",
  "pap_Latn": "pap",
  "pes_Arab": "fa",
  "pol_Latn": "pl",
  "por_Latn": "pt",
  "prs_Arab": "fa",
  "pbt_Arab": "ps",
  "quy_Latn": "qu",
  "ron_Latn": "ro",
  "run_Latn": "rn",
  "rus_Cyrl": "ru",
  "sag_Latn": "sg",
  "san_Deva": "sa",
  "sat_Olck": "sat",
  "scn_Latn": "scn",
  "shn_Mymr": "shn",
  "sin_Sinh": "si",
  "slk_Latn": "sk",
  "slv_Latn": "sl",
  "smo_Latn": "sm",
  "sna_Latn": "sn",
  "snd_Arab": "sd",
  "som_Latn": "so",
  "sot_Latn": "st",
  "spa_Latn": "es",
  "als_Latn": "sq",
  "srd_Latn": "sc",
  "srp_Cyrl": "sr",
  "ssw_Latn": "ss",
  "sun_Latn": "su",
  "swe_Latn": "sv",
  "swh_Latn": "sw",
  "szl_Latn": "szl",
  "tam_Taml": "ta",
  "tat_Cyrl": "tt",
  "tel_Telu": "te",
  "tgk_Cyrl": "tg",
  "tgl_Latn": "tl",
  "tha_Thai": "th",
  "tir_Ethi": "ti",
  "taq_Latn": "tmh",
  "taq_Tfng": "tmh",
  "tpi_Latn": "tpi",
  "tsn_Latn": "tn",
  "tso_Latn": "ts",
  "tuk_Latn": "tk",
  "tum_Latn": "tum",
  "tur_Latn": "tr",
  "twi_Latn": "tw",
  "tzm_Tfng": "ber",
  "uig_Arab": "ug",
  "ukr_Cyrl": "uk",
  "umb_Latn": "umb",
  "urd_Arab": "ur",
  "uzn_Latn": "uz",
  "vec_Latn": "vec",
  "vie_Latn": "vi",
  "war_Latn": "war",
  "wol_Latn": "wo",
  "xho_Latn": "xh",
  "ydd_Hebr": "yi",
  "yor_Latn": "yo",
  "yue_Hant": "zh",
  "zho_Hans": "zh",
  "zho_Hant": "zh",
  "cmn_Hans": "zh",
  "cmn_Hant": "zh",
  "zsm_Latn": "ms",
  "zul_Latn": "zu",
  "ekk_Latn": "et",
  "zxx_Zxxx": "misc"
}
def clean_data_json(data_json):
    for lan in list(data_json.keys()):
        if lan != "misc":
            # Accessing the nested 'grids' list to check length
            if len(data_json[lan]['metadata']['grids']) < 2:
                data_json.pop(lan)
    
    return data_json

import re
import statistics

import re
import statistics


def filter_page_artifacts(
    blocks,
    isolation_multiplier=3.0,
    max_digits=4,
    min_isolation_gap=5.0,
    band_fraction=0.12,
    band_gap_multiplier=2.0,
    min_band_gap=15.0,
    max_boilerplate_len=60,
):

    if not blocks:
        return list(blocks)

    # n = len(blocks)

    # # Patterns that must match the WHOLE (stripped) text of the block.
    # _FULLMATCH_PATTERNS = [
    #     re.compile(r'\d{1,%d}' % max_digits),                     # "4"
    #     re.compile(r'[-\u2013\u2014]?\s*\d{1,%d}\s*[-\u2013\u2014]?' % max_digits),  # "- 4 -"
    #     re.compile(r'\d+\s*(?:of|/)\s*\d+', re.IGNORECASE),       # "3 of 122"
    #     re.compile(r'page\s+\d+(?:\s*(?:of|/)\s*\d+)?', re.IGNORECASE),
    #     re.compile(r'\d{4}-\d{2}-\d{2}'),                         # lone date
    #     re.compile(r'\d{1,2}:\d{2}(?::\d{2})?'),                  # lone time
    # ]

    # # Markers that may appear anywhere, but ONLY inside short one-line blocks.
    # _CONTAINS_PATTERNS = [
    #     re.compile(r'https?://|www\.', re.IGNORECASE),
    #     re.compile(r'©|\bcopyright\b', re.IGNORECASE),
    #     re.compile(r'\ball rights reserved\b', re.IGNORECASE),
    #     re.compile(r'\bconfidential\b|\bproprietary\b', re.IGNORECASE),
    #     re.compile(r'\brevision\b|\bIFU\b'),
    # ]

    # def is_pagenum_like(i):
    #     t = blocks[i][4].strip()
    #     return t.isdigit() and len(t) <= max_digits

    # def matches_boilerplate(text):
    #     t = text.strip()
    #     # Long or multi-line blocks are body text, never boilerplate.
    #     if len(t) > max_boilerplate_len or '\n' in t:
    #         return False
    #     if any(p.fullmatch(t) for p in _FULLMATCH_PATTERNS):
    #         return True
    #     return any(p.search(t) for p in _CONTAINS_PATTERNS)

    # # ---- 1. Page extent, ignoring lone page-number blocks so a stray
    # #         "4" at the very bottom can't stretch the footer band. ----
    # extent_idx = [i for i in range(n) if not is_pagenum_like(i)] or list(range(n))
    # page_top = min(blocks[i][1] for i in extent_idx)
    # page_bottom = max(blocks[i][3] for i in extent_idx)
    # page_height = page_bottom - page_top
    # if page_height <= 0:
    #     return list(blocks)

    # header_cutoff = page_top + page_height * band_fraction
    # footer_cutoff = page_bottom - page_height * band_fraction

    # # ---- 2. Geometry helpers ----
    # def bbox_gap(a, b):
    #     """Shortest distance between two bounding boxes (0 if they overlap)."""
    #     ax0, ay0, ax1, ay1 = a[:4]
    #     bx0, by0, bx1, by1 = b[:4]
    #     dx = max(0.0, ax0 - bx1, bx0 - ax1)
    #     dy = max(0.0, ay0 - by1, by0 - ay1)
    #     return (dx * dx + dy * dy) ** 0.5

    # def vertical_gap(i, others):
    #     """Vertical-only gap from block i to its nearest block in `others`."""
    #     ay0, ay1 = blocks[i][1], blocks[i][3]
    #     best = float('inf')
    #     for j in others:
    #         by0, by1 = blocks[j][1], blocks[j][3]
    #         dy = max(0.0, ay0 - by1, by0 - ay1)
    #         if dy < best:
    #             best = dy
    #     return 0.0 if best == float('inf') else best

    # # ---- 3. Partition blocks into bands vs. body ----
    # header_band = {i for i in range(n) if blocks[i][3] <= header_cutoff}
    # footer_band = {i for i in range(n) if blocks[i][1] >= footer_cutoff}
    # band_set = header_band | footer_band
    # body_indices = [i for i in range(n) if i not in band_set]

    # # If literally everything is in a band, treat the bands as body so we
    # # don't accidentally strip the whole page.
    # if not body_indices:
    #     return list(blocks)

    # to_remove = set()

    # # ---- 4. Band-based header/footer detection (cascading sweep) ----
    # # Baseline: typical nearest-neighbor gap among body blocks
    # body_gaps = []
    # for i in body_indices:
    #     gaps = [bbox_gap(blocks[i], blocks[j]) for j in body_indices if j != i]
    #     if gaps:
    #         body_gaps.append(min(gaps))
    # baseline = statistics.median(body_gaps) if body_gaps else 0.0
    # band_threshold = max(baseline * band_gap_multiplier, min_band_gap)

    # def sweep_band(indices, order_key):
    #     """Walk band blocks from the body outward. A block is kept if it is
    #     chained to the body (or to an already-kept band block) by a small
    #     vertical gap and doesn't look like boilerplate. The chain breaks at
    #     the first large gap — everything beyond it is measured against the
    #     kept set only, so real headers/footers are still removed."""
    #     kept = list(body_indices)
    #     for i in sorted(indices, key=order_key):
    #         v_gap = vertical_gap(i, kept)
    #         if v_gap >= band_threshold or matches_boilerplate(blocks[i][4]):
    #             to_remove.add(i)
    #         else:
    #             kept.append(i)   # now shields the next block outward

    # # header: process nearest-to-body first = largest y1 first
    # sweep_band(header_band, order_key=lambda i: -blocks[i][3])
    # # footer: process nearest-to-body first = smallest y0 first
    # sweep_band(footer_band, order_key=lambda i: blocks[i][1])

    # # ---- 5. Isolated numeric page-number detection (anywhere on page) ----
    # def nearest_gap(i):
    #     return min(
    #         (bbox_gap(blocks[i], blocks[j]) for j in range(n) if j != i),
    #         default=0.0,
    #     )

    # numeric_candidates = [i for i in range(n) if is_pagenum_like(i)]
    # if numeric_candidates:
    #     cand_set = set(numeric_candidates)
    #     baseline_gaps = [
    #         nearest_gap(i) for i in range(n)
    #         if i not in cand_set and i not in to_remove
    #     ]
    #     baseline_num = statistics.median(baseline_gaps) if baseline_gaps else 0.0
    #     num_threshold = max(baseline_num * isolation_multiplier, min_isolation_gap)
    #     for i in numeric_candidates:
    #         if nearest_gap(i) >= num_threshold:
    #             to_remove.add(i)

    # return [b for i, b in enumerate(blocks) if i not in to_remove]

def filter_aligned_blocks(blocks, x_min=50, x_max=150, tolerance=5, min_count=5):
    candidates = [i for i, b in enumerate(blocks) if x_min <= b[0] <= x_max]
    to_remove = set()
    for i in candidates:
        x0_i = blocks[i][0]
        count = sum(1 for j in candidates if abs(blocks[j][0] - x0_i) <= tolerance)
        if count >= min_count:
            to_remove.add(i)
    
    return [b for idx, b in enumerate(blocks) if idx not in to_remove]
def extract_from_page(page, settings=None):
    """Helper to extract tables and return a list of [bbox, df]"""
    results = []
    # Use provided settings or default to None
    tables = page.find_tables(table_settings=settings) if settings else page.find_tables()
    
    for table in tables:
        data = table.extract()
        if data and len(data) >= 2:
            # Create DF, drop completely empty rows/cols to clean up
            df = pd.DataFrame(data[1:], columns=data[0]).dropna(how='all')
            if not df.empty:
                results.append([table.bbox, df])
    return results

def get_best_settings(memory_stream):
    metadata_0, metadata_1 = {}, {}
    settings = {"snap_tolerance": 10}
    with pdfplumber.open(memory_stream) as pdf:
        for i, page in enumerate(pdf.pages):
            metadata_0[i] = extract_from_page(page) # Assuming this is a predefined helper
            metadata_1[i] = extract_from_page(page, settings=settings)
    
    count0 = sum(1 for v in metadata_0.values() if v)
    count1 = sum(1 for v in metadata_1.values() if v)
    return settings if count1 >= count0 else None, (metadata_1 if count1 >= count0 else metadata_0)


def _get_pdf_stream(pdf_path, mode = "local"):
    if mode == "local" and ".pdf" in pdf_path:
        return pdf_path
    elif mode == "local" and ".docx" in pdf_path:
        doc_bytes = Path(pdf_path).read_bytes()
        redline_rejected_bytes, doc_bytes, annotations = docx_to_pdf(doc_bytes)
        return BytesIO(redline_rejected_bytes)
        
    elif mode == "blob" and ".pdf" in pdf_path:
        pdf_bytes = read_file(pdf_path)
        return BytesIO(pdf_bytes)
    elif mode == "blob" and ".docx" in pdf_path:
        doc_bytes = read_file(pdf_path)
        redline_rejected_bytes, doc_bytes, annotations = docx_to_pdf(doc_bytes)
        return BytesIO(redline_rejected_bytes)


def _detect_language(text, fasttext_model, isolated_lid_model=None):
    """Unified language detection with specific logic for Chinese (zh)."""
    if not text or len(text.split()) <= 6:
        return "misc", 0.0
    
    lang_pred, prob_pred = fasttext_model.predict([text.replace('\n', ' ')])
    iso_code = lang_pred[0][0].replace('__label__', "")
    prob = prob_pred[0][0]
    
    # Map code if mapper exists (used in 'others' type)
    mapped_lan = language_code_mapper.get(iso_code, iso_code)
    
    if mapped_lan == "zh" and isolated_lid_model:
        return isolated_lid_model.predict(text), prob
    
    return mapped_lan, prob

def _merge_tables_logic(tables):
    """Standardized logic to merge tables with matching columns."""
    if not tables:
        return []
    
    merged = []
    curr_group = tables[0]
    
    for next_table in tables[1:]:
        curr_df = curr_group['table']
        next_df = next_table['table']
        
        # Check column matching
        cols_match = curr_df.columns.equals(next_df.columns)
        
        # Vertical distance check (only if bbox is not a list yet)
        curr_bbox = curr_group['table_bbox']
        next_bbox = next_table['table_bbox']
        
        # Determine distance check based on structure (grid vs others)
        dist_check = False
        if isinstance(curr_bbox, tuple) and isinstance(next_bbox, tuple):
             dist_check = abs(curr_bbox[2] - next_bbox[0]) < 100
        else:
             dist_check = True # Default for multi-page 'others' logic
             
        if cols_match and dist_check:
            curr_group['table'] = pd.concat([curr_df, next_df]).reset_index(drop=True)
            if not isinstance(curr_group['page_no'], list):
                curr_group['page_no'] = [curr_group['page_no']]
                curr_group['table_bbox'] = [curr_group['table_bbox']]
            curr_group['page_no'].append(next_table['page_no'])
            curr_group['table_bbox'].append(next_table['table_bbox'])
        else:
            merged.append(curr_group)
            curr_group = next_table
            
    merged.append(curr_group)
    return merged


def _has_arabic(doc, min_chars=5, sample_pages=None):
    """Return True if the PDF contains Arabic text.

    min_chars: minimum number of Arabic characters required to count as
               Arabic (avoids false positives from a stray symbol).
    sample_pages: if set, only scan the first N pages for speed on large PDFs.
                  None = scan all pages until the threshold is hit.
    """
    count = 0
    ARABIC_RE = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]')
    pages = doc if sample_pages is None else (doc[i] for i in range(min(sample_pages, len(doc))))
    for page in pages:
        text = page.get_text("text")
        if not text:
            continue
        count += len(ARABIC_RE.findall(text))
        if count >= min_chars:
            return True
    return False


def _extract_tables_fitz(doc):
    table_metadata = {}
    
    for i, page in enumerate(doc):
        table_metadata[i] = []
        for table in page.find_tables():
            table_data = table.extract()
            if table_data and len(table_data) >= 2:
                df = pd.DataFrame(table_data[1:], columns=table_data[0])
                table_metadata[i].append([table.bbox, df])

            else:
            
                    total_text = " ".join(
                        str(cell).strip()
                        for row in table_data
                        for cell in row
                        if cell
                    )
                    if len(total_text) >= 50:
                        df = pd.DataFrame(table_data[1:], columns=table_data[0])
                        table_metadata[i].append([table.bbox, df])
    return table_metadata


def _extract_tables_pdfplumber(memory_stream):
    table_metadata = {}
    with pdfplumber.open(memory_stream) as pdf:
        for i, page in enumerate(pdf.pages):
            table_metadata[i] = []
            for table in page.find_tables():
                table_data = table.extract()
                if table_data and len(table_data) >= 2:
                    df = pd.DataFrame(table_data[1:], columns=table_data[0])
                    table_metadata[i].append([table.bbox, df])
                else:
                
                        total_text = " ".join(
                            str(cell).strip()
                            for row in table_data
                            for cell in row
                            if cell
                        )
                        if len(total_text) >= 50:
                            df = pd.DataFrame(table_data[1:], columns=table_data[0])
                            table_metadata[i].append([table.bbox, df])
    return table_metadata

import re
import unicodedata 
 
def _count(text, patterns):
    """Return {label: hit_count} for every pattern that matches at least once."""
    hits = {}
    for pat, label in patterns.items():
        n = len(re.findall(pat, text))
        if n:
            hits[label] = n
    return hits
 
 
def classify_sr_cnr(text):
    """Classify a Cyrillic text as Serbian ('sr') or Montenegrin ('cnr')."""
    IJEKAVIAN = {
        r"посљед\w*":  "posljed-",
        r"замјен\w*":  "zamjen-",
        r"сјечив\w*":  "sjeciv-",
        r"мјер\w*":    "mjer-",
        r"\bприје\b":  "prije",
        r"вијек\w*":   "vijek-",
        r"вјек\w*":    "vjek-",
        r"тијел\w*":   "tijel-",
        r"мјест\w*":   "mjest-",
        r"вриј\w*":    "vrij- (vrijeme)",
        r"избјег\w*":  "izbjeg-",
        r"дјел\w*":    "djel-",
        r"\bдио\b":    "dio",
        r"усљед":      "usljed",
        r"измијењ\w*": "izmijenj-",
        r"\bвјер\w*":  "vjer-",
    }
    
    # nijes- is so diagnostic it gets its own heavily-weighted bucket
    STRONG_CNR = {
        r"нијес\w*":   "nijes- (nijesu/nijesam) -- strong Montenegrin marker",
    }
    
    EKAVIAN = {
        r"последиц\w*":                              "posledic-",
        r"замен\w*":                                 "zamen-",
        r"сечив\w*":                                 "seciv-",
        r"\b(мере|мера|меру|мерама)\b":               "mer-",
        r"\b(век|века|веку)\b":                       "vek-",
        r"\b(тело|тела|телу)\b|телом":                "tel-",
        r"\bместо\b|местим\w*":                       "mest-",
        r"\bвреме\b|времен\w*":                       "vrem-",
        r"избег\w*":                                 "izbeg-",
        r"\bнису\b":                                 "nisu",
        r"\bдео\b|делов\w*":                          "del-",
        r"услед":                                    "usled",
    }
    
    # Montenegrin-exclusive letters (positive evidence only)
    CNR_LETTERS = {"\u0405\u0301", "\u0405", "\u0306"}  # placeholder; see check below
    t = text.lower()
 
    ije   = _count(t, IJEKAVIAN)
    strong = _count(t, STRONG_CNR)
    eka   = _count(t, EKAVIAN)
 
    # Montenegrin-only graphemes: с/з + combining acute (U+0301)
    special = len(re.findall(r"[сз\u0441\u0437]\u0301", text))
 
    ije_score    = sum(ije.values())
    strong_score = sum(strong.values()) * 3      # heavy weight
    eka_score    = sum(eka.values())
 
    cnr_score = ije_score + strong_score + special * 5
    sr_score  = eka_score
 
    total = cnr_score + sr_score
    if total == 0:
        return {"label": "undetermined", "confidence": 0.0,
                "cnr_score": 0, "sr_score": 0, "evidence": {}}
 
    if cnr_score > sr_score:
        label, conf = "cnr", cnr_score / total
    elif sr_score > cnr_score:
        label, conf = "sr",      sr_score / total
    else:
        label, conf = "tie", 0.5
 
    return label
 
def overlap_ratio(bbox, table_bbox):
    """Fraction of bbox's area that lies inside table_bbox."""
    x0 = max(bbox[0], table_bbox[0])
    y0 = max(bbox[1], table_bbox[1])
    x1 = min(bbox[2], table_bbox[2])
    y1 = min(bbox[3], table_bbox[3])
    if x1 <= x0 or y1 <= y0:
        return 0.0
    inter = (x1 - x0) * (y1 - y0)
    area = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
    return inter / area if area else 0.0


def line_in_table(line_bbox, table_bboxes, threshold=0.5):
    return any(overlap_ratio(line_bbox, tb) > threshold for tb in table_bboxes)


   

def extract_data(pdf_path, pdf_type, llm_structured,llm, client_ocr,yolo_model, extract_images=True, mode="local",filter_footer=False):
   # 1. Initialization
    data_json = {}
    template = {"text": "", "table": [], "metadata": {'grids': []}}
    doc = get_doc(pdf_path, mode)
    memory_stream = _get_pdf_stream(pdf_path, mode)
    # Load Models based on PDF type
    model_name = 'lid.176.bin' if pdf_type == "grid" else "openlid-v3.bin"
    lang_model_path = os.path.join(ROOT_DIR, 'ifu_models', model_name)
    lang_model = fasttext.load_model(lang_model_path)

    lang_model_edge_case_path = lang_model_path = os.path.join(ROOT_DIR, 'ifu_models', 'lid.176.bin')
    lang_model_edge_case = fasttext.load_model(lang_model_edge_case_path)
    isolated_lid = IsolatedLID()

    # 2. Strategy: Grid Extraction
    if pdf_type == "grid":
        bbox_values = get_grid_bboxes(doc)
        if _has_arabic(doc, sample_pages=4):
            table_metadata = _extract_tables_fitz(doc)
        else:
            table_metadata = _extract_tables_pdfplumber(memory_stream)

        curr_lan = None

        for i in range(len(doc)):
            text_blocks = doc[i].get_text("blocks")
            page_tables = table_metadata.get(i, [])
            table_bboxes = [t[0] for t in page_tables]
            crects = color_rects(doc[i])
            for grid_bbox in bbox_values[i]:
                # content, full_content = '', ''
                # for x0, y0, x1, y1, text, *_ in text_blocks:
                #     text_bbox = (x0, y0, x1, y1)
                #     inside_table = any(is_bbox_similar(text_bbox, tb) or is_bbox_contained(text_bbox, tb,tolerance=25) for tb in table_bboxes)

                #     if is_bbox_contained(text_bbox, grid_bbox):
                #         if not inside_table:
                #             content += "\n" + text
                #         full_content += "\n" + text

                # clean_text = " ".join((content if len(content) >= 1 else full_content).split())
                content = extract_grid_text(doc, i, grid_bbox, crects)

                clean_text = content.replace("\n", " ")

                if len(clean_text.split()) > 15:
                    lan, prob = _detect_language(clean_text, lang_model, isolated_lid)
                    if lan == "zh-yue":
                        curr_lan = "zh-hant"
                        lan = "zh-hant"

                    # Probability filters
                    if prob > 0.5 or (lan in ['sr', 'sh'] and prob > 0.25):
                        curr_lan = 'sr' if lan in ['sr', 'sh'] else lan
                    
                    else:
                        curr_lan = 'misc'

                    if curr_lan not in data_json:
                        data_json[curr_lan] = copy.deepcopy(template)

                    if curr_lan == 'en' and len(data_json['en']['metadata']['grids']) > 1:
                        prev_grid_sum = sum(data_json['en']['metadata']['grids'][-1][1])
                        if abs(prev_grid_sum - sum(grid_bbox)) < 1500:
                            data_json['en']['text'] += content
                            data_json['en']['metadata']['grids'].append([i, grid_bbox])
                    else:
                        data_json[curr_lan]['text'] += content
                        if curr_lan != 'misc':
                            data_json[curr_lan]['metadata']['grids'].append([i, grid_bbox])

                # --- TABLE ASSOCIATION MOVED OUTSIDE the word-count check ---
                if curr_lan is not None and len(page_tables) >= 1:
                    for t_bbox, df in page_tables:
                        if is_bbox_contained(t_bbox, grid_bbox,tolerance=25):
                            if curr_lan not in data_json:
                                data_json[curr_lan] = copy.deepcopy(template)
                            data_json[curr_lan]['table'].append({"page_no": i, "table_bbox": t_bbox, "table": df})
                            data_json[curr_lan]['metadata']['grids'].append([i, grid_bbox])

        if 'ar' in data_json:
            unique_ar_grids = []
            [unique_ar_grids.append(x) for x in data_json['ar']['metadata']['grids'] if x not in unique_ar_grids]
            data_json['ar']['text'] = ''
            for page_no, g_bbox in unique_ar_grids[::-1]:
                blocks = doc[page_no].get_text("blocks")
                t_bboxes = [t.bbox for t in doc[page_no].find_tables()]
                for x0, y0, x1, y1, text, *_ in blocks:
                    if not any(is_bbox_contained((x0,y0,x1,y1), tb) for tb in t_bboxes) and is_bbox_contained((x0,y0,x1,y1), g_bbox):
                        cleaned = text.replace("(.", ".(").replace(".)", ").").replace(". \n)", "). \n")
                        data_json['ar']['text'] += "\n" + fix_arabic_typos(llm_structured, cleaned)

    # 3. Strategy: "Others" Extraction
    elif pdf_type == "others":
        width = doc[0].rect.width
        best_settings, table_metadata = get_best_settings(memory_stream)
        for k in table_metadata: table_metadata[k] = [] # Reset for final pass

        with pdfplumber.open(memory_stream) as pdf:
            last = len(pdf.pages) - 1
            for i, page in enumerate(pdf.pages):
                if 0 < i < last:
                    # Tables
                    tabs = page.find_tables(table_settings=best_settings) if best_settings else page.find_tables()
                    for t in tabs:
                        t_data = t.extract()
                        if t_data and len(t_data) >= 2:
                            df = pd.DataFrame(t_data[1:], columns=t_data[0])
                            if len(df) <2:
                                df = df.replace(r'^\s*$', np.nan, regex=True)
                            if width > 600 and len(df.columns) ==2:
                                continue                   
                            df = df.dropna()
                            if not df.empty:
                                table_metadata[i].append([t.bbox, df])

                    # Text
                    # for k in table_metadata: table_metadata[k] = []  # temp fix to include table elements in the extracted text
                    t_bboxes = [tm[0] for tm in table_metadata[i]]
                    page_dict = doc[i].get_text("dict")
                    content = []
                    text_blocks = []
                    for block in page_dict["blocks"]:
                        if block["type"] != 0:  # skip image blocks
                            continue

                        kept_lines = []
                        for line in block["lines"]:
                            # if not line_in_table(line["bbox"], t_bboxes):
                            text = "".join(span["text"] for span in line["spans"])
                            kept_lines.append(text)

                            # FIX: use the line-level bbox, which covers all spans
                            text_blocks.append(list(line["bbox"]) + [text])

                        if kept_lines:
                            content.append("\n".join(kept_lines))


                    #  text_blocks = filter_by_y0(doc[i].get_text("blocks")
                    full_text = "\n".join([b[4] for b in text_blocks])
                    clean_content_str = " ".join(content) if content else full_text

                    lan, prob = _detect_language(clean_content_str, lang_model, isolated_lid)
                    curr_lan = lan if (prob > 0.5 or (lan in ["zh", "hr"] and prob > 0.3)) else 'misc'
                    if lan in ["en", "misc"] and prob < 0.5:
                        lan, prob = _detect_language(clean_content_str, lang_model_edge_case, isolated_lid)
                        if lan == "en" and prob > 0.65:
                            curr_lan = "en"
                    if curr_lan == "sr":
                        curr_lan = classify_sr_cnr(doc[i].get_text())
                        print(f'entered block, curr lan is: {curr_lan}')

                    if curr_lan not in data_json:
                        data_json[curr_lan] = copy.deepcopy(template)

                    if filter_footer:
                        text_blocks = filter_page_artifacts(text_blocks)
                        text_blocks = filter_aligned_blocks(text_blocks)
                        text_blocks = filter_aligned_blocks(text_blocks, x_min=350, x_max=400, tolerance=5, min_count=5)
                
                    
                    content = [b[4] for b in text_blocks]
                    text = "\n".join(content)
                    removed_footer = remove_footer(llm,text)

                    data_json[curr_lan]['text'] += "\n" + removed_footer
                    data_json[curr_lan]['metadata']['grids'].append(i)
                    
                    for t_bbox, df in table_metadata[i]:
                        data_json[curr_lan]['table'].append({"page_no": i, "table_bbox": t_bbox, "table": df})

        data_json = sort_tables(data_json)

    # 4. Final Processing (Merging, Cleaning, Images)
    
    for lan in data_json:
        if lan == 'misc': continue
        data_json[lan]["table"] = _merge_tables_logic(data_json[lan].get('table', []))
        print(f"len of {lan}: {len(data_json[lan]['table'])} ")

    if "misc" not in data_json:
        data_json['misc'] = {"table":{},
                             "metadata":{"grids":[]}
                             }
    # data_json = clean_data_json(data_json)
    data_json = update_table_metadata(data_json, pdf_path, client_ocr, mode)

    if pdf_type == "others":
        for lan in data_json:
            if lan == 'misc': continue
            data_json[lan]["table"] = _merge_tables_logic(data_json[lan].get('table', []))
            print(f"len of {lan}: {len(data_json[lan]['table'])} ")

    
    if extract_images:
        data_json = extract_table_images(yolo_model, pdf_path, data_json, mode=mode, pdf_type=pdf_type)

    return data_json


def ocr_extract_misc_table(pdf_path, page_no, client_ocr, mode="local"):
        output_dir= "table_images"
        doc = get_doc(pdf_path, mode)
        page = doc[page_no]
        # Extract PDF filename without extension
        if mode == "local":
            pdf_name = os.path.splitext(os.path.basename(pdf_path))[0]

            # Create output directory: table_images/<pdf_name>/
            new_folder_path = os.path.join(output_dir, pdf_name)
            os.makedirs(new_folder_path, exist_ok=True)

            print(f"Folder created at: {new_folder_path}")

        elif mode == "blob":
            pdf_path = os.path.splitext(pdf_path)[0]
            new_folder_path = os.path.join(pdf_path, output_dir)

            print(f"Folder created at: {new_folder_path}")
        zoom = 4  # decrease resolution
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat)
        img_data = pix.samples
        img_array = np.frombuffer(img_data, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)

        

        if pix.n > 1:
                img_array = np.mean(img_array, axis=2).astype(np.uint8)
                
        base64_arr = np_array_to_base64(img_array)

        analyze_request = {
        "base64Source": base64_arr
                        }
        

        poller = client_ocr.begin_analyze_document(
                "prebuilt-layout", body=analyze_request
                                )

        
        result = poller.result()
        if len(result.tables) == 0:
            return None, None, None

        else:
            # Extract PDF filename without extension
            image_paths = []
            img = Image.fromarray(img_array).convert("RGB")
                    
            image_name = f"{page_no}_symbols.png"

            image_path = os.path.join(new_folder_path, image_name)
            
            if mode == "local":
                img.save(image_path, "PNG")
                image_paths.append(image_path)

            elif mode == "blob":
                img = np.array(img)
                image_path = image_path.replace("\\","/")
                print(image_path)
                write_img(image_path, img)
                image_paths.append(image_path)
                
            poly= result.tables[0]['boundingRegions'][0]['polygon']
            bbox_table = polygon_to_bbox(poly)

            data = result.tables[0]["cells"]
            # Convert to DataFrame
            df = pd.DataFrame(data)

            # Pivot to get a table format with rowIndex as index and columns as '0' and '1'

            df_pivot = df.pivot(index='rowIndex', columns='columnIndex', values='content')

            df_pivot.columns = df_pivot.iloc[0]
            if len(df_pivot.columns) == 2:
                df_pivot[' '] = " " # Adding an empty-named column for the transition
            df = df_pivot.drop(index=0).reset_index(drop=True)
            new_df = pd.DataFrame([df.columns], columns=df.columns)
            df = pd.concat([new_df, df], ignore_index=True)

            # 2. Rename columns to 1, 2, 3...
            # We use range starting from 1 to the length of columns + 1
            df.columns = range(1, len(df.columns) + 1)

            return df, result, image_paths


import re

def get_best_fit_bbox(target_text, metadata):
    """
    Finds the best fit bounding box for target_text by mapping character 
    indices to their estimated physical coordinates in the metadata.
    """
    # 1. Build a character-level map of the entire text
    full_text = ""
    char_coords = []
    
    for entry in metadata:
        content = entry['content']
        poly = entry['polygon']
        
        # Determine basic geometry of the entry
        # Assuming poly is [x1, y1, x2, y2, x3, y3, x4, y4]
        x_min, y_min = min(poly[0], poly[6]), min(poly[1], poly[3])
        x_max, y_max = max(poly[2], poly[4]), max(poly[5], poly[7])
        
        # Estimate width of each character
        char_count = len(content)
        if char_count == 0: continue
        char_width = (x_max - x_min) / char_count
        
        # Append each character and its estimated bbox to our map
        for i, char in enumerate(content):
            char_x_min = x_min + (i * char_width)
            char_x_max = x_min + ((i + 1) * char_width)
            char_coords.append((char_x_min, y_min, char_x_max, y_max))
            full_text += char
            
        # Add a virtual space/separator between entries to prevent false matches
        # but don't add coordinates for it
        full_text += " "
        char_coords.append(None)

    # 2. Normalize and search for the target string
    # We use a case-insensitive search and ignore extra whitespace
    target_clean = target_text.strip()
    # Find the index in the full_text
    # Note: Using regex to find the string allows us to handle the prefixes (en:, el:) 
    # simply by searching for the target within the larger string.
    match = re.search(re.escape(target_clean), full_text, re.IGNORECASE)
    
    if not match:
        return None

    start_idx, end_idx = match.start(), match.end()
    
    # 3. Aggregate coordinates for the matched character range
    matched_coords = [c for c in char_coords[start_idx:end_idx] if c is not None]
    
    if not matched_coords:
        return None
        
    # Extract all x and y values from the matched character bboxes
    all_x = [c[0] for c in matched_coords] + [c[2] for c in matched_coords]
    all_y = [c[1] for c in matched_coords] + [c[3] for c in matched_coords]
    
    return [int(min(all_x)), int(min(all_y)), int(max(all_x)), int(max(all_y))]


def parse_legends_others(df, data_json):
    legends = ''
    df=df.fillna(" ")
    for value in df.values:
        legends+= " " + value[1]+ " " +value[2] 

    legends = legends.replace("It:","lt:").replace("Iv:", "lv:").replace("Sv:", "sv:").replace("CS:", "cs:").replace("тк:", "mk:")
    legends = legends.strip()
    import re
    allowed_codes = ["zh" if code in ["zh-hans", "zh-hant"] else code for code in list(data_json.keys())]

    # 1. Join the list into a regex "OR" pattern: (es|nl|tx)
    codes_pattern = "|".join(allowed_codes)
    regex_pattern = rf'\s+(?=(?:{codes_pattern}):)'
    parts = re.split(regex_pattern, legends)


    buckets = []
    current_bucket = []


    for item in parts:
        if item.startswith("en: "):
            if current_bucket:  # save the previous bucket
                buckets.append(current_bucket)
            current_bucket = [item]  # start new bucket
        else:
            current_bucket.append(item)

    if current_bucket:
        buckets.append(current_bucket)


    output_data = {}
    current_en_key = None
    for bucket in buckets:
        for item in bucket:
            parts = item.split(':', 1)
            if len(parts) == 2:
                lang_code = parts[0].strip()
                content = parts[1].strip()
                
                if lang_code == 'en':
                    current_en_key = content
                    output_data[current_en_key] = {}
                else:
                    if current_en_key:
                        output_data[current_en_key][lang_code] = content

    

    return output_data
    
def get_pdf_type(pdf_path, mode):

    doc = get_doc(pdf_path, mode)

    if len(doc) <= 3:
        return "grid"
    elif 3<len(doc)<6:
        counter = 0
        grids = get_grid_bboxes(doc)

        for key in grids.keys():
            counter += len(grids[key])

        if counter > 20:
            return "grid"
        else:
            return "others"

    else:
        return "others"

def get_legends_others_grid(doc, bbox, page_no):
    text_blocks = doc[page_no].get_text("words")
    subset_text = []
    for entry in text_blocks:
        x0, y0, x1, y1, text, *_ = entry
        if is_bbox_contained((x0, y0, x1, y1), bbox):
            subset_text.append(entry)
    merge_flag = False

    data = subset_text
    sorted_data = sorted(data, key=lambda x: (x[1], x[0]))

    merged_data = merge_to_lines_with_bbox(sorted_data)
    # legends = filter_by_x0(merged_data, width)
    for block in merged_data:
        if block[4][0].islower():
            merge_flag = True
            break
    if merge_flag:
        merged_data = group_text_lines(merged_data,line_gap_factor=1.1)
    # return merged_data

    return [legend[4] for legend in merged_data]


# def extract_grid_text(doc, grid_bbox, page_no,table_bboxes):
#     text_blocks = doc[page_no].get_text("words")
#     subset_text = []
#     for entry in text_blocks:
#         x0, y0, x1, y1, text, *_ = entry
#         text_bbox = (x0, y0, x1, y1)
#         inside_table = any(is_bbox_contained(text_bbox, tb,tolerance=2) for tb in table_bboxes)

#         if is_bbox_contained(text_bbox, grid_bbox):
#             if not inside_table:
#                 subset_text.append(entry)
#     merge_flag = False

#     data = subset_text
#     sorted_data = sorted(data, key=lambda x: (x[1], x[0]))

#     merged_data = merge_to_lines_with_bbox(sorted_data)
#     # legends = filter_by_x0(merged_data, width)
#     for block in merged_data:
#         if block[4][0].islower():
#             merge_flag = True
#             break
#     if merge_flag:
#         merged_data = group_text_lines(merged_data,line_gap_factor=1.1)
#     # return merged_data

#     texts = [legend[4] for legend in merged_data]

#     texts = "\n".join(texts)

#     return texts
def reading_order_key(t, y_tol=4.0):
    x0, y0 = t[0], t[1]
    # round y to a "row band" so words on the same line group together
    row = round(y0 / y_tol)
    return (row, x0)

TEAL = [(0, 128, 143)]      

def _rgb(c):
    return (c >> 16) & 255, (c >> 8) & 255, c & 255

def _colored(rgb, min_spread=40):
    return (max(rgb) - min(rgb)) >= min_spread

def color_rects(page):
    return [fitz.Rect(s["bbox"]) for b in page.get_text("dict")["blocks"]
            if b["type"] == 0 for l in b["lines"] for s in l["spans"]
            if _colored(_rgb(s["color"]))]

def extract_grid_text(doc, page_no, bbox, crects, drop_colored=True):
    subset_text = []
    for entry in doc[page_no].get_text("words"):
        x0, y0, x1, y1, text, *_ = entry
        if not is_bbox_contained((x0, y0, x1, y1), bbox):
            continue
        # mid = fitz.Point((x0 + x1) / 2, (y0 + y1) / 2)
        # if any(r.contains(mid) for r in crects) == drop_colored:
        #     continue
        subset_text.append(entry)
    merge_flag = False

    data = subset_text
    sorted_data = sorted(data, key=reading_order_key)

    merged_data = merge_to_lines_with_bbox(sorted_data)
    # legends = filter_by_x0(merged_data, width)
    for block in merged_data:
        if block[4][0].islower():
            merge_flag = True
            break
    if merge_flag:
        merged_data = group_text_lines(merged_data,line_gap_factor=1.1)
    # return merged_data

    texts = [legend[4] for legend in merged_data]

    texts = "\n".join(texts)

    return texts