import sys
import os
import aspose.words as aw
from io import BytesIO
from pathlib import Path
from utils.blob_storage import read_file

font_settings = aw.fonts.FontSettings.default_instance
font_settings.substitution_settings.table_substitution.add_substitutes(
    "Calibri", ["Carlito"]
)

class FontWarningCallback(aw.IWarningCallback):
    def __init__(self):
        self.messages = []

    def warning(self, info):
        if info.warning_type == aw.WarningType.FONT_SUBSTITUTION:
            self.messages.append(info.description)
            print(f"[FONT] {info.description}")


def report_fonts(*names):
    """Report which fonts Aspose can actually see on THIS machine."""
    try:
        sources = aw.fonts.FontSettings.default_instance.get_fonts_sources()
        available = set()
        for s in sources:
            for f in s.get_available_fonts():
                available.add(f.font_family_name.lower())

        print(f"Fonts visible to Aspose: {len(available)}")
        for n in names:
            status = "FOUND" if n.lower() in available else "MISSING"
            print(f"  {n:<18} {status}")
    except Exception as ex:
        print(f"(font report failed: {ex})")


def debug_word_file(file_path, output_path):
    # 0) LICENSE. Without this, Aspose.Words runs in evaluation mode,
    #    which injects a watermark page and truncates long documents.
    #    That changes the page count on its own — see the note below.
    # lic = aw.License()
    # lic.set_license("Aspose.Words.lic")

    aw.fonts.FontSettings.default_instance.set_fonts_sources([
        aw.fonts.SystemFontSource(),
        aw.fonts.FolderFontSource("fonts", True),
    ])

    # 2) Report what Aspose can actually see on THIS machine.
    report_fonts("Calibri", "Cambria", "Arial", "Times New Roman")

    # 3) Load the document and attach a warning callback.
    doc_bytes = read_file(file_path)
    doc = aw.Document(BytesIO(doc_bytes))
    warnings = FontWarningCallback()
    doc.warning_callback = warnings

    # 4) page_count forces layout — substitution warnings fire here.
    pages = doc.page_count
    print(f"\n==> PAGE COUNT: {pages}")

    # # 5) Save to PDF for a visual side-by-side comparison.
    # doc.save(output_path)
    # print(f"==> Saved: {os.path.abspath(output_path)}")

    if not warnings.messages:
        print("No font-substitution warnings — fonts resolved cleanly.")
