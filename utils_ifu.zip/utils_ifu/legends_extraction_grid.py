"""Extract symbol descriptors and classify a document's symbol legends."""
from __future__ import annotations

import math
import re
import statistics
import warnings

import pymupdf as fitz
import sys
import os
from pathlib import Path
ROOT_DIR = Path(__file__).parent.parent.absolute()
sys.path.append(str(ROOT_DIR))
from utils_ifu.symbols_detection_grid import get_symbol_legend_bboxes

__all__ = ["get_symbol_descriptors", "get_symbol_legend_language_type", "LegendTextWarning"]

_LAYERS = {"Mapfold grid", "Symbol legend highlights"}
_SYMBOL = re.compile(r"^(?:LOT|REF|UDI|MD|STERILE|EC\s*REP|CH\s*REP|CR/X|MS/X)$", re.I)
_CODES = "ar az bg bn bs ca cs da de el en es et fa fi fr he hi hr hu id is it ja ka kk km ko lt lv mk ms nl no pl pt ro ru sk sl sq sr sv th tr uk ur uz vi zh".split()
_LANG = r"(?:zh[-_]cn|zh[-_]tw|" + "|".join(_CODES) + r")"
_DASH = r"[-\u2010\u2011\u2012\u2013\u2014]"
_PREFIX = re.compile(r"(?:^|/)\s*(?P<lang>" + _LANG + r")\s*" + _DASH, re.I)
_TAG_SPAN = re.compile(r"\s*(?P<lang>" + _LANG + r")\s*" + _DASH + r"\s*", re.I)
_RTL_SUFFIX = re.compile(_DASH + r"(?P<lang>ar|he|fa)(?![a-z0-9_])", re.I)
_HEADER = re.compile(r"symb|sz?[eüií]mb|s[iİ]mge|симв|σύμβ|συμβ|符[号號]|기호|記号|סמל|رمز", re.I)


class LegendTextWarning(UserWarning):
    """The PDF contains replacement characters in extracted descriptors."""


def _inside(box, region):
    return region.contains((box.tl + box.br) / 2)


def _components(rects, tolerance=.6):
    groups = []
    for rect, ink in sorted(rects, key=lambda r: r[0].y0):
        joined = []
        for i, (other, weight) in enumerate(groups):
            if (rect+(-tolerance,-tolerance,tolerance,tolerance)).intersects(other):
                rect = rect | other
                ink += weight
                joined.append(i)
        for i in reversed(joined):
            groups.pop(i)
        groups.append((rect,ink))
    return groups


def _clean(text):
    text = text.replace("\u00ad\n", "")
    text = re.sub(r"([-\u2010\u2011])\s*\n\s*", r"\1", text)
    text = re.sub(r"(?<=[\u3400-\u9fff\u0e00-\u0e7f])\n(?=[\u3400-\u9fff\u0e00-\u0e7f])", "", text)
    return re.sub(r"\s+", " ", text).strip()


def _languages(text):
    """Split at printed language tags, preserving slashes inside descriptors."""
    text = _clean(text)
    result = {}
    # Relocate a suffix-style RTL tag to its descriptor's start, including
    # when Arabic is between English and Spanish or continues on another line.
    for suffix in reversed(list(_RTL_SUFFIX.finditer(text))):
        previous = [m for m in _PREFIX.finditer(text[:suffix.start()])]
        start = 0
        if previous:
            lower = previous[-1].end()
            segment = text[lower:suffix.start()]
            rtl = re.search(r"[\u0590-\u08ff]",segment)
            # An Arabic-labelled brand name can consist entirely of Latin
            # letters, e.g. CONTROL RELEASE followed by a suffix-style tag.
            delimiter = (segment[:rtl.start()] if rtl else segment).rfind('/')
            if delimiter < 0:
                if not rtl:
                    continue
                raise ValueError('Cannot locate the start of an RTL descriptor')
            start = lower+delimiter+1
        text = (text[:start] + ' ' + suffix['lang'].lower() + '-' +
                text[start:suffix.start()] + ' ' + text[suffix.end():])
        text = text.lstrip()
    markers = list(_PREFIX.finditer(text))
    if not markers:
        return None
    if text[:markers[0].start()].strip(" /"):
        raise ValueError("Unlabelled text precedes the first language label")
    for i, marker in enumerate(markers):
        end = markers[i+1].start() if i+1 < len(markers) else len(text)
        value = _clean(text[marker.end():end]).strip(' /')
        lang = marker['lang'].lower().replace("_", "-")
        if not value:
            raise ValueError(f"Empty descriptor for language {lang!r}")
        if lang in result:
            raise ValueError(f"Repeated language {lang!r} in one symbol row; check row boundaries")
        result[lang] = value
    return result


def _text_lines(raw, region, mark_tags=False):
    result = []
    x0,y0,x1,y1=region
    for block in raw['blocks']:
        for line in block.get('lines', []):
            pieces, bounds, origins = [], [], []
            for span in line['spans']:
                chars = [c for c in span['chars'] if x0 <= (c['bbox'][0]+c['bbox'][2])/2 < x1
                         and y0 <= (c['bbox'][1]+c['bbox'][3])/2 < y1]
                if chars:
                    piece=''.join(c['c'] for c in chars)
                    tag=_TAG_SPAN.fullmatch(piece) if mark_tags else None
                    # A separate language-label span is authoritative even
                    # when bidi layout places its slash before an Arabic word.
                    pieces.append('/ '+piece if tag else piece)
                    bounds.extend(c['bbox'] for c in chars)
                    origins.extend(c['origin'][1] for c in chars)
            text = ''.join(pieces)
            if text.strip():
                rect = fitz.Rect(min(b[0] for b in bounds),min(b[1] for b in bounds),
                                 max(b[2] for b in bounds),max(b[3] for b in bounds))
                result.append((statistics.median(origins), rect, text))
    return sorted(result, key=lambda row: (row[0],row[1].x0))


def _region_text(raw, region):
    return _clean('\n'.join(text for _,_,text in _text_lines(raw, region)))


def _icons(cell, words, paths, images):
    heights = [r.height for r,t in words if t.strip()]
    h = statistics.median(heights) if heights else 8
    max_w, max_h = min(cell.width*.42,10*h), max(22,5*h)
    parts = []
    for path in paths:
        r = path['rect']
        fill, stroke = path.get('fill'), path.get('color')
        if (fill is None or min(fill)>.93) and (stroke is None or min(stroke)>.93):
            continue
        if .15<r.width<=max_w and .15<r.height<=max_h and _inside(r,cell):
            weight = len(path['items']) if any(i[0]!='re' for i in path['items']) else 0
            parts.append((r,weight))
    parts += [(r,10) for r in images if _inside(r,cell) and 2<r.width<=max_w and 2<r.height<=max_h]
    parts += [(r,10) for r,t in words if _SYMBOL.fullmatch(t)]
    icons = [r for r,n in _components(parts) if n>=3 and 2<=r.width<=max_w and 2<=r.height<=max_h]
    icons = [r for r in icons if not any(not _SYMBOL.fullmatch(t) and
             (r&w).get_area()>.65*r.get_area() for w,t in words)]
    return icons,h


def _find_tables(page, rules, **options):
    """Keep filtered graphics on PyMuPDF versions without the paths argument."""
    try:
        return page.find_tables(paths=rules, **options)
    except TypeError as exc:
        if "unexpected keyword argument 'paths'" not in str(exc):
            raise

    # Older table finders read page.get_drawings() internally. Supply the same
    # filtered paths there, on this call's private page snapshot only. Avoid
    # changing the Page class or letting the fallback use unfiltered artwork.
    missing = object()
    previous = page.__dict__.get('get_drawings', missing)
    page.get_drawings = lambda *args, **kwargs: rules[:]
    try:
        return page.find_tables(**options)
    finally:
        if previous is missing:
            del page.get_drawings
        else:
            page.get_drawings = previous


def _table_descriptors(page, cell, raw, paths, icons):
    # Feed actual rectilinear rules to the table finder. Complex outlined
    # illustrations otherwise create false columns and are costly to cluster.
    rules = [p for p in paths if p['items'] and all(
        item[0]=='re' or (item[0]=='l' and
        (abs(item[1].x-item[2].x)<.15 or abs(item[1].y-item[2].y)<.15))
        for item in p['items']) and
        ((p.get('color') is not None and min(p['color'])<.93) or
         (p.get('fill') is not None and min(p['fill'])<.93))]
    tables = _find_tables(page,rules,clip=cell,strategy='lines_strict',
                          snap_tolerance=.8,join_tolerance=1,
                          intersection_tolerance=1,edge_min_length=5).tables
    output = []
    for table in sorted(tables,key=lambda t:(t.bbox[1],t.bbox[0])):
        # A table can contain two independent symbol/description column pairs
        # with different row heights, as in the VERITAS language panels.
        taken = set()
        for column in range(table.col_count-1):
            if column in taken:
                continue
            pairs = []
            seen = set()
            for row in table.rows:
                a,b = row.cells[column:column+2]
                if a is None or b is None or tuple(b) in seen:
                    continue
                a,b = fitz.Rect(a),fitz.Rect(b)
                if b.width < a.width*1.12:
                    continue
                label,desc = _region_text(raw,a),_region_text(raw,b)
                if desc:
                    pairs.append((a,b,label,desc))
                    seen.add(tuple(b))
            header = any(_HEADER.search(label) and len(label)<15 for a,b,label,desc in pairs)
            graphic = any(any(_inside(icon,a) for icon in icons) for a,b,label,desc in pairs)
            if not (header or graphic):
                continue
            taken.update((column,column+1))
            for a,b,label,desc in pairs:
                if _HEADER.search(label) and len(label)<15:
                    continue
                # Empty symbols are usual: outlined icons have no native text.
                output.append((b,desc))
    return output


def _borderless_descriptors(cell, raw, words, icons, height):
    pairs = []
    for icon in icons:
        cy=(icon.y0+icon.y1)/2
        for side in ('right','left'):
            candidates=[(r,t) for r,t in words if r.y0-height*.25<=cy<=r.y1+height*.25
                        and ((.2<=r.x0-icon.x1<cell.width*.65) if side=='right'
                             else (.2<=icon.x0-r.x1<cell.width*.65))]
            if sum(sum(c.isalpha() for c in t) for _,t in candidates)<2:
                continue
            edge=min(r.x0 for r,t in candidates) if side=='right' else max(r.x1 for r,t in candidates)
            pairs.append((icon,side,edge))
    groups=[]
    for icon,side,edge in pairs:
        group=[r for r,s,e in pairs if s==side and abs(e-edge)<=max(3,height*.6)
               and min(r.x1,icon.x1)>max(r.x0,icon.x0)]
        if len(group)>=3:
            groups.append((group,side,edge))
    if not groups:
        return []
    group,side,edge=max(groups,key=lambda g:len(g[0]))
    bands=[]
    for r in sorted(group,key=lambda r:r.y0):
        # Merge vertically adjacent pieces of one icon, e.g. CE + 2797.
        if bands and r.y0<=bands[-1][1]+max(1.25,height*.17):
            bands[-1][1]=max(bands[-1][1],r.y1)
        else:
            bands.append([r.y0,r.y1])
    if len(bands)<3:
        return []
    centers=[(a+b)/2 for a,b in bands]
    if statistics.median(b-a for a,b in zip(centers,centers[1:]))>4*height:
        return []
    x0,x1=(max(r.x1 for r in group)+.1,cell.x1) if side=='right' else (cell.x0,min(r.x0 for r in group)-.1)
    result=[]
    for i,(a,b) in enumerate(bands):
        top=(bands[i-1][1]+a)/2 if i else a-height*.35
        bottom=(b+bands[i+1][0])/2 if i+1<len(bands) else min(cell.y1,b+3*height)
        region=fitz.Rect(x0,top,x1,bottom)
        lines=_text_lines(raw,region)
        if i==len(bands)-1 and lines:
            kept=[lines[0]]
            for line in lines[1:]:
                if line[0]-kept[-1][0]>height*1.45:
                    break
                kept.append(line)
            lines=kept
        text=_clean('\n'.join(t for _,_,t in lines))
        if text:
            result.append((region,text))
    return result


def get_symbol_descriptors(doc: fitz.Document, page_no: int, bbox) -> list[str] | list[dict[str,str]]:
    """Extract symbol descriptors inside one grid cell of an open PDF.

    page_no is ZERO-BASED. bbox is [x0,y0,x1,y1] in unrotated, CropBox-relative
    PDF points, matching get_grid_bboxes / get_symbol_legend_bboxes.
    Returns one string per monolingual symbol, or one {language: descriptor}
    dictionary per multilingual symbol. Language keys come from printed tags
    such as en-, de-, zh-cn-; text is extracted, not translated. If only one
    explicit language occurs, strings are returned. Mixed tagged/untagged
    multilingual rows raise ValueError rather than guessing language keys.

    Rows run top-to-bottom within each symbol/description column pair, then
    left-to-right through additional pairs. Table headers, symbols and nearby
    body text are excluded. Whitespace and line wraps are normalized. Native
    spelling, punctuation and encoding defects are otherwise preserved.

    Ruled tables and aligned borderless legends are supported. [] means no
    recoverable legend rows. Scans need OCR; image-only cells raise ValueError.
    Replacement characters emit LegendTextWarning. New layouts need
    review, especially unlabelled multilingual legends and outlined text.
    The caller's document is never modified, saved or closed; no files or
    highlighted images are created.
    """
    if not isinstance(doc,fitz.Document):
        raise TypeError('doc must be an open fitz.Document')
    if doc.is_closed or not doc.is_pdf or doc.is_encrypted:
        raise ValueError('doc must be an open, unlocked PDF')
    if type(page_no) is not int or not 0<=page_no<len(doc):
        raise ValueError('page_no must be a valid zero-based page index')
    try:
        coords=list(bbox)
    except TypeError as exc:
        raise ValueError('bbox must contain four finite coordinates') from exc
    if len(coords)!=4 or not all(type(x) in (int,float) and math.isfinite(x) for x in coords):
        raise ValueError('bbox must contain four finite coordinates')
    cell=fitz.Rect(coords)
    if cell.is_empty:
        raise ValueError('bbox must have x0 < x1 and y0 < y1')
    with fitz.open(stream=doc.tobytes(),filetype='pdf') as copy:
        page=copy[page_no]
        page.set_rotation(0)
        if not (page.rect+(-.1,-.1,.1,.1)).contains(cell):
            raise ValueError('bbox must lie inside the unrotated visible page')
        flags=fitz.TEXTFLAGS_RAWDICT & ~fitz.TEXT_PRESERVE_IMAGES
        raw=page.get_text('rawdict',clip=cell,flags=flags)
        words=[(fitz.Rect(w[:4]),w[4]) for w in page.get_text('words',clip=cell) if w[4].strip()]
        paths=[p for p in page.get_drawings() if p.get('layer') not in _LAYERS and
               (p['rect'].intersects(cell) or _inside(p['rect'],cell))]
        images=[fitz.Rect(im['bbox']) for im in page.get_image_info() if fitz.Rect(im['bbox']).intersects(cell)]
        if not words:
            if images:
                raise ValueError('This cell has no searchable text; OCR is required')
            return []
        icons,height=_icons(cell,words,paths,images)
        rows=_table_descriptors(page,cell,raw,paths,icons)
        if not rows:
            rows=_borderless_descriptors(cell,raw,words,icons,height)
        texts=[text for _,text in rows]
        if any('\ufffd' in text for text in texts):
            warnings.warn('PDF text includes replacement characters; inspect this cell or use OCR.',LegendTextWarning,stacklevel=2)
        parsed=[_languages('\n'.join(t for _,_,t in _text_lines(raw,r,mark_tags=True))) for r,text in rows]
        languages={lang for value in parsed if value for lang in value}
        if len(languages)>1:
            if any(value is None for value in parsed):
                raise ValueError('Multilingual legend contains unlabelled rows; language keys cannot be inferred safely')
            return parsed
        return [next(iter(value.values())) if value else text for value,text in zip(parsed,texts)]


def _classify_legend_cell(doc, page_no, bbox):
    """Classify only the descriptors belonging to this legend cell."""
    descriptors = get_symbol_descriptors(doc, page_no, bbox)
    if not descriptors:
        raise ValueError("No recoverable symbol descriptors in this grid; cannot classify its languages")
    languages = {language for row in descriptors if isinstance(row, dict) for language in row}
    return "multilingual" if len(languages) > 1 else "non multilingual"


def get_symbol_legend_language_type(doc: fitz.Document) -> str:
    """Return one 'multilingual' or 'non multilingual' label for an open PDF.

    Detect symbol-legend grids internally, then classify their descriptors.
    Any legend cell with multiple printed language tags makes the document
    'multilingual'; return immediately on that evidence. Otherwise all
    detected cells must be inspected before returning 'non multilingual'.
    Languages are not pooled across cells: separate single-language legends
    on different pages or panels remain 'non multilingual'. Only legend
    descriptors contribute, not symbol codes, headings or surrounding prose.

    This uses the existing extractor's printed language tags, not general
    language identification. Untagged translations can be misclassified as
    'non multilingual'. No detected legends or no recoverable descriptors
    raises ValueError rather than implying a single-language document.
    Detection/extraction errors and warnings propagate, including OCR needs
    and ambiguous mixed tagged/untagged rows. The caller's document remains
    open and unchanged; no files are written.

    Keep symbol_legends.py and grid_ifu.py alongside this module and install
    PyMuPDF and NumPy. The descriptor-only API does not need these modules.
    """
    legend_grids = get_symbol_legend_bboxes(doc)
    found = False
    for page_no, boxes in legend_grids.items():
        for bbox in boxes:
            if _classify_legend_cell(doc, page_no, bbox) == "multilingual":
                return "multilingual"
            found = True
    if not found:
        raise ValueError("No symbol legends detected in this document; cannot classify its languages")
    return "non multilingual"
