import sys
import numpy as np
from pathlib import Path
import pandas as pd

import re
ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR))

from utils_ifu.utils import split_lists_with_overlap
from utils_ifu.embeddings import match_lists_by_embeddings, filter_rows, prepare_A_side, match_with_new_B
from utils_ifu.genai import safe_scoring
from utils_ifu.processing import restructure_text
def perform_semantic_analysis(translated_json, mapper_en_translated, llm_structured):
    semantic_analysis = {}

    for to_lan in translated_json.keys():

        # vendor lines (list of lines)
        if to_lan == 'ar':
            vendor = restructure_text(translated_json[to_lan]['vendor'], 'ar').splitlines()

        else:
            vendor = restructure_text(translated_json[to_lan]['vendor']).splitlines()

        df_translated = mapper_en_translated[to_lan]

        # Ensure df_translated has the column "translated" (or adapt accordingly)
        translated = df_translated["translated"].tolist()

        # create overlapping chunks
        translated_parts, vendor_parts = split_lists_with_overlap(translated, vendor)
        all_pairs = []
        for idx in range(len(translated_parts)):
            linesA = translated_parts[idx]
            linesB = vendor_parts[idx]
            all_pairs.append([linesA, linesB])

        # accumulate matches found by embeddings
        # initialize with column names to keep things deterministic
        full_pairs_df = pd.DataFrame(columns=["translated", "vendor"])

        for i in range(len(all_pairs)):
            text1, text2 = all_pairs[i]
            pairs = match_lists_by_embeddings(text1, text2, max_span=2, similarity_threshold=0.6)
            if not pairs:
                continue
            df_pairs = pd.DataFrame(pairs)
            # guard: ensure df_pairs has exactly 2 columns before renaming
            if df_pairs.shape[1] >= 2:
                df_pairs = df_pairs.iloc[:, :2]
                df_pairs.columns = ["translated", "vendor"]
            else:
                # skip malformed result
                continue

            full_pairs_df = pd.concat([full_pairs_df, df_pairs], ignore_index=True)
            
        full_pairs_df = full_pairs_df[
                            full_pairs_df.apply(lambda r: filter_rows(r, 10), axis=1)
                        ]

        

        # If nothing matched, continue with empty result
        if full_pairs_df.empty:
            semantic_analysis[to_lan] = full_pairs_df
            continue

        # Map translated -> original using existing mapper
        # Ensure mapper_en_translated[to_lan] has appropriate columns before renaming
        df = mapper_en_translated[to_lan].copy()
        # If df has two columns but names are different, rename as needed:
        # expected: ["original", "translated"]
        if df.shape[1] >= 2:
            df = df.iloc[:, :2]
            df.columns = ["original", "translated"]
        else:
            raise ValueError(f"mapper_en_translated[{to_lan}] must have at least 2 columns")

        translated_text = full_pairs_df['translated'].astype(str)
        original_text = df["original"].astype(str)

        # prepare index or structure expected by match_with_new_B
        translated_index = prepare_A_side(translated_text)
        result1 = match_with_new_B(translated_index, original_text)

        # result1 expected to be iterable of (translated, original) pairs
        df_mapper = pd.DataFrame(result1)
        if df_mapper.shape[1] >= 2:
            df_mapper = df_mapper.iloc[:, :2]
            df_mapper.columns = ['translated', 'original']
        else:
            # If mapping failed, keep empty and continue
            semantic_analysis[to_lan] = pd.DataFrame()
            continue

        # merge pairs with mapper to get original text for each translated row
        full_df = full_pairs_df.merge(df_mapper, on='translated', how='inner')

        # compute score and remark using safe_scoring(llm_structured, row) which should return (score, remark)
        # apply and expand into columns
        scores_series = full_df.apply(lambda row: pd.Series(safe_scoring(llm_structured, row)), axis=1)
        # ensure we have two columns from safe_scoring
        if scores_series.shape[1] >= 2:
            scores_series.columns = ['score', 'remark', 'category']
        else:
            # if safe_scoring returns single value, put it in 'score' and remark empty
            scores_series = scores_series.rename(columns={0: 'score'})
            scores_series['remark'] = None

        full_df = pd.concat([full_df.reset_index(drop=True), scores_series.reset_index(drop=True)], axis=1)

        # cast score to nullable integer if possible
        try:
            full_df['score'] = full_df['score'].astype('Int64')
            full_df = full_df[full_df['score'] < 5]

        except Exception:
            # leave as-is if cast fails
            pass

        print("^"*20)
        # show dtypes and sample problematic values
        print("dtype of score column:", full_df['score'].dtype)
        print("unique types in score column:", full_df['score'].apply(type).value_counts().to_dict())
        # show a few examples that are not numeric
        non_numeric_mask = pd.to_numeric(full_df['score'], errors='coerce').isna()
        print("rows with non-numeric score (first 10):")
        print(full_df.loc[non_numeric_mask].head(10))
        print("^"*20)


        #full_df = full_df.sort_values(by='score', ascending=False).reset_index(drop=True)

        semantic_analysis[to_lan] = full_df

    return semantic_analysis