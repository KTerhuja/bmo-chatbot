"""
Author partial label boxes for "special case" symbols.

Some symbols pair a glyph with adjacent text (e.g. "RX only", where "only" may sit to
the RIGHT of - or BELOW - the "RX"). Training the detector on the WHOLE artwork as a
single class confuses it, while training on the bare glyph misses the real-world
context the text provides. The approach used by create_dataset.py is to paste the FULL
artwork but label only the meaningful part (the "RX"); OCR then decides the exact
variant (horizontal vs vertical) in post-processing.

This script lets you draw that partial box once per symbol and saves the result to
object_detection/roi_special_cases.json, e.g.:

    {
      "RX_ONLY.png":                {"class": "RX", "bbox": [x1, y1, x2, y2]},
      "0258 - RX Only Vertical.png": {"class": "RX", "bbox": [x1, y1, x2, y2]}
    }

`bbox` is in the native pixel space of each PNG. Re-running adds/overwrites only the
entries listed in SPECIAL_CASES below and keeps any others already in the file.

Controls (selection window):
    drag           draw the box around the part to label
    ENTER / SPACE  confirm
    c              cancel the current symbol (its previous value, if any, is kept)
"""
import os
import json
from pathlib import Path

import cv2

ROOT_DIR = Path(__file__).parent.parent.absolute()  # repo root (new_repo)

# Symbols needing a partial label box -> the class the model should predict for them.
# Several files may map to the same class. Add more entries here as needed.
SPECIAL_CASES = {
    "RX_ONLY.png": "RX",                  # "RX only" horizontal ("only" to the right)
    "0258 - RX Only Vertical.png": "RX",  # "RX only" vertical ("only" below)
    "CE Mark 0344 Vertical.png": "CE",  # "CE 0344" vertical ("0344" below)
    "0058 - CE 0120 horizontal.png": "CE",  # "CE 0120" horizontal ("0120" to the right)
    "CE 0086 vertical.png": "CE",  # "CE 0086" vertical ("0086" below)
    "0057 - CE 0086 horizontal.png": "CE",  # "CE 0086" horizontal ("0086" to the right)
    "0323 - eIFU Indicator_Horizontal.png": "IFU",
    "0009 - i book GEN11.png": "IFU",
    "N_PC (boxed).png": "N_PC"
}

SYMBOL_DIR = os.path.join(ROOT_DIR, "data", "object_detection_symbols")
OUTPUT_JSON = os.path.join(ROOT_DIR, "object_detection", "roi_special_cases.json")

# Symbols are small; enlarge them so the box is easy to draw accurately.
DISPLAY_MIN_SIDE = 600


def author_box(filename: str, class_name: str, manifest: dict) -> None:
    """Prompt for a box on one symbol and store {class, bbox} in `manifest`."""
    path = os.path.join(SYMBOL_DIR, filename)
    img = cv2.imread(path)
    if img is None:
        print(f"  ! could not read {path} - skipping")
        return

    h, w = img.shape[:2]
    scale = max(1.0, DISPLAY_MIN_SIDE / min(h, w))
    disp = cv2.resize(img, (int(round(w * scale)), int(round(h * scale))),
                      interpolation=cv2.INTER_NEAREST)

    window = f"Draw box around the labelled part - {filename}  (ENTER=confirm, c=cancel)"
    rx, ry, rw, rh = cv2.selectROI(window, disp, showCrosshair=True, fromCenter=False)
    cv2.destroyWindow(window)

    if rw == 0 or rh == 0:
        print(f"  - {filename}: cancelled, leaving as-is")
        return

    # Convert the display-space ROI back to native pixel coordinates and clamp.
    x1 = max(0, min(int(round(rx / scale)), w))
    y1 = max(0, min(int(round(ry / scale)), h))
    x2 = max(0, min(int(round((rx + rw) / scale)), w))
    y2 = max(0, min(int(round((ry + rh) / scale)), h))

    manifest[filename] = {"class": class_name, "bbox": [x1, y1, x2, y2]}
    print(f"  + {filename}: class={class_name} bbox=[{x1}, {y1}, {x2}, {y2}]")

    # Quick confirmation preview (press any key to continue).
    preview = disp.copy()
    cv2.rectangle(preview,
                  (int(x1 * scale), int(y1 * scale)),
                  (int(x2 * scale), int(y2 * scale)),
                  (0, 0, 255), 2)
    pv_window = f"Result - {filename}  (press any key)"
    cv2.imshow(pv_window, preview)
    cv2.waitKey(0)
    cv2.destroyWindow(pv_window)


def main() -> None:
    # Preserve existing entries so the script can be re-run for a subset.
    manifest = {}
    if os.path.exists(OUTPUT_JSON):
        with open(OUTPUT_JSON) as f:
            manifest = json.load(f)

    print(f"Authoring {len(SPECIAL_CASES)} special-case box(es).")
    for filename, class_name in SPECIAL_CASES.items():
        print(f"- {filename}")
        author_box(filename, class_name, manifest)

    os.makedirs(os.path.dirname(OUTPUT_JSON), exist_ok=True)
    with open(OUTPUT_JSON, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"\nSaved manifest with {len(manifest)} entr(ies) -> {OUTPUT_JSON}")


if __name__ == "__main__":
    main()
