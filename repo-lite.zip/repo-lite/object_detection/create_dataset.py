import os
import json
import random
import cv2
import numpy as np
from pathlib import Path
import shutil
import string
import barcode
from barcode.writer import ImageWriter
from PIL import Image
from pylibdmtx.pylibdmtx import encode
from io import BytesIO
from math import floor, ceil

import sys
ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 
from utils.utils import show_img #for debugging
from object_detection.yolo_detect import get_quadrants

def check_overlap(image:np.ndarray, sub_image:np.ndarray, x, y, threshold=230):
    """Check if the image we are trying to paste touches anything else"""
    h, w = image.shape[:2]
    h_s, w_s = sub_image.shape[:2]

    if x<0 or x+w_s>=w or y<0 or y+h_s>=h:
        return False 
    
    if image.ndim > 2:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) 
    if sub_image.ndim > 2:
        sub_image = cv2.cvtColor(sub_image, cv2.COLOR_BGR2GRAY) 
    
    region = image[y:y+h_s, x:x+w_s]
    success = not np.any(np.logical_and(region < threshold, sub_image < threshold))
    return success

def paste_transparent(image: np.ndarray, sub_image: np.ndarray, x: int, y: int, opacity: float = 1.0) -> np.ndarray:
    """
    Paste color `sub_image` onto `image` at (y, x),
    treating white pixels (>=250,250,250) in the sub_image as transparent.
    `opacity` (0-1) controls how strongly the symbol is blended over the
    background: 1.0 is fully opaque, lower values let the background show through.
    """
    sub_image = cv2.cvtColor(sub_image, cv2.COLOR_GRAY2BGR).copy()
    fh, fw = sub_image.shape[:2]
    roi = image[y:y+fh, x:x+fw]

    # Create mask of non-white pixels (True where pixel is not white)
    mask = np.any(sub_image < 250, axis=2)  # shape: (fh, fw)

    # Expand mask to shape (fh, fw, 3) for broadcasting
    mask_3ch = mask[..., None]

    # Blend the symbol over the background according to the requested opacity
    blended = (opacity * sub_image.astype(np.float32) +
               (1.0 - opacity) * roi.astype(np.float32)).astype(roi.dtype)

    # Use np.where for pixel-wise fusion
    fused = np.where(mask_3ch, blended, roi)

    image[y:y+fh, x:x+fw] = fused

def resize_short_side(img: np.ndarray, target: int = 110) -> np.ndarray:
    """
    Resize `img` so its short side equals `target` pixels, preserving aspect ratio.
    Brings variably sized symbols up to the same scale as the fixed 110x110
    object-detection symbols.
    """
    h, w = img.shape[:2]
    short = min(h, w)
    if short == 0:
        return img
    factor = target / short
    new_w = max(1, round(w * factor))
    new_h = max(1, round(h * factor))
    return cv2.resize(img, (new_w, new_h))

def load_symbol_on_white(path: str) -> np.ndarray:
    """
    Load a symbol image as single-channel grayscale, flattening any transparency
    onto a white background. Symbols stored light-on-dark (inverted) are flipped
    to the dark-on-white convention used by the rest of the pipeline so that
    white can be treated as transparent.
    """
    with Image.open(path) as im:
        if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
            im = im.convert("RGBA")
            background = Image.new("RGBA", im.size, (255, 255, 255, 255))
            im = Image.alpha_composite(background, im).convert("L")
        else:
            im = im.convert("L")
        g = np.array(im)

    # Detect inverted (light-on-dark) symbols by sampling the corner patches,
    # which almost always belong to the background.
    h, w = g.shape[:2]
    p = max(1, min(5, h, w))
    corners = np.concatenate([
        g[:p, :p].ravel(), g[:p, -p:].ravel(),
        g[-p:, :p].ravel(), g[-p:, -p:].ravel(),
    ])
    if np.median(corners) < 128:
        g = 255 - g
    return g

def crop_white_edges(img: np.ndarray, square=False):
    """
    Crop white edges from the image
    """
    h, w = img.shape
    rows = np.any(img < 255, axis=1)
    cols = np.any(img < 255, axis=0)
    pad = 4 # Padding of white allowed
    top = max(0, np.argmax(rows) - pad )# np.argmax(rows) gives the first ocurrence of a non-all-white row
    bottom = min(len(rows), len(rows) - np.argmax(rows[::-1]) + pad)
    left = max(0, np.argmax(cols) - pad)
    right = min(len(cols), len(cols) - np.argmax(cols[::-1]) + pad)
    if not square or (right-left) == (top-bottom):
        return img[top:bottom, left:right]
    else:
        delta = abs((right-left)-(bottom-top))
        if right-left < bottom-top:
            delta_1 = min(floor(delta/2), left)
            delta_2 = min(ceil(delta/2), w - right)
            return img[top:bottom, left-delta_1:right+delta_2]
        else:
            delta_1 = min(floor(delta/2), top)
            delta_2 = min(ceil(delta/2), h - bottom)
            return img[top-delta_1:bottom+delta_2, left:right]


def generate_dataset(
    background_dir,
    symbol_images_dir,
    needle_images_dir,
    output_dir,
    ep_symbol_images_dir=None,
    num_train_samples=800,
    num_val_samples=200,
    min_scale=0.05,
    max_scale=0.2,
    max_attempts=100,
    n_min=1,
    n_max=5,
    special_cases_path=None,
    draw_bboxes=False,
):
    """
    Generate a dataset with train and validation splits for YOLO training.
    
    Args:
        background_dir: Directory with background images
        symbol_images_dir: Directory with fixed-size (110x110) symbol images to paste
        ep_symbol_images_dir: Directory with variable-size EP symbol images. They are
            resized on the fly so their short side is 110 px to match the scale of
            the fixed-size symbols.
        output_dir: Root directory for output dataset
        num_train_samples: Number of training samples to generate
        num_val_samples: Number of validation samples to generate
        min_scale: Minimum scale factor for symbol images
        max_scale: Maximum scale factor for symbol images
        max_attempts: Maximum attempts to find a white area
        n_min: Minimum number of objects per image
        n_max: Maximum number of objects per image
        special_cases_path: Path to the JSON manifest of special-case symbols whose
            label box should cover only PART of the artwork (e.g. the "RX" inside an
            "RX only" symbol). Maps "<file>.png" -> {"class": <class>, "bbox":
            [x1, y1, x2, y2]} with bbox in the PNG's native pixels. Produced by
            object_detection/select_roi_special_cases.py. Defaults to
            object_detection/roi_special_cases.json.
        draw_bboxes: When True, also write copies of each generated image with the
            YOLO label boxes drawn on, under <output_dir>/bbox_check, for quick
            visual verification.
    """
    # Create output directories with YOLO structure
    train_images_dir = os.path.join(output_dir, "train", "images")
    train_labels_dir = os.path.join(output_dir, "train", "labels")
    val_images_dir = os.path.join(output_dir, "val", "images")
    val_labels_dir = os.path.join(output_dir, "val", "labels")

    shutil.rmtree(output_dir, ignore_errors=True)
    os.makedirs(train_images_dir, exist_ok=True)
    os.makedirs(train_labels_dir, exist_ok=True)
    os.makedirs(val_images_dir, exist_ok=True)
    os.makedirs(val_labels_dir, exist_ok=True)
    
    # Get lists of background and symbol images
    background_images = [f for f in os.listdir(background_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    
    # Fixed-size (110x110) object-detection symbols
    od_symbol_files = [f for f in os.listdir(symbol_images_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    # Variable-size EP symbols (resized on the fly so the short side is 110 px)
    ep_symbol_files = []
    if ep_symbol_images_dir and os.path.isdir(ep_symbol_images_dir):
        ep_symbol_files = [f for f in os.listdir(ep_symbol_images_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    # Resolve and load the special-case manifest: symbols whose label box should
    # cover only PART of the artwork (e.g. the "RX" inside an "RX only" symbol). Maps
    # "<file>.png" -> {"class": <class>, "bbox": [x1, y1, x2, y2]} with bbox in the
    # PNG's native pixel space. Produced by select_roi_special_cases.py.
    if special_cases_path is None:
        special_cases_path = os.path.join(ROOT_DIR, "object_detection", "roi_special_cases.json")
    special_cases = {}
    if os.path.exists(special_cases_path):
        with open(special_cases_path) as f:
            special_cases = json.load(f)
        print(f"Loaded {len(special_cases)} special-case symbol(s) from {special_cases_path}")

    def file_class(filename):
        """Class a symbol file maps to: the manifest class for special cases,
        otherwise the filename stem (e.g. 'BP.png' -> 'BP')."""
        if filename in special_cases:
            return special_cases[filename]['class']
        return filename.split('.')[0]

    # Build the ordered, de-duplicated class list. Several special-case files can map
    # to one class (e.g. both RX-only variants -> 'RX'), which may also already exist
    # from a normal file ('RX.png'), so duplicates must be collapsed.
    class_names = []
    for f in od_symbol_files + ep_symbol_files:
        name = file_class(f)
        if name not in class_names:
            class_names.append(name)
    for special_class in ['NEEDLE', 'BARCODE', 'DATAMATRIX']: # Special non-file classes
        if special_class not in class_names:
            class_names.append(special_class)

    # Create mapping from class name to class id
    code_to_class_id = {code: idx for idx, code in enumerate(class_names)}

    # Map every selectable symbol file to its source directory and whether it needs
    # dynamic short-side resizing: EP symbols do, the fixed-size symbols do not.
    symbol_sources = {}
    for f in od_symbol_files:
        if file_class(f) in class_names:
            symbol_sources[f] = (symbol_images_dir, False)
    for f in ep_symbol_files:
        if file_class(f) in class_names:
            symbol_sources[f] = (ep_symbol_images_dir, True)

    # Get symbol images that match our codes
    symbol_images = list(symbol_sources.keys())
    # needle_images = [f for f in os.listdir(needle_images_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg')) and f.startswith('needle_')]
    needle_images = [f for f in os.listdir(needle_images_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    if not background_images:
        print(f"No background images found in {background_dir}")
        return
    
    if not symbol_images:
        print(f"No symbol images found in {symbol_images_dir}")
        return
    
    if not needle_images:
        print(f"No symbol images found in {needle_images_dir}")
        return
    
    # Split background images into train and validation sets
    train_backgrounds = background_images
    val_backgrounds = background_images
    
    print(f"Found {len(background_images)} background images")
    print(f"Found {len(symbol_images)} symbol images")
    print(f"Found {len(needle_images)} needle images")

    def make_augmented_symbol(scale, rotation=None):
        """Build a single random NON-needle/barcode/datamatrix symbol at the given
        scale, applying the same general augmentations (crop, rotation, pledget
        rotation) as the main placement loop. Used to build cluttered lines/columns
        of symbols. When `rotation` is given (0/90/180/270) it is used instead of a
        random one, so a whole cluster can share one orientation. Returns
        (symbol_img_resized, class_id, label_mask)."""
        img_file = random.choice(symbol_images)
        src_dir, dynamic_resize = symbol_sources[img_file]
        img_path = os.path.join(src_dir, img_file)

        special = special_cases.get(img_file)
        class_key = special['class'] if special else img_file.split('.')[0]
        label_mask = None

        if dynamic_resize:
            symbol_img = load_symbol_on_white(img_path)
            if special:
                label_mask = np.zeros(symbol_img.shape[:2], dtype=np.uint8)
                bx1, by1, bx2, by2 = special['bbox']
                label_mask[by1:by2, bx1:bx2] = 255
                label_mask = resize_short_side(label_mask, 110)
            symbol_img = resize_short_side(symbol_img, 110)
        else:
            symbol_img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if special:
                label_mask = np.zeros(symbol_img.shape[:2], dtype=np.uint8)
                bx1, by1, bx2, by2 = special['bbox']
                label_mask[by1:by2, bx1:bx2] = 255

        class_id = code_to_class_id[class_key]

        if label_mask is None:
            symbol_img = crop_white_edges(symbol_img)

        symbol_height, symbol_width = symbol_img.shape[:2]
        new_w = max(1, int(symbol_width * scale))
        new_h = max(1, int(symbol_height * scale))
        symbol_img_resized = cv2.resize(symbol_img, (new_w, new_h))
        if label_mask is not None:
            label_mask = cv2.resize(label_mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)

        rotation = random.choice([0, 90, 180, 270]) if rotation is None else rotation
        if rotation > 0:
            rot_map = {90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}
            symbol_img_resized = cv2.rotate(symbol_img_resized, rot_map[rotation])
            if label_mask is not None:
                label_mask = cv2.rotate(label_mask, rot_map[rotation])

        if class_key.startswith("PLED"):
            angle = random.randint(1, 90)
            symbol_img_resized = rotate_bound(symbol_img_resized, angle)

        return symbol_img_resized, class_id, label_mask

    def cluster_annotation(nx, ny, c_img, c_class_id, c_mask, bg_width, bg_height):
        """YOLO annotation string for a clustered symbol pasted at (nx, ny)."""
        c_h, c_w = c_img.shape[:2]
        if c_mask is not None:
            mask_bin = (c_mask >= 128).astype(np.uint8)
            bx, by, bw, bh = cv2.boundingRect(mask_bin)
            if bw > 0 and bh > 0:
                cx, cy, ww, hh = xywh2yolo(nx + bx, ny + by, bw, bh, bg_width, bg_height)
            else:
                cx, cy, ww, hh = xywh2yolo(nx, ny, c_w, c_h, bg_width, bg_height)
        else:
            cx, cy, ww, hh = xywh2yolo(nx, ny, c_w, c_h, bg_width, bg_height)
        return f"{c_class_id} {cx:.6f} {cy:.6f} {ww:.6f} {hh:.6f}"

    # Function to generate samples for a specific partition
    def generate_partition_samples(
        backgrounds,
        output_images_dir,
        output_labels_dir,
        num_samples,
        prefix
    ):
        generated = 0
        
        for i in range(num_samples):
            # Select random background image
            bg_img_path = os.path.join(background_dir, random.choice(backgrounds))
            bg_img = cv2.imread(bg_img_path)
            bg_height, bg_width = bg_img.shape[:2]
            
            bg_imgs = []
            quadrants = get_quadrants(bg_width, bg_height)
            bg_imgs = []
            for x1, y1, x2, y2 in quadrants:
                # Crop the quadrant
                quadrant_img = bg_img[y1:y2, x1:x2].copy()  # Copy to ensure contiguous memory
                bg_imgs.append(quadrant_img)

            for q, bg_img in  enumerate(bg_imgs):
                bg_height, bg_width = bg_img.shape[:2] # Recalculate width and height
                # Random number of objects to place
                num_objects = random.randint(n_min, n_max)
                
                # Keep track of annotations for this image
                annotations = []
                
                # Whether the once-per-image "cluttered" line/column of symbols has
                # already been generated for this image.
                cluster_done = False

                # Place multiple objects on the image
                needle_pct = .30
                bcode_dmtx_pct = .10
                for j in range(num_objects):
                    label_mask = None  # set only for special-case symbols whose label
                                       # box covers part of the artwork (e.g. RX in "RX only")
                    if j<=num_objects*needle_pct: # First add needle images. 35% of the objects in the image
                        # Select random needle image
                        img_file = random.choice(needle_images)
                        img_path = os.path.join(needle_images_dir, img_file)
            
                        class_key = "NEEDLE"
                        scale = random.uniform(0.9, 1.1)
                        scale = random.uniform(0.3, 0.4)
                        # Read image
                        symbol_img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                    elif j<=num_objects*(needle_pct + bcode_dmtx_pct): # Add random barcodes and data matrices
                        if random.random()<.5:
                            class_key = 'BARCODE'
                            symbol_img = generate_random_barcode()
                        else:
                            class_key = "DATAMATRIX"
                            symbol_img = generate_random_datamatrix()
                        scale = random.uniform(.7, 2)
                    else:
                        # Select random symbol image
                        img_file = random.choice(symbol_images)
                        src_dir, dynamic_resize = symbol_sources[img_file]
                        img_path = os.path.join(src_dir, img_file)
                    
                        # Special-case symbols map to a class via the manifest and
                        # carry a partial label box; normal symbols use the filename.
                        special = special_cases.get(img_file)
                        class_key = special['class'] if special else img_file.split('.')[0]  # e.g. "BP"
                        scale = random.uniform(min_scale, max_scale)
                        if dynamic_resize:
                            # EP symbols come in many sizes and may have transparent or
                            # inverted backgrounds. Flatten onto white and normalize so
                            # the short side is 110 px, matching the fixed-size symbols.
                            symbol_img = load_symbol_on_white(img_path)
                            if special:
                                # Build the label mask before the short-side resize, then
                                # resize it identically so it tracks the artwork.
                                label_mask = np.zeros(symbol_img.shape[:2], dtype=np.uint8)
                                bx1, by1, bx2, by2 = special['bbox']
                                label_mask[by1:by2, bx1:bx2] = 255
                                label_mask = resize_short_side(label_mask, 110)
                            symbol_img = resize_short_side(symbol_img, 110)
                        else:
                            # Read image
                            symbol_img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                            if special:
                                # bbox is in this PNG's native pixel space, which matches
                                # the freshly loaded symbol_img.
                                label_mask = np.zeros(symbol_img.shape[:2], dtype=np.uint8)
                                bx1, by1, bx2, by2 = special['bbox']
                                label_mask[by1:by2, bx1:bx2] = 255
            
                    # Get class ID from the key
                    class_id = code_to_class_id[class_key]

                    # Tighten the bounding box. Special-case symbols keep their full
                    # extent (including adjacent text) so the partial label mask stays
                    # aligned; their label comes from the mask, not the ink outline.
                    if label_mask is None:
                        symbol_img = crop_white_edges(symbol_img)
                    
                    symbol_height, symbol_width = symbol_img.shape[:2]
                    
                    # Random scale
                    
                    new_symbol_width = int(symbol_width * scale)
                    new_symbol_height = int(symbol_height * scale)
                    
                    # Make sure the new size is at least 1x1
                    new_symbol_width = max(1, new_symbol_width)
                    new_symbol_height = max(1, new_symbol_height)

                    # Resize symbol image 
                    # This is after double_needle to keep shift consistent
                    symbol_img_resized = cv2.resize(symbol_img, (new_symbol_width, new_symbol_height))
                    if label_mask is not None:
                        # Nearest-neighbour keeps the mask binary as it tracks the symbol
                        label_mask = cv2.resize(label_mask, (new_symbol_width, new_symbol_height), interpolation=cv2.INTER_NEAREST)
                    
                    shift = int(100*scale)
                    if class_key == "NEEDLE" and False: #Erosion disabled (new needle images don't seem to need it)
                        iter = random.choice([0, 1, 2]) #[0, 1, 2]
                        kernel = np.ones((2, 2), np.uint8) 
                        symbol_img_resized = cv2.erode(symbol_img_resized, kernel, iterations=iter) 

                    # Random rotation (90 degree intervals). Applied to special-case
                    # symbols too: labels are not guaranteed upright and the downstream
                    # post-processing keys off the detected symbol orientation.
                    rotation = random.choice([0, 90, 180, 270])
                    if rotation > 0:
                        symbol_img_resized = cv2.rotate(symbol_img_resized, 
                                                    {90: cv2.ROTATE_90_CLOCKWISE, 
                                                    180: cv2.ROTATE_180, 
                                                    270: cv2.ROTATE_90_COUNTERCLOCKWISE}[rotation])
                        if label_mask is not None:
                            label_mask = cv2.rotate(label_mask, 
                                                    {90: cv2.ROTATE_90_CLOCKWISE, 
                                                    180: cv2.ROTATE_180, 
                                                    270: cv2.ROTATE_90_COUNTERCLOCKWISE}[rotation])
                    
                    # Pledget images can be rotated at any angle
                    if class_key.startswith("PLED"):
                        angle = random.randint(1, 90)
                        symbol_img_resized = rotate_bound(symbol_img_resized, angle)


                    # Update dimensions after rotation if needed
                    symbol_height_final, symbol_width_final = symbol_img_resized.shape[:2]
                    
                    # Find a suitable white area to paste the symbol image
                    placed = False
                    for _ in range(max_attempts):
                        # Random position
                        if bg_width - symbol_width_final < 0 or bg_height - symbol_height_final < 0:
                            break # Symbol dimension too large
                        x = random.randint(0, bg_width - symbol_width_final)
                        y = random.randint(0, bg_height - symbol_height_final)
                        
                        # Check if the area in the bg_img image is white to avoid overlapping objects
                        if check_overlap(bg_img, symbol_img_resized, x, y):
                            placed = True
                            break
                    
                    if not placed:
                        print(f"Warning: Could not find a suitable white area for object {j} in {prefix} sample {i}")
                        continue
                    
                    # Random opacity so symbols blend into the background to varying degrees
                    opacity = random.uniform(0.6, 1.0)

                    # Paste the symbol image onto the bg_img
                    # symbol_img_resized = cv2.cvtColor(symbol_img_resized, cv2.COLOR_GRAY2BGR)
                    paste_transparent(bg_img, symbol_img_resized, x, y, opacity)
                    # bg_img[y:y+symbol_height_final, x:x+symbol_width_final] = symbol_img_resized
                    
                    if label_mask is not None:
                        # Label box = bounding rect of the transformed ROI mask, offset
                        # to the paste position. Covers only the meaningful part of the
                        # artwork (e.g. the "RX") while the full symbol - including the
                        # adjacent text - is rendered around it for context.
                        mask_bin = (label_mask >= 128).astype(np.uint8)
                        bx, by, bw, bh = cv2.boundingRect(mask_bin)
                        if bw > 0 and bh > 0:
                            center_x, center_y, bb_width, bb_height = xywh2yolo(x+bx, y+by, bw, bh, bg_width, bg_height)
                        else:
                            center_x, center_y, bb_width, bb_height = xywh2yolo(x,y,symbol_width_final,symbol_height_final,bg_width,bg_height)
                    else:
                        center_x, center_y, bb_width, bb_height = xywh2yolo(x,y,symbol_width_final,symbol_height_final,bg_width,bg_height)
                    annotations.append(f"{class_id} {center_x:.6f} {center_y:.6f} {bb_width:.6f} {bb_height:.6f}")

                    ### CLUTTERED CLUSTER OF SYMBOLS
                    # Roughly once per image, instead of scattering symbols randomly,
                    # butt a run of 3-5 symbols directly against the one just placed to
                    # mimic the tightly packed symbol groups seen in real images. The
                    # run grows to the right (a line) or, with 50% probability,
                    # downward (a column). Every symbol reuses the current `scale` but
                    # gets its own general augmentations; needles/barcodes/datamatrices
                    # are excluded. Stops early if the next symbol would hit the
                    # background or an existing symbol.
                    if (not cluster_done
                            and class_key not in ("NEEDLE", "BARCODE", "DATAMATRIX")
                            and random.random() < 1.0 / max(1, num_objects)*2): # Multiplied by 2 because it seemed too rare
                        cluster_done = True
                        make_column = random.random() < 0.5
                        n_cluster = random.randint(4, 7)
                        last_x, last_y = x, y
                        last_w, last_h = symbol_width_final, symbol_height_final
                        for _ in range(n_cluster - 1):
                            c_img, c_class_id, c_mask = make_augmented_symbol(scale, rotation=rotation)
                            c_h, c_w = c_img.shape[:2]
                            if make_column:
                                nx, ny = last_x, last_y + last_h
                            else:
                                nx, ny = last_x + last_w, last_y
                            # Stop the run if the next symbol overlaps background ink
                            # or another symbol, or would fall off the image.
                            if not check_overlap(bg_img, c_img, nx, ny):
                                break
                            paste_transparent(bg_img, c_img, nx, ny, random.uniform(0.6, 1.0))
                            annotations.append(
                                cluster_annotation(nx, ny, c_img, c_class_id, c_mask, bg_width, bg_height))
                            last_x, last_y, last_w, last_h = nx, ny, c_w, c_h

                    ### DOUBLE NEEDLE
                    if class_key == "NEEDLE" and random.random() < .5: # Try to put a second needle UNDER the original
                        rot_idx = [0, 90, 180, 270].index(rotation) # Get the index fo the rotation
                        x_shift = [0, -shift, 0, shift][rot_idx] # Calculate the shift per coordinate and rotation
                        y_shift = [shift, 0, -shift, 0][rot_idx]

                        if check_overlap(bg_img, symbol_img_resized, x + x_shift, y + y_shift):
                            # Paste the second needle image onto the bg_img
                            #symbol_img_resized = cv2.cvtColor(symbol_img_resized, cv2.COLOR_GRAY2BGR)
                            paste_transparent(bg_img, symbol_img_resized, x + x_shift, y + y_shift, opacity)

                            # bg_img[y:y+symbol_height_final, x:x+symbol_width_final] = symbol_img_resized

                            center_x, center_y, bb_width, bb_height = xywh2yolo(x+x_shift, y+y_shift, symbol_width_final, symbol_height_final, bg_width, bg_height)
                            annotations.append(f"{class_id} {center_x:.6f} {center_y:.6f} {bb_width:.6f} {bb_height:.6f}")
                    
                    ### NP SYMBOL INSIDE NEEDLE
                    if class_key == "NEEDLE" and random.random() < .5: # Put a NP symbol ON TOP of the original

                        np_file = random.choice([s for s in symbol_images if s.startswith('NP')]) # Pick a random needle point
                        np_class =  code_to_class_id[np_file.split('.')[0]]
                        np_path = os.path.join(symbol_images_dir, np_file)

                        np_img = cv2.imread(np_path, cv2.IMREAD_GRAYSCALE)
                        np_img = crop_white_edges(np_img)

                        np_img = cv2.resize(np_img, (0
                                                    , 0), fx=scale, fy=scale)
                        np_h, np_w = np_img.shape[:2]
                        rot_idx = [0, 90, 180, 270].index(rotation) # Get the index fo the rotation
                        x_shift = [symbol_width_final//2 - np_w//2, shift, symbol_width_final//2 - np_w//2, -shift][rot_idx] # Calculate the shift per coordinate and rotation
                        y_shift = [-shift, symbol_height_final//2 - np_h//2, shift, symbol_height_final//2 - np_h//2][rot_idx]

                        if rotation > 0: # ROTATE
                            np_img = cv2.rotate(np_img, 
                                                {90: cv2.ROTATE_90_CLOCKWISE, 
                                                180: cv2.ROTATE_180, 
                                                270: cv2.ROTATE_90_COUNTERCLOCKWISE}[rotation])
                            # Refresh dimensions: a 90/270 rotation swaps width and
                            # height, so the annotation below must use the rotated
                            # image's actual size (the shifts above intentionally keep
                            # the pre-rotation values).
                            np_h, np_w = np_img.shape[:2]

                        if check_overlap(bg_img, np_img, x + x_shift, y + y_shift):
                            # Paste the NP symbol image onto the bg_img
                            #np_img = cv2.cvtColor(np_img, cv2.COLOR_GRAY2BGR)
                            
                            paste_transparent(bg_img, np_img, x + x_shift, y + y_shift, random.uniform(0.6, 1.0))

                            #bg_img[y:y+np_h, x:x+np_w] = np_img

                            center_x, center_y, bb_width, bb_height = xywh2yolo(x+x_shift, y+y_shift, np_w, np_h, bg_width, bg_height)
                            annotations.append(f"{np_class} {center_x:.6f} {center_y:.6f} {bb_width:.6f} {bb_height:.6f}")


                    # # Create annotation 
                    # # Standard YOLO format: [class_id, center_x, center_y, width, height] (normalized)
                    # if not double:
                    # else: # Need to add 2 bounding boxes for double needle
                    #     if rotation in [0, 180]:
                    #         x_shift = 0
                    #         y_shift = shift
                    #     else:
                    #         x_shift = shift
                    #         y_shift = 0
                    #     symbol_width_final -= x_shift
                    #     symbol_height_final-= y_shift

                    #     # bbox1
                    #     center_x, center_y, bb_width, bb_height = xywh2yolo(x, y, symbol_width_final, symbol_height_final, bg_width, bg_height)
                    #     annotations.append(f"{class_id} {center_x:.6f} {center_y:.6f} {bb_width:.6f} {bb_height:.6f}")
                    #     # bbox2 
                    #     center_x, center_y, bb_width, bb_height = xywh2yolo(x+x_shift, y+y_shift, symbol_width_final, symbol_height_final, bg_width, bg_height)
                    #     annotations.append(f"{class_id} {center_x:.6f} {center_y:.6f} {bb_width:.6f} {bb_height:.6f}")

                        

                # If no objects were successfully placed, skip this image
                if not annotations:
                    print(f"Warning: Could not place any objects in {prefix} sample {i}_q{q+1}")
                    continue
                
                invert_prob = .2
                if random.random() < invert_prob:
                    bg_img = ~bg_img
                
                # Convert to grayscale before saving
                bg_img = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY)

                # Save the bg_img image
                output_image_path = os.path.join(output_images_dir, f"{prefix}_{i:05d}_q{q+1}.jpg")
                cv2.imwrite(output_image_path, bg_img)
                
                # Save the YOLO annotation
                output_label_path = os.path.join(output_labels_dir, f"{prefix}_{i:05d}_q{q+1}.txt")
                with open(output_label_path, 'w') as f:
                    f.write("\n".join(annotations))

                # Optionally render the YOLO labels onto the image for visual
                # verification (enabled via draw_bboxes / test mode).
                if draw_bboxes:
                    dbg_img = cv2.cvtColor(bg_img, cv2.COLOR_GRAY2BGR)
                    for ann in annotations:
                        cid, cx, cy, ww, hh = ann.split()
                        cid = int(cid)
                        cx, cy, ww, hh = float(cx), float(cy), float(ww), float(hh)
                        x1 = int(round((cx - ww / 2) * bg_width))
                        y1 = int(round((cy - hh / 2) * bg_height))
                        x2 = int(round((cx + ww / 2) * bg_width))
                        y2 = int(round((cy + hh / 2) * bg_height))
                        cv2.rectangle(dbg_img, (x1, y1), (x2, y2), (0, 0, 255), 2)
                        cv2.putText(dbg_img, class_names[cid], (x1, max(10, y1 - 3)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
                    dbg_dir = os.path.join(output_dir, "bbox_check")
                    os.makedirs(dbg_dir, exist_ok=True)
                    cv2.imwrite(os.path.join(dbg_dir, f"{prefix}_{i:05d}_q{q+1}.jpg"), dbg_img)
                
                generated += 1
            
        return generated
    
    # Generate training samples
    train_generated = generate_partition_samples(
        train_backgrounds,
        train_images_dir,
        train_labels_dir,
        num_train_samples,
        "train"
    )
    
    # Generate validation samples
    val_generated = generate_partition_samples(
        val_backgrounds,
        val_images_dir,
        val_labels_dir,
        num_val_samples,
        "val"
    )
    
    print(f"Generated {train_generated} training samples and {val_generated} validation samples")
    print(f"Training dataset saved to {train_images_dir} and {train_labels_dir}")
    print(f"Validation dataset saved to {val_images_dir} and {val_labels_dir}")
    
    # Create and save YAML configuration for YOLO
    yaml_path = os.path.join(output_dir, "dataset.yaml")
    with open(yaml_path, 'w') as f:
        f.write(f"# YOLOv5 dataset configuration\n")
        f.write(f"path: {output_dir.split('/')[-1]}  # dataset root directory\n")
        f.write(f"train: train/images  # train images relative to path\n")
        f.write(f"val: val/images  # validation images relative to path\n")
        f.write(f"test:  # test images (optional)\n\n")
        
        f.write(f"# Classes\n")
        f.write(f"names:\n")
        for i, name in enumerate(class_names):
            f.write(f"  {i}: {name}\n")
    
    print(f"YOLO dataset configuration saved to {yaml_path}")
    
    # Create and save classes.txt file
    classes_path = os.path.join(output_dir, "classes.txt")
    with open(classes_path, 'w') as f:
        for name in class_names:
            f.write(f"{name}\n")
    
    print(f"Class names saved to {classes_path}")
    
    return train_generated, val_generated, class_names

def rotate_bound(image, angle):
    # Copied from imutils
    # grab the dimensions of the image and then determine the
    # center
    (h, w) = image.shape[:2]
    (cX, cY) = (w / 2, h / 2)

    # grab the rotation matrix (applying the negative of the
    # angle to rotate clockwise), then grab the sine and cosine
    # (i.e., the rotation components of the matrix)
    M = cv2.getRotationMatrix2D((cX, cY), -angle, 1.0)
    cos = np.abs(M[0, 0])
    sin = np.abs(M[0, 1])

    # compute the new bounding dimensions of the image
    nW = int((h * sin) + (w * cos))
    nH = int((h * cos) + (w * sin))

    # adjust the rotation matrix to take into account translation
    M[0, 2] += (nW / 2) - cX
    M[1, 2] += (nH / 2) - cY

    # perform the actual rotation and return the image
    return cv2.warpAffine(image, M, (nW, nH), borderMode=cv2.BORDER_CONSTANT, borderValue=255)

def xywh2yolo(x,y,w,h,W,H):
    center_x = (x + w / 2) / W
    center_y = (y + h / 2) / H
    bb_width = w / W
    bb_height = h / H
    return center_x, center_y, bb_width, bb_height

def generate_random_datamatrix():
    """Generate a DataMatrix as a NumPy array encoding random data."""
    data = random_string(random.randint(2,12))
    encoded = encode(data.encode('utf-8'))
    img = Image.frombytes('RGB', (encoded.width, encoded.height), encoded.pixels)
    img = np.array(img.convert(mode='L'))
    return img

def generate_random_barcode():
    """Generate a barcode as a NumPy array encoding random data of different sizes."""
    bcode_types = ['code128', 'code39']
    bcode_type = random.choice(bcode_types)
    data = random_string(random.randint(5,9))
    code = barcode.get(bcode_type, data, writer=ImageWriter(mode='L', dpi=100))
    buf = BytesIO()
    code.write(buf, options={"module_height": 16, 
                             "module_width": random.uniform(0.3, 0.6), 
                             "write_text" : False})
    buf.seek(0)
    img = Image.open(buf)
    img = np.array(img)
    return img

def random_string(n):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=n))

if __name__ == "__main__":
    ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo

    test = False

    if not test:
        # Paths
        background_dir = os.path.join(ROOT_DIR, "object_detection/datasets/no_text")  # Directory with background images
        symbol_images_dir = os.path.join(ROOT_DIR, "data/object_detection_symbols")  # Directory with fixed-size symbol images to paste
        ep_symbol_images_dir = os.path.join(ROOT_DIR, "data/ep_symbols")  # Variable-size EP symbols (resized so short side = 110)
        needle_images_dir = os.path.join(ROOT_DIR, "data/needle_profiles/images")  # Directory with needle images to paste
        output_dir = os.path.join(ROOT_DIR, "object_detection/datasets/yolo_dataset_4_7")
        
        # Generate dataset with train/val split
        generate_dataset(
            background_dir=background_dir,
            symbol_images_dir=symbol_images_dir,
            needle_images_dir=needle_images_dir,
            output_dir=output_dir,
            ep_symbol_images_dir=ep_symbol_images_dir,
            num_train_samples=2500,   # Generate 800 training samples
            num_val_samples=500,      # Generate 200 validation samples
            min_scale=.5,            # Minimum size scale factor
            max_scale=.8,            # Maximum size scale factor
            n_min=12,                 # Minimum number of objects per image
            n_max=17,                # Maximum number of objects per image
            draw_bboxes=test,         # Draw label boxes onto images for verification
        )
    else:        
        # small dataset just for testing changes
        #Paths
        background_dir = os.path.join(ROOT_DIR, "object_detection/datasets/no_text")  # Directory with background images
        symbol_images_dir = os.path.join(ROOT_DIR, "data/object_detection_symbols")  # Directory with fixed-size symbol images to paste
        ep_symbol_images_dir = os.path.join(ROOT_DIR, "data/ep_symbols")  # Variable-size EP symbols (resized so short side = 110)
        needle_images_dir = os.path.join(ROOT_DIR, "data/needle_profiles/images")  # Directory with needle images to paste
        output_dir = os.path.join(ROOT_DIR, "object_detection/datasets/test_dataset")
        
        # Generate dataset with train/val split
        generate_dataset(
            background_dir=background_dir,
            symbol_images_dir=symbol_images_dir,
            needle_images_dir=needle_images_dir,
            output_dir=output_dir,
            ep_symbol_images_dir=ep_symbol_images_dir,
            num_train_samples=25,   # Generate 800 training samples
            num_val_samples=0,      # Generate 200 validation samples
            min_scale=.5,            # Minimum size scale factor
            max_scale=.8,            # Maximum size scale factor
            n_min=12,                 # Minimum number of objects per image
            n_max=17,                # Maximum number of objects per image
            draw_bboxes=test,         # Draw label boxes onto images for verification
        )