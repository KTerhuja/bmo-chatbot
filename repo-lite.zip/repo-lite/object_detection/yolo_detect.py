from ultralytics import YOLO
import cv2
import numpy as np
from typing import Union, List, Dict, Any, Tuple
from pathlib import Path
import torch
import re  # add at top with other imports
import sys
import os
from functools import lru_cache

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 
from utils.spatial import find_neighbor_direction, expand_bboxes, find_next_line, intersection, bbox_distance, direction, find_element_inside_bbox_soft, find_element_inside_bbox, bbox_center
from utils.symbol import BOX_SYMBOLS, DARK_BOX_SYMBOLS, CURVE_TYPE_SYMBOLS, name_map
from utils.color import get_text_color

# Silhouette-match score (0..1) at/above which a template match to the left/above of an
# anchor text is accepted as a real RX / CE symbol. Tunable.
RX_MATCH_THRESHOLD = 0.45
CE_MATCH_THRESHOLD = 0.45


def load_yolo_model(weights_path: Union[str, Path], mode='normal') -> YOLO:
    """
    Load a YOLOv11l model from the specified weights file.
    
    Args:
        weights_path: Path to the weights file
        mode: normal or quad
        
    Returns:
        A loaded YOLO model ready for inference
    """
    try:
        # normal or quad mode - both use standard YOLO
        # Load the model with the specified weights
        model = YOLO(weights_path)
        print(f"Model loaded successfully from {weights_path}")
        return model
    except Exception as e:
        print(f"Error loading model: {e}")
        raise

def get_quadrants(width, height, overlap=150, max_size=2500, max_divisions=5):
    """
    Generate grid regions for an image based on its size.
    This is because downsampling the image too much would hurt inference recall. So instead the image is split
    into multiple images at better resolution.
    Divides the image into multiple parts if a dimension is larger than max_size.
    Named quadrants because originally it would return 4 regions, but now it will return m X n regions,
    depending on how many times each dimension must be split so that the resulting dimension + overlap < max_size
    The actual overlapping region will be 2*overlap for most cases (when the dimension splits in 2 only), for more
    splits, it will be 1.5*overlap, this is a consequence of trying to keep quadrants square
    """
    # Determine number of divisions along each axis
    def get_divisions(size):
        if size <= max_size:
            return 0
        else:
            # Calculate number of divisions, up to max_divisions
            divisions = size // max_size
            return min(divisions, max_divisions)
    
    div_x = get_divisions(width)
    div_y = get_divisions(height)
    
    # Calculate the size of each partition
    step_x = width // (div_x + 1)
    step_y = height // (div_y + 1)
        
    quadrants = []
    for i in range(div_x + 1):
        for j in range(div_y +1):
            x1 = i * step_x
            y1 = j * step_y
            x2 = x1 + step_x
            y2 = y1 + step_y
            
            # The following block ensures that the quadrants are (almost) square, to maximize data passed to yolo, since frames are letterboxed anyway
            d_step = abs(step_x - step_y) # The difference between the dimensions
            if step_x > step_y:
                if j in [0, div_y]: # If at the edge of the image add a full overlap and a full d_step
                    overlap_y = overlap + d_step
                    overlap_x = overlap
                else: # Only add hal if not at the edge (because another overlap will be added on the other side)
                    overlap_y = overlap//2 + d_step//2
                    overlap_x = overlap//2
            else:
                if i in [0, div_x]:
                    overlap_x = overlap + d_step
                    overlap_y = overlap
                else:
                    overlap_x = overlap//2 + d_step//2
                    overlap_y = overlap//2
            
            # Add overlap adjustments
            x1_adj = max(0, x1 - overlap_x)
            y1_adj = max(0, y1 - overlap_y)
            x2_adj = min(width, x2 + overlap_x)
            y2_adj = min(height, y2 + overlap_y)
            
            quadrants.append((x1_adj, y1_adj, x2_adj, y2_adj))
    
    return quadrants


def detect_objects(model: YOLO, image: Union[str, np.ndarray, torch.Tensor], mode='normal', iou_threshold=0.5, conf_thresh=0.5, batch=False, agnostic_nms=False, quad_max_size=2500):
    """
    Perform object detection on the provided image using the loaded YOLOv11l model.
    
    Args:
        model: A loaded YOLO model
        image: Path to image file or numpy array or PyTorch tensor containing the image
        mode: normal or quad
        iou_threshold: IoU threshold for NMS in quad mode (default 0.5)
        conf_thresh: Confidence threshold for detections (default 0.5)
        batch: Whether to process quadrants in a single batch (default False)
        agnostic_nms: Whether to use class-agnostic NMS (default False)
        
    Returns:
        A list of dictionaries containing detection results
    """
    try:
        if mode == "quad":
            # Ensure image is a numpy array
            if isinstance(image, str):
                image = cv2.imread(image)
            elif isinstance(image, torch.Tensor):
                image = image.cpu().numpy()
                
            # Get image dimensions
            height, width = image.shape[:2]
            
            quadrants = get_quadrants(width, height, max_size=quad_max_size)
            
            # Store all detections from all quadrants
            all_boxes = []
            all_scores = []
            all_classes = []
            all_names = {}
            
            # Create a batch of all four quadrants for efficient processing
            batch_images = []
            for x1, y1, x2, y2 in quadrants:
                # Crop the quadrant
                quadrant_img = image[y1:y2, x1:x2].copy()  # Copy to ensure contiguous memory
                batch_images.append(quadrant_img)
            
            if batch:
                # Process all quadrants in a single batch
                batch_results = model(batch_images, agnostic_nms=agnostic_nms, iou=iou_threshold, 
                                      conf=conf_thresh, rect=True, batch=True)
            else:
                batch_results = []
                for image in batch_images:
                    result = model(image, agnostic_nms=agnostic_nms, 
                                   iou=iou_threshold, rect=True, 
                                   conf=conf_thresh)[0]
                    batch_results.append(result)

            # Process results from each quadrant
            for i, (result, (x1, y1, _, _)) in enumerate(zip(batch_results, quadrants)):
                if result.boxes is not None:
                    # Get boxes, scores, and classes
                    boxes = result.boxes.xyxy.cpu().numpy()
                    scores = result.boxes.conf.cpu().numpy()
                    classes = result.boxes.cls.cpu().numpy()
                    
                    # Adjust coordinates to original image space
                    for j, box in enumerate(boxes):
                        # Transform to original coordinates
                        box[0] += x1
                        box[1] += y1
                        box[2] += x1
                        box[3] += y1
                        
                        # Clip to image boundaries
                        box[0] = max(0, min(box[0], width))
                        box[1] = max(0, min(box[1], height))
                        box[2] = max(0, min(box[2], width))
                        box[3] = max(0, min(box[3], height))
                        
                        all_boxes.append(box)
                        all_scores.append(scores[j])
                        all_classes.append(classes[j])
                
                # Collect class names
                if hasattr(result, 'names'):
                    all_names.update(result.names)
            
            # Convert to numpy arrays for NMS
            if all_boxes:
                all_boxes = np.array(all_boxes)
                all_scores = np.array(all_scores)
                all_classes = np.array(all_classes)
                
                # Apply NMS to remove duplicate detections in overlapping regions
                detections = []
                
                # Group by class for NMS
                unique_classes = np.unique(all_classes)
                for cls in unique_classes:
                    class_name = all_names.get(int(cls), f"class_{int(cls)}")
                    if class_name != 'NEEDLE':
                        iou_margin = -0.25 # Have stricter IOU threshold for non Needle classes
                    else:
                        iou_margin = 0
                    cls_mask = all_classes == cls
                    cls_boxes = all_boxes[cls_mask]
                    cls_scores = all_scores[cls_mask]
                    
                    # Apply NMS
                    keep_indices = []
                    sorted_indices = np.argsort(-cls_scores)
                    while len(sorted_indices) > 0:
                        # Keep the box with highest score
                        current_index = sorted_indices[0]
                        keep_indices.append(current_index)
                        
                        if len(sorted_indices) == 1:
                            break
                            
                        # Get IoU with remaining boxes
                        current_box = cls_boxes[current_index]
                        remaining_boxes = cls_boxes[sorted_indices[1:]]
                        
                        # Calculate IoU
                        xx1 = np.maximum(current_box[0], remaining_boxes[:, 0])
                        yy1 = np.maximum(current_box[1], remaining_boxes[:, 1])
                        xx2 = np.minimum(current_box[2], remaining_boxes[:, 2])
                        yy2 = np.minimum(current_box[3], remaining_boxes[:, 3])
                        
                        w = np.maximum(0, xx2 - xx1)
                        h = np.maximum(0, yy2 - yy1)
                        intersection = w * h
                        
                        area1 = (current_box[2] - current_box[0]) * (current_box[3] - current_box[1])
                        area2 = (remaining_boxes[:, 2] - remaining_boxes[:, 0]) * (remaining_boxes[:, 3] - remaining_boxes[:, 1])
                        union = area1 + area2 - intersection
                        
                        iou = intersection / union

                        # Intersection over area, measure to discard partial matches due to an objevt being cropped by the quad border
                        # Such detections will have low IOU with the correct detection. The idea here is to detect objects that are 
                        # almost entirely inside another object (they will have a large ioa).
                        ioa_threshold = .9
                        ioa1 = intersection / area1 # Is current box mostly inside another box?
                        ioa2 = intersection / area2 # Is any of the other boxes mostly inside current box?
                                                                                        
                        # Remove boxes with IoU above threshold
                        inds = np.where((iou <= iou_threshold + iou_margin) & (ioa1 <= ioa_threshold) & (ioa2 <= ioa_threshold) )[0]
                        sorted_indices = sorted_indices[inds + 1]
                    
                    # Add kept detections to result
                    for idx in keep_indices:
                        x1, y1, x2, y2 = cls_boxes[idx].astype(int)
                        cls_id = int(cls)
                        class_name = all_names.get(cls_id, f"class_{cls_id}")
                        
                        detection = {
                            "bbox": [x1, y1, x2, y2],
                            "confidence": float(cls_scores[idx]),
                            "class_id": cls_id,
                            "class_name": class_name
                        }
                        detections.append(detection)
                
                return detections
            else:
                return []
                
        else:  # normal mode
            # Run inference
            results = model(image, agnostic_nms=agnostic_nms, iou=iou_threshold,
                            conf=conf_thresh, rect=True)
            
            # Process and format results
            detections = []
            for result in results:
                # Get boxes, confidence scores, and class information
                boxes = result.boxes.xyxy.cpu().numpy() if result.boxes is not None else []
                confidences = result.boxes.conf.cpu().numpy() if result.boxes is not None else []
                classes = result.boxes.cls.cpu().numpy() if result.boxes is not None else []
                class_names = result.names if hasattr(result, 'names') else {}
                
                # Format the detections
                for idx, (box, conf, cls_id) in enumerate(zip(boxes, confidences, classes)):
                    cls_id = int(cls_id)
                    class_name = class_names.get(cls_id, f"class_{cls_id}")
                    x1, y1, x2, y2 = box.astype(int)
                    
                    detection = {
                        "bbox": [x1, y1, x2, y2],
                        "confidence": float(conf),
                        "class_id": cls_id,
                        "class_name": class_name
                    }
                    detections.append(detection)
            
        return detections
    
    except Exception as e:
        print(f"Error during detection: {e}")
        raise

def _to_foreground_mask(img: np.ndarray) -> np.ndarray:
    """
    Reduce a symbol image to a polarity-normalized binary foreground mask (ink=255,
    background=0).

    This is what makes matching invariant to colour and to inversion: the symbol's hue
    and whether it is drawn dark-on-light or light-on-dark are discarded, keeping only
    its silhouette. Otsu splits the image into two intensity classes; whichever class
    dominates the border (which, thanks to the crop padding, is background) is treated
    as background, and the mask is flipped so the foreground is always 255.
    """
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Light denoise so stray specks don't corrupt the Otsu split or the silhouette.
    # img = cv2.medianBlur(img, 3)
    _, bw = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # Background is assumed to touch the (padded) border; if that border is bright the
    # background is the bright class, so invert to keep foreground == 255.
    border = np.concatenate([bw[0, :], bw[-1, :], bw[:, 0], bw[:, -1]])
    if border.mean() > 127:
        bw = cv2.bitwise_not(bw)
    return bw


def _tight_mask(mask: np.ndarray) -> np.ndarray:
    """Crop a foreground mask to its tight bounding box, dropping empty canvas margins."""
    ys, xs = np.where(mask > 0)
    if len(xs) == 0:
        return mask
    return mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def _mask_match_score(big: np.ndarray, small: np.ndarray) -> float:
    """
    Best normalized cross-correlation of `small` slid over `big` (silhouette masks).

    TM_CCOEFF_NORMED subtracts the mean, so it penalizes both missing ink and extra ink
    (e.g. clutter from a neighbouring symbol), which keeps the score discriminative for
    identity verification rather than just loose orientation matching.
    """
    if small.shape[0] > big.shape[0] or small.shape[1] > big.shape[1]:
        return 0.0
    res = cv2.matchTemplate(big, small, cv2.TM_CCOEFF_NORMED)
    res = np.nan_to_num(res, nan=0.0, posinf=0.0, neginf=0.0)
    return float(res.max())


def _best_template_match(crop: np.ndarray, template: np.ndarray, pad: int = 20):
    """
    Match a template against a (padded) crop over 4 rotations and a range of scales,
    reporting how closely the crop's symbol matches the template's symbol.

    Originally this only had to be good enough to pick an orientation; it is now also
    used to verify that a detected symbol is the *same artwork* as the ACCLM reference,
    so it is hardened in three ways:
      * Colour / inversion invariance - both images are reduced to polarity-normalized
        silhouettes (see _to_foreground_mask), so hue and dark-on-light vs light-on-dark
        are ignored.
      * Clutter tolerance - the template is slid across the padded crop, so small
        fragments of neighbouring symbols near the border fall outside the best-match
        window, and the mean-subtracted score penalizes any extra ink that remains.
      * Scale precision - the template is first sized from the detection bbox (a tight,
        clutter-free bound) using the template's own ink extent, then a coarse-to-fine
        scale sweep locks onto the exact size.

    Returns:
        (best_score, best_orientation): best score (0..1) and the rotation
        (0/90/180/270 degrees) at which it occurred.
    """
    crop_fg = _to_foreground_mask(crop)
    tmpl_fg = _tight_mask(_to_foreground_mask(template))
    if crop_fg.size == 0 or tmpl_fg.size == 0:
        return 0.0, 0

    # Base scale: fit the template's ink extent to the detection bbox (crop minus its
    # padding). Measuring the template by its ink extent (not its canvas) keeps the two
    # silhouettes at a comparable size regardless of aspect ratio or canvas margins.
    inner = ((crop_fg.shape[0] - 2 * pad) + (crop_fg.shape[1] - 2 * pad)) / 2.0
    src = (tmpl_fg.shape[0] + tmpl_fg.shape[1]) / 2.0
    if inner <= 0 or src <= 0:
        return 0.0, 0
    base = inner / src

    orientations = [0, 90, 180, 270]
    # coarse = [0.6, 0.75, 0.9, 1.0, 1.1, 1.25, 1.4]
    coarse = list(np.arange(.6,1.45,.05))

    def score_at(mask_base: np.ndarray, scale: float) -> float:
        s = base * scale
        if s <= 0:
            return 0.0
        interp = cv2.INTER_AREA if s < 1.0 else cv2.INTER_LINEAR
        t = cv2.resize(mask_base, (0, 0), fx=s, fy=s, interpolation=interp)
        if t.shape[0] <= crop_fg.shape[0] and t.shape[1] <= crop_fg.shape[1]:
            return _mask_match_score(crop_fg, t)
        if crop_fg.shape[0] <= t.shape[0] and crop_fg.shape[1] <= t.shape[1]:
            return _mask_match_score(t, crop_fg)
        return 0.0  # mixed ordering (one dim larger, one smaller) -> skip

    # Coarse sweep over rotations x scales.
    best_score, best_orientation, best_scale = 0.0, 0, 1.0
    best_mask = tmpl_fg
    rotated = tmpl_fg
    for ang in orientations:
        for sc in coarse:
            score = score_at(rotated, sc)
            if score > best_score:
                best_score, best_orientation, best_scale = score, ang, sc
                best_mask = rotated
        rotated = cv2.rotate(rotated, cv2.ROTATE_90_CLOCKWISE)

    # Fine refinement around the best coarse scale (orientation already settled).
    if best_score > 0:
        for sc in np.linspace(best_scale - 0.04, best_scale + 0.04, 9).round(2).tolist():  # 9 steps from -0.04 to +0.04 around best coarse scale
            score = score_at(best_mask, sc)
            if score > best_score:
                best_score = score

    return best_score, best_orientation


def _match_with_generous_pad(template: np.ndarray, bbox, image: np.ndarray):
    """
    Re-run _best_template_match against a crop padded generously (0.7 * max(w, h) on every
    side) around `bbox`.

    YOLO occasionally returns a bbox much smaller than the true symbol (correct class, wrong
    size). The tight crop then chops the artwork off and the silhouette match fails even
    though the symbol is correct. Padding wide brings the full artwork back into the crop.

    Returns (best_score, best_orientation), or (0.0, 0) when the crop is empty.
    """
    x1, y1, x2, y2 = bbox
    pad = int(0.7 * max(x2 - x1, y2 - y1))
    h, w = image.shape[:2]
    crop = image[max(0, y1 - pad):min(h, y2 + pad), max(0, x1 - pad):min(w, x2 + pad)]
    if crop.size == 0:
        return 0.0, 0
    if crop.ndim == 3:
        crop = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    return _best_template_match(crop, template, pad)


# ---- Logo detection via OCR-triggered template matching --------------------------------
# Brand logos are found by using OCR text as an anchor: when a configured trigger phrase is
# read on the page, the corresponding logo artwork (data/logos/*.png) is template-matched in
# the region around that text. This localisation is essential - matching a small logo over a
# whole page produces false positives on line/table structures, whereas the OCR anchor pins
# the search to the right spot.

# Minimum silhouette-match score (0..1) to accept a logo template match at an OCR anchor.
# Real logos in the test sample score ~0.62-0.71 while plain text of the brand name (e.g. a
# "PART OF THE Johnson&Johnson ..." tagline) stays below ~0.48, so 0.55 separates them.
LOGO_MATCH_THRESHOLD = 0.55

# Each entry maps a set of trigger phrases (as they appear in OCR, normalized) to a logo
# template in data/logos. When OCR text contains any phrase, that template is matched in the
# region around the text. 'name' is the symbol name used for a confirmed logo.
# Add new logos by dropping a PNG in data/logos and appending an entry here.
LOGO_CONFIG = [
    {
        'name': 'LOGO_BIOSENSE_WEBSTER',
        'template': 'BWI.png',
        'phrases': ['biosensewebster'],
    },
    {
        'name': 'LOGO_JOHNSON_JOHNSON',
        'template': 'JNJ.png',
        'phrases': ['johnsonjohnson'],
    },
]


def _normalize_logo_text(text: str) -> str:
    """Lowercase and strip every non-alphanumeric char so 'Johnson & Johnson' -> 'johnsonjohnson'."""
    return re.sub(r'[^a-z0-9]', '', text.lower())


def _ioa(inner, outer) -> float:
    """Intersection area divided by `inner`'s area (how much of `inner` lies within `outer`)."""
    ix1 = max(inner[0], outer[0]); iy1 = max(inner[1], outer[1])
    ix2 = min(inner[2], outer[2]); iy2 = min(inner[3], outer[3])
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    area = max(1, (inner[2] - inner[0]) * (inner[3] - inner[1]))
    return inter / area


@lru_cache(maxsize=16)
def _load_logo_template(filename: str):
    """Load (and cache) a logo template PNG from data/logos. Returns None when missing."""
    path = ROOT_DIR / 'data' / 'logos' / filename
    return cv2.imread(str(path))


def _match_logo_template(crop: np.ndarray, template: np.ndarray, anchor_len: float):
    """
    Slide `template` over `crop` across 4 rotations and a range of scales, returning the best
    silhouette-match score and the matched bbox (in crop coordinates).

    Both images are reduced to polarity-normalized foreground masks (see _to_foreground_mask)
    so colour and dark-on-light vs light-on-dark are ignored. The template is scaled so its
    long side is ~anchor_len (the OCR text's long side) and swept, which absorbs the logo mark
    and tagline artwork that OCR does not capture in the anchor bbox.

    Returns:
        (best_score, best_bbox, best_orientation) where best_bbox is [x1,y1,x2,y2] in crop
        coordinates (or None when nothing fit).
    """
    crop_fg = _to_foreground_mask(crop)
    tmpl_fg = _tight_mask(_to_foreground_mask(template))
    if crop_fg.size == 0 or tmpl_fg.size == 0:
        return 0.0, None, 0
    ch, cw = crop_fg.shape
    long_t = max(tmpl_fg.shape)
    if long_t <= 0:
        return 0.0, None, 0
    best_score, best_bbox, best_orientation = 0.0, None, 0
    for k in range(4):  # 0/90/180/270 degrees
        rot = tmpl_fg if k == 0 else np.rot90(tmpl_fg, k)
        for sc in np.arange(0.8, 1.8, 0.05):
            fx = (anchor_len * sc) / long_t
            if fx <= 0:
                continue
            interp = cv2.INTER_AREA if fx < 1 else cv2.INTER_LINEAR
            t = cv2.resize(rot, (0, 0), fx=fx, fy=fx, interpolation=interp)
            th, tw = t.shape
            if th > ch or tw > cw:
                continue
            res = cv2.matchTemplate(crop_fg, t, cv2.TM_CCOEFF_NORMED)
            res = np.nan_to_num(res, nan=0.0, posinf=0.0, neginf=0.0)
            _, mx, _, loc = cv2.minMaxLoc(res)
            if mx > best_score:
                best_score = float(mx)
                best_bbox = [loc[0], loc[1], loc[0] + tw, loc[1] + th]
                best_orientation = k * 90
    return best_score, best_bbox, best_orientation


def logo_detection(image: np.ndarray, text_data: list, symbol_data: list):
    """
    Detect brand logos by template-matching around OCR text anchors, adding them to
    symbol_data and deleting the OCR text they replace (both lists are mutated in place).

    For every OCR line whose text contains a configured trigger phrase (e.g. 'Biosense
    Webster', 'Johnson&Johnson'), the matching logo template from data/logos is slid over the
    region around that text. When the match passes LOGO_MATCH_THRESHOLD the logo is appended
    to symbol_data as an image symbol and every OCR line inside the matched logo bbox is
    removed from text_data (the logo artwork replaces the OCR text it was drawn from, e.g. a
    wordmark plus its tagline).

    Args:
        image: page image (BGR) to crop logo regions from (use images['original']).
        text_data: list of text elements ({'text','bbox','font',...}); mutated in place.
        symbol_data: list of symbols; confirmed logos are appended in place.

    Returns:
        symbol_data (the same list, mutated), mirroring box_symbol_detection's style.
    """
    if image is None or not text_data:
        return symbol_data
    H, W = image.shape[:2]
    logos = []
    remove_ocr_idx = set()
    for cfg in LOGO_CONFIG:
        template = _load_logo_template(cfg['template'])
        if template is None:
            continue
        for text in text_data:
            # Only OCR-detected text triggers a logo search.
            if text.get('font') != 'OCR_text':
                continue
            norm = _normalize_logo_text(text.get('text', ''))
            if not any(p in norm for p in cfg['phrases']):
                continue
            b = text['bbox']
            bw, bh = b[2] - b[0], b[3] - b[1]
            anchor = max(bw, bh)
            # Expand generously around the anchor so the logo's mark/tagline (which OCR does
            # not capture) is included in the search crop.
            margin = int(max(bw, bh) * 0.6)
            rx1, ry1 = max(0, b[0] - margin), max(0, b[1] - margin)
            rx2, ry2 = min(W, b[2] + margin), min(H, b[3] + margin)
            crop = image[ry1:ry2, rx1:rx2]
            if crop.size == 0:
                continue
            score, rel_bbox, orientation = _match_logo_template(crop, template, anchor)
            if score < LOGO_MATCH_THRESHOLD or rel_bbox is None:
                continue
            logo_bbox = [rel_bbox[0] + rx1, rel_bbox[1] + ry1,
                         rel_bbox[2] + rx1, rel_bbox[3] + ry1]
            # Skip logos already found from a nearby anchor (overlapping bbox, same logo).
            if any(cfg['name'] == l['name'] and _ioa(logo_bbox, l['bbox']) > 0.5 for l in logos):
                continue
            logos.append({
                'name': cfg['name'],
                'bbox': logo_bbox,
                'orientation': orientation,
                'confidence': round(score, 3),
            })
            # Delete every OCR line mostly inside the matched logo region.
            for j, other in enumerate(text_data):
                if other.get('font') != 'OCR_text':
                    continue
                if _ioa(other['bbox'], logo_bbox) > 0.5:
                    remove_ocr_idx.add(j)

    for logo in logos:
        lbbox = logo['bbox']
        logo_color, _ = get_text_color(image[lbbox[1]:lbbox[3], lbbox[0]:lbbox[2]])
        symbol_data.append({
            'symbol_name': logo['name'],
            'symbol_type': 'Image',
            'bbox': lbbox,
            'center': bbox_center(lbbox),
            'confidence': logo['confidence'],
            'size': 1,
            'font': 'Logo',
            'color': logo_color,
            'orientation': logo['orientation'],
            'validations': [],
        })
    for j in sorted(remove_ocr_idx, reverse=True):
        text_data.pop(j)
    return symbol_data


@lru_cache(maxsize=1)
def _acclm_library_files() -> tuple:
    """Return a cached tuple of PNG Paths in the ACCLM symbol library (empty if missing)."""

    # --- ACCLM symbol library (latest official symbol artwork) ---
    # Directory holding the reference PNGs each detected symbol is validated against.
    # The folder name starts with 'acclm_symbol_library' and carries a date suffix
    # (e.g. 'acclm_symbol_library_20260612_075855'); when several exist, the latest is
    # picked via descending name sort. It may be absent in some environments; lookups
    # degrade gracefully when missing.
    acclm_root = ROOT_DIR.parent / 'acclm'
    if not acclm_root.is_dir():
        return ()
    library_dirs = sorted(
        (d for d in acclm_root.glob('acclm_symbol_library*') if d.is_dir()),
        reverse=True,
    )
    if not library_dirs:
        return ()
    return tuple(library_dirs[0].glob('*.png'))


def find_acclm_template_path(class_name: str):
    """
    Locate the ACCLM library PNG for a detected symbol class.

    Lookup order:
        1. The class name returned by the model (e.g. 'RX_ONLY').
        2. The business name from name_map (e.g. 'RX Only Horizontal').
    ACCLM filenames may carry an irrelevant numeric prefix, e.g.
    '0028 - RX Only Horizontal.png'; that prefix is ignored when matching.

    Returns:
        Path of the matching file, or None when the symbol is not in the ACCLM
        library (in which case no ACCLM validation should be produced).
    """
    files = _acclm_library_files()
    if not files:
        return None
    candidates = [class_name]
    business_name = name_map.get(class_name)
    if business_name:  # skip empty business names
        candidates.append(business_name)
    for cand in candidates:
        for f in files:
            stem = f.stem  # filename without extension
            # exact match, or '<numeric prefix> - <name>' (prefix ignored)
            if stem == cand or stem.split(' - ', 1)[-1] == cand:
                return f
    return None


# Silhouette-match score (0..1) at/above which a detected symbol is considered an exact
# match to its ACCLM library version. Shared by every ACCLM check below. Tunable.
ACCLM_MATCH_THRESHOLD = 0.67


def acclm_validate_symbol(class_name: str, bbox, image: np.ndarray, pad: int = 20):
    """
    ONLY USED FOR special-font symbols

    Validate a single symbol against the ACCLM reference library (latest official artwork).

    Crops the symbol (plus padding) out of `image` and colour/inversion/clutter-invariantly
    matches it against the ACCLM template for `class_name`. This is the shared core of the
    ACCLM check, so it can be applied both to YOLO/image detections and to font-decoded
    symbols.

    NOTE for font-decoded symbols: pass the ORIGINAL page image (images['original']). Font
    glyphs are redacted out of the 'no_text' image, so a 'no_text' crop would be blank.

    Args:
        class_name: symbol identifier (model class name or font symbol name).
        bbox: [x1, y1, x2, y2] of the symbol in `image`.
        image: page image to crop from (BGR or grayscale).
        pad: extra border (px) kept around the bbox for the sliding template match.

    Returns:
        'acclm_pass' / 'acclm_data_error' when the symbol exists in the ACCLM library,
        'no_acclm' when the symbol is not in the library (no reference artwork to check
        against), or None when the crop/template could not be read.
    """
    acclm_path = find_acclm_template_path(class_name)
    if acclm_path is None:
        return 'no_acclm'  # symbol not present in the ACCLM library
    acclm_template = cv2.imread(str(acclm_path), cv2.IMREAD_GRAYSCALE)
    if acclm_template is None:
        return 'no_acclm'
    x1, y1, x2, y2 = bbox
    crop = image[max(0, y1 - pad):y2 + pad, max(0, x1 - pad):x2 + pad]
    if crop.size == 0:
        return 'acclm_data_error'
    if crop.ndim == 3:
        crop = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    score, _ = _best_template_match(crop, acclm_template, pad)
    if score < ACCLM_MATCH_THRESHOLD:
        # A too-small YOLO bbox crops the symbol off; retry with a generously padded crop.
        retry_score, _ = _match_with_generous_pad(acclm_template, bbox, image)
        score = max(score, retry_score)
    return 'acclm_pass' if score >= ACCLM_MATCH_THRESHOLD else 'acclm_data_error'


def symbol_orientation(detection: dict, image: np.ndarray, acclm: bool = False):
    """
    Determine the orientation of a detected symbol via template matching, and (optionally)
    validate it against the ACCLM symbol library (the latest official artwork).

    Args:
        acclm: When True, also compare the symbol against the ACCLM library. When False
            (default), only the orientation is computed and no ACCLM validation is produced.

    Returns:
        (best_orientation, acclm_validation) where:
            best_orientation: one of 0/90/180/270 degrees.
            acclm_validation: 'acclm_pass' / 'acclm_data_error' when the symbol exists in
            the ACCLM library, 'no_acclm' when it is not, or None when acclm is disabled.
    """
    box = detection['bbox']
    pad = 10
    crop = image[max(0, box[1]-pad):box[3]+pad, max(0, box[0]-pad):box[2]+pad]
    if len(crop.shape) == 3:
        crop = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

    # ACCLM validation: compare against the official library symbol when it exists.
    # 'no_acclm' means the symbol has no reference artwork in the ACCLM library.
    # When acclm is disabled, skip the check entirely (acclm_validation stays None).
    acclm_validation = 'no_acclm' if acclm else None
    acclm_path = find_acclm_template_path(detection['class_name']) if acclm else None
    if acclm_path is not None:
        acclm_template = cv2.imread(str(acclm_path), cv2.IMREAD_GRAYSCALE)
        if acclm_template is not None:
            acclm_score, best_orientation = _best_template_match(crop, acclm_template, pad)
            if acclm_score < ACCLM_MATCH_THRESHOLD:
                # A too-small YOLO bbox crops the symbol off; retry with a generously padded
                # crop and keep the better score/orientation.
                retry_score, retry_orientation = _match_with_generous_pad(
                    acclm_template, detection['bbox'], image)
                if retry_score > acclm_score:
                    acclm_score, best_orientation = retry_score, retry_orientation
            acclm_validation = 'acclm_pass' if acclm_score >= ACCLM_MATCH_THRESHOLD else 'acclm_data_error'
    else:
        # Orientation: match against the object-detection stock symbol (unchanged behavior).
        try:
            template_path = os.path.join(str(ROOT_DIR), "data/object_detection_symbols", f"{detection['class_name']}.png")
            template = cv2.imread(str(template_path), cv2.IMREAD_GRAYSCALE)
        except FileNotFoundError as e:
            try:
                template_path = os.path.join(str(ROOT_DIR), "data/ep_symbols", f"{detection['class_name']}.png")
                template = cv2.imread(str(template_path), cv2.IMREAD_GRAYSCALE)
            except FileNotFoundError as e:
                template = None
        if template is None:
            return 0, acclm_validation

        _, best_orientation = _best_template_match(crop, template, pad)
        
    return best_orientation, acclm_validation


def _correct_celsius_sign(c_mag: float, c_neg: bool, f_val: float) -> bool:
    """
    Fix an OCR false-negative sign in front of the Celsius value using F = C*9/5 + 32.

    A small line that is part of the symbol is sometimes OCR'd as a leading minus on the
    Celsius reading (e.g. '-25°C/77°F'); since -25°C ≈ -13°F (far from 77°F) the negative
    is bogus. The sign is only flipped from negative to positive (never the reverse), and
    only when the original (negative) reading is inconsistent while the positive one
    matches the Fahrenheit value within tolerance.

    Returns the (possibly corrected) c_neg flag.
    """
    if not c_neg:
        return c_neg  # only an existing negative can be a spurious minus

    TOL = 5.0  # max |F_measured - F_from_C| in °F to accept a pair as consistent (tunable)

    def f_from_c(c: float) -> float:
        return c * 9.0 / 5.0 + 32.0

    orig_error = abs(f_val - f_from_c(-c_mag))   # keep negative Celsius
    flipped_error = abs(f_val - f_from_c(c_mag)) # flip to positive Celsius

    # Override only if the negative reading is inconsistent and the positive one fits.
    if flipped_error <= TOL < orig_error:
        return False
    return c_neg


def _format_temp_string(text: str) -> str:
    """Parse a temperature text like '-10°C/+14°F' into compact form 'n10C14F'.

    OCR sometimes reads a small symbol line in front of the Celsius value as a leading
    minus, producing a false negative; such cases are corrected via the C/F equivalence
    (see _correct_celsius_sign).
    """
    # The degree glyph may be a real degree sign (°/º) or an OCR'd 'o'/'O' (some fonts
    # render the degree as a small, superscript 'o'); accept any of them, optionally
    # surrounded by whitespace when the value/degree/unit arrive as separate OCR tokens.
    c_str, c_neg = None, False
    c_match = re.search(r'([+-]?\d+\.?\d*)\s*[°ºoO]?\s*C(?!S)', text)  # avoid matching °CS
    if c_match:
        val = c_match.group(1).replace('+', '')
        c_neg = val.startswith('-')
        c_str = val[1:] if c_neg else val

    f_str, f_neg = None, False
    f_match = re.search(r'([+-]?\d+\.?\d*)\s*[°ºoO]?\s*F(?!S)', text)  # avoid matching °FS
    if f_match:
        val = f_match.group(1).replace('+', '')
        f_neg = val.startswith('-')
        f_str = val[1:] if f_neg else val

    # Correct an OCR false negative in front of the Celsius value using the F value.
    if c_str is not None and f_str is not None:
        f_val = -float(f_str) if f_neg else float(f_str)
        c_neg = _correct_celsius_sign(float(c_str), c_neg, f_val)

    result = ""
    if c_str is not None:
        result += ('n' if c_neg else '') + c_str + 'C'
    if f_str is not None:
        result += ('n' if f_neg else '') + f_str + 'F'
    return result

def _extract_temp_points(text: str) -> list:
    """Extract every temperature reading from a (possibly fragmented / multi-value) text
    and return a list of compact strings, one per limit point.

    A single limit symbol carries a lower and an upper value. Depending on the label these
    can be Celsius-only ('-30°C' / '65°C') or Celsius+Fahrenheit ('-10°C/+14°F'). The OCR
    also splits these across boxes and can drop a stray glyph ('X') between the two rows,
    so we cannot rely on the values arriving as two clean, separate text elements. Instead
    we scan the whole nearby text for '<number><degree?><C|F>' readings and reconstruct the
    limit points:

      * When Celsius and Fahrenheit readings appear in equal numbers we pair them in order
        (each point = a Celsius value with its Fahrenheit equivalent), reusing the C/F sign
        correction from _format_temp_string.
      * Otherwise every reading is treated as its own single-unit point.

    The degree glyph may be a real degree sign (°/º) or an OCR'd small 'o'/'O'.
    """
    matches = re.findall(r'([+-]?\d+\.?\d*)\s*[°ºoO]?\s*([CF])(?!S)', text, re.IGNORECASE)
    readings = []
    for val, unit in matches:
        val = val.replace('+', '')
        neg = val.startswith('-')
        readings.append({'unit': unit.upper(), 'neg': neg, 'num': val[1:] if neg else val})

    c_readings = [r for r in readings if r['unit'] == 'C']
    f_readings = [r for r in readings if r['unit'] == 'F']

    points = []
    if c_readings and f_readings and len(c_readings) == len(f_readings):
        for rc, rf in zip(c_readings, f_readings):
            f_val = -float(rf['num']) if rf['neg'] else float(rf['num'])
            c_neg = _correct_celsius_sign(float(rc['num']), rc['neg'], f_val)
            points.append(('n' if c_neg else '') + rc['num'] + 'C' +
                          ('n' if rf['neg'] else '') + rf['num'] + 'F')
    else:
        for r in readings:
            points.append(('n' if r['neg'] else '') + r['num'] + r['unit'])
    return points

def _format_humid_string(text: str) -> str:
    """Parse a humidity text like '90 %' into compact form '90'."""
    match = re.search(r'(\d+\.?\d*)\s*%', text)
    return match.group(1) if match else ""


def _format_pressure_string(text: str) -> str:
    """Parse a pressure text like '106 kPa', '1060 hPa' or '1020 mbar' into its compact
    numeric form (e.g. '106'). The unit anchors the value so stray numbers are ignored."""
    match = re.search(r'(\d+\.?\d*)\s*(?:kpa|hpa|mbar)', text, re.IGNORECASE)
    return match.group(1) if match else ""


def _cluster_text_elements(items: list, gap_ratio: float = 0.75) -> list:
    """Group spatially-adjacent OCR fragments into clusters.

    Limit values are frequently split across several OCR boxes (e.g. the lower limit
    '-30°C' arrives as three tokens: '-30', 'o' (the degree glyph rendered as a small
    superscript 'o') and 'C'). To reconstruct the full value we merge tokens that sit on
    the same text line (their bboxes overlap vertically) and are horizontally close (the
    gap between them is small relative to their height).

    `items` is a list of dicts, each carrying at least an 'el' (with a 'bbox') and its
    original 'idx' in text_data. Returns a list of clusters, each a dict with the merged
    'bbox' and the ordered list of member 'items'.
    """
    ordered = sorted(items, key=lambda it: it['el']['bbox'][0])  # left-to-right
    clusters = []
    for it in ordered:
        eb = it['el']['bbox']
        for cl in clusters:
            cb = cl['bbox']
            v_overlap = min(cb[3], eb[3]) - max(cb[1], eb[1])
            if v_overlap <= 0:  # different text line
                continue
            min_h = min(cb[3] - cb[1], eb[3] - eb[1])
            gap = eb[0] - cb[2]  # negative when the boxes overlap horizontally
            if gap <= gap_ratio * min_h:
                cl['bbox'] = expand_bboxes(cb, eb)
                cl['items'].append(it)
                break
        else:
            clusters.append({'bbox': list(eb), 'items': [it]})
    return clusters


def limit_post(detection: dict, text_data: list) -> str:
    """
    Rename a TEMP/TEMP_LO/TEMP_UP/LIMIT_HUMID/LIMIT_PRESSURE detection based on surrounding text.
    Expands the detection bbox to include matched text elements and removes them from text_data.
    Returns the new class_name string.

    The lower/upper limit texts sit right next to (and usually overlapping) the symbol, but
    their layout is diagonal (e.g. lower value bottom-left, upper value top-right) and the
    OCR frequently splits a single value across several boxes (e.g. '-30', 'o', 'C') or
    drops a stray glyph ('X') between the two rows. We therefore cluster the nearby
    fragments, extract every temperature reading from the clustered text, and take the
    smallest value as the lower limit and the largest as the upper limit.
    """
    base = detection['class_name']  # TEMP, TEMP_LO, TEMP_UP, LIMIT_HUMID or LIMIT_PRESSURE

    if base.startswith('TEMP'):
        parse = _format_temp_string
    elif base.startswith('LIMIT_HUMID'):
        parse = _format_humid_string
    elif base.startswith('LIMIT_PRESSURE'):
        parse = _format_pressure_string
    else:
        return detection['class_name']

    bx = detection['bbox']
    sym_size = max(bx[2] - bx[0], bx[3] - bx[1])
    max_dist = sym_size  # the value texts touch/overlap the symbol; neighbours sit farther

    # Collect nearby text elements, then cluster spatially-adjacent fragments together so a
    # value split across several OCR boxes (e.g. '-30', 'o', 'C') is parsed as one value.
    nearby = [
        {'idx': idx, 'el': el}
        for idx, el in enumerate(text_data)
        if bbox_distance(bx, el['bbox']) <= max_dist
    ]
    clusters = _cluster_text_elements(nearby)

    # Turn each cluster into one or more limit "points". For temperature a single cluster
    # may hold BOTH the lower and upper value (e.g. OCR merges the two rows via a stray
    # glyph), so we extract every reading; humidity/pressure yield at most one value.
    is_temp = base.startswith('TEMP')
    candidates = []
    for cl in clusters:
        text = ' '.join((it['el'].get('text', '') or '') for it in cl['items'])
        strs = _extract_temp_points(text) if is_temp else ([parse(text)] if parse(text) else [])
        if not strs:
            continue
        dist = bbox_distance(bx, cl['bbox'])
        for s in strs:
            # Numeric key for ordering low vs high ('n' marks a negative in the compact form).
            m = re.search(r'-?\d+\.?\d*', s.replace('n', '-'))
            val = float(m.group()) if m else 0.0
            candidates.append({'cluster': cl, 'dist': dist, 'val': val, 'str': s})

    # Order the points by numeric value and take the extremes: smallest -> lower limit,
    # largest -> upper limit. Using min/max (rather than the two nearest) keeps the pairing
    # correct even when both values come from one merged cluster.
    candidates.sort(key=lambda c: c['val'])
    if len(candidates) >= 2:
        chosen = [candidates[0], candidates[-1]]
    else:
        chosen = candidates[:1]

    lo_str = chosen[0]['str'] if len(chosen) >= 1 else ""
    hi_str = chosen[1]['str'] if len(chosen) >= 2 else ""

    # Expand bbox and remove the matched clusters' elements from text_data.
    chosen_clusters = {id(c['cluster']): c['cluster'] for c in chosen}
    indices_to_remove = []
    for cl in chosen_clusters.values():
        detection['bbox'] = expand_bboxes(detection['bbox'], cl['bbox'])
        indices_to_remove.extend(it['idx'] for it in cl['items'])
    for idx in sorted(set(indices_to_remove), reverse=True):
        text_data.pop(idx)

    if base in ['TEMP_UP', 'TEMP_LO']:
        base = "TEMP"
    if lo_str and hi_str:
        detection['class_name'] = f"{base}_{lo_str}_{hi_str}"
    if lo_str and not hi_str:
        detection['class_name'] = f"{base}_{lo_str}"
    if hi_str and not lo_str:
        detection['class_name'] = f"{base}_{hi_str}"
    return detection['class_name']

def _rx_variant_by_template(detection: dict, image: np.ndarray):
    """
    Decide the RX variant ('0258 - RX Only Vertical' vs 'RX_ONLY') by template matching
    the RX detection against the two stock RX-only artworks.

    OCR does not always read the 'only' text (or reads it as something else), so when the
    text anchor is missing we fall back to matching the whole artwork silhouette directly.

    The RX detection bbox tightly bounds only the 'Rx' mark; the 'only' word sits beside it
    (horizontal variant) or below it (vertical variant) and is NOT inside the bbox. We
    therefore search a generously padded region (~1.5x the symbol extent on every side) so
    the full 'Rx only' artwork fits, slide each template across it over 4 rotations and a
    range of scales, and keep the best-scoring template/location. On a confident match the
    detection bbox is EXPANDED to cover the located artwork (Rx mark + 'only').

    Returns the winning class_name (and expands detection['bbox'] in place), or None when
    neither template matches well enough (or the image/templates are unavailable), in which
    case the caller keeps the generic 'RX'.
    """
    if image is None:
        return None
    x1, y1, x2, y2 = detection['bbox']
    sym_w, sym_h = x2 - x1, y2 - y1
    if sym_w <= 0 or sym_h <= 0:
        return None

    # Generous padding so the 'only' text (outside the tight Rx bbox) is inside the search
    # region: ~1.5x the symbol extent on each side.
    H, W = image.shape[:2]
    pad_x, pad_y = int(1.5 * sym_w), int(1.5 * sym_h)
    region = [max(0, x1 - pad_x), max(0, y1 - pad_y),
              min(W, x2 + pad_x), min(H, y2 + pad_y)]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image

    # Size the template around the Rx-mark extent, sweeping up in scale so the full artwork
    # (Rx mark + 'only') can be larger than the bare mark.
    base = max(sym_w, sym_h)
    scales = [0.9, 1.1, 1.3, 1.6, 1.9, 2.2, 2.6, 3.0]

    best_name, best_score, best_bbox = None, 0.0, None
    for name in ("0258 - RX Only Vertical", "RX_ONLY"):
        template = _load_od_symbol_template(name)
        if template is None:
            continue
        for orientation in (0, 90, 180, 270):
            score, bbox = _locate_template_in_region(
                gray, region, template, base, orientation, scales)
            if score > best_score:
                best_name, best_score, best_bbox = name, score, bbox

    if best_score < RX_MATCH_THRESHOLD or best_bbox is None:
        return None

    # Expand the detection bbox to cover the full located artwork (Rx mark + 'only').
    detection['bbox'] = expand_bboxes(detection['bbox'], best_bbox)
    return best_name


def rx_post(detection: dict, text_data: list, image: np.ndarray = None) -> str:
    """
    Rename a RX detection based on the position of the 'only' text next to it.

    The variant depends on where 'only' sits relative to the Rx symbol (accounting for
    the symbol's orientation): to the side -> horizontal 'RX_ONLY', below -> the vertical
    variant. Expands the detection bbox to include the matched text and removes it from
    text_data.

    We search specifically for the nearest element containing 'only' rather than asking
    for a generic directional neighbor: find_neighbor_direction returns the FIRST element
    that passes its direction test, which (especially for rotated symbols, where the
    direction check has boundary/rounding ambiguity) can be some unrelated adjacent word
    instead of the actual 'only' text.

    When no 'only' text is found near the symbol (OCR sometimes misses it or reads it as
    something else) and `image` is provided, fall back to template matching the crop
    against the two stock RX-only artworks to still resolve the variant.
    """
    # Find the nearest text element containing 'only' close to the Rx symbol.
    bx = detection['bbox']
    sym_size = max(bx[2] - bx[0], bx[3] - bx[1])
    max_dist = sym_size + 20  # allow a small gap beyond the symbol extent
    best_idx, best_el, best_dist = None, None, None
    for idx, el in enumerate(text_data):
        if 'only' not in el.get('text', '').lower():
            continue
        dist = bbox_distance(bx, el['bbox'])
        if dist <= max_dist and (best_dist is None or dist < best_dist):
            best_idx, best_el, best_dist = idx, el, dist
    if best_el is not None:
        # Direction accounts for the symbol's orientation (rotates into its local frame).
        dir_ = direction(detection, best_el)
        detection['bbox'] = expand_bboxes(detection['bbox'], best_el['bbox'])
        if dir_ in ('top', 'bottom'):
            detection['class_name'] = "0258 - RX Only Vertical"
        else:  # 'right' / 'left' -> side-by-side horizontal layout
            detection['class_name'] = "RX_ONLY"
        text_data.pop(best_idx)
    else:
        # No 'only' text anchor: try matching the artwork silhouette directly.
        variant = _rx_variant_by_template(detection, image)
        detection['class_name'] = variant if variant is not None else "RX"


def ce_post(detection: dict, text_data: list) -> str:
    """
    Rename a CE detection based on the 4-digit notified-body number next to it.

    A CE mark is always accompanied by the notified body's 4-digit number, placed either
    beside it (horizontal layout) or above/below it (vertical layout). This finds the
    nearest 4-digit number, expands the detection bbox to include it, removes it from
    text_data, and renames the detection to 'CE_XXXX_O' where XXXX is the number and O is
    'H' (number to the side) or 'V' (number above/below), using orientation-aware
    direction(). Mirrors rx_post.
    """
    bx = detection['bbox']
    sym_size = max(bx[2] - bx[0], bx[3] - bx[1])
    max_dist = sym_size + 25  # allow a small gap beyond the symbol extent

    def nearest_number(exact_only):
        """Nearest text element carrying a 4-digit number. When exact_only, the whole
        (stripped) text must be the 4 digits, which avoids grabbing e.g. '8888' out of a
        phone number like '+800 8888 2020'."""
        b_idx = b_el = b_dist = b_num = None
        for idx, el in enumerate(text_data):
            t = el.get('text', '').strip()
            if exact_only:
                m = re.fullmatch(r'\d{4}', t)
            else:
                m = re.search(r'\d{4}', t)
            if not m:
                continue
            dist = bbox_distance(bx, el['bbox'])
            if dist <= max_dist and (b_dist is None or dist < b_dist):
                b_idx, b_el, b_dist, b_num = idx, el, dist, m.group(0)
        return b_idx, b_el, b_num

    # Prefer a standalone 4-digit token; fall back to a 4-digit substring only if needed.
    best_idx, best_el, best_num = nearest_number(exact_only=True)
    if best_el is None:
        best_idx, best_el, best_num = nearest_number(exact_only=False)

    if best_el is not None:
        dir_ = direction(detection, best_el)  # accounts for the symbol's orientation
        orient_letter = 'H' if dir_ in ('left', 'right') else 'V'
        detection['bbox'] = expand_bboxes(detection['bbox'], best_el['bbox'])
        detection['class_name'] = f"CE_{best_num}_{orient_letter}"
        text_data.pop(best_idx)
    else:
        detection['class_name'] = "CE"


def IFU_post(detection: dict, text_data: list) -> str:
    """
    Rename an IFU detection based on the reference / phone text printed around it.

    IFU marks come in several variants that share the same artwork and are told apart purely
    by the text drawn next to the symbol:
        * 'IFU'                        -> no relevant text around the symbol.
        * '0009 - i book GEN11'        -> a 'GEN11' label directly UNDER the symbol.
        * 'eIFU Indicator_Horizontal'  -> three lines stacked to the RIGHT of the symbol:
              'www.e-ifu.com', 'EU: +800 8888 2020', 'EU: +32 2 4037222'.
        * 'IFU_EP'                     -> 'www.e-ifu.com' UNDER the symbol, plus the EU phone
              numbers and a 'USA: +1-800-729-9010' number to the RIGHT.

    Directions are evaluated with orientation-aware direction(), so the layout is read in the
    symbol's own frame and the variants survive a rotated symbol. Matched text elements are
    folded into the detection bbox and removed from text_data. Returns the new class_name.
    """
    bx = detection['bbox']
    sym_size = max(bx[2] - bx[0], bx[3] - bx[1])
    max_dist = sym_size * 2.5  # the reference / phone text sits close to the symbol

    def norm(t):
        """Space-free, lower-cased form so OCR spacing doesn't matter ('www.e-ifu.com')."""
        return re.sub(r'\s+', '', (t or '')).lower()

    # Collect nearby text, tagging each with its orientation-aware direction and a digits-only
    # form (so phone numbers match regardless of OCR spacing / punctuation).
    nearby = []
    for idx, el in enumerate(text_data):
        if bbox_distance(bx, el['bbox']) > max_dist:
            continue
        n = norm(el.get('text', ''))
        nearby.append({
            'idx': idx,
            'el': el,
            'norm': n,
            'digits': re.sub(r'\D', '', n),
            'dir': direction(detection, el),
        })

    def find(pred):
        return next((it for it in nearby if pred(it)), None)

    gen11 = find(lambda it: 'gen11' in it['norm'] and it['dir'] == 'bottom')
    eifu = find(lambda it: 'e-ifu.com' in it['norm'])
    # USA notified number '+1-800-729-9010' -> digits end in 8007299010.
    usa = find(lambda it: 'usa' in it['norm'] or it['digits'].endswith('8007299010'))

    matched = []
    if eifu is not None:
        # EU phone lines accompany both eIFU variants (numbers '...8888 2020' / '...4037222').
        eu = [it for it in nearby
              if 'e-ifu.com' not in it['norm']
              and ('eu' in it['norm'] or '88882020' in it['digits'] or '4037222' in it['digits'])]
        # 'www.e-ifu.com' UNDER the symbol (or a USA number present) marks the IFU_EP variant;
        # otherwise the reference lines sit to the right -> eIFU Indicator_Horizontal.
        if eifu['dir'] == 'bottom' or usa is not None:
            detection['class_name'] = 'IFU_EP'
        else:
            detection['class_name'] = 'eIFU Indicator_Horizontal'
        matched = [eifu] + eu + ([usa] if usa is not None else [])
    elif gen11 is not None:
        detection['class_name'] = '0009 - i book GEN11'
        matched = [gen11]
    else:
        detection['class_name'] = 'IFU'

    # Fold the matched text into the detection bbox and consume it from text_data.
    seen, remove = set(), []
    for it in matched:
        if it is None or it['idx'] in seen:
            continue
        seen.add(it['idx'])
        detection['bbox'] = expand_bboxes(detection['bbox'], it['el']['bbox'])
        remove.append(it['idx'])
    for idx in sorted(remove, reverse=True):
        text_data.pop(idx)

    return detection['class_name']


def _inner_number_string(detection: dict, text_data: list) -> str:
    """
    Find an OCR element that sits inside the detection's bbox and reads as a 1-2 digit
    number (e.g. the count printed inside a STACK_LIMIT or N_PC box). Returns the digit
    string (e.g. '12') and removes the matched OCR element from text_data so the number
    isn't double-counted downstream. Returns '' when no such number is found.
    """
    inside = find_element_inside_bbox_soft(detection['bbox'], text_data)
    if not inside:
        return ""
    digits = re.sub(r"\D", "", inside.get('text', ''))  # keep digits only
    if not re.fullmatch(r"\d{1,2}", digits):
        return ""
    try:
        text_data.remove(inside)
    except ValueError:
        pass
    return digits


def stack_limit_post(detection: dict, text_data: list) -> str:
    """
    Rename a STACK_LIMIT detection by appending the 1-2 digit number printed inside the
    symbol, e.g. 'STACK_LIMIT_12'. The number OCR element is consumed from text_data.
    Returns the new class_name.
    """
    num = _inner_number_string(detection, text_data)
    if num:
        detection['class_name'] = f"STACK_LIMIT_{num}"
    return detection['class_name']


def n_pc_post(detection: dict, text_data: list) -> str:
    """
    Rename an N_PC (packaging unit) detection by appending the 1-2 digit number printed
    inside the box, e.g. 'N_PC_6'. Mirrors stack_limit_post; previously this number was
    extracted later in process_pdf.find_input_elements(). The number OCR element is
    consumed from text_data. Returns the new class_name.
    """
    num = _inner_number_string(detection, text_data)
    if num:
        detection['class_name'] = f"N_PC_{num}"
    return detection['class_name']


def pin_connector_post(detection: dict, text_data: list) -> str:
    """
    Rename a PIN_CONNECTOR detection by appending the number of pins found in a neighboring
    text element, e.g. 'PIN_CONNECTOR_25'.

    The pin count is written next to the symbol (not inside it). Sometimes it comes with a
    descriptive label such as 'Pin Connector : 25', and sometimes it is just a bare number
    ('25') sitting beside the symbol. It may come from either the PDF text layer or OCR. We
    first look for the nearest text element that matches one of the known templates; if none
    is found we fall back to the nearest standalone 1-2 digit number.

    This symbol is rotationally symmetric, so its detected orientation is unreliable; we do
    NOT use direction() here and simply take the closest matching element regardless of side.
    Extra phrasings can be supported later by adding to `templates`.
    """
    # Each template must expose the pin count via a capture group. Add more phrasings here.
    templates = [
        r"pin\s*connector\s*:?\s*(\d{1,2})",
    ]
    patterns = [re.compile(t, re.IGNORECASE) for t in templates]
    # Fallback: a bare 1-2 digit number that is the entire (stripped) text element.
    bare_number = re.compile(r"^\s*(\d{1,2})\s*$")

    bx = detection['bbox']
    sym_size = max(bx[2] - bx[0], bx[3] - bx[1])
    max_dist = sym_size + 40  # allow a small gap beyond the symbol extent

    def _contained(el_bbox):
        """True if the element sits fully inside the symbol bbox. The pin count is printed
        BESIDE/BELOW the symbol, never within it; a number inside the bbox belongs to the
        symbol's own artwork (e.g. a stray '8' glyph) and must be ignored."""
        return (el_bbox[0] >= bx[0] and el_bbox[1] >= bx[1] and
                el_bbox[2] <= bx[2] and el_bbox[3] <= bx[3])

    def nearest(use_templates):
        """Nearest element carrying a pin count. When use_templates, match the descriptive
        phrasings; otherwise match a standalone bare number."""
        b_idx = b_el = b_num = b_dist = None
        for idx, el in enumerate(text_data):
            text = el.get('text', '') or ''
            num = None
            if use_templates:
                for pat in patterns:
                    m = pat.search(text)
                    if m:
                        num = m.group(1)
                        break
            else:
                m = bare_number.match(text)
                if m:
                    num = m.group(1)
            if num is None:
                continue
            if _contained(el['bbox']):
                continue  # number belongs to the symbol artwork, not the pin-count label
            dist = bbox_distance(bx, el['bbox'])
            if dist <= max_dist and (b_dist is None or dist < b_dist):
                b_idx, b_el, b_num, b_dist = idx, el, num, dist
        return b_idx, b_el, b_num

    # Prefer the labelled phrasing; fall back to a nearby standalone number.
    best_idx, best_el, best_num = nearest(use_templates=True)
    if best_el is None:
        best_idx, best_el, best_num = nearest(use_templates=False)

    if best_el is not None:
        detection['bbox'] = expand_bboxes(detection['bbox'], best_el['bbox'])
        detection['class_name'] = f"PIN_CONNECTOR_{best_num}"
        text_data.pop(best_idx)
    return detection['class_name']


# --- Text-anchored symbol recovery (RX / CE) --------------------------------------------
# YOLO sometimes misses the RX ("Rx only") and CE (notified-body) marks, and OCR does not
# reliably read them either. But each is always accompanied by a reliable text anchor: the
# word 'only' for RX, and a 4-digit number for CE. Starting from that anchor we template
# match the RX/CE artwork in the region to its left and above (in the anchor's own reading
# frame) to recover the symbol even when it was never detected.

_READ_UNIT = {0: (1, 0), 90: (0, 1), 180: (-1, 0), 270: (0, -1)}


@lru_cache(maxsize=8)
def _load_od_symbol_template(name: str):
    """Load and cache an object-detection stock symbol template (grayscale)."""
    p = ROOT_DIR / 'data' / 'object_detection_symbols' / f'{name}.png'
    return cv2.imread(str(p), cv2.IMREAD_GRAYSCALE)


def _reading_cross(bbox, orientation):
    """Return (reading_size, cross_size): the anchor's extent along the reading axis and
    perpendicular to it. Reading axis is x for 0/180, y for 90/270."""
    w = bbox[2] - bbox[0]
    h = bbox[3] - bbox[1]
    return (w, h) if orientation in (0, 180) else (h, w)


def _reading_dirs(orientation):
    """Unit vectors (image frame) for 'before' (reading-left) and 'above' (previous line),
    derived from the reading direction so they follow rotated text."""
    r = _READ_UNIT.get(orientation, (1, 0))
    before = (-r[0], -r[1])
    above = (r[1], -r[0])  # reading vector rotated -90 in screen coords -> reading-up
    return before, above


def _neighbor_region(bbox, dvec, ext, cross_pad):
    """Axis-aligned image region spanning from the anchor bbox outward by ext along dvec,
    padded by cross_pad on all sides."""
    x1, y1, x2, y2 = bbox
    dx, dy = dvec
    sx1, sy1 = x1 + dx * ext, y1 + dy * ext
    sx2, sy2 = x2 + dx * ext, y2 + dy * ext
    return [min(x1, x2, sx1, sx2) - cross_pad, min(y1, y2, sy1, sy2) - cross_pad,
            max(x1, x2, sx1, sx2) + cross_pad, max(y1, y2, sy1, sy2) + cross_pad]


def _locate_template_in_region(gray, region, template, base_size, orientation, scales):
    """
    Slide a polarity-normalized silhouette of `template` (rotated to `orientation` and
    sized around `base_size`) across the image `region`; return (best_score, best_bbox)
    in full-image coordinates, or (score, None) if nothing fits.
    """
    H, W = gray.shape[:2]
    x1, y1, x2, y2 = [int(v) for v in region]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(W, x2), min(H, y2)
    if x2 - x1 < 6 or y2 - y1 < 6:
        return 0.0, None
    crop_fg = _to_foreground_mask(gray[y1:y2, x1:x2])
    tmpl_fg = _tight_mask(_to_foreground_mask(template))
    if crop_fg.size == 0 or tmpl_fg.size == 0:
        return 0.0, None
    rot = {90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180,
           270: cv2.ROTATE_90_COUNTERCLOCKWISE}.get(orientation)
    if rot is not None:
        tmpl_fg = cv2.rotate(tmpl_fg, rot)
    th, tw = tmpl_fg.shape
    best_score, best_bbox = 0.0, None
    for s in scales:
        fac = (base_size * s) / max(th, tw)
        if fac <= 0:
            continue
        interp = cv2.INTER_AREA if fac < 1 else cv2.INTER_LINEAR
        t = cv2.resize(tmpl_fg, (0, 0), fx=fac, fy=fac, interpolation=interp)
        if t.shape[0] > crop_fg.shape[0] or t.shape[1] > crop_fg.shape[1]:
            continue
        res = cv2.matchTemplate(crop_fg, t, cv2.TM_CCOEFF_NORMED)
        res = np.nan_to_num(res, nan=0.0, posinf=0.0, neginf=0.0)
        _, mx, _, loc = cv2.minMaxLoc(res)
        if mx > best_score:
            bx1, by1 = x1 + loc[0], y1 + loc[1]
            best_bbox = [bx1, by1, bx1 + t.shape[1], by1 + t.shape[0]]
            best_score = float(mx)
    return best_score, best_bbox


def _overlaps_existing(bbox, detections, thresh=0.3):
    """True if bbox overlaps an existing detection by more than `thresh` of the smaller area
    (used to avoid adding a recovered symbol the model already detected)."""
    for det in detections:
        inter = intersection(bbox, det['bbox'])
        a = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
        b = (det['bbox'][2] - det['bbox'][0]) * (det['bbox'][3] - det['bbox'][1])
        m = min(a, b)
        if m > 0 and inter / m > thresh:
            return True
    return False


def _recover_symbol_from_anchor(anchor, image, detections, template, threshold):
    """
    Template-match `template` in the region to the left of and above `anchor` (in the
    anchor's reading frame). Returns the located bbox when a match >= threshold is found
    and it doesn't overlap an existing detection, else None.
    """
    orientation = anchor.get('orientation', 0) or 0
    reading_size, cross_size = _reading_cross(anchor['bbox'], orientation)
    base = cross_size  # symbol height ~ text height
    scales = [0.7, 0.85, 1.0, 1.2, 1.4, 1.6, 1.8]
    before, above = _reading_dirs(orientation)
    ext = cross_size * 3 + reading_size * 0.3
    cross_pad = cross_size * 0.9
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image

    best_score, best_bbox = 0.0, None
    for dvec in (before, above):
        region = _neighbor_region(anchor['bbox'], dvec, ext, cross_pad)
        score, bbox = _locate_template_in_region(gray, region, template, base, orientation, scales)
        if score > best_score:
            best_score, best_bbox = score, bbox
    if best_bbox is not None and best_score >= threshold and not _overlaps_existing(best_bbox, detections):
        return best_bbox
    return None


def recover_symbols_from_text(detections: list, image: np.ndarray, text_data: list) -> list:
    """
    Recover RX and CE symbols the detector missed, anchored on nearby text:
      * RX  -> anchored on the word 'only'.
      * CE  -> anchored on a 4-digit notified-body number.
    Adds a raw 'RX' / 'CE' detection at the matched location; rx_post/ce_post (run later in
    detections_postprocessing) then resolve the final class name and consume the text.
    """
    rx_tmpl = _load_od_symbol_template('RX')
    ce_tmpl = _load_od_symbol_template('CE')

    # RX from 'only'
    if rx_tmpl is not None:
        for el in text_data:
            if el.get('text', '').strip().lower() != 'only':
                continue
            bbox = _recover_symbol_from_anchor(el, image, detections, rx_tmpl, RX_MATCH_THRESHOLD)
            if bbox is not None:
                detections.append({'bbox': bbox, 'confidence': 1.0, 'class_id': -1,
                                   'class_name': 'RX', 'orientation': el.get('orientation', 0) or 0})

    # CE from a 4-digit number
    if ce_tmpl is not None:
        remove_text = set()
        for el in text_data:
            if not re.fullmatch(r'\d{4}', el.get('text', '').strip()):
                continue
            bbox = _recover_symbol_from_anchor(el, image, detections, ce_tmpl, CE_MATCH_THRESHOLD)
            if bbox is not None:
                detections.append({'bbox': bbox, 'confidence': 1.0, 'class_id': -1,
                                   'class_name': 'CE', 'orientation': el.get('orientation', 0) or 0})
                # If OCR happened to read the CE mark as literal 'CE' text, consume it so it
                # doesn't linger as a stray text element.
                for j, el2 in enumerate(text_data):
                    if el2.get('text', '').strip().upper() == 'CE' and intersection(bbox, el2['bbox']) > 0:
                        remove_text.add(j)
        for j in sorted(remove_text, reverse=True):
            text_data.pop(j)

    return detections


# --- Strand-count symbols (CR/n, MS/n) from OCR text ------------------------------------
# The Control-Release ('CR/2', 'CR/3', ...) and Multi-Strand ('MS/2', 'MS/3', ...) marks
# are stylised labels that OCR frequently reads verbatim even when YOLO misses the artwork.
# Each such OCR text is verified by template-matching the family's stock artwork
# (data/object_detection_symbols/CR_X.png / MS_X.png) around it before it is trusted, since
# a bare 'MS/2' string in body text should not become a symbol on its own.

# Valid strand counts per family (mirrors the CR_X/MS_X handling in process_pdf).
_STRAND_COUNTS = {
    'CR': {'2', '3', '4', '5', '6', '8'},
    'MS': {'2', '3', '4', '5', '6', '7', '8', '10', '12'},
}

# Minimum silhouette-match score (0..1) to accept a CR/MS template match at an OCR anchor.
STRAND_MATCH_THRESHOLD = 0.4

# 'MS/2', 'CR / 3', 'MS|10', 'MS/X' etc. The separator is often a slash but OCR may read it
# as a vertical bar or a stray '1'/'l'/'I'; the family and the count (a 1-2 digit number, or
# a literal 'X' for the generic variant) are what matter.
_STRAND_RE = re.compile(r'^\s*(MS|CR)\s*[/|1lI]\s*(\d{1,2}|[Xx])\s*$', re.IGNORECASE)


def strand_symbol_detection(image: np.ndarray, text_data: list, detections: list) -> list:
    """
    Detect Control-Release (CR/n) and Multi-Strand (MS/n) symbols from OCR text anchors.

    For every OCR line that reads like 'CR/<n>' or 'MS/<n>' (with a valid strand count),
    the family's stock artwork (CR_X.png / MS_X.png) is template-matched in the region
    around that text over 4 rotations and a range of scales. On a match >= STRAND_MATCH_THRESHOLD
    a 'CR_<n>' / 'MS_<n>' detection is added (replacing any overlapping detection so a YOLO
    CR_X/MS_X hit isn't duplicated) and the OCR text is consumed.

    Args:
        image: page image (BGR or grayscale) to crop match regions from.
        text_data: list of OCR element dicts ({'text','bbox','orientation',...}); mutated in place.
        detections: existing detections list; matched symbols are added/replaced in place.

    Returns:
        detections (the same list, mutated), mirroring box_symbol_detection's style.
    """
    if image is None or not text_data:
        return detections
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
    H, W = gray.shape[:2]

    remove_idx = set()
    for idx, el in enumerate(text_data):
        m = _STRAND_RE.match(el.get('text', '') or '')
        if not m:
            continue
        family = m.group(1).upper()  # 'MS' or 'CR'
        count = m.group(2).upper()   # a strand count ('2'..'12') or the literal 'X'
        # 'X' is the generic variant (e.g. 'MS/X' printed verbatim on some IFUs); any other
        # value must be a valid strand count for the family.
        if count != 'X' and count not in _STRAND_COUNTS[family]:
            continue
        template = _load_od_symbol_template(f'{family}_X')
        if template is None:
            continue

        # Search a region generously padded around the text so the full artwork fits.
        b = el['bbox']
        bw, bh = b[2] - b[0], b[3] - b[1]
        pad_x, pad_y = int(1.0 * bw), int(1.0 * bh)
        region = [max(0, b[0] - pad_x), max(0, b[1] - pad_y),
                  min(W, b[2] + pad_x), min(H, b[3] + pad_y)]
        base = max(bw, bh)
        scales = [0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0]

        best_score, best_bbox = 0.0, None
        for orientation in (0, 90, 180, 270):
            score, bbox = _locate_template_in_region(
                gray, region, template, base, orientation, scales)
            if score > best_score:
                best_score, best_bbox = score, bbox
        if best_score < STRAND_MATCH_THRESHOLD or best_bbox is None:
            continue

        class_name = f'{family}_{count}'  # e.g. 'MS_2', 'CR_3', 'MS_X'
        new_det = {'bbox': best_bbox, 'confidence': round(best_score, 3), 'class_id': -1,
                   'class_name': class_name, 'orientation': el.get('orientation', 0) or 0}

        # Replace an overlapping detection (e.g. a YOLO CR_X/MS_X hit) rather than duplicate.
        replaced = False
        for di, det in enumerate(detections):
            inter = intersection(best_bbox, det['bbox'])
            a = (best_bbox[2] - best_bbox[0]) * (best_bbox[3] - best_bbox[1])
            c = (det['bbox'][2] - det['bbox'][0]) * (det['bbox'][3] - det['bbox'][1])
            mn = min(a, c)
            if mn > 0 and inter / mn > 0.5:
                detections[di] = new_det
                replaced = True
                break
        if not replaced:
            detections.append(new_det)
        remove_idx.add(idx)

    for j in sorted(remove_idx, reverse=True):
        text_data.pop(j)
    return detections

def detections_postprocessing(detections: list, image: np.ndarray, text_data: list, acclm: bool = False) -> list:
    """
    Driver for post-processing steps on raw YOLO detections:
    1. Compute symbol orientation via template matching for all detections.
    2. Rename TEMP/TEMP_LO/TEMP_UP symbols based on surrounding temperature text.

    Args:
        acclm: When True, also validate each symbol against the ACCLM library and attach
            the result to its 'validations'. Off by default (only SURGERY enables it).
    Returns the updated detections list (modified in place).
    """
    # Recover RX/CE symbols missed by YOLO (and OCR) using nearby text as an anchor.
    recover_symbols_from_text(detections, image, text_data)

    for det in detections:
        if det['class_name'] in ('BARCODE', 'DATAMATRIX', 'NEEDLE'):
            continue  # Skip orientation for these classes
        orientation, acclm_validation = symbol_orientation(det, image, acclm=acclm)
        det['orientation'] = orientation

        # The generic 'RX' class has no ACCLM template, so symbol_orientation returns
        # 'no_acclm' but still gives an orientation from the stock 'RX' symbol.
        # Use that orientation to resolve the specific RX variant NOW (via rx_post), then
        # run the ACCLM check against the corrected class name.
        if det['class_name'] == 'RX':
            rx_post(det, text_data, image)
            if acclm:
                acclm_validation = acclm_validate_symbol(det['class_name'], det['bbox'], image)
        # CE marks are numbered via ce_post (CE_XXXX_H/V). ACCLM is validated against the
        # base 'CE' artwork, which the numbered variants all share.
        elif det['class_name'] == 'CE':
            ce_post(det, text_data)
            if acclm:
                acclm_validation = acclm_validate_symbol('CE', det['bbox'], image)
        # IFU marks resolve to a specific variant (plain IFU, i-book GEN11, eIFU horizontal or
        # IFU_EP) from the reference / phone text around them. Re-run the ACCLM check against
        # the resolved variant name so validation matches the final class.
        elif det['class_name'] == 'IFU':
            IFU_post(det, text_data)
            if acclm:
                acclm_validation = acclm_validate_symbol(det['class_name'], det['bbox'], image)

        if acclm_validation:  # 'acclm_pass' / 'acclm_data_error' / 'no_acclm'
            det.setdefault('validations', []).append(acclm_validation)

    for det in detections:
        if det['class_name'] in ('TEMP', 'TEMP_LO', 'TEMP_UP', 'LIMIT_HUMID', 'LIMIT_PRESSURE'):
            limit_post(det, text_data)
        # Append the count printed inside the box to the symbol name (e.g. N_PC_6,
        # STACK_LIMIT_12). N_PC's ACCLM validation already ran above against the base
        # 'N_PC' class; STACK_LIMIT does not need ACCLM validation.
        elif det['class_name'] == 'N_PC':
            n_pc_post(det, text_data)
        elif det['class_name'] == 'STACK_LIMIT':
            stack_limit_post(det, text_data)
        # Append the pin count from neighboring text (e.g. PIN_CONNECTOR_25).
        elif det['class_name'] == 'PIN_CONNECTOR':
            pin_connector_post(det, text_data)

    return detections



def box_symbol_detection(image: np.ndarray, text_data: list, detections: list) -> list:
    """
    Detect box symbols (text inside a rectangle) using OCR results and CV2.
    Matches text_data entries against BOX_SYMBOLS, verifies enclosure in a drawn box,
    then adds to detections and removes matched entries from text_data.

    Args:
        image: The page image (BGR numpy array)
        text_data: List of OCR element dicts with 'text', 'bbox', 'color', 'orientation'
        detections: Existing YOLO detections list (may be updated in place)

    Returns:
        Updated detections list
    """
    img_h, img_w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image.copy()

    def normalize_for_match(text: str) -> str:
        """Normalize OCR text to match BOX_SYMBOLS underscore-delimited format."""
        t = text.strip()
        t = re.sub(r'[\[\](){}]', '', t)  # box outline occasionally OCR'd as brackets
        t = re.sub(r'[|/]', '_', t)   # subdivision dividers
        t = re.sub(r'\s+', '_', t)    # spaces between words
        t = re.sub(r'_+', '_', t)     # collapse repeated dividers (e.g. 'REF |US' -> 'REF_US')
        t = t.strip('_')
        return t

    def find_box_boundary(bbox, scan_gray, threshold=80):
        """
        Scan outward from each side of bbox to find a dark box outline line.
        scan_gray should already be inverted if the symbol has white-on-dark text.
        Returns [x1, y1, x2, y2] if all 4 sides are found within threshold, else None.
        """
        bx1, by1, bx2, by2 = int(bbox[0]), int(bbox[1]), int(bbox[2]), int(bbox[3])
        dark_thresh = 128

        def scan_h(start_row, step):
            found = False
            for d in range(threshold + 1):
                row = start_row + d * step
                if not (0 <= row < img_h):
                    return None
                line = scan_gray[row, max(0, bx1):min(img_w, bx2)]
                if not found and len(line) > 0 and np.all(line < dark_thresh):
                    found = True
                if found and len(line) > 0 and np.all(line >= dark_thresh):
                    return row + 4*step # Add a small margin
            return None

        def scan_v(start_col, step):
            found = False
            for d in range(threshold + 1):
                col = start_col + d * step
                if not (0 <= col < img_w):
                    return None
                line = scan_gray[max(0, by1):min(img_h, by2), col]
                if not found and len(line) > 0 and np.all(line < dark_thresh):
                    found = True
                if found and len(line) > 0 and np.all(line >= dark_thresh):
                    return col + 4*step # Add a small margin
            return None

        top    = scan_h(by1, -1)
        bottom = scan_h(by2,  1)
        left   = scan_v(bx1, -1)
        right  = scan_v(bx2,  1)

        if all(v is not None for v in [top, bottom, left, right]):
            return [left, top, right, bottom]
        return None

    # Build normalized symbol lookup: normalized_text -> original BOX_SYMBOLS name
    box_sym_map = {normalize_for_match(sym): sym for sym in BOX_SYMBOLS if sym}

    indices_to_remove = set()
    new_detections = []

    for i, el in enumerate(text_data):
        if i in indices_to_remove:
            continue

        text = el.get('text', '').strip()
        if not text:
            continue

        unpad = 2

        # Determine scan image: invert if text is white (bright color)
        color = el.get('color', (0, 0, 0))
        brightness = sum(int(c) for c in color[:3]) / 3 if isinstance(color, (list, tuple)) and len(color) >= 3 else 0
        scan_gray = (255 - gray) if brightness > 200 else gray

        def commit_detection(box_bbox, sym_name):
            """Register a box-symbol detection, replacing an overlapping YOLO detection."""
            overlap_idx = None
            for di, det in enumerate(detections):
                inter = intersection(box_bbox, det['bbox'])
                det_area = (det['bbox'][2] - det['bbox'][0]) * (det['bbox'][3] - det['bbox'][1])
                box_area = (box_bbox[2] - box_bbox[0]) * (box_bbox[3] - box_bbox[1])
                min_area = min(det_area, box_area)
                if min_area > 0 and inter / min_area > 0.5:
                    overlap_idx = di
                    break
            new_det = {"bbox": box_bbox, "confidence": 1.0, "class_id": -1, "class_name": sym_name}
            if overlap_idx is not None:
                detections[overlap_idx] = new_det  # OCR result is more accurate
            else:
                new_detections.append(new_det)

        # Prefer the longest (multi-box) match starting at this element. Some symbols are
        # substrings of a combined symbol (e.g. 'REF' and 'US' both exist, but so does
        # 'REF_US'); a greedy longest-match prevents splitting 'REF_US' into two symbols.
        matched_sym = None
        matched_bbox = None
        matched_indices = None

        combined_text = text
        combined_bbox = list(el['bbox'])
        chain_indices = [i]
        cur_el = el
        # Consider this element plus up to 2 following lines (3-element symbols max).
        for _ in range(3):
            if normalize_for_match(combined_text) in box_sym_map:
                matched_sym = box_sym_map[normalize_for_match(combined_text)]
                matched_bbox = list(combined_bbox)
                matched_indices = list(chain_indices)
            next_el, next_idx = find_next_line(cur_el, text_data, thresh=25, mode='right')
            if not next_el or next_idx is False or next_idx in indices_to_remove:
                break
            combined_text = combined_text + '_' + next_el.get('text', '').strip()
            combined_bbox = expand_bboxes(combined_bbox, next_el['bbox'])
            chain_indices.append(next_idx)
            cur_el = next_el

        if not matched_sym:
            # OCR sometimes merges a leading box symbol with adjacent text into a single
            # line (e.g. 'REF 34L33M' or '[REF] 34L33M'), so the whole line never matches a
            # BOX_SYMBOL. Try to peel a leading box symbol off the front. Two layouts occur:
            #   (A) the symbol itself is boxed  -> find the box around the leading token.
            #   (B) the leading token is a plain label and the trailing value is boxed
            #       (e.g. REF followed by a boxed catalogue number).
            # In both cases a drawn box (around the symbol OR the value) confirms this is a
            # real symbol+value pair, so we register the symbol and keep the remainder text.
            # This works for horizontal AND vertical (rotated) text by peeling along the
            # reading axis implied by the element's orientation: the reading axis is x for
            # 0/180 and y for 90/270, and the leading token sits at the low end of that axis
            # for orientations 0/90 and the high end for 180/270 (see
            # calculate_bbox_orientation).
            words = text.split()
            if len(words) >= 2:
                ex1, ey1, ex2, ey2 = (int(el['bbox'][0]), int(el['bbox'][1]),
                                      int(el['bbox'][2]), int(el['bbox'][3]))
                orientation = el.get('orientation', 0) or 0
                vertical = orientation in (90, 270)
                forward = orientation in (0, 90)  # leading token at the low end of the axis
                lo_idx, hi_idx = (1, 3) if vertical else (0, 2)
                if vertical:
                    axis_lo, axis_hi, cross_thickness = ey1, ey2, ex2 - ex1
                else:
                    axis_lo, axis_hi, cross_thickness = ex1, ex2, ey2 - ey1
                axis_len = axis_hi - axis_lo
                inset = max(3, int(cross_thickness * 0.2))

                def make_box(a_lo, a_hi, cross_inset):
                    """Axis-aligned seed box spanning [a_lo, a_hi] on the reading axis,
                    inset by cross_inset on the perpendicular (cross) axis."""
                    a_lo, a_hi = int(a_lo), int(max(a_lo + 1, a_hi))
                    if vertical:
                        return [ex1 + cross_inset, a_lo, ex2 - cross_inset, a_hi]
                    return [a_lo, ey1 + cross_inset, a_hi, ey2 - cross_inset]

                def make_box_full(a_lo, a_hi):
                    """Full-cross-width box spanning [a_lo, a_hi] on the reading axis."""
                    a_lo, a_hi = int(a_lo), int(max(a_lo + 1, a_hi))
                    if vertical:
                        return [ex1, a_lo, ex2, a_hi]
                    return [a_lo, ey1, a_hi, ey2]

                full_len = len(text)
                for k in range(1, min(3, len(words))):
                    prefix_str = ' '.join(words[:k])
                    prefix_sym = box_sym_map.get(normalize_for_match(prefix_str))
                    if not prefix_sym:
                        continue
                    # Estimate the split point along the reading axis from char proportion.
                    prop = len(prefix_str) / full_len if full_len else 0
                    seg = int(axis_len * prop)
                    if forward:
                        sym_lo, sym_hi = axis_lo, axis_lo + seg
                        rem_lo, rem_hi = axis_lo + seg, axis_hi
                    else:
                        sym_lo, sym_hi = axis_hi - seg, axis_hi
                        rem_lo, rem_hi = axis_lo, axis_hi - seg

                    # Case A: the leading symbol is itself boxed. Shrink the estimated
                    # symbol sub-bbox inward so the boundary scan starts inside the drawn
                    # outline before expanding outward to find it.
                    sym_scan = make_box(sym_lo + inset, sym_hi - inset, inset)
                    box_bbox = find_box_boundary(sym_scan, scan_gray)
                    if box_bbox is not None:
                        commit_detection(box_bbox, prefix_sym)
                        # Keep the remainder text, starting just past the symbol box.
                        if forward:
                            el['bbox'] = make_box_full(max(box_bbox[hi_idx] + 2, rem_lo), axis_hi)
                        else:
                            el['bbox'] = make_box_full(axis_lo, min(box_bbox[lo_idx] - 2, rem_hi))
                        el['text'] = ' '.join(words[k:])
                        break

                    # Case B: the trailing value is boxed instead. Probe a thin seed at the
                    # middle of the remainder region (reliably inside the value's box) and
                    # expand outward to find that box. If found, register the symbol at the
                    # leading label letters and keep the (boxed) value as the remainder.
                    mid = (rem_lo + rem_hi) // 2
                    val_scan = make_box(mid - 2, mid + 2, inset)
                    val_box = find_box_boundary(val_scan, scan_gray)
                    if val_box is not None:
                        if forward:
                            sym_bbox = make_box_full(axis_lo, max(axis_lo + 1, val_box[lo_idx] - 1))
                        else:
                            sym_bbox = make_box_full(min(axis_hi - 1, val_box[hi_idx] + 1), axis_hi)
                        commit_detection(sym_bbox, prefix_sym)
                        el['text'] = ' '.join(words[k:])
                        el['bbox'] = list(val_box)
                        break
            continue

        # If this is only a single-element match, make sure it isn't actually the tail of
        # a longer symbol whose head sits to the LEFT (text_data order isn't guaranteed to
        # be left-to-right, so 'US' of 'REF_US' can be iterated before 'REF'). If a left
        # neighbor would combine into a real box symbol, defer this element so the left
        # (head) element claims the full multi-box symbol when it is processed.
        if len(matched_indices) == 1:
            left_el, left_idx = find_next_line(el, text_data, thresh=25, mode='left')
            if (left_el and left_idx is not False and left_idx not in indices_to_remove):
                left_combined = left_el.get('text', '').strip() + '_' + text
                if normalize_for_match(left_combined) in box_sym_map:
                    continue

        # Single-element matches get a small inset so the box-boundary scan starts inside
        # the text; multi-element matches already span the combined bbox.
        if len(matched_indices) == 1:
            matched_bbox = [matched_bbox[0]+unpad, matched_bbox[1]+unpad,
                            matched_bbox[2]-unpad, matched_bbox[3]-unpad]

        box_bbox = find_box_boundary(matched_bbox, scan_gray)
        if box_bbox is None:
            continue

        commit_detection(box_bbox, matched_sym)
        indices_to_remove.update(matched_indices)

    # Remove matched text elements in reverse order to preserve indices
    for idx in sorted(indices_to_remove, reverse=True):
        text_data.pop(idx)

    detections.extend(new_detections)
    return detections


def dark_box_symbol_detection(image: np.ndarray, text_data: list, detections: list) -> list:
    """
    Detect "dark box" symbols: white text inside a solid, colour-filled rounded rectangle
    (e.g. 'NAV', '8mm', 'ST SF', 'NON NAV'). Unlike box_symbol_detection (which looks for
    a thin drawn outline around normal text), here the whole box is flood-filled with a
    colour and the text is knocked out in white.

    The OCR text of each candidate is matched against DARK_BOX_SYMBOLS. Multi-part symbols
    arrive as separate OCR lines and are joined: 'NON NAV' is stacked (NON above NAV) and
    'ST SF' is side-by-side, so neighbours are chained both downward and rightward. For a
    match the filled box is located by its fill colour, that colour is extracted (stored on
    the detection as 'color', a BGR tuple - no action is taken on it for now), the box is
    added to detections and the matched OCR elements are consumed.

    Args:
        image: The page image (BGR numpy array). Pass the ORIGINAL image (not 'no_text'):
            the white glyphs must still be present for the box to read correctly.
        text_data: List of OCR element dicts with 'text', 'bbox', 'orientation'.
        detections: Existing detections list (an overlapping one is replaced in place).

    Returns:
        Updated detections list.
    """
    img_h, img_w = image.shape[:2]

    def normalize_for_match(text: str) -> str:
        """Collapse to a case-insensitive, space-free key ('ST SF' -> 'STSF', '8mm' -> '8MM')."""
        return re.sub(r'\s+', '', text).upper()

    # normalized key -> canonical DARK_BOX_SYMBOLS name
    dark_sym_map = {normalize_for_match(sym): sym for sym in DARK_BOX_SYMBOLS if sym}

    def find_filled_box(text_bbox, pad=40):
        """
        Locate the colour-filled box around a text bbox and return (box_bbox, fill_color)
        in full-image coordinates, or (None, None) when no filled box is found.

        The fill colour is found first (the dominant pixel that is neither near-white -
        page background and white text - nor near-black - adjacent graphics/outlines), then
        the box is the connected region of that colour overlapping the text.
        """
        x1, y1, x2, y2 = int(text_bbox[0]), int(text_bbox[1]), int(text_bbox[2]), int(text_bbox[3])
        rx1, ry1 = max(0, x1 - pad), max(0, y1 - pad)
        rx2, ry2 = min(img_w, x2 + pad), min(img_h, y2 + pad)
        if rx2 - rx1 < 3 or ry2 - ry1 < 3:
            return None, None
        region = image[ry1:ry2, rx1:rx2].astype(np.int32)
        flat = region.reshape(-1, 3)
        near_white = np.all(flat > 200, axis=1)
        near_black = np.all(flat < 60, axis=1)
        colored = flat[~near_white & ~near_black]
        if len(colored) < 50:  # no meaningful colour fill -> not a dark box
            return None, None

        # Dominant fill colour: coarse-quantize to a 16-step grid, take the mode, then
        # refine to the mean of the pixels close to it.
        quant = (colored // 16) * 16
        uq, cq = np.unique(quant, axis=0, return_counts=True)
        fill = uq[cq.argmax()]
        close = colored[np.abs(colored - fill).sum(1) < 60]
        fill = tuple(int(v) for v in (close.mean(0).round() if len(close) else fill))

        # A dark-box fill is a real colour, not a shade of grey. Reject near-grey fills
        # (e.g. anti-aliased grey dimension text on the diagram gets merged into a grey blob).
        if max(fill) - min(fill) < 25:
            return None, None

        # Mask everything within colour tolerance of the fill, close text holes, and take
        # the connected component that best overlaps the text bbox.
        dist = np.abs(region - np.array(fill)).sum(2)
        mask = (dist < 70).astype(np.uint8) * 255
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        tb = (x1 - rx1, y1 - ry1, x2 - rx1, y2 - ry1)
        best, best_ov = None, 0
        for c in cnts:
            bx, by, bw, bh = cv2.boundingRect(c)
            ix = max(0, min(tb[2], bx + bw) - max(tb[0], bx))
            iy = max(0, min(tb[3], by + bh) - max(tb[1], by))
            ov = ix * iy
            if ov > best_ov and bw * bh > 300:
                best_ov, best = ov, (bx, by, bw, bh)
        if best is None or best_ov <= 0:
            return None, None
        bx, by, bw, bh = best
        # The box is a SOLID fill, so the fill colour should cover most of its bounding
        # rect. A low coverage means the match is really thin text, not a filled box.
        if (mask[by:by + bh, bx:bx + bw] > 0).mean() < 0.6:
            return None, None
        return [rx1 + bx, ry1 + by, rx1 + bx + bw, ry1 + by + bh], fill

    def commit_detection(box_bbox, sym_name, color):
        """Register a dark-box detection, replacing an overlapping existing detection."""
        overlap_idx = None
        for di, det in enumerate(detections):
            inter = intersection(box_bbox, det['bbox'])
            det_area = (det['bbox'][2] - det['bbox'][0]) * (det['bbox'][3] - det['bbox'][1])
            box_area = (box_bbox[2] - box_bbox[0]) * (box_bbox[3] - box_bbox[1])
            min_area = min(det_area, box_area)
            if min_area > 0 and inter / min_area > 0.5:
                overlap_idx = di
                break
        new_det = {"bbox": box_bbox, "confidence": 1.0, "class_id": -1,
                   "class_name": sym_name, "color": color}
        if overlap_idx is not None:
            detections[overlap_idx] = new_det
        else:
            new_detections.append(new_det)

    indices_to_remove = set()
    new_detections = []

    for i, el in enumerate(text_data):
        if i in indices_to_remove:
            continue
        text = el.get('text', '').strip()
        if not text:
            continue

        # Greedy longest match starting at this element. Multi-part symbols split across OCR
        # lines are joined by chaining neighbours in every reading direction: the parts can
        # be stacked ('NON NAV' with NAV below NON) or side-by-side ('ST SF'), and for small
        # rotated boxes the two words can even carry opposite orientations (90 vs 270), which
        # places the neighbour above/left instead of below/right. All four directions are
        # searched; a wrong join simply won't match a DARK_BOX_SYMBOL. The longest chain wins.
        matched_sym, matched_bbox, matched_indices = None, None, None
        for mode in ('bottom', 'right', 'top', 'left'):
            combined_text = text
            combined_bbox = list(el['bbox'])
            chain_indices = [i]
            cur_el = el
            for _ in range(3):  # up to 3 parts (e.g. head + 2 lines)
                key = normalize_for_match(combined_text)
                if key in dark_sym_map and (matched_indices is None or len(chain_indices) > len(matched_indices)):
                    matched_sym = dark_sym_map[key]
                    matched_bbox = list(combined_bbox)
                    matched_indices = list(chain_indices)
                next_el, next_idx = find_next_line(cur_el, text_data, thresh=30, mode=mode)
                if not next_el or next_idx is False or next_idx in indices_to_remove or next_idx in chain_indices:
                    break
                combined_text = combined_text + ' ' + next_el.get('text', '').strip()
                combined_bbox = expand_bboxes(combined_bbox, next_el['bbox'])
                chain_indices.append(next_idx)
                cur_el = next_el

        if not matched_sym:
            continue

        # Defer a lone-element match that could actually be the tail (right) or bottom of a
        # longer symbol whose head sits to the left / above - OCR order isn't guaranteed, so
        # let the head element claim the full symbol when it is processed.
        if len(matched_indices) == 1:
            deferred = False
            for head_mode, combine in (('left', lambda h: h + text), ('top', lambda h: h + text)):
                nb, nb_idx = find_next_line(el, text_data, thresh=30, mode=head_mode)
                if nb and nb_idx is not False and nb_idx not in indices_to_remove:
                    if normalize_for_match(combine(nb.get('text', '').strip())) in dark_sym_map:
                        deferred = True
                        break
            if deferred:
                continue

        box_bbox, color = find_filled_box(matched_bbox)
        if box_bbox is None:  # matched the text but it isn't inside a colour-filled box
            continue

        commit_detection(box_bbox, matched_sym, color)
        indices_to_remove.update(matched_indices)

    for idx in sorted(indices_to_remove, reverse=True):
        text_data.pop(idx)

    detections.extend(new_detections)
    return detections


def circle_symbol_detection(image: np.ndarray, text_data: list, detections: list) -> list:
    """
    Detect "circle" symbols: white text inside a solid, colour-filled circle (curve-type
    markers such as 'D', 'F', 'XR'). These are the round cousins of the dark-box symbols -
    the whole disc is flood-filled with a colour and the one/two-character label is knocked
    out in white.

    Each candidate OCR element whose (space-free, upper-cased) text matches an entry of
    CURVE_TYPE_SYMBOLS is checked: the coloured disc around it is located by its fill colour
    and validated to be roughly circular (near-square bounding box, high fill coverage, and
    a contour area close to that of its enclosing circle). On a match the disc is added to
    detections as 'CURVE_TYPE_<TEXT>', its fill colour is stored on the detection as 'color'
    (a BGR tuple), and the matched OCR element is consumed.

    Args:
        image: The page image (BGR numpy array). Pass the ORIGINAL image (not 'no_text'):
            the white glyphs must still be present for the disc to read correctly.
        text_data: List of OCR element dicts with 'text', 'bbox', 'orientation'.
        detections: Existing detections list (an overlapping one is replaced in place).

    Returns:
        Updated detections list.
    """
    img_h, img_w = image.shape[:2]

    def normalize_for_match(text: str) -> str:
        """Collapse to a case-insensitive, space-free key ('X R' -> 'XR')."""
        return re.sub(r'\s+', '', text).upper()

    # normalized key -> canonical CURVE_TYPE_SYMBOLS name
    curve_sym_map = {normalize_for_match(sym): sym for sym in CURVE_TYPE_SYMBOLS if sym}

    def match_curve_symbol(text: str):
        """Return the canonical CURVE_TYPE symbol for an OCR text, or None.

        Besides the exact normalized key, this tolerates common OCR misreads of the single
        white glyph knocked out of the disc: the letter is sometimes doubled or split with a
        stray separator (e.g. 'D' read as 'DD' or 'D-D'). We therefore also try a key with
        all non-alphanumeric characters removed and consecutive duplicate letters collapsed.
        None of the real symbols ('D', 'F', 'XR') contain a doubled letter, so collapsing is
        safe.
        """
        key = normalize_for_match(text)
        if key in curve_sym_map:
            return curve_sym_map[key]
        alnum = re.sub(r'[^A-Z0-9]', '', key)          # drop dashes/dots: 'D-D' -> 'DD'
        collapsed = re.sub(r'(.)\1+', r'\1', alnum)    # collapse runs:    'DD'  -> 'D'
        return curve_sym_map.get(alnum) or curve_sym_map.get(collapsed)

    def find_filled_circle(text_bbox, pad=None):
        """
        Locate the colour-filled circle around a text bbox and return (circle_bbox,
        fill_color) in full-image coordinates, or (None, None) when no filled circle is
        found. Mirrors dark_box's find_filled_box but additionally requires the fill
        region to be circular.
        """
        x1, y1, x2, y2 = int(text_bbox[0]), int(text_bbox[1]), int(text_bbox[2]), int(text_bbox[3])
        # Pad relative to the text size: the disc can be noticeably larger than its label, so
        # a fixed small pad would clip the circle. But too generous a floor makes the search
        # region bleed into adjacent colour-filled symbols (e.g. a neighbouring 'mm' box),
        # letting their fill colour dominate and the disc be missed - so scale with the text
        # and keep only a small floor.
        if pad is None:
            pad = max(25, int(0.9 * max(x2 - x1, y2 - y1)))
        rx1, ry1 = max(0, x1 - pad), max(0, y1 - pad)
        rx2, ry2 = min(img_w, x2 + pad), min(img_h, y2 + pad)
        if rx2 - rx1 < 3 or ry2 - ry1 < 3:
            return None, None
        region = image[ry1:ry2, rx1:rx2].astype(np.int32)
        flat = region.reshape(-1, 3)
        near_white = np.all(flat > 200, axis=1)
        near_black = np.all(flat < 60, axis=1)
        colored = flat[~near_white & ~near_black]
        if len(colored) < 50:  # no meaningful colour fill -> not a circle symbol
            return None, None

        # Dominant fill colour (see dark_box.find_filled_box for the rationale).
        quant = (colored // 16) * 16
        uq, cq = np.unique(quant, axis=0, return_counts=True)
        fill = uq[cq.argmax()]
        close = colored[np.abs(colored - fill).sum(1) < 60]
        fill = tuple(int(v) for v in (close.mean(0).round() if len(close) else fill))

        # A circle fill is a real colour, not a shade of grey.
        if max(fill) - min(fill) < 25:
            return None, None

        dist = np.abs(region - np.array(fill)).sum(2)
        mask = (dist < 70).astype(np.uint8) * 255
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        tb = (x1 - rx1, y1 - ry1, x2 - rx1, y2 - ry1)
        best, best_ov, best_cnt = None, 0, None
        for c in cnts:
            bx, by, bw, bh = cv2.boundingRect(c)
            ix = max(0, min(tb[2], bx + bw) - max(tb[0], bx))
            iy = max(0, min(tb[3], by + bh) - max(tb[1], by))
            ov = ix * iy
            if ov > best_ov and bw * bh > 300:
                best_ov, best, best_cnt = ov, (bx, by, bw, bh), c
        if best is None or best_ov <= 0:
            return None, None
        bx, by, bw, bh = best

        # Circularity gates:
        #  - the bounding box is near-square (a circle has aspect ratio ~1),
        #  - the fill covers most of the bounding rect (a solid disc),
        #  - the contour area is close to that of the enclosing circle (pi*r^2), which a
        #    square/rounded-rect would exceed relative to its inscribed circle.
        aspect = bw / bh if bh else 0
        if not (0.7 <= aspect <= 1.4):
            return None, None
        # Coverage of the bounding rect by the fill mask. A circle inscribed in its bounding
        # square fills ~0.785; the white glyph knocked out of the disc lowers this, and on a
        # small disc with a chunky letter it can dip to ~0.6, so use a slightly relaxed floor.
        # The circularity gate below still rejects non-disc shapes.
        if (mask[by:by + bh, bx:bx + bw] > 0).mean() < 0.55:
            return None, None
        area = cv2.contourArea(best_cnt)
        (cx, cy), radius = cv2.minEnclosingCircle(best_cnt)
        circle_area = np.pi * radius * radius
        if circle_area <= 0 or area / circle_area < 0.6:
            return None, None
        # Build the bbox from the enclosing circle (centre + radius) rather than the raw
        # contour boundingRect: the colour mask can miss anti-aliased edge pixels, leaving a
        # boundingRect slightly smaller than the visible disc. The circle bounds wrap it fully.
        cx, cy = rx1 + cx, ry1 + cy
        bx1 = int(max(0, np.floor(cx - radius)))
        by1 = int(max(0, np.floor(cy - radius)))
        bx2 = int(min(img_w, np.ceil(cx + radius)))
        by2 = int(min(img_h, np.ceil(cy + radius)))
        return [bx1, by1, bx2, by2], fill

    def commit_detection(circle_bbox, sym_name, color):
        """Register a circle detection, replacing an overlapping existing detection."""
        overlap_idx = None
        for di, det in enumerate(detections):
            inter = intersection(circle_bbox, det['bbox'])
            det_area = (det['bbox'][2] - det['bbox'][0]) * (det['bbox'][3] - det['bbox'][1])
            box_area = (circle_bbox[2] - circle_bbox[0]) * (circle_bbox[3] - circle_bbox[1])
            min_area = min(det_area, box_area)
            if min_area > 0 and inter / min_area > 0.5:
                overlap_idx = di
                break
        new_det = {"bbox": circle_bbox, "confidence": 1.0, "class_id": -1,
                   "class_name": sym_name, "color": color}
        if overlap_idx is not None:
            detections[overlap_idx] = new_det
        else:
            new_detections.append(new_det)

    indices_to_remove = set()
    new_detections = []

    for i, el in enumerate(text_data):
        if i in indices_to_remove:
            continue
        text = el.get('text', '').strip()
        if not text:
            continue

        matched_sym = match_curve_symbol(text)
        if not matched_sym:
            continue

        circle_bbox, color = find_filled_circle(el['bbox'])
        if circle_bbox is None:  # matched the text but it isn't inside a colour-filled circle
            continue

        commit_detection(circle_bbox, f"CURVE_TYPE_{matched_sym}", color)
        indices_to_remove.add(i)

    for idx in sorted(indices_to_remove, reverse=True):
        text_data.pop(idx)

    detections.extend(new_detections)
    return detections

