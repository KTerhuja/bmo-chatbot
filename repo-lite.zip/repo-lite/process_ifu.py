import os
import sys
import json
import pandas as pd
from pathlib import Path
import numpy as np

# Setup Path
ROOT_DIR = Path(__file__).parent.absolute()
sys.path.append(str(ROOT_DIR))

# Custom Imports
from utils_ifu.extraction import extract_data, get_pdf_type
from utils_ifu.load_models import load_llm, load_ocr
from utils_ifu.genai import generate_translations
from utils_ifu.structural_analysis import create_difference_report, compare_texts
from utils_ifu.processing import restructure_text
from utils_ifu.semantic_analysis import perform_semantic_analysis
from utils_ifu.embeddings import match_lists_by_embeddings, match_lists, align_lists
from utils_ifu.symbol_legends import validate_symbols_and_detect_objects
from utils_ifu.legends_map import get_legends_map
from utils_ifu.load_models import load_yolo_model
        
class IFUProcessor:
    def __init__(self):
        """Initialize the processor and persistent clients."""
        self.client_ocr = load_ocr() #
        self.llm = None
        self.llm_structured = None
        self.client_embed = None
        self.current_gpt_version = None
        self.response_json = {}
        yolo_path = os.path.join(ROOT_DIR, 'object_detection', 'best.pt')
        self.yolo_model = load_yolo_model(yolo_path)

    def _initialize_llm(self, gpt_version):
        """Internal helper to load/switch LLM versions only when necessary."""
        if self.current_gpt_version != gpt_version:
            print(f"Loading {gpt_version}...")
            # Updated to pass the version to load_llm
            self.llm, self.llm_structured, self.client_embed = load_llm(gpt_version=gpt_version)
            self.current_gpt_version = gpt_version

    def process_file(self, pdf_path, gpt_version="gpt-5.1", mode="local", class_legend_mapping=None, skip_translation=False):
        """
        The main orchestration pipeline.
        gpt_version: Accepts "gpt-4.1" or "gpt-5.1"
        """
        pdf_type = get_pdf_type(pdf_path, mode)

        # Ensure the correct LLM version is loaded
        self._initialize_llm(gpt_version)

        # 1. Data Extraction
        data_json = self._extract_content(pdf_path, pdf_type, mode)

        # 2. Translation
        if not skip_translation:
            translated_json, mapper_en_translated = generate_translations(data_json, self.llm)
            self.response_json['translation'] = translated_json

            # 3. Structural & Semantic Analysis
            self.response_json['structural_analysis'] = {
                'table_analysis': self._analyze_tables(data_json, pdf_type,translated_json),
                'structural_comparison': self._compare_text_structure(data_json, translated_json),
                'semantic_analysis': self._analyze_semantics(translated_json, mapper_en_translated),
                'full_pairs': self._match_embeddings(data_json, translated_json, mapper_en_translated)
            }

        # 4. Symbol & Legend Validation
        legend_path = os.path.join(ROOT_DIR, "ifu_models/symbol_legends_v3.2.db")
        yolo_path = os.path.join(ROOT_DIR, 'object_detection', 'best.pt')
        page_results, symbol_results = validate_symbols_and_detect_objects(self.client_ocr,
            self.llm_structured,self.llm, pdf_path, data_json, legend_path, 
            yolo_path, class_legend_mapping, 4, pdf_type, mode=mode
        )

        print(page_results)
        
        self.response_json['symbol_legends_validation'] = {
            'legends_validation': page_results,
            'symbol validation': symbol_results
        }

        return self.response_json

    def _extract_content(self, pdf_path, pdf_type, mode, extract_images=True):
        """Handles local or blob storage extraction."""
        if mode == "blob":
            return extract_data(pdf_path, pdf_type, self.llm_structured,self.llm, self.client_ocr,self.yolo_model,extract_images =extract_images, mode="blob")
        
        return extract_data(pdf_path, pdf_type, self.llm_structured,self.llm, self.client_ocr,self.yolo_model, extract_images =extract_images, mode="local")

    def _analyze_tables(self, data_json, pdf_type, translated_json):
        """Generates difference reports for tables across languages."""
        table_analysis = {}
        for lan in translated_json.keys():
            table_analysis[lan] = []
            if len(data_json['en']['table']) != len(data_json[lan]['table']):
                table_analysis[lan].append({
                    "table": None,
                    "img_path_original": None,
                    "img_path_vendor": None
                })

            else:

                for i in range(len(data_json['en']['table'])):
                    original_table = data_json['en']['table'][i]['table']

                    if lan== 'ar' and pdf_type == "grid":
                        vendor_table = data_json[lan]['table'][-i-1]['table']
                        if original_table.shape == vendor_table.shape:
                    
                            diff_df = create_difference_report(original_table, vendor_table)
                            # diff_df = diff_df.dropna(subset=['Original_Value']).drop(['Row', 'Column'], axis=1)
                            
                            table_analysis[lan].append({
                                "table": diff_df.to_json(orient="records", force_ascii=False, indent=2),
                                "img_path_original": [data_json["en"]['table'][i]['image_path']],
                                "img_path_vendor": [data_json[lan]['table'][-i-1]['image_path']]
                            })

                    else:
                        vendor_table = data_json[lan]['table'][i]['table']
                        

                        if original_table.shape == vendor_table.shape:
                        
                            diff_df = create_difference_report(original_table, vendor_table)
                            # diff_df = diff_df.dropna(subset=['Original_Value']).drop(['Row', 'Column'], axis=1)
                            
                            table_analysis[lan].append({
                                "table": diff_df.to_json(orient="records", force_ascii=False, indent=2),
                                "img_path_original": [data_json["en"]['table'][i]['image_path']],
                                "img_path_vendor": [data_json[lan]['table'][i]['image_path']]
                            })
        return table_analysis

    def _compare_text_structure(self, data_json, translated_json):
        """Compares restructured text from vendor and AI."""
        comparison = {}
        original_text = data_json['en']['text']
        for to_lan, content in translated_json.items():
            vendor_text = data_json[to_lan]['text']
            ai_translated = content['ai']
            # compare_texts(original,vendor, translated)
            df = compare_texts(original_text, vendor_text, ai_translated)
            df.reset_index(inplace=True)
            comparison[to_lan] = df.to_json(orient="records", force_ascii=False, indent=2)
        return comparison

    def _analyze_semantics(self, translated_json, mapper_en_translated):
        """Performs semantic validation using the structured LLM."""
        analysis = perform_semantic_analysis(translated_json, mapper_en_translated, self.llm_structured)
        return {lan: df.to_json(orient="records", force_ascii=False, indent=2) for lan, df in analysis.items()}

    def _match_embeddings(self, data_json, translated_json, mapper_en_translated):
        """Pairs text segments based on vector similarity."""
        full_pairs = {}
        for lan in data_json.keys():
            if lan not in ["en", "misc"]:
                vendor = restructure_text(data_json[lan]['text']).splitlines()
                translated = mapper_en_translated[lan]['translated'].values.tolist()
                english = mapper_en_translated[lan]['original'].values.tolist()
                full_pair = align_lists(translated, english, vendor)
                df = pd.DataFrame(full_pair)
                df = df.groupby(df.iloc[:, -1].replace('', np.nan).notna().cumsum()).agg(lambda x: ' '.join(x.dropna().astype(str))).reset_index(drop=True)
                full_pair = df.to_json(orient="records", force_ascii=False, indent=2)
                full_pairs[lan] = full_pair
                
        return full_pairs

    def save_results(self, output_path="sample_response.json"):
        """Saves the processed data to a JSON file."""
        with open(output_path, "w") as f:
            json.dump(self.response_json, f, indent=4)

    