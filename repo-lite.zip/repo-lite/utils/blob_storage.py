from azure.storage.blob import BlobServiceClient
import cv2
import fitz
from io import BytesIO
import os 
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 
from utils.aspose_words import docx_to_pdf

sas_blob = os.getenv("sas_blob") 
container_name = os.getenv("container_name", "acm")

# Get the account URL without SAS token
account_url = os.getenv("account_url")
sas_token = sas_blob  # Using the existing sas_blob variable

def read_file(blob_name):
    try:
        # Create BlobServiceClient with account URL and SAS token
        blob_service_client = BlobServiceClient(account_url=account_url, credential=sas_token)
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client(blob_name)
        
        # Download the blob content
        downloaded_blob = blob_client.download_blob()
        content = downloaded_blob.readall()
        return content
    except Exception as e:
        print(f"Error reading file: {e}")
        return None

def write_file(blob_name, content):
    try:
        # Create BlobServiceClient with account URL and SAS token
        blob_service_client = BlobServiceClient(account_url=account_url, credential=sas_token)
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client(blob_name)
        
        # Upload the content
        blob_client.upload_blob(content, overwrite=True)
        return True
    except Exception as e:
        print(f"Error writing file: {e}")
        return False

def write_img(blob_name, img):
    # Check if image was successfully loaded
    if img is not None:
        # Encode image to PNG format
        _, img_encoded = cv2.imencode('.png', img)
        # Convert to bytes
        img_bytes = img_encoded.tobytes()
        
        # Upload to Azure Storage
        result = write_file(blob_name, img_bytes)
        print(f"Image upload {'successful' if result else 'failed'}")
    else:
        print("Error: Could not load image")

def read_pdf(blob_name):
    try:
        # Get PDF bytes from storage
        pdf_bytes = read_file(blob_name)
        if pdf_bytes is None:
            return None
            
        # Create a fitz document from the bytes
        memory_stream = BytesIO(pdf_bytes)
        doc = fitz.open(stream=memory_stream, filetype="pdf")
        return doc
    except Exception as e:
        print(f"Error processing PDF: {e}")
        return None

def read_docx(blob_name, local=False):
    try:
        # Get DOCX bytes from storage
        if not local:
            doc_bytes = read_file(blob_name)
        else:
            doc_bytes = Path(blob_name).read_bytes() # In this case blob_name is just the path
        if doc_bytes is None:
            return None, None, None
        
        from_bytes, redline_bytes, annotations = docx_to_pdf(doc_bytes)

        # Create a fitz document from the bytes
        from_doc = fitz.open(stream=BytesIO(from_bytes), filetype="pdf")
        if redline_bytes:
            redline_doc = fitz.open(stream=BytesIO(redline_bytes), filetype="pdf")
        else:
            redline_doc = None
        return from_doc, redline_doc, annotations
    except ValueError as e:
        print(f"Error processing DOCX: {e}")
        return None, None

def delete_file(blob_name):
    """
    Delete a file from Azure Blob Storage.
    Created for deleting files during unit testing
    """
    try:
        # Create BlobServiceClient with account URL and SAS token
        blob_service_client = BlobServiceClient(account_url=account_url, credential=sas_token)
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client(blob_name)
        
        # Delete the blob
        blob_client.delete_blob()
        return True
    except Exception as e:
        print(f"Error deleting file: {e}")
        return False
