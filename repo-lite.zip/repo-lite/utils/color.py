import pickle
import math
from scipy.spatial import distance
import pandas as pd
from pathlib import Path
import os
import cv2
import numpy as np
from sklearn.cluster import KMeans

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo

def load_pantone_rgb():
    # Read CSV
    df = pd.read_csv(os.path.join(ROOT_DIR,"data/pantone_to_rgb.csv"), index_col=0)
    
    # Convert DataFrame to dictionary with RGB tuples
    pantone_to_rgb = {
        index: tuple(row) 
        for index, row in df.iterrows()
    }
    
    return pantone_to_rgb

# Load in the rgb-pantone mapping
pantone_to_rgb = load_pantone_rgb()

def get_common_colors(image, min_percentage=0.10, white_threshold=220, black_threshold=35, return_all_colors=False):
    """
    Get most common colors in an image using direct pixel counting.
    
    Args:
    image (numpy.ndarray): Input image as a numpy array (BGR format)
    min_percentage (float): Minimum percentage of pixels for a color to be considered (default 1%)
    white_threshold (int): RGB values above this are considered close to white
    black_threshold (int): RGB values below this are considered close to black
    
    Returns:
    list: List of dictionaries containing 'color' (BGR), 'count', and 'percentage'
    """
    # Downsample image considerably for speed
    image = cv2.resize(image, (int(image.shape[1]*0.1), int(image.shape[0]*0.1)))
    
    # Create dictionary to store color counts
    color_counts = {}
    
    # Iterate through pixels
    for bgr in image.reshape(-1, 3):
        # Skip colors close to white or black
        if all(c > white_threshold for c in bgr) or all(c < black_threshold for c in bgr):
            continue
            
        color = tuple(int(c) for c in bgr)
        color_counts[color] = color_counts.get(color, 0) + 1

    total_pixels = sum(color_counts.values())
    min_pixels = int(total_pixels * min_percentage)

    # Convert to list of dictionaries with percentage
    colors = [
        {
            'color': color,
            'count': count,
            'percentage': (count / total_pixels) * 100
        }
        for color, count in color_counts.items()
        if count >= min_pixels
    ]
    
    # Sort by count in descending order
    colors.sort(key=lambda x: x['count'], reverse=True)
    if return_all_colors:
        return colors
    if colors:
        return colors[0]['color']
    else:
        return None


def compare_colors(image1, image2, threshold=15):
    """
    Compare the top two colors of two images.
    
    Args:
        colors1 (list): List of dictionaries for image 1's colors with 'color'.
        colors2 (list): List of dictionaries for image 2's colors with 'color'.
        threshold (float): Euclidean distance threshold (default 15).
        
    Returns:
        bool: True if the top two colors match within threshold, False otherwise.
    """
    colors1 = get_common_colors(image1, min_percentage=.15, return_all_colors=True)
    colors2 = get_common_colors(image2, min_percentage=.15, return_all_colors=True)
    
    # Extract the top two colors from each list
    def get_top_colors(colors):
        if len(colors) == 0:
            return []
        elif len(colors) == 1:
            return [colors[0]['color']]
        else: # len(colors) >= 2
            return [colors[0]['color'], colors[1]['color']]

    top_colors1 = get_top_colors(colors1)
    top_colors2 = get_top_colors(colors2)

    # Check if one has only one color and the other has two
    if len(top_colors1) != len(top_colors2):
        return False

    # Compare each corresponding color
    for c1, c2 in zip(top_colors1, top_colors2):
        if euclidean_distance(c1, c2) > threshold:
            return False

    return True

def int_to_rgba(color: int):
    """
    Convert an int color (what fitz reads in pdf) to rgba format
    """
    val = color & 0xFFFFFFFF
    a = (val >> 24) & 0xFF
    r = (val >> 16) & 0xFF
    g = (val >> 8) & 0xFF
    b = val & 0xFF
    return (b, g, r)

def euclidean_distance(c1, c2):
    return math.sqrt(sum((int(a) - int(b)) ** 2 for a, b in zip(c1, c2))) # the int cast is to avoid overflow in np.uint8

def same_color(color1, color2, threshold=30, black_threshold=60):
    """
    Compare two colors considering them the same if they are within threshold distance.
    Special handling for shades of black: if both colors are dark (all channels < black_threshold),
    they are considered the same color regardless of euclidean distance.
    
    Args:
        color1: First color (BGR tuple)
        color2: Second color (BGR tuple)
        threshold: Euclidean distance threshold for regular colors (default 30)
        black_threshold: RGB value below which a color is considered "black-ish" (default 128, which is 50% brightness)
    
    Returns:
        bool: True if colors are considered the same, False otherwise
    """
    if not (color1 and color2):
        # If either color1 or color2 are None (rare), assume they are the same
        return True
    
    # Check if both colors are shades of black
    is_black1 = all(c < black_threshold for c in color1[:3])
    is_black2 = all(c < black_threshold for c in color2[:3])
    
    # If both are shades of black, consider them the same
    if is_black1 and is_black2:
        return True
    
    # Otherwise, use euclidean distance with threshold
    if euclidean_distance(color1[:3], color2[:3]) > threshold:
        return False
    return True

def get_text_color(img):
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Threshold (Otsu helps auto adapt to light/dark text)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Decide if we need to invert: background should be white
    white_pixels = np.sum(thresh == 255)
    black_pixels = np.sum(thresh == 0)

    if black_pixels < white_pixels:
        # Invert so background is white and text is black
        thresh = ~thresh

    # Find contours with hierarchy
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)

    if hierarchy is None:
        return None, None

    # Mask for text (external contours only)
    mask = np.zeros(gray.shape, dtype=np.uint8)
    for i, h in enumerate(hierarchy[0]):
        # Only take external contours (parent == -1)
        if h[3] == -1:
            cv2.drawContours(mask, contours, i, 255, -1)
        else:
            cv2.drawContours(mask, contours, i, 0, -1) # For "holes" inside letters (like P, O, D etc.)


    # Calculate average color inside mask (foreground / text)
    text_pixels = img[mask == 255]
    if text_pixels.size == 0:
        #No text pixels detected
        text_color = (0, 0, 0)
    else:
        # Find unique pixels and their counts
        unique_pixels, counts = np.unique(text_pixels, axis=0, return_counts=True)

        # Find the pixel with the highest count (mode)
        mode_index = np.argmax(counts)
        text_color = tuple(unique_pixels[mode_index]) 
           
    # Calculate average color outside mask (background)
    bg_pixels = img[mask == 0]
    if bg_pixels.size == 0:
        bg_color = (255, 255, 255) #No bg pixels detected
    else:
        # Find unique pixels and their counts
        unique_pixels, counts = np.unique(bg_pixels, axis=0, return_counts=True)

        # Find the pixel with the highest count (mode)
        mode_index = np.argmax(counts)
        bg_color = tuple(unique_pixels[mode_index])
    return text_color, bg_color