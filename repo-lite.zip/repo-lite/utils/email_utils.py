import os
import smtplib
from email.message import EmailMessage

from constants import Current_Label_and_Future_Label, From_label_and_To_label

SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = os.getenv("SMTP_PORT")
SMTP_SENDER = os.getenv("SMTP_SENDER")
sas_blob = os.getenv("sas_blob")


def send_email(to_email: str, subject: str, body: str):
    """Send an HTML email via SMTP."""
    message = EmailMessage()
    message["From"] = SMTP_SENDER
    message["To"] = to_email
    message["Subject"] = subject
    message.set_content(body, subtype="html")
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.send_message(message)
    except Exception as e:
        print(f"Failed to send email: {e}")


def get_project_recipients(project):
    """Return a dict {email: name} for project owner and creator (deduplicated)."""
    if project.owner_email.lower() == project.created_by_email.lower():
        return {project.owner_email: project.owner_name}
    return {
        project.owner_email: project.owner_name,
        project.created_by_email: project.created_by_name,
    }


def get_comparison_type_display(project):
    """Return the display-friendly comparison type string."""
    return (
        Current_Label_and_Future_Label
        if project.comparision_type == From_label_and_To_label
        else project.comparision_type
    )


def _attachments_html(attachments):
    """Render attachment list items as HTML."""
    return ''.join(
        f'<li><a href="{att["fileurl"]}?{sas_blob}">{att["filename"]}</a></li>'
        for att in attachments
    )


def _project_detail_rows(project, comparison_type, attachments):
    """Common HTML table rows for project details (full template)."""
    return f"""
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Project Name</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.project_name}</td>
                    </tr>
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Document Type</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.document_type}</td>
                    </tr>
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Comparison Type</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{comparison_type}</td>
                    </tr>
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Owner</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.owner_name}</td>
                    </tr>
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Created by</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.created_by_name}</td>
                    </tr>
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Attachments</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">
                            <ul>
                                {_attachments_html(attachments)}
                            </ul>
                        </td>
                    </tr>"""


def build_project_success_body(name, project, comparison_type, attachments, inspection_link):
    """Build the success email HTML body for a standard project."""
    return f"""
            <html>
            <body>
                <p>Dear {name},</p>
                <p>The report is ready for inspection. You can start execution on the project and proofreading.</p>
                <p>To access the inspection report click here <a href="{inspection_link}">Inspection Report</a>.</p>
                <p>Below are the project details:</p>
                <table style="width:100%; border-collapse: collapse;">
                    {_project_detail_rows(project, comparison_type, attachments)}
                </table>
                <p>Best Regards,</p>
                <p>Autocheckmate Team</p>
            </body>
            </html>
            """


def build_project_failure_body(name, project, comparison_type, attachments, error):
    """Build the failure email HTML body for a standard project."""
    return f"""
            <html>
            <body>
                <p>Dear {name},</p>
                <p>The Inspection Report Generation Failed for {project.project_name}.</p>
                <p>Below are the project details and the error:</p>
                <table style="width:100%; border-collapse: collapse;">
                    {_project_detail_rows(project, comparison_type, attachments)}
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Failure Message</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{error}</td>
                    </tr>
                </table>
                <p>Best Regards,</p>
                <p>Autocheckmate Team</p>
            </body>
            </html>
            """


def build_ifu_success_body(name, project, inspection_link):
    """Build the success email HTML body for an IFU project."""
    return f"""
            <html>
            <body>
                <p>Dear {name},</p>
                <p>The IFU translation processing has finished for {project.project_name}.</p>
                <p>You can inspect the project here: <a href="{inspection_link}">Inspection Report</a></p>
                <p>Project details:</p>
                <table style="width:100%; border-collapse: collapse;">
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Project Name</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.project_name}</td>
                    </tr>
                    <tr>
                        <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Document Type</th>
                        <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.document_type}</td>
                    </tr>
                </table>
                <p>Best Regards,</p>
                <p>Autocheckmate Team</p>
            </body>
            </html>
            """


def build_ifu_failure_body(name, project, error):
    """Build the failure email HTML body for an IFU project."""
    return f"""
        <html>
        <body>
            <p>Dear {name},</p>
            <p>The Inspection Report Generation Failed for <strong>{project.project_name}</strong>.</p>
            <p>Failure message: {error}</p>
            <table style="width:100%; border-collapse: collapse;">
                <tr>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Project Name</th>
                    <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.project_name}</td>
                </tr>
                <tr>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Document Type</th>
                    <td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">{project.document_type}</td>
                </tr>
            </table>
            <p>Best Regards,</p>
            <p>Autocheckmate Team</p>
        </body>
        </html>
        """


def notify_project_success(project, attachments, send_email_flag=True):
    """Send success notification emails for a completed standard project."""
    if not send_email_flag:
        return
    recipients = get_project_recipients(project)
    comparison_type = get_comparison_type_display(project)
    inspection_link = f"{os.environ['APP_URL'].rstrip('/')}/report/{project.id}"
    subject = f"Inspection Report is Ready for Project '{project.project_name}'"
    for email, name in recipients.items():
        body = build_project_success_body(name, project, comparison_type, attachments, inspection_link)
        send_email(email, subject, body)


def notify_project_failure(project, attachments, error, send_email_flag=True):
    """Send failure notification emails for a standard project."""
    if not send_email_flag:
        return
    recipients = get_project_recipients(project)
    comparison_type = get_comparison_type_display(project)
    subject = f"Inspection Report generation failed for Project '{project.project_name}'"
    for email, name in recipients.items():
        body = build_project_failure_body(name, project, comparison_type, attachments, error)
        send_email(email, subject, body)


def notify_ifu_success(project, send_email_flag=True):
    """Send success notification emails for a completed IFU project."""
    if not send_email_flag:
        return
    recipients = get_project_recipients(project)
    inspection_link = f"{os.environ['APP_URL'].rstrip('/')}/project-details/{project.id}/ifu/translation-analysis"
    subject = f"Inspection Report is Ready for Project '{project.project_name}'"
    for email, name in recipients.items():
        body = build_ifu_success_body(name, project, inspection_link)
        send_email(email, subject, body)


def notify_ifu_comparison_success(project, attachments, send_email_flag=True):
    """Send success notification emails for a completed IFU comparison project."""
    if not send_email_flag:
        return
    recipients = get_project_recipients(project)
    comparison_type = get_comparison_type_display(project)
    inspection_link = f"{os.environ['APP_URL'].rstrip('/')}/project-details/{project.id}/ifu-comparison/text-comparison"
    subject = f"Inspection Report is Ready for Project '{project.project_name}'"
    for email, name in recipients.items():
        body = build_project_success_body(name, project, comparison_type, attachments, inspection_link)
        send_email(email, subject, body)


def notify_ifu_failure(project, error, send_email_flag=True):
    """Send failure notification emails for an IFU project."""
    if not send_email_flag:
        return
    recipients = get_project_recipients(project)
    subject = f"Inspection Report generation failed for Project '{project.project_name}'"
    for email, name in recipients.items():
        body = build_ifu_failure_body(name, project, error)
        send_email(email, subject, body)
