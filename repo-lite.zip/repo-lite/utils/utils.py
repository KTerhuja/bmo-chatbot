import cv2
import pandas as pd
import numpy as np
from time import time
import fitz
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 
from utils.color import same_color

def rect_to_list(rect):
    """
    Convert a fitz.Rect object to a list in the format [xmin, ymin, xmax, ymax].

    Args:
        rect (fitz.Rect): The input rectangle.

    Returns:
        list: The rectangle as a list [xmin, ymin, xmax, ymax].
    """
    return [int(rect.x0), int(rect.y0), int(rect.x1), int(rect.y1)]

def validations_join(from_element, to_element):
    """ Join validation lists handling duplicates, None, and empty lists"""
    if from_element == None and  to_element == None:
        return []
    if from_element == None:
        return to_element.get('validations', [])
    if to_element == None:
        return from_element.get('validations', [])
    return list(set(from_element.get('validations', []) + to_element.get('validations', [])))

def validations_str(validations):
    """
    return validations in comma separated string or Pass
    """
    if not validations:
        return 'Pass'
    if validations == 'Pass':
        return 'Pass'
    if type(validations) == str:
        raise ValueError("validations should be a list, not a string (except for 'Pass')")
    return ", ".join(validations)

def validations_append(element, val):
    element.setdefault("validations", []).append(val) 

def value_accuracy_str(validations, expected_value=None):
    value_accuracy = "Match" # Start assuming a match
    data_errors = False
    data_checks = []
    validations_filtered =[]
    if validations:
        for v in validations:
            if v.endswith('_pass'): 
                data_checks.append(v[:v.find('_pass')]) # Extract the check name without '_pass'
            elif v.endswith('_data_error'): 
                data_checks.append(v[:v.find('_data_error')]) # Extract failed data checks too
                if v not in ['SEA_data_error', 'address_db_data_error', 'font_data_error']: # Ignore these as they will be redundant with other validations they will trigger (i.e. address_error)
                    validations_filtered.append(v) # Keep validations that are not '_pass' 
                value_accuracy = "Mismatch"
                data_errors = True
            else:
                value_accuracy = "Mismatch"
                validations_filtered.append(v) # Keep validations that are not '_pass' 
    if validations_filtered:
        value_accuracy += "\n" # Newline for display
        value_accuracy += ", ".join(validations_filtered) # Append the validations
    if not data_errors and validations_filtered and data_checks:
        value_accuracy += "\nMatch"
    if expected_value not in [None, 'N/A']:
        value_accuracy += f'\nExpected: "{expected_value}"' # Append the expected value if provided
    if data_checks:
        value_accuracy += f"\n({', '.join(data_checks).upper()})" # Append the data checks if any
    else:        
        value_accuracy += "\n(N/A)"
    if value_accuracy == "Match\n(N/A)":
        value_accuracy = None # If no validations and no data checks, return None
    return value_accuracy
    
def font_check_block(elements, document_type):
    """
    Font size check for aggregated blocks (translations, addresses) that are built
    from multiple text boxes with potentially different fonts/sizes.

    Because a translation or address block is assembled from several individual text
    boxes (language indicators, different scripts, etc.), there is no single font to
    compare. Instead, every constituent box is run through font_check and if ANY of
    them triggers a 'fontsize_small_error' (i.e. is below the minimum font-size
    threshold) the whole block is flagged. Reusing font_check keeps the threshold
    defined in a single place.

    Args:
        elements (iterable): The text-box dicts (with 'font', 'size', 'color') that
            make up the block.
        document_type (str): Document type, forwarded to font_check.

    Returns:
        bool: True if any box triggers a 'fontsize_small_error'.
    """
    for element in elements:
        if element is None:
            continue
        _, validations_to = font_check([], [], None, element, document_type)
        if 'fontsize_small_error' in validations_to:
            return True
    return False

def font_check(validations, validations_to, from_text_element, to_text_element, document_type):
    """
    Label

    color comparison
    size comparison with diff threshold
    min threshold 6

    IFU

    no color comparison
    min 50% blc
    no size comparison
    min threshold  of 6
    """
    # from_text_element is None for 'Added' elements (there is no 'from' to compare against).
    # Guard the 'from' reads so the checks that rely only on the 'to' element (e.g. the
    # minimum font-size threshold) still run for those.
    from_font = from_text_element['font'] if from_text_element else None
    to_font = to_text_element['font']
    from_size = from_text_element['size'] if from_text_element else None
    to_size = to_text_element['size']

    if document_type in ['Pre-Printed', 'Thunderbird']:
        size_delta_thresh = 6
        # if to_font != from_font:
        #     validations.append("fontstyle_error")
        if to_size and to_size < 6:
            validations_to.append("fontsize_small_error")
            validations_to.append("fontsize_data_error")
        else:
            validations_to.append("fontsize_pass")
        if to_size and from_size and abs(to_size - from_size) > size_delta_thresh:
            validations.append("fontsize_change")
        if from_text_element and not same_color(to_text_element['color'], from_text_element['color']):
            validations.append("fontcolor_change")

    elif document_type == "IFU comparison":
        size_delta_thresh = 6
        B,G,R = to_text_element['color']
        Y = 0.2126*R + 0.7152*G + 0.0722*B
        # if to_font != from_font:
        #     validations.append("fontstyle_change")
        if to_size and from_size and abs(to_size - from_size) > size_delta_thresh:
            validations.append("fontsize_change")
        if to_size and to_size < 6:
            validations_to.append("fontsize_small_error")
        if Y > 50: # Check for 50% black
            validations_to.append("fontcolor_error")
    return validations, validations_to

def show_img(img, resize=False, t=False):
    tmp_img = img.copy()
    # Make tmp_img smaller
    if resize:
        tmp_img = cv2.resize(tmp_img, (int(tmp_img.shape[1] * resize), int(tmp_img.shape[0] * resize)))
    title = t if t else "title"
    cv2.imshow(title, tmp_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def remove_blue_lines(image, blue_sensitivity=30):
    """
    Remove blue pixels from an image by converting them to white.
    
    Args:
        image: Input image in BGR format
        blue_sensitivity: How strong the blue channel needs to be compared to other channels
                        to be considered a blue pixel
    
    Returns:
        Image with blue pixels converted to white
    """
    # Work on a copy of the image
    result = image.copy()
    
    # Split into color channels
    b, g, r = cv2.split(result)
    
    # Find pixels where blue is dominant
    blue_pixels = (b > r + blue_sensitivity) & (b > g + blue_sensitivity)
    
    # Set blue pixels to white
    result[blue_pixels] = [255, 255, 255]
    
    return result

def dict_get_none(dictionary, key):
    """
    Get a value from a dictionary, but don't do anything if dict is None
    """
    if dictionary:
        return dictionary.get(key, None)
    else:
        return None
    
def dict_set_none(dictionary, key, value):
    """
    Set a value to a dictionary, but don't do anything if dict is None
    """
    if dictionary:
        dictionary[key] = value
        return True 
    else:
        return False

def make_json_serializable(obj):
    """Convert numpy types and other non-serializable types to standard Python types"""
    if isinstance(obj, dict):
        return {key: make_json_serializable(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [make_json_serializable(item) for item in list(obj)]
    elif isinstance(obj, (np.int64, np.int32)):
        return int(obj)
    elif isinstance(obj, (np.float64, np.float32)):
        return float(obj)
    elif isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, np.ndarray):
        return make_json_serializable(obj.tolist())
    elif pd.isna(obj):  # Handle NaN/None values
        return None
    elif isinstance(obj, bool):  # Handle regular Python booleans
        return bool(obj)
    return obj


# EXCEPTIONS


class PageError(Exception):
    def __init__(self, message):            
        super().__init__(message)
        self.message = message
        print(message)

class InputFileError(Exception):
    def __init__(self, message):            
        super().__init__(message)
        self.message = message
        print(message)

class Timer():
    def __init__(self):
        self.times = {}
        self.start()
    
    def start(self):
        self.t_start = time()
        self.t_last = time()

    def end(self):
        print(f"Total time: {round(time() - self.t_start, 1)}")
        self.append("remainder")
        total_sum = sum(self.times.values())
        for category, t in self.times.items():
            print(f"{category} time: {round(t, 2)}, {round(t/total_sum*100, 1)}%")
        print(f"Total sum: {round(total_sum, 2)}")

    def append(self, category):
        if category not in self.times:
            self.times[category] = 0
        t_now = time()
        self.times[category] += t_now- self.t_last
        self.t_last = t_now

def split_pdf(input_pdf):
    """
    Split a PDF into two PDFs: one containing odd pages and one containing even pages.
    
    Args:
        input_pdf (str): Path to input PDF file
        odd_output_pdf (str): Path where to save PDF with odd pages
        even_output_pdf (str): Path where to save PDF with even pages
    """
    # Open the input PDF
    pdf_document = fitz.open(input_pdf)
    
    # Create separate documents for odd and even pages
    odd_document = fitz.open()
    even_document = fitz.open()
    
    # Process all pages
    for page_num in range(pdf_document.page_count):
        if page_num % 2 == 0:  # odd pages (0-based index)
            odd_document.insert_pdf(pdf_document, from_page=page_num, to_page=page_num)
        else:  # even pages
            even_document.insert_pdf(pdf_document, from_page=page_num, to_page=page_num)

    return odd_document, even_document
