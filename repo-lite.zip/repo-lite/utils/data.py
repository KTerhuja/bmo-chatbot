import os
import pandas as pd
from pathlib import Path
import sys

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 
from utils.utils import  InputFileError

MASTER_DATA_VER = {'ps5': 'ps5_master_data_v1',
                    'vantage': 'Vantage File_master_data_v2',
                    'translation': 'Translation_master_data_v1',
                    'manufacturer_address': 'Manufacturer Address_master_data_v1',}

def load_vantage_file(path, wave_colour_path=None):
    VAN_COLS = ['EURO CODE', 'SUTURE NAME', 'Needle Sales Type', 'Scientific Name'] # Relevant columns from Thunderbird database

    df_vantage = pd.read_parquet(path)
    
    # Keep only relevant columns
    df_vantage = df_vantage[VAN_COLS]
    
    # If Wave_Colour mapping file is provided, merge it
    if wave_colour_path and os.path.exists(wave_colour_path):
        df_wave_colour = pd.read_excel(wave_colour_path)
        # Merge on Product_Name to SUTURE NAME
        df_vantage = df_vantage.merge(
            df_wave_colour[['Product_Name', 'Wave_Colour']], 
            left_on='SUTURE NAME', 
            right_on='Product_Name', 
            how='left'
        )
        # Drop the duplicate Product_Name column if it exists
        if 'Product_Name' in df_vantage.columns:
            df_vantage = df_vantage.drop(columns=['Product_Name'])
        # Fill missing Wave_Colour values with "Not Applicable"
        df_vantage['Wave_Colour'] = df_vantage['Wave_Colour'].fillna('Not Applicable')
    
    vantage_unique = {} # This dictionary will hold all unique values for certain columns. Used for identyfying some elements in labels
    # Names of the columns to compute columns from (keys). The values are the names that will be used after, for consistency with TAD file/code
    columns = {'SUTURE NAME' : 'brand', 
               'Needle Sales Type' : 'needle_type_to', 
               'Scientific Name' : 'Raw_Material', 
    }
    filter_out = ['N/A', 'Not Applicable', None] # Values to ignore
    for col, name in columns.items():
        vantage_unique[name] = df_vantage[col].unique().tolist()
        vantage_unique[name] = [value for value in vantage_unique[name] if value not in filter_out]

    # vantage_sub_cols = ['Wave_Colour', 'Product_Name', 'Raw_Material', 'Sales_Needle_Type']
    # vantage_sub = df_vantage[vantage_sub_cols].drop_duplicates().reset_index(drop=True)
    return df_vantage, vantage_unique

TAD_COLS = {'Brand': 'brand', # ETHIBOND -> Text OR Symbol
        'To Print Code': 'code_to', # Text - Key
        'Control Release? (Yes or No)': 'ctrl_release', # "N-->No" -> Symbol
        'Future CE Status': 'CE_to', # CE -> Symbol
        'To Suture Color': 'sut_color_to', #& WHITE /&/ GREEN -> Symbol
        'To Suture Number of Strands': 'num_strands_to', # 4 -> 4 x 30" (75cm)
        'To Derived Suture Length(cm)': 'len_cm_to', # 75CM -> 75cm
        'Derived Future Suture Length(in)': 'len_in_to', # 30IN -> 30"
        'Future Suture USP': 'USP_to', #& 2-0 /&/ 2-0 -> 2-0
        'Future Suture Gauge (Metric)': 'gauge_to', #& 3 -> (3 Ph. Eur.)
        'To Sales Needle Type': 'needle_type_to', # V-5 -> V-5
        'To Needle PS-5 Label Length': 'needle_len_lbl_to', # 17 -> 17 mm
        'To Needle L1 Length (mm)': 'needle_len_l1_to', # 17.0 -> 17 mm
        'To Curvature Degrees': 'needle_curve_deg_to', # 180
        'To Needle Point(Shape of the point)': 'needle_point_to', # TC -> Symbol
        'Needle Trademark (point type)': 'needle_point_tm', # TAPERCUT
        'Needle Trademark (coating)': 'needle_tm', # MULTIPASS -> Text OR Symbol
        'To Needle Wire Alloy': 'needle_alloy_to', # ETHALLOY -> Text OR Symbol
        'To Sterilization': 'steri_to', # ETO -> Unknown
        'Future Pieces Per Box': 'pieces_to', # 6 -> 6 + Symbol
        'To Catalog Code (unmerged)': 'REF_no', # Reference number. REF symbol + text
        }
def load_tad_file(path):
    # Load TAD file        
    cols = TAD_COLS
    converters = {col: lambda x: str(x).strip() if pd.notna(x) else '' for col in list(range(len(cols)))}

    try:
        df_tad = pd.read_excel(path,
                            header=0,
                                usecols = list(cols.keys()),
                                converters=converters,
                                na_filter=False)
    except ValueError: # Try with the header in the second row
        try: 
            df_tad = pd.read_excel(path,
                            header=1,
                                usecols = list(cols.keys()),
                                converters=converters,
                                na_filter=False)
        except ValueError as e:
            raise InputFileError(f"Error in input TAD file: {str(e)}")
    df_tad = df_tad[cols.keys()] # Reorder columns to the order in cols
    # excel_names = df_tad.columns.tolist() 
    # colname_map = dict(zip(list(cols.values()), excel_names))
    df_tad.columns = (cols.values()) # Change df names to values from cols (instead of excel names)

    return df_tad

def _excel_display_number(value, number_format):
    """
    Render a numeric Excel cell the way it is *displayed* on screen, applying the cell's
    number_format (which pandas ignores - it only reads the raw stored value).

    Handles the common numeric formats: a fixed number of decimal places ('0', '0.0',
    '0.00'), optional-digit placeholders ('0.##', trailing zeros suppressed), thousands
    separators and percentages. Anything non-numeric, or a 'General' format, falls back to
    a plain stripped string.

    Examples (value stored -> format -> result):
        26.4  '0'    -> '26'
        9.3   '0.0'  -> '9.3'
        26.4  '0.00' -> '26.40'
        1234  '#,##0'-> '1,234'
    """
    if value is None:
        return ''
    # Leave text / booleans untouched.
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return str(value).strip()

    fmt = (number_format or 'General').strip()
    if fmt in ('', 'General', '@'):
        f = float(value)
        return str(int(f)) if f.is_integer() else repr(f)

    # A format can hold up to 4 sections (positive;negative;zero;text). Pick by sign.
    sections = fmt.split(';')
    if value < 0 and len(sections) > 1:
        section, force_neg = sections[1], False  # negative section defines its own sign
    elif value == 0 and len(sections) > 2:
        section, force_neg = sections[2], False
    else:
        section, force_neg = sections[0], value < 0  # single section -> Excel adds '-'

    is_percent = '%' in section
    num = abs(float(value)) * 100 if is_percent else abs(float(value))

    # Decimal placeholders after the '.': '0' forces a digit, '#' is optional.
    if '.' in section:
        frac = section.split('.', 1)[1]
        placeholders = ''.join(ch for ch in frac if ch in '0#')
        max_dec = len(placeholders)
        min_dec = placeholders.count('0')
    else:
        max_dec = min_dec = 0

    grouped = ',' in section.split('.', 1)[0]  # thousands separator in the integer part

    text = f"{num:,.{max_dec}f}" if grouped else f"{num:.{max_dec}f}"

    # Drop trailing zeros allowed by optional '#' placeholders, keeping min_dec decimals.
    if max_dec > min_dec and '.' in text:
        int_part, dec_part = text.split('.')
        dec_part = dec_part.rstrip('0')
        while len(dec_part) < min_dec:
            dec_part += '0'
        text = f"{int_part}.{dec_part}" if dec_part else int_part

    if is_percent:
        text += '%'
    if force_neg:
        text = '-' + text
    return text


def load_ps5_file(path):
    # Load PS-5 data
    cols = {0 : "sales_type_spec", ## V-5
            1 : "sales_type_lbl", ## V-5
            4 : "radius", # 5.41
            5 : "chord_len", # 0.425983
            6 : "l1_std", ## 17 # Could have decimals
            7 : "l1_lbl", ## 17
            8 : "point", ## TC
            9 : "curve_frac", ## 1/2
            10: "curve_deg", ## 180
            11: "RMC" # V005
            }
    
    converters = {col: lambda x: str(x).strip() if pd.notna(x) else '' for col in cols.values()}
    df_ps5 = pd.read_excel(path,
                            sheet_name=0,
                            usecols = cols.keys(),
                            names = cols.values(),
                            nrows = 540,
                            converters=converters)

    # l1_lbl must match what Excel *shows*, not the raw stored number: some rows store
    # 26.4 but the cell is formatted to 0 decimals (shown as '26'), others store 9.3 with
    # 1 decimal (shown as '9.3'). pandas keeps the raw value and drops the format, so we
    # re-read that one column through openpyxl and apply each cell's number_format.
    import openpyxl
    l1_lbl_col = 7  # 0-based position of l1_lbl in the sheet (Excel column H)
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    try:
        ws = wb.worksheets[0]
        display_vals = []
        # read_excel above consumed row 1 as the header, so data starts at Excel row 2.
        for row in ws.iter_rows(min_row=2, min_col=l1_lbl_col + 1,
                                 max_col=l1_lbl_col + 1, max_row=len(df_ps5) + 1):
            cell = row[0]
            display_vals.append(_excel_display_number(cell.value, cell.number_format))
    finally:
        wb.close()

    # Guard against any row-count mismatch by aligning on the shorter length.
    n = min(len(df_ps5), len(display_vals))
    df_ps5.loc[:n - 1, "l1_lbl"] = display_vals[:n]

    return df_ps5

def load_translation_file(path):
    unnamed_str='Unnamed: 0' # Unnecessary line. Mostly to make SonarQube shut up
    # Load translation data
    translation_database = {}
    translation_database["trademark"] = pd.read_excel(path,
                                    sheet_name="Trademark & Needle Point",
                                    skiprows=2, nrows=13).rename(columns = {unnamed_str:'trademark'})
    translation_database["needle_point"] = pd.read_excel(path,
                                    sheet_name="Trademark & Needle Point",
                                    skiprows=17).drop(columns=['en']).rename(columns = {unnamed_str:'needle_point', 'en.1':'en'})
    translation_database["MDR_products"] = pd.read_excel(path,
                                    sheet_name="MDR Products",
                                    skiprows=1).rename(columns = {unnamed_str:'MDR_products'}).drop(columns=['Unnamed: 1'])
    translation_database["terms"] = pd.read_excel(path,
                                    sheet_name="Terms",
                                    skiprows=2).rename(columns = {unnamed_str:'terms'})
    translation_database["DTPL"] = pd.read_excel(path,
                                    sheet_name="DTPL",
                                    skiprows=2).rename(columns = {unnamed_str:'DTPL'})
    return translation_database

def load_manufacturer_address_db(path):
    df = pd.read_csv(path, quotechar='"', skipinitialspace=True)
    keys = df.iloc[:, 0]
    values = [address.split('\\n') for address in df.iloc[:, 1]]
    return dict(zip(keys, values))
