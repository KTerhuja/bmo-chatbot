import aspose.words as aw
from io import BytesIO
from pathlib import Path
import sys
# import fitz

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo

license_path = ROOT_DIR / "Aspose.WordsforPythonvia.NET.lic"

lic = aw.License()
lic.set_license(str(license_path))

dpi = 300 # DPI after zoom
zoom = dpi / 72

def docx_to_pdf(file_bytes, clear_comments=False):
    """
    Takes a docx and returns the original redline and rejected changes versions as pdf (if there are any revisions)

    Returns:
    Rejected (It is just the original doc if there are no revisions)
    Redline (only if there are any revisions)
    Annotations (comments + revisions )
    """
    # Convert to PDF
    doc = aw.Document(BytesIO(file_bytes))
    doc.layout_options.comment_display_mode = aw.layout.CommentDisplayMode.HIDE

    revisions = extract_revisions_step1(doc)

    # Build the layout
    layout = aw.layout.LayoutCollector(doc)
    enum = aw.layout.LayoutEnumerator(doc)
    # traverse_layout_forward(enum, 1) # Prints layout for debugging

    doc_stream = BytesIO()
    comments = extract_comments(doc, layout, enum)

    doc.save(doc_stream, aw.SaveFormat.PDF)
    doc_bytes = doc_stream.getvalue()

    if doc.revisions.count == 0:
        return doc_bytes, None, comments
    else:
        # Redline ACCEPT
        redline_accepted = doc.clone()
        redline_accepted.revisions.accept_all()
        redline_accepted_stream = BytesIO()
        redline_accepted.save(redline_accepted_stream, aw.SaveFormat.PDF)
        redline_accepted_bytes = redline_accepted_stream.getvalue()

        # Redline REJECT
        redline_rejected = doc.clone()
        redline_rejected.revisions.reject_all()
        redline_rejected_stream = BytesIO()
        redline_rejected.save(redline_rejected_stream, aw.SaveFormat.PDF)
        redline_rejected_bytes = redline_rejected_stream.getvalue()

        annotations = comments + extract_revisions_step2(doc, layout, enum, revisions)        
        
        return redline_rejected_bytes, doc_bytes, annotations  # Order is changed because in this case doc_bytes is the redline

def extract_comments(doc, layout, enum):
    """
    Extract and clear comments
    """    
    comments = []
    comments_object = doc.get_child_nodes(aw.NodeType.COMMENT, True)
    for node in comments_object:
        comment = node.as_comment()
        enum.set_current(layout, node)
        rect = enum.rectangle
        comment_text = comment.to_string(aw.SaveFormat.TEXT).strip()
        start_node, end_node = find_comment_range(doc, comment.id)
        if start_node==None or end_node==None:
            continue # This happens with floating comments not anchored to anything
        
        enum.set_current(layout, start_node)
        boxes, _ = traverse_layout_forward_logical_bbox(enum, 1, "comment")

        for page_num, box in boxes.items():
            comments.append({
            "content": comment_text,
            "title": comment.author,
            "type": 'COMMENT',
            "validation": "N/A",
            "bbox": box,
            "page": page_num,
            })

    comments_object.clear()
    return comments

def expand_bboxes(bbox1, bbox2):
    expanded_box = [0,0,0,0]
    expanded_box[0] = min(bbox1[0], bbox2[0])
    expanded_box[1] = min(bbox1[1], bbox2[1])
    expanded_box[2] = max(bbox1[2], bbox2[2])
    expanded_box[3] = max(bbox1[3], bbox2[3])
    return expanded_box

def insert_bookmarks(node, doc, bk_name, mode):
    if node.node_type == aw.NodeType.PARAGRAPH:
        para = node.as_paragraph()
        if mode in ['before', 'both']:
            para.prepend_child(aw.BookmarkStart(doc, bk_name))
        if mode in ['after', 'both']:
            para.append_child(aw.BookmarkEnd(doc, bk_name))
    else:
        parent_node = node.parent_node.as_composite_node()
        if mode in ['before', 'both']:
            parent_node.insert_before(aw.BookmarkStart(doc, bk_name), node)
        if mode in ['after', 'both']:
            parent_node.insert_after(aw.BookmarkEnd(doc, bk_name), node)


def extract_revisions_step1(doc):
    """
    First step of the revision extraction process

    Gets the revision information and inserts bookmarks in the document, 
    which are used in the second step to extract the location.
    In between the two steps, the document layout must be calculated
    """
    # Wrap revisions to bookmakrs for further processing
    revisions = []
    i = 0
    prev_group = None
    for rev in doc.revisions:
        curr_group = rev.group

        if curr_group == None or curr_group != prev_group:
            # Single revision that does not belong to a group
            # OR
            # First rev of a group
            # if curr_group == prev_group:
            #     continue # Skip. If it is the last of the group, the next first will handle it or after the loop (for last group)

            # Check if we need to add the bookmarkend for the previous node
            if len(revisions) > 0:
                insert_bookmarks(node, doc, bk_name, 'after') # node and bk_name are not yet updated

            # update node and bk_name
            node = rev.parent_node
            bk_name = f"rev_{i}"

            # Skip nodes in headers/footers
            if node.get_ancestor(aw.NodeType.HEADER_FOOTER) is not None:
                continue
            insert_bookmarks(node, doc, bk_name, 'before')
            
            revisions.append({
                "content": rev.group.text if rev.group else '',
                "group": bool(rev.group),
                "parent_text": rev.parent_node.get_text(),
                "author": rev.author,
                "type": rev.revision_type.name,
                "bk_name": bk_name,
                "datetime": rev.date_time, 
                })

            i += 1

            prev_group = curr_group
        else:
            node = rev.parent_node # Just update the node for the "after" bookmarks
    if len(revisions) > 0:
        insert_bookmarks(node, doc, bk_name, 'after') # Close the bookmark of the last revision
    
    return revisions

def extract_revisions_step2(doc, layout, enum, revisions):
    """
    Second step of the revision extraction.
    It locates the previously inserted bookmarks to locate the revision in the layout
    """
    revisions_out = [] # Output revisions as some might  have to be split into multiple pages
    try:
        for revision in revisions:
            bk_name = revision["bk_name"]
            bk = doc.range.bookmarks.get_by_name(bk_name)
            enum.set_current(layout, bk.bookmark_start)
            
            boxes, _ = traverse_layout_forward_logical_bbox(enum, 1, "revision")

            for page_num, box in boxes.items():
                revision["page"] = page_num
                revision["bbox"] = box
                revisions_out.append(revision)
        return revisions_out
    
    except:
        return []

def convert_bbox(rect):
    """
    Converts the rect from aspose nodes to a bbox in the format expected by the pipeline (xyxy)
    """
    xmin = int(rect.x * zoom)
    ymin = int(rect.y * zoom)
    xmax = int((rect.x + rect.width)*zoom)
    ymax = int((rect.y + rect.height)*zoom)

    return [xmin, ymin, xmax, ymax]

def find_comment_range(doc, comment_id):
    start = None
    end = None

    for node in doc.get_child_nodes(aw.NodeType.COMMENT_RANGE_START, True):
        if node.as_comment_range_start().id == comment_id:
            start = node

    for node in doc.get_child_nodes(aw.NodeType.COMMENT_RANGE_END, True):
        if node.as_comment_range_end().id == comment_id:
            end = node

    return start, end

def print_current_entity(layout_enumerator: aw.layout.LayoutEnumerator, indent: int):
    """Print information about layout_enumerator's current entity to the console, while indenting the text with tab characters
    based on its depth relative to the root node that we provided in the constructor LayoutEnumerator instance.
    The rectangle that we process at the end represents the area and location that the entity takes up in the document."""
    tabs = '\t' * indent
    if layout_enumerator.kind == '':
        print(f'{tabs}-> Entity type: {layout_enumerator.type}')
    else:
        print(f'{tabs}-> Entity type & kind: {layout_enumerator.type}, {layout_enumerator.kind}')
    # Only spans can contain text.
    if layout_enumerator.type == aw.layout.LayoutEntityType.SPAN:
        print(f'{tabs}   Span contents: "{layout_enumerator.text}"')
    le_rect = layout_enumerator.rectangle
    print(f'{tabs}   Rectangle dimensions {le_rect.width}x{le_rect.height}, X={le_rect.x} Y={le_rect.y}')
    print(f'{tabs}   Page {layout_enumerator.page_index}')

def traverse_layout_forward(layout_enumerator: aw.layout.LayoutEnumerator, depth: int):
    """
    PULLED FROM ASPOSE DOCUMENTATION
    Enumerate through layout_enumerator's layout entity collection front-to-back,
    in a depth-first manner, and in the "Visual" order."""
    while True:
        print_current_entity(layout_enumerator, depth)
        if layout_enumerator.move_first_child():
            traverse_layout_forward(layout_enumerator, depth + 1)
            layout_enumerator.move_parent()
        if not layout_enumerator.move_next():
            break

def traverse_layout_forward_logical_bbox(layout_enumerator: aw.layout.LayoutEnumerator,
                                         depth: int,
                                         range_type: str,
                                         page_bboxes: dict | None = None):
    """
    Depth-first logical traversal that:
    - accumulates bounding boxes separately per page (key = page_index),
    - returns (page_bboxes, stopped),
      where stopped == True means traversal was aborted because COMMENTEND or BOOKMARKEND was found.

    depth doesn't really do anything, it's just for the indentation while printing
    range_type is "comment" or "revision", just to know what markers to look for in the layout
    page_bboxes is a dict mapping page_index -> bbox (the accumulated bbox for that page/(revision/coment)).
    """
    if page_bboxes is None:
        page_bboxes = {}
    if range_type == "comment":
        start_kind = "COMMENTSTART"
        end_kind = "COMMENTEND"
    if range_type == "revision":
        start_kind = "BOOKMARKSTART"
        end_kind = "BOOKMARKEND"

    nested_n = 0 # Counter to store any nested revisions
    while True:
        # current page and current entity bbox
        curr_page = layout_enumerator.page_index
        curr_bbox = convert_bbox(layout_enumerator.rectangle)

        # Add/expand bbox for the current page
        prev = page_bboxes.get(curr_page, curr_bbox) # Get the current box if there is not yet a box for this page
        page_bboxes[curr_page] = expand_bboxes(prev, curr_bbox)

        # Print or otherwise handle the current entity for debugging
        # print_current_entity(layout_enumerator, depth)

        # Require to find another end_kind if we found COMMENTSTART or BOOKMARKSTART (for nested revisions)
        if layout_enumerator.kind == start_kind:
            nested_n += 1
        # Stop traversal completely if we found COMMENTEND or BOOKMARKEND
        if layout_enumerator.kind == end_kind:
            if nested_n == 1: # This is the end of the revision/comment we are looking for
                return page_bboxes, True
            else: # We need to move up one level
                nested_n -= 1

        # Recurse into children (they will add their bboxes into the same page_bboxes dict
        # — if a child is on a different page, it will add/update that page's entry).
        if layout_enumerator.move_first_child():
            page_bboxes, stopped = traverse_layout_forward_logical_bbox(
                layout_enumerator, depth + 1, range_type, page_bboxes)
            layout_enumerator.move_parent()
            if stopped:
                return page_bboxes, True

        # Continue to next logical sibling; break when there are no more siblings
        if not layout_enumerator.move_next_logical():
            break

    return page_bboxes, False

if __name__ == "__main__":
    import fitz
    import numpy as np
    import cv2

    def show_img(img, resize=False, t=False):
        tmp_img = img.copy()
        # Make tmp_img smaller
        if resize:
            tmp_img = cv2.resize(tmp_img, (int(tmp_img.shape[1] * resize), int(tmp_img.shape[0] * resize)))
        title = t if t else "title"
        cv2.imshow(title, tmp_img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()


    doc_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\aspose redline tests\redline_manual.docx"
    doc_path = r"IFU\examples\Redline(word) to Clean Draft(word)\Example 1\391256E01_Redlined_11-13-2024 CURRENT.docx"
    doc_bytes = Path(doc_path).read_bytes()
    mat = fitz.Matrix(zoom, zoom)

    # revisions_a_butalov(doc_path)
    # revisions_a_moskov(doc_path)
    redline_rejected_bytes, doc_bytes, annotations = docx_to_pdf(doc_bytes)

    fitz_doc = fitz.open(stream=BytesIO(doc_bytes), filetype="pdf")

    for page_num in range(len(fitz_doc)):
        page = fitz_doc.load_page(page_num)
        orig_pix = page.get_pixmap(matrix=mat)
        image = np.frombuffer(orig_pix.samples, dtype=np.uint8).reshape(orig_pix.height, orig_pix.width, orig_pix.n)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        for ann in annotations:
            if page_num + 1 == ann["page"]:
                bbox = ann["bbox"]
                if ann["type"]=="REVISION":
                    color = (255,0,0)
                else:
                    color = (255,0,255)
                cv2.rectangle(image, (bbox[0], bbox[1]), (bbox[2], bbox[3]), color, 5)
        pass

    pass 