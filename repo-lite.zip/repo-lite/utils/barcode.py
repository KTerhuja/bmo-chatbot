import os
import cv2
import math
import zxingcpp
import numpy as np

from utils.spatial import find_neighbor, bbox_distance


def _reconstruct_barcode_text(code_bbox, decoded, text_data):
    """
    Rebuild a barcode/datamatrix human-readable value (HRI) that is split across
    several nearby text boxes (e.g. wrapped onto multiple lines).

    Starting from the full decoded value, nearby text boxes are consumed one at a
    time: at each step the unused box whose cleaned text matches the start of the
    still-unmatched remainder is appended, until the whole decoded value is
    accounted for. Matching against the remaining prefix (rather than a loose "is
    contained anywhere") keeps unrelated text from being pulled in, so the value is
    only rebuilt when the pieces genuinely concatenate to the decoded value.

    Args:
        code_bbox: The barcode/datamatrix bbox (in the same coordinate space as the
            ``text_data`` bboxes).
        decoded: The full decoded value string.
        text_data: List of text box dicts (each with 'text' and 'bbox').

    Returns:
        str | None: The matched boxes' text joined in reading order (the full
        expected value) when the entire decoded value is reconstructed, else None.
    """
    def clean(text):
        # Mirror the single-box comparison (drop parentheses) and also drop spaces
        # so line-wrap / typesetting whitespace can't break the join.
        return text.replace('(', '').replace(')', '').replace(' ', '')

    target = clean(decoded)
    if not target:
        return None

    # Search within roughly one code-size of the barcode; this scales with the
    # symbol so it works at any resolution. The reconstruction below is what
    # actually rejects unrelated boxes, so a generous radius is safe.
    bw = code_bbox[2] - code_bbox[0]
    bh = code_bbox[3] - code_bbox[1]
    search_radius = max(bw, bh)
    candidates = [t for t in text_data
                  if clean(t['text']) and bbox_distance(code_bbox, t['bbox']) <= search_radius]

    remaining = target
    matched = []  # original box texts, in the order consumed (i.e. reading order)
    while remaining:
        # Among unused boxes that start the remaining value, take the longest
        # match (closest box breaks ties) so segments are consumed unambiguously.
        best_idx, best_len, best_dist = -1, -1, None
        for idx, t in enumerate(candidates):
            piece = clean(t['text'])
            if remaining.startswith(piece):
                dist = bbox_distance(code_bbox, t['bbox'])
                if len(piece) > best_len or (len(piece) == best_len and dist < best_dist):
                    best_idx, best_len, best_dist = idx, len(piece), dist
        if best_idx == -1:
            break  # Nothing matches the remainder -> can't fully rebuild
        t = candidates.pop(best_idx)
        matched.append(t['text'].strip())
        remaining = remaining[best_len:]

    if remaining == '' and matched:
        return ' '.join(matched)
    return None


def check_hri(code_bbox, decoded, text_data, distance_threshold):
    """
    Check whether the decoded value's human-readable interpretation (HRI) is
    present in the text boxes near the barcode/datamatrix.

    The HRI is considered found when the decoded value can be reconstructed from
    the nearby text boxes (a single box, or several boxes when the value is wrapped
    across lines). Reconstruction searches within roughly one code-size of the
    symbol, so it tolerates the small gap between a code and its printed value
    (which a tight single-box distance threshold would otherwise miss).

    Args:
        code_bbox: The barcode/datamatrix bbox (same coordinate space as the
            ``text_data`` bboxes).
        decoded: The decoded value string (falsy if the code did not decode).
        text_data: List of text box dicts (each with 'text' and 'bbox').
        distance_threshold: Max distance used only for the fallback "closest text
            box" lookup that supplies an expected value when the HRI is NOT found.

    Returns:
        tuple[bool, str | None]: ``(found, expected_value)`` where ``found`` is
        True when the HRI was located, and ``expected_value`` is the matched (or
        reconstructed) human-readable text; when not found it is the nearest text
        box's text (if any) so a mismatch can still be reported, else None.
    """
    if not decoded:
        return False, None

    # Reconstruction handles both the single-box and multi-box (wrapped) cases and
    # uses a code-sized search radius, so it isn't defeated by the small gap
    # between the symbol and its printed human-readable value.
    reconstructed = _reconstruct_barcode_text(code_bbox, decoded, text_data)
    if reconstructed is not None:
        return True, reconstructed

    # Not found: report the closest text box (if any) as the expected value so the
    # mismatch can still be surfaced downstream.
    code = {'bbox': list(code_bbox)}
    neighbor = find_neighbor(code, text_data, distance_threshold=distance_threshold)
    return False, (neighbor['text'] if neighbor else None)


def show_img(img, resize=False, t=False):
    tmp_img = img.copy()
    # Convert binary (bool or 0/1) arrays to a viewable 0/255 grayscale image
    if tmp_img.dtype == bool:
        tmp_img = tmp_img.astype(np.uint8) * 255
    elif np.issubdtype(tmp_img.dtype, np.number):
        unique_vals = np.unique(tmp_img)
        if unique_vals.size > 0 and np.all(np.isin(unique_vals, (0, 1))):
            tmp_img = tmp_img.astype(np.uint8) * 255
    # Make tmp_img smaller
    if resize:
        tmp_img = cv2.resize(tmp_img, (int(tmp_img.shape[1] * resize), int(tmp_img.shape[0] * resize)))
    title = t if t else "title"
    cv2.imshow(title, tmp_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def detect_barcode_datamatrix(page_image, bbox, btype='both', pixels_to_mm=None,
                              text_data=None, text_scale=1, hri_distance_threshold=None):
    """
    Detect barcodes and datamatrices in the image.

    When ``text_data`` is provided the human-readable interpretation (HRI) of each
    decoded code is validated against the nearby text boxes and reported as an
    ``HRI`` grade metric (A when found, F otherwise). If ``text_data`` is None no
    HRI check is performed and the HRI metric is omitted.
    
    Args:
        page_image (numpy.ndarray): The input image (grayscale).
        bbox (int tuple): bbox coordinates so that returned bboxes are generalized
        btype (str): 'datamatrix', 'barcode' or 'both'. Only run specified library if
                     we are certain of the kind of code it is, if not, try both,
        pixels_to_mm (float): Conversion factor from pixels to millimeters (optional).
        text_data (list): Text box dicts (each with 'text' and 'bbox') used for the
            HRI check. If None, no HRI check is performed.
        text_scale (float): Factor to convert a detected bbox (in ``page_image``
            space) to the coordinate space of ``text_data`` (bbox is divided by it).
        hri_distance_threshold (float): Max neighbor distance for the HRI check, in
            ``text_data`` coordinate space.
    Returns:
        str: "barcode" if the image is a barcode, "datamatrix" if the image is a 2D data matrix, False otherwise.
    """
    pad = 40  # doubled from 20 to match 2x resolution
    if btype == 'barcode':
        # Detection boxes are sometimes too tight and clip bars off the sides,
        # which breaks decoding; widen the box to recover them before decoding.
        bbox = barcode_bbox_correction(page_image, bbox)
    # extract_region clamps the padded crop to the image bounds, so near an edge
    # the applied padding is smaller than ``pad`` on that side. Use the actual
    # region origin it returns (rather than assuming a full ``pad`` offset), so
    # decoded coordinates are not shifted inward when the code sits near an edge.
    image, (region_xmin, region_ymin, _, _) = extract_region(page_image, bbox, xpadding=pad, ypadding=pad)
    h, w = image.shape[:2]
    def rect_to_bbox(rect, mtxbug=False):
        """
        Convert rect returned by decode to bboxes that are with respect of the original page image
        """
        # x_scale = (bbox[2] - bbox[0])/w
        # y_scale = (bbox[3] - bbox[1])/h
        x_scale = 1
        y_scale = 1
        left = rect.left*x_scale + region_xmin
        top = rect.top*y_scale + region_ymin
        if mtxbug:
            # pylibdmtx has a bug that returns y coordinates flipped
            top = (h-rect.top-rect.height)*y_scale + region_ymin
        right = left + rect.width*x_scale
        bottom = top + rect.height*y_scale
        return [int(left), int(top), int(right), int(bottom)]
    
    def position_to_bbox_zxing(position):
        x_coords = [p.x + region_xmin for p in [position.bottom_left, position.bottom_right, position.top_right, position.top_left]]
        y_coords = [p.y + region_ymin for p in [position.bottom_left, position.bottom_right, position.top_right, position.top_left]]
        return [min(x_coords), min(y_coords), max(x_coords), max(y_coords)]

    def hri_for(code_bbox, decoded):
        """Run the HRI check for a decoded code (bbox in page_image space).

        Returns (hri_score, expected_value) where hri_score is 1.0/0.0 when a check
        was performed and None when no ``text_data`` was supplied (check skipped).
        """
        if text_data is None:
            return None, None
        # Convert the detected bbox to the text_data coordinate space.
        code_bbox_text = [c / text_scale for c in code_bbox]
        found, expected_value = check_hri(code_bbox_text, decoded, text_data,
                                          distance_threshold=hri_distance_threshold)
        return (1.0 if found else 0.0), expected_value

    # Ensure grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
    
    output = []

    if btype in ['barcode']:
        # Try to decode as barcode
        barcodes = zxingcpp.read_barcodes(gray)
        if not barcodes: # If nothing was detected, try a small gaussian blur
            barcodes = zxingcpp.read_barcodes(cv2.GaussianBlur(gray, (5, 5), 0))
        if barcodes:
            for b in barcodes:
                orientation = b.orientation if b.orientation != -90 else 270  # ZXing returns -90 for 270, convert to positive angle
                decoded = b.bytes.decode("utf-8")
                code_bbox = position_to_bbox_zxing(b.position)
                hri_score, expected_value = hri_for(code_bbox, decoded)
                grade, metrics = grade_barcode(page_image, code_bbox, decoded_data=decoded, barcode_type=str(b.format), pixels_to_mm=pixels_to_mm, orientation=orientation, hri_score=hri_score)
                output.append({"type": "barcode", "subtype":str(b.format), "decoded": decoded, "bbox": code_bbox,
                               "grade": grade, "grade_metrics": metrics, "orientation": orientation, "expected_value": expected_value,
                               "HRI_found": None if hri_score is None else bool(hri_score)})
        else:
                # Decoding failed, but still grade the barcode so metrics are returned.
                # decoded_data=None makes the 'decode' metric fail while the rest are computed.
                # No decoded value means no HRI check is possible (hri_score stays None).
                try:
                    grade, metrics = grade_barcode(page_image, bbox, decoded_data=None, barcode_type=None, pixels_to_mm=pixels_to_mm, orientation=0, hri_score=None)
                except Exception:
                    grade, metrics = 'F', None
                output.append({"type": "barcode", "subtype": None, "decoded": False, "bbox": bbox,
                               "grade": grade, "grade_metrics": metrics, "orientation": 0, "expected_value": None,
                               "HRI_found": None})

    if btype in ['datamatrix']:
        # Try to decode as data matrix
        datamatrices = zxingcpp.read_barcodes(gray)
        if not datamatrices: # If nothing was detected, try a small gaussian blur
            datamatrices = zxingcpp.read_barcodes(cv2.GaussianBlur(gray, (5, 5), 0))
        if datamatrices:  
            for d in datamatrices:
                orientation = d.orientation if d.orientation != -90 else 270  # ZXing returns -90 for 270, convert to positive angle
                dims = d.extra['Version'].split('x') # Get the datamatrix dimensions
                subtype = str(d.format) + ' (' + str(d.content_type).split('.')[1] + ')' # Data Matrix (GS1 or Text)
                decoded = d.bytes.decode("utf-8")
                code_bbox = position_to_bbox_zxing(d.position)
                hri_score, expected_value = hri_for(code_bbox, decoded)
                grade, metrics = grade_datamatrix(page_image, code_bbox, dims, decoded_data=decoded, pixels_to_mm=pixels_to_mm, orientation=orientation, hri_score=hri_score)      
                output.append({"type": "datamatrix", "subtype": subtype, "decoded": decoded, "bbox": code_bbox,
                               "grade": grade, "grade_metrics": metrics, "orientation": orientation, "expected_value": expected_value,
                               "HRI_found": None if hri_score is None else bool(hri_score)})
        else:
            output.append({"type": "datamatrix", "subtype": None, "decoded": False, "bbox": bbox,
                               "grade": 'F', "grade_metrics": None, "orientation": 0, "expected_value": None,
                               "HRI_found": None})
    return output

def extract_region(page_image, bbox, xpadding=20, ypadding=20):
    """Extracts a padded region around the barcode."""
    h, w = page_image.shape[:2]
    xmin, ymin, xmax, ymax = bbox

    xmin_p = max(0, xmin - xpadding)
    ymin_p = max(0, ymin - ypadding)
    xmax_p = min(w, xmax + xpadding)
    ymax_p = min(h, ymax + ypadding)

    return page_image[ymin_p:ymax_p, xmin_p:xmax_p], (xmin_p, ymin_p, xmax_p, ymax_p)

def crop_barcode_image(page_image, bbox , margin_ratio=0.40, box_color=(255, 0, 255), box_thickness=2):
    """
    Build a crop centered on a barcode/datamatrix, with its bounding box drawn on it.

    Every side gets the same pixel margin: ``margin_ratio`` of the *longest* bbox
    dimension. The shorter side therefore ends up with proportionally more than
    ``margin_ratio`` of its own length. The content is placed on a white canvas so
    the requested margin is preserved even when the code sits close to a page edge.

    Args:
        page_image (np.ndarray): Full page image (BGR or grayscale).
        bbox (list[int]): Bounding box [xmin, ymin, xmax, ymax] in page-image coordinates.
        margin_ratio (float): Margin on every side as a fraction of the longest side.
        box_color (tuple): BGR color used to draw the bounding box rectangle.
        box_thickness (int): Thickness in pixels of the drawn bounding box.

    Returns:
        np.ndarray: BGR crop with the bounding box drawn on it.
    """
    # Work in color so the drawn box is visible regardless of the input image type
    source = cv2.cvtColor(page_image, cv2.COLOR_GRAY2BGR) if len(page_image.shape) == 2 else page_image.copy()

    xmin, ymin, xmax, ymax = [int(round(v)) for v in bbox]

    # Draw the bounding box on the page copy
    cv2.rectangle(source, (xmin, ymin), (xmax, ymax), box_color, box_thickness)

    # Uniform pixel margin on every side = margin_ratio of the longest bbox side
    longest = max(xmax - xmin, ymax - ymin)
    margin = int(round(longest * margin_ratio))

    crop_xmin, crop_ymin = xmin - margin, ymin - margin
    crop_xmax, crop_ymax = xmax + margin, ymax + margin
    crop_w = max(crop_xmax - crop_xmin, 1)
    crop_h = max(crop_ymax - crop_ymin, 1)

    # White canvas keeps the full margin even when the crop runs off the page
    crop = np.full((crop_h, crop_w, 3), 255, dtype=np.uint8)

    # Intersect the desired crop with the actual image bounds
    h, w = source.shape[:2]
    src_xmin, src_ymin = max(crop_xmin, 0), max(crop_ymin, 0)
    src_xmax, src_ymax = min(crop_xmax, w), min(crop_ymax, h)

    if src_xmax > src_xmin and src_ymax > src_ymin:
        # Place the in-bounds region at its corresponding offset inside the canvas
        dst_x, dst_y = src_xmin - crop_xmin, src_ymin - crop_ymin
        crop[dst_y:dst_y + (src_ymax - src_ymin), dst_x:dst_x + (src_xmax - src_xmin)] = \
            source[src_ymin:src_ymax, src_xmin:src_xmax]

    return crop

def save_barcode_crop(page_image, bbox, output_folder, filename, mode='local'):
    """
    Crop a single barcode/datamatrix (with its bbox drawn on it) and save it into a
    'barcode_crops' subfolder of ``output_folder``. The crop path (relative to the output
    folder) is stored on the barcode dict under ``crop_filename`` so the UI can pull the
    image from blob storage (or disk in local mode).

    Args:
        page_image (np.ndarray): Full page image the bbox refers to.
        bbox (list[int]): Bounding box [xmin, ymin, xmax, ymax] in page-image coordinates.
        output_folder (str): Base output folder. Crops go into '<output_folder>/barcode_crops'.
        filename (str): Unique filename for the crop image, e.g. 'page1_to_barcode1.png'. The UI relies on a unique name to fetch the correct crop.
        mode (str): 'local' to write to disk with cv2, 'blob' to upload to blob storage.

    Returns:
        dict: The same barcode dict, now including a 'crop_filename' key.
    """
    crop = crop_barcode_image(page_image, bbox)

    full_path = os.path.join(output_folder, "barcode_crops", filename)
    if mode == 'blob':
        from utils.blob_storage import write_img  # Lazy import to avoid azure dependency when unused
        write_img(full_path, crop)
    else:
        os.makedirs(os.path.join(output_folder, "barcode_crops"), exist_ok=True)
        cv2.imwrite(full_path, crop)

    return

def check_contrast(page_image, bbox):
    """
    Computes symbol contrast metric for the barcode region.
    Contrast = (max intensity - min intensity) / 255.
    Returns a score 0-1 (1 = great contrast) and min and max intensity values.
    Expects grayscale page_image.
    """
    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    min_r = region.min()
    max_r = region.max()
    sc = float(max_r - min_r)
    return min_r/255.0, max_r/255.0, sc / 255.0

def remove_thin_colored_lines(gray_region, color_region, saturation_threshold=50, max_line_thickness=15):
    """
    Whiten thin colored "die lines" inside a region so they cannot corrupt a
    quiet-zone measurement.

    Die lines are thin, variably-colored lines that outline a label and
    sometimes run right next to a barcode/datamatrix. In the quiet zone they
    look like stray ink and unfairly shorten the measured clear area. Barcodes
    are black/white (low saturation), so colored pixels here are almost always a
    die line.

    Detection:
      * Colored pixels are found via HSV saturation (hue independent, so any
        die-line color is caught while black/white barcode pixels are ignored).
      * Only *thin* colored structures are removed: a morphological opening with
        a kernel larger than ``max_line_thickness`` keeps thick colored blobs,
        and subtracting it leaves just the thin lines.
      * The thin-line mask is dilated slightly to cover the line's anti-aliased
        edges, then those pixels are set to white (255).

    Args:
        gray_region (np.ndarray): Grayscale region to clean.
        color_region (np.ndarray): Same region in BGR, used to detect color.
        saturation_threshold (int): Min HSV saturation (0-255) to count as colored.
        max_line_thickness (int): Colored structures thicker than this (px) are
                                  treated as blobs and kept.

    Returns:
        np.ndarray: Grayscale region with thin colored lines whitened. Returned
                    unchanged when no color image is available.
    """
    if color_region is None or color_region.ndim != 3:
        return gray_region

    saturation = cv2.cvtColor(color_region, cv2.COLOR_BGR2HSV)[:, :, 1]
    colored = (saturation > saturation_threshold).astype(np.uint8)
    if not colored.any():
        return gray_region

    # Keep thick colored blobs, isolate the thin colored lines (die lines).
    k = max(3, int(max_line_thickness) | 1)  # force odd, >= 3
    blob_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    thick = cv2.morphologyEx(colored, cv2.MORPH_OPEN, blob_kernel)
    thin_lines = cv2.subtract(colored, thick)
    if not thin_lines.any():
        return gray_region

    # Grow slightly so the line's anti-aliased shoulders are whitened too.
    thin_lines = cv2.dilate(thin_lines, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))

    cleaned = gray_region.copy()
    cleaned[thin_lines.astype(bool)] = 255
    return cleaned

def check_quiet_zone(page_image, bbox, code_type, brightness_threshold=230, barcode_type=None, narrow_bar_width_mm=None, pixels_to_mm=None, orientation=0, cell_size_mm=None):
    """
    Check that there is enough 'quiet zone' around the barcode.
    Quiet zone is the white space immediately adjacent to the code.
    
    Args:
        page_image: The full page image
        bbox: Bounding box [xmin, ymin, xmax, ymax]
        code_type: Type of the code ('barcode' or 'datamatrix')
        brightness_threshold: Pixel value above which is considered "white"
        barcode_type: Specific type of barcode (optional)
        narrow_bar_width_mm: Width of the narrowest bar in the barcode (optional)
        pixels_to_mm: Conversion factor from pixels to millimeters (optional)
        orientation: Orientation of the code (degrees)
        cell_size_mm: Ideal quiet zone size in mm (optional, for datamatrix)
    
    Returns:
        tuple: (left_qz_score, right_qz_score) or (left_qz_score, right_qz_score, top_qz_score, bottom_qz_score)
    """
    quiet_zone_multiplier = {"Code 128": 10, 
                       "Code 39": 10, 
                       "GS1-128": 1, 
                       "EAN-13": 11, 
                       "EAN-8": 7, 
                       "UPC-A": 9,
                       "UPC-E": 9,}
    # Minimum quiet zone in inches, whichever is greater
    quiet_zone_min_inches = {"Code 128": 0.25,
                             "Code 39": 0.25,}

    ideal_qz_mm = None
    if code_type == 'datamatrix' and cell_size_mm:
        ideal_qz_mm = cell_size_mm
    elif barcode_type and narrow_bar_width_mm:
        multiplier = quiet_zone_multiplier.get(barcode_type, 10)
        ideal_qz_mm = multiplier * narrow_bar_width_mm
        if barcode_type in quiet_zone_min_inches:
            inch_min_mm = quiet_zone_min_inches[barcode_type] * 25.4
            ideal_qz_mm = max(ideal_qz_mm, inch_min_mm)

    if not ideal_qz_mm or not pixels_to_mm:
        return None, None

    if code_type == 'barcode':
        left_qz_px, right_qz_px = check_quiet_zone_axis(page_image, bbox, orientation, brightness_threshold)
        left_qz_mm = left_qz_px * pixels_to_mm
        right_qz_mm = right_qz_px * pixels_to_mm
        return min(left_qz_mm / ideal_qz_mm, 1.0), min(right_qz_mm / ideal_qz_mm, 1.0)
    elif code_type == 'datamatrix':
        left_qz_px, right_qz_px = check_quiet_zone_axis(page_image, bbox, 0, brightness_threshold)
        top_qz_px, bottom_qz_px = check_quiet_zone_axis(page_image, bbox, 90, brightness_threshold)
        return (min(left_qz_px * pixels_to_mm / ideal_qz_mm, 1.0),
                min(right_qz_px * pixels_to_mm / ideal_qz_mm, 1.0),
                min(top_qz_px * pixels_to_mm / ideal_qz_mm, 1.0),
                min(bottom_qz_px * pixels_to_mm / ideal_qz_mm, 1.0))

def check_quiet_zone_axis(page_image, bbox, orientation, brightness_threshold=127):
    
    xmin, ymin, xmax, ymax = bbox
    code_width = xmax - xmin
    code_height = ymax - ymin
    
    if orientation in [0, 180]: # Horizontal
        xpad, ypad = code_width, -int(code_height * 0.1)
    else:
        xpad, ypad = -int(code_width * 0.1), code_height

    region, (region_xmin, region_ymin, _, _) = extract_region(page_image, bbox, xpadding=xpad, ypadding=ypad)

    # page_image is color: drop to grayscale and strip any thin colored die
    # lines so they can't shorten the measured quiet zone.
    gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY) if region.ndim == 3 else region
    gray = remove_thin_colored_lines(gray, region)

    h, w = gray.shape[:2]

    # Find the code position within the extracted region
    if orientation in [0, 180]: # Horizontal
        code_start = xmin - region_xmin
        code_end = xmax - region_xmin
        # Use middle 10-90% of rows
        row_start = int(h * 0.20)
        row_end = int(h * 0.80)
        slice_region = gray[row_start:row_end, :]
        white_mask = slice_region > brightness_threshold
        column_all_white = np.all(white_mask, axis=0)
        column_all_black = np.all(~white_mask, axis=0)
    else:
        code_start = ymin - region_ymin
        code_end = ymax - region_ymin
        # Use middle 10-90% of columns
        col_start = int(w * 0.20)
        col_end = int(w * 0.80)
        slice_region = gray[:, col_start:col_end]
        white_mask = slice_region > brightness_threshold
        column_all_white = np.all(white_mask, axis=1)
        column_all_black = np.all(~white_mask, axis=1)
    
    left_qz_width = 0
    for i in range(code_start - 1, -1, -1):
        if left_qz_width <= 4*2 or column_all_white[i] or (column_all_black[i] and left_qz_width <= 10*2):
            # Second part accounts for cases where the bbox is too tight and is inside of the code, so we have a tolerance of a few pixels
            left_qz_width += 1
        else:
            break
    
    right_qz_width = 0
    for i in range(code_end, len(column_all_white)):
        if right_qz_width <= 4*2 or column_all_white[i] or (column_all_black[i] and right_qz_width <= 10*2):
            # Second part accounts for cases where the bbox is too tight and is inside of the code, so we have a tolerance of a few pixels
            right_qz_width += 1
        else:
            break

    # --- DEBUG visualization (convert to color for colored lines) ---
    # debug_region = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    # if orientation in [0, 180]: # Horizontal
    #     debug_region[:, code_start-left_qz_width-1:code_start-left_qz_width+1] = (0, 255, 0)   # Green for left quiet zone
    #     debug_region[:, code_end+right_qz_width-1:code_end+right_qz_width+1] = (0, 0, 255)  # Red for right quiet zone
    # else:
    #     debug_region[code_start-left_qz_width-1:code_start-left_qz_width+1, :] = (0, 255, 0)   # Green for top quiet zone
    #     debug_region[code_end+right_qz_width-1:code_end+right_qz_width+1, :] = (0, 0, 255)  # Red for bottom quiet zone
    # show_img(debug_region, resize = 0.5)
    # --- END DEBUG visualization ---
    
    return left_qz_width, right_qz_width

def check_magnification(page_image, bbox, code_type):
    """
    Estimate magnification by analyzing bar/module widths.
    Expects grayscale page_image.
    """
    if code_type not in ['barcode', 'datamatrix']:
        return None
    
    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    gray = region
    
    # Use edge detection to find bar/module boundaries
    edges = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if not contours:
        return 0.5  # Unable to assess
    
    # Measure widths of detected features
    widths = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if code_type == 'barcode':
            widths.append(w)  # Bar width for 1D
        else:
            widths.append(min(w, h))  # Module size for 2D
    
    if not widths:
        return 0.5
    
    avg_width = np.mean(widths)
    optimal_min, optimal_max = 4, 8  # doubled from 2, 4
    
    if optimal_min <= avg_width <= optimal_max:
        return 1.0
    elif 2 <= avg_width <= 12:  # doubled from 1 <= avg_width <= 6
        return 0.7
    else:
        return 0.3

def _element_reflectance(scan_line, start, end):
    """
    Representative reflectance of one element (bar or space), sampled at its centre.

    The central ~50% of the element is averaged (median) so the blurred edge
    ramps at the element borders are excluded. Because the sample window is a
    fraction of the element width, the reading is scale invariant: it returns the
    same value whether the element is 2 or 20 pixels wide.
    """
    n = scan_line.size
    start = max(0, int(start))
    end = min(n, int(end))
    if end <= start:
        return None
    width = end - start
    if width <= 2:
        # Too narrow to trim ramps - use whatever pixels the element has.
        return float(np.median(scan_line[start:end]))
    margin = width // 4
    return float(np.median(scan_line[start + margin:end - margin]))


def _bars_from_scan_line(scan_line):
    """
    Recover (start, end) bar intervals directly from a 1D scan line.

    Used as a fallback when pre-computed bar positions are unavailable: the line
    is binarised with Otsu's method and each run of dark (bar) pixels becomes one
    interval.
    """
    values = scan_line.astype(np.uint8)
    _, binary = cv2.threshold(values, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    is_bar = binary.ravel() == 0  # dark pixels are bars
    intervals = []
    start = None
    for i, bar in enumerate(is_bar):
        if bar and start is None:
            start = i
        elif not bar and start is not None:
            intervals.append((start, i))
            start = None
    if start is not None:
        intervals.append((start, len(is_bar)))
    return intervals


def check_min_edge_contrast(page_image, bbox, code_type, orientation=0, bars=None):
    """
    Measure minimum edge contrast (ECmin) per ISO/IEC 15416.

    Edge contrast is the difference between the reflectance of a space (Rs) and
    the reflectance of an adjoining bar (Rb); ECmin is the lowest edge contrast
    found across every edge in the scan reflectance profile (quiet zones
    included). Expects a grayscale page_image.

    Rather than sampling pixels straddling each transition - which is sensitive
    to scale, because the edge ramp grows wider and blurrier at higher
    resolutions - each element's reflectance is read at its *centre*. The bar
    start/end positions found by :func:`check_bar_width` are reused to locate the
    elements: the bars are the supplied intervals and the spaces are the gaps
    between them (plus the quiet zones flanking the symbol). Centre sampling is
    scale invariant, so the result no longer drifts with image resolution.

    Args:
        bars: Sorted (start, end) bar intervals along the scan axis, in
              region-relative pixels, as returned by :func:`check_bar_width`.
              When omitted the bars are recovered from the centre scan line so
              the function still works standalone.
    """
    if code_type != 'barcode':
        return None

    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    gray = region
    h, w = gray.shape

    if orientation in [0, 180]:
        scan_line = gray[h // 2, :].astype(np.float32)
    else:
        scan_line = gray[:, w // 2].astype(np.float32)

    n = scan_line.size
    if n < 2:
        return 0.0

    if bars:
        # Clamp the supplied intervals to the scan line and keep them ordered.
        bars = sorted((max(0, int(s)), min(n, int(e))) for s, e in bars if int(e) > int(s))
    else:
        bars = _bars_from_scan_line(scan_line)

    if not bars:
        return 0.0

    # Build the ordered element list: each bar, the space/quiet-zone gap that
    # precedes it, and the trailing quiet zone after the final bar.
    #
    # Single-pixel elements are dropped: a lone pixel at a bar/space boundary is
    # almost always the anti-aliased transition ramp between the two (e.g. a 136
    # pixel sitting between a 32 bar and a 255 space). Sampling it as its own
    # element would invent a phantom element whose intermediate reflectance
    # produces a spuriously low edge contrast. Skipping it lets the real bar and
    # space sit adjacent, so their true (full) edge contrast is measured. A
    # genuine element is never a single pixel at the resolutions we grade at.
    elements = []
    prev_end = 0
    for start, end in bars:
        if start > prev_end and (start - prev_end) > 1:
            elements.append((prev_end, start))  # space or leading quiet zone
        if (end - start) > 1:
            elements.append((start, end))       # bar
        prev_end = end
    if prev_end < n and (n - prev_end) > 1:
        elements.append((prev_end, n))           # trailing quiet zone

    # Reflectance sampled at the centre of every element, in scan order.
    reflectances = [r for r in (_element_reflectance(scan_line, s, e) for s, e in elements)
                    if r is not None]
    if len(reflectances) < 2:
        return 0.0

    # Edge contrast between each pair of adjoining elements; ECmin is the lowest.
    edge_contrasts = [abs(reflectances[i] - reflectances[i - 1]) / 255.0
                      for i in range(1, len(reflectances))]

    return float(np.min(edge_contrasts))


def check_uniformity(page_image, bbox, code_type, brightness_threshold=230, orientation=0):
    """
    Check uniformity (voids, spots, artifacts) in barcode.
    Expects grayscale page_image.
    """    
    if code_type != 'barcode':
        return 1.0  # Return 1 for datamatrix

    region, _ = extract_region(page_image, bbox, xpadding=-3, ypadding=-3) # slight negative padding to avoid bad crop defect inclusion
    gray = region
    
    h, w = gray.shape
    
    if orientation in [0, 180]:
        # For horizontal, analyze the middle row
        middle_row_idx = h // 2
        middle_row = gray[middle_row_idx, :] > brightness_threshold
        # Flattened version: column is white if ALL pixels in column are white
        column_all_white = np.all(gray > brightness_threshold, axis=0)
    else:
        # For vertical, analyze the middle column
        middle_col_idx = w // 2
        middle_row = gray[:, middle_col_idx] > brightness_threshold
        # Flattened version: column is white if ALL pixels in column are white
        column_all_white = np.all(gray > brightness_threshold, axis=1)

    # Compare
    row_uniformity = np.sum(middle_row == column_all_white) / len(middle_row)
    
    return row_uniformity

def check_datamatrix_uniformity(page_image, bbox, dims, threshold=None, min_run_ratio=0.7, lump_tol_ratio=0.2):
    """
    Check that a Data Matrix is a clean grid of uniform black/white cells.

    This is the Data Matrix equivalent of :func:`check_uniformity`. A Data
    Matrix is built from square modules of a fixed cell size, so when a scan
    line is run across it the (binarised) value should stay constant for
    roughly one cell and only ever change at cell boundaries. Put another way,
    every run of a single colour should be at least about one cell long.

    The scan is run in *both* directions — top-to-bottom over every column and
    left-to-right over every row — because a small defect (a stray mark, a
    misplaced symbol, or text printed on top of the matrix) may only break the
    grid along one axis. Results from both directions are pooled into a single
    score.

    A run that is much shorter than a cell means the colour changed *faster*
    than the grid allows, which is a strong indicator of such a defect — but
    only when the short run is *black*. A defect is, by definition, an
    unexpected black object, so short *white* runs are never counted (they are
    just slivers of the light background between modules).

    Boundary-lump suppression
    -------------------------
    A common, benign artifact is ignored: along a black/white boundary that
    spans more than one module, the black often protrudes by a few pixels right
    where one module hands over to the next. A perpendicular scan slices through
    that little protrusion and sees a tiny black run, which would otherwise be
    flagged as a defect. Such a lump always sits at a module *grid corner* — the
    intersection of the module-to-module transition and the long boundary edge —
    so it is recognised (and skipped) only when the short black run is close to a
    module grid line in *both* directions at once. Requiring proximity to the
    grid on both axes is deliberate: genuine defects also create edges, but they
    rarely coincide with a grid corner, so they stay counted.

    Args:
        page_image: Full page image (grayscale).
        bbox: Bounding box [xmin, ymin, xmax, ymax].
        dims: Data Matrix dimensions as (cols, rows), e.g. ['14', '14'].
        threshold: Fixed binarisation threshold (0-255). If None, Otsu's method
                   picks it automatically from the region.
        min_run_ratio: A run shorter than ``min_run_ratio * cell_size`` (cell
                       height for vertical scans, cell width for horizontal
                       scans) is counted as a defect. Values < 1 tolerate the
                       partial-cell slivers produced by minor misalignment /
                       anti-aliasing.
        lump_tol_ratio: Half-width, as a fraction of the cell size, of the
                        "on-grid" band used to recognise the boundary-lump
                        artifact. A short black run is treated as a lump only
                        when its centre is within this band of a module grid
                        line in the scan direction *and* the scan line itself
                        runs within this band of a perpendicular grid line.
                        Larger values suppress more lumps but risk ignoring real
                        defects that happen to sit near a grid corner.

    Returns:
        float: Uniformity score in [0, 1], pooled over both scan directions.
               1.0 means no defect runs were found (a clean grid); lower values
               mean genuine sub-cell black objects were detected.
    """
    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY) if len(region.shape) == 3 else region

    h, w = gray.shape[:2]
    n_cols = int(dims[0])
    n_rows = int(dims[1])
    if n_rows <= 0 or n_cols <= 0 or h < 2 or w < 2:
        return 1.0

    # Expected size of one cell (module) in pixels along each axis.
    cell_h = h / n_rows  # vertical extent of a cell (used for column scans)
    cell_w = w / n_cols  # horizontal extent of a cell (used for row scans)
    min_run_v = max(1.0, cell_h * min_run_ratio)
    min_run_h = max(1.0, cell_w * min_run_ratio)

    # Binarise so every cell is purely black or white before measuring runs.
    # Convention: 1 == light/white (background), 0 == dark/black (ink).
    if threshold is None:
        _, binary = cv2.threshold(gray, 0, 1, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    else:
        binary = (gray > threshold).astype(np.uint8)

    # Module grid lines along each axis (n + 1 lines, including the outer edges).
    y_grid = np.arange(n_rows + 1, dtype=np.float64) * cell_h  # horizontal lines
    x_grid = np.arange(n_cols + 1, dtype=np.float64) * cell_w  # vertical lines

    # Half-width (px) of the "on-grid" band used to recognise boundary lumps.
    lump_tol_v = max(2.0, cell_h * lump_tol_ratio)  # measured along a column (y)
    lump_tol_h = max(2.0, cell_w * lump_tol_ratio)  # measured along a row (x)

    # A lump can only occur on a scan line that hugs the long black/white module
    # boundary, i.e. one running close to a perpendicular grid line.
    col_on_boundary = (
        np.min(np.abs(np.arange(w)[:, None] - x_grid[None, :]), axis=1) <= lump_tol_h
    )
    row_on_boundary = (
        np.min(np.abs(np.arange(h)[:, None] - y_grid[None, :]), axis=1) <= lump_tol_v
    )

    def _count_runs(line, line_len, min_run, grid_pos, on_boundary, lump_tol):
        """Inner-run count and defect-run count for a single scan line.

        Only short *black* runs (value 0) are eligible to be defects. Among
        those, a run that sits at a module grid corner (its centre near a grid
        line in the scan direction while the line itself hugs a perpendicular
        grid line) is treated as the benign boundary-lump artifact and skipped.
        """
        # Run-length encode the line: indices where the value changes.
        change_idx = np.flatnonzero(np.diff(line)) + 1
        boundaries = np.concatenate(([0], change_idx, [line_len]))
        run_lengths = np.diff(boundaries)
        # Skip the first and last run: they touch the bbox edges and may be
        # clipped mid-cell, which would falsely look like a short run.
        if run_lengths.size <= 2:
            return 0, 0

        inner_lengths = run_lengths[1:-1]
        inner_starts = boundaries[1:-2]
        inner_ends = boundaries[2:-1]

        # Defect candidates: shorter than a cell AND black (dark ink).
        candidate = (inner_lengths < min_run) & (line[inner_starts] == 0)

        # Suppress boundary lumps: short black runs sitting at a grid corner.
        if on_boundary and grid_pos.size and np.any(candidate):
            centres = (inner_starts + inner_ends) / 2.0
            near_grid = np.min(np.abs(centres[:, None] - grid_pos[None, :]), axis=1) <= lump_tol
            candidate &= ~near_grid

        return int(inner_lengths.size), int(np.count_nonzero(candidate))

    total_runs = 0
    bad_runs = 0
    # Vertical scan lines (top-to-bottom over each column); lumps register at the
    # horizontal grid lines (y_grid) when the column hugs a vertical boundary.
    for col in range(w):
        t, b = _count_runs(binary[:, col], h, min_run_v, y_grid, bool(col_on_boundary[col]), lump_tol_v)
        total_runs += t
        bad_runs += b
    # Horizontal scan lines (left-to-right over each row); lumps register at the
    # vertical grid lines (x_grid) when the row hugs a horizontal boundary.
    for row in range(h):
        t, b = _count_runs(binary[row, :], w, min_run_h, x_grid, bool(row_on_boundary[row]), lump_tol_h)
        total_runs += t
        bad_runs += b

    if total_runs == 0:
        return 1.0

    # --- DEBUG visualization ---
    # Red   = counted black defect, Green = suppressed boundary-lump,
    # Blue  = short white run (never counted).
    # if 1.0 - bad_runs / total_runs < 1.0:
    #     debug = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    #     for col in range(w):
    #         line = binary[:, col]
    #         boundaries = np.concatenate(([0], np.flatnonzero(np.diff(line)) + 1, [h]))
    #         for i in range(1, boundaries.size - 2):
    #             s, e = int(boundaries[i]), int(boundaries[i + 1])
    #             if (e - s) >= min_run_v:
    #                 continue
    #             if line[s] != 0:
    #                 debug[s:e, col] = (255, 0, 0)
    #                 continue
    #             centre = (s + e) / 2.0
    #             is_lump = bool(col_on_boundary[col]) and np.min(np.abs(y_grid - centre)) <= lump_tol_v
    #             debug[s:e, col] = (0, 255, 0) if is_lump else (0, 0, 255)
    #     for row in range(h):
    #         line = binary[row, :]
    #         boundaries = np.concatenate(([0], np.flatnonzero(np.diff(line)) + 1, [w]))
    #         for i in range(1, boundaries.size - 2):
    #             s, e = int(boundaries[i]), int(boundaries[i + 1])
    #             if (e - s) >= min_run_h:
    #                 continue
    #             if line[s] != 0:
    #                 debug[row, s:e] = (255, 0, 0)
    #                 continue
    #             centre = (s + e) / 2.0
    #             is_lump = bool(row_on_boundary[row]) and np.min(np.abs(x_grid - centre)) <= lump_tol_h
    #             debug[row, s:e] = (0, 255, 0) if is_lump else (0, 0, 255)
    #     show_img(debug, resize=.4, t="datamatrix_uniformity")
    # --- END DEBUG ---

    return 1.0 - bad_runs / total_runs

def check_data_structure(page_image, bbox, code_type):
    """
    Validate data structure integrity.
    Expects grayscale page_image.
    """
    if code_type != 'datamatrix':
        return None
    
    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    gray = region
    
    h, w = gray.shape
    
    corner_size = min(h // 4, w // 4, 10)
    
    corners = [
        gray[:corner_size, :corner_size],
        gray[:corner_size, -corner_size:],
        gray[-corner_size:, :corner_size],
        gray[-corner_size:, -corner_size:]
    ]
    
    corner_contrasts = [float(c.max() - c.min()) / 255.0 for c in corners if c.size > 0]
    
    if not corner_contrasts:
        return 0.5
    
    avg_corner_contrast = np.mean(corner_contrasts)
    return avg_corner_contrast

def check_datamatrix_modulation(page_image, bbox, n_rows, n_cols, min_intensity, max_intensity, threshold=127):
    """
    Compute per-module modulation (M_MOD) for a Data Matrix symbol.

    For each module the center pixel value R is sampled.  The module's expected
    state (light or dark) is determined by comparing R to the threshold T.

    Light modules (R >= T):
        M_MOD = (R - T) / (Rmax - T)   if R >= T and R < Rmax
        M_MOD = 1.0                     if R >= Rmax
        M_MOD = 0.0                     if R < T

    Dark modules (R < T):
        M_MOD = (T - R) / (T - Rmin)   if R < T and R >= Rmin
        M_MOD = 1.0                     if R <= Rmin
        M_MOD = 0.0                     if R >= T

    Args:
        page_image: Full page image (grayscale).
        bbox: Bounding box [xmin, ymin, xmax, ymax].
        n_rows: Number of module rows in the Data Matrix.
        n_cols: Number of module columns in the Data Matrix.
        min_intensity: Rmin (0-255 scale, will be used as-is).
        max_intensity: Rmax (0-255 scale, will be used as-is).
        threshold: Global threshold T (0-255).

    Returns:
        np.ndarray: (n_rows, n_cols) array of per-module M_MOD values in [0, 1].
    """
    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    h, w = region.shape[:2]

    T = float(threshold)
    Rmin = float(min_intensity)
    Rmax = float(max_intensity)

    cell_h = h / n_rows
    cell_w = w / n_cols

    modulations = np.zeros((n_rows, n_cols), dtype=np.float64)

    for row in range(n_rows):
        cy = int(row * cell_h + cell_h / 2)
        cy = min(cy, h - 1)
        for col in range(n_cols):
            cx = int(col * cell_w + cell_w / 2)
            cx = min(cx, w - 1)
            R = float(region[cy, cx])

            if R >= T:
                # Light module
                if Rmax <= T:
                    m = 0.0
                elif R >= Rmax:
                    m = 1.0
                else:
                    m = (R - T) / (Rmax - T)
            else:
                # Dark module
                if Rmin >= T:
                    m = 0.0
                elif R <= Rmin:
                    m = 1.0
                else:
                    m = (T - R) / (T - Rmin)

            modulations[row, col] = m

    # --- DEBUG visualization ---
    # debug_region = cv2.cvtColor(region, cv2.COLOR_GRAY2BGR)
    # for row in range(n_rows):
    #     cy = int(row * cell_h + cell_h / 2)
    #     cy = min(cy, h - 1)
    #     for col in range(n_cols):
    #         cx = int(col * cell_w + cell_w / 2)
    #         cx = min(cx, w - 1)
    #         color = (0, 255, 0) if modulations[row, col] >= 0.5 else (0, 0, 255)
    #         cv2.circle(debug_region, (cx, cy), 1, color, -1)
    # show_img(debug_region, t="datamatrix_modulation")
    # --- END DEBUG ---

    return modulations

def check_datamatrix_sharpness(page_image, bbox, min_intensity, max_intensity):
    """
    Estimate the sharpness of a Data Matrix symbol using known dark/light intensity levels.

    Each pixel is assigned to either the dark (min_intensity) or light (max_intensity)
    cluster based on a midpoint threshold. Sharpness is 1 minus the mean normalised
    distance from each pixel to its assigned centre.

    Args:
        page_image: Full page image (grayscale).
        bbox: Bounding box [xmin, ymin, xmax, ymax].
        min_intensity (float): Dark level in [0, 1] (from check_contrast).
        max_intensity (float): Light level in [0, 1] (from check_contrast).

    Returns:
        float: Sharpness score in [0, 1].
    """
    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY) if len(region.shape) == 3 else region

    Rmin = min_intensity * 255.0
    Rmax = max_intensity * 255.0
    threshold = (Rmin + Rmax) / 2.0

    pixels = gray.flatten().astype(np.float32)
    assigned = np.where(pixels < threshold, Rmin, Rmax)
    distances = np.abs(pixels - assigned)

    sharpness = 1.0 - distances.mean() / 127.5
    return float(np.clip(sharpness, 0.0, 1.0))

def _silhouette_score_1d(values, labels):
    """
    Mean silhouette score for a 1D clustering.
    Returns -1.0 for fewer than two populated clusters.
    Singleton clusters contribute 0.0 (standard convention).
    """
    values = np.asarray(values, dtype=np.float64)
    labels = np.asarray(labels).flatten()
    unique_labels = np.unique(labels)
    if unique_labels.size < 2:
        return -1.0

    scores = np.zeros(values.shape[0], dtype=np.float64)
    for i in range(values.shape[0]):
        same = values[labels == labels[i]]
        if same.size <= 1:
            scores[i] = 0.0
            continue
        a = np.sum(np.abs(same - values[i])) / (same.size - 1)
        b = np.inf
        for lbl in unique_labels:
            if lbl == labels[i]:
                continue
            other = values[labels == lbl]
            b = min(b, float(np.mean(np.abs(other - values[i]))))
        denom = max(a, b)
        scores[i] = (b - a) / denom if denom > 0 else 0.0
    return float(np.mean(scores))

def _cluster_bar_widths(sorted_widths, k_min=2, k_max=6):
    """
    Cluster 1D bar widths trying k in [k_min, k_max], keep the clustering
    with the best silhouette score.

    Outliers (e.g. large connected components caused by defects) are removed
    with a standard IQR filter before clustering so they cannot pull cluster
    centres away from the true bar-width groups.

    Returns:
        tuple[float, float]: (narrow_width, wide_width) — smallest and largest
        cluster centres.
    """
    # --- Outlier removal (Tukey fences, upper side only) ---
    q1, q3 = np.percentile(sorted_widths, [25, 75])
    iqr = q3 - q1
    upper_fence = q3 + 1.5 * iqr
    filtered = sorted_widths[sorted_widths <= upper_fence]
    if filtered.size < 2:
        filtered = sorted_widths  # Fall back to all values if too many removed

    data = filtered.reshape(-1, 1).astype(np.float32)
    n_unique = int(np.unique(filtered).size)
    k_max = min(k_max, n_unique, len(filtered))
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.1)

    best_score = -np.inf
    best_centers = None
    for k in range(max(2, k_min), max(2, k_max) + 1):
        if k > len(filtered):
            break
        _, labels_k, centers = cv2.kmeans(data, k, None, criteria, 10, cv2.KMEANS_PP_CENTERS)
        score = _silhouette_score_1d(filtered, labels_k.flatten())
        if score > best_score:
            best_score = score
            best_centers = centers.flatten()

    if best_centers is None:
        mean_width = float(np.mean(filtered))
        return mean_width, mean_width

    return float(np.min(best_centers)), float(np.max(best_centers))

def _bar_intervals(stats, orientation, min_length_ratio=0.5):
    """
    Reduce connected-component stats to sorted (start, end) bar intervals along
    the scan axis (x for horizontal codes, y for vertical ones).

    A component whose length along the bar direction (the perpendicular axis) is
    shorter than ``min_length_ratio`` of the *median* bar length is treated as
    noise and skipped, so stray specks cannot introduce phantom elements. Using
    the median rather than the region height keeps the filter correct even when
    the bounding box is slightly loose.
    """
    if orientation in [90, 270]:
        pos_idx, size_idx, perp_idx = cv2.CC_STAT_TOP, cv2.CC_STAT_HEIGHT, cv2.CC_STAT_WIDTH
    else:
        pos_idx, size_idx, perp_idx = cv2.CC_STAT_LEFT, cv2.CC_STAT_WIDTH, cv2.CC_STAT_HEIGHT

    comps = stats[1:]
    if comps.shape[0] == 0:
        return []

    min_length = min_length_ratio * float(np.median(comps[:, perp_idx]))
    intervals = sorted(
        (int(c[pos_idx]), int(c[pos_idx]) + int(c[size_idx]))
        for c in comps if c[perp_idx] >= min_length
    )

    # Merge any overlapping intervals so each bar is represented exactly once.
    merged = []
    for start, end in intervals:
        if merged and start < merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged


def check_bar_width(page_image, bbox, code_type, orientation=0):
    """
    Measure narrow bar width (1D only).
    Expects grayscale page_image.

    Returns:
        tuple: ``(wide_width, narrow_width, ratio, bars)`` where ``bars`` is a
        list of (start, end) intervals - in region-relative pixels along the
        scan axis - marking where each bar begins and ends. The intervals are
        ordered left-to-right (top-to-bottom for vertical codes) and are reused
        by :func:`check_min_edge_contrast` to sample element centres.
    """
    if code_type != 'barcode':
        return None
    
    region, _ = extract_region(page_image, bbox, xpadding=0, ypadding=0)
    gray = region
    
    _, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
    
    _, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    
    if stats.shape[0] < 2:
        return 0, 0, 0, []
    
    stat_idx = cv2.CC_STAT_HEIGHT if orientation in [90, 270] else cv2.CC_STAT_WIDTH
    widths = stats[1:, stat_idx]
    
    if widths.size == 0:
        return 0, 0, 0, []

    # Bar start/end positions along the scan axis, reused for edge contrast.
    bars = _bar_intervals(stats, orientation)
    
    # Group widths into narrow and wide bars
    sorted_widths = np.sort(widths).astype(np.float32)
    if sorted_widths.max() - sorted_widths.min() < 1:
        # All bars roughly the same width
        narrow_width = float(np.mean(sorted_widths))
        wide_width = narrow_width
    else:
        # Try multiple k and keep the best-fitting clustering (silhouette score)
        narrow_width, wide_width = _cluster_bar_widths(sorted_widths, k_min=2, k_max=6)

    ratio = wide_width / (narrow_width + 1e-6)
    
    return wide_width, narrow_width, ratio, bars

def barcode_bbox_correction(page_image, bbox, orientation=None, search_factor=2.0,
                            height_tol=0.6, gap_factor=6.0):
    """
    Widen a too-tight 1D-barcode bbox so bars clipped off the sides are included.

    Object-detection boxes are occasionally narrower than the symbol, leaving
    some bars (sometimes close to half) outside the box; the decoder then sees a
    partial symbol and fails. This looks for full-height bars just outside the
    box and grows the box to cover any that belong to the same symbol, stopping
    at the quiet zone so neighbouring text or codes are never absorbed.

    The approach mirrors the intuitive one - find the bars, walk outward while
    the spacing still matches the symbol, stop when it no longer does:
      * Only full-height vertical runs count as bars (via the same connected-
        component idea as :func:`check_bar_width`), so text and specks that
        share the symbol's rows are ignored.
      * A neighbouring bar is absorbed only when the white gap to it is narrower
        than a quiet zone (``gap_factor`` narrow-bar widths); the first wider
        gap marks the quiet zone and ends the search on that side.
      * The box is only ever grown, never shrunk, so a correct box is returned
        unchanged.

    Args:
        page_image: Full page image (grayscale or BGR).
        bbox: Detected barcode box [xmin, ymin, xmax, ymax].
        orientation: Code orientation in degrees. When None the scan axis is
                     decided automatically (see below) since a heavily clipped
                     box can end up taller than wide.
        search_factor: How far to look past each side, as a multiple of the
                       box's length along the scan axis.
        height_tol: Minimum bar length, as a fraction of the reference bar
                    length, for a component to be treated as a bar.
        gap_factor: Largest space between adjoining bars, in narrow-bar widths,
                    still considered part of the symbol rather than a quiet zone.

    Returns:
        list[int]: Possibly widened [xmin, ymin, xmax, ymax]. The original box
                   is returned unchanged when no extension is warranted.
    """
    xmin, ymin, xmax, ymax = [int(round(float(v))) for v in bbox]

    def _correct_axis(horizontal):
        """Grow the box along one axis; also report how many in-box bars it
        anchored on, which is used to pick the true scan axis."""
        # Work from the current box (which may already have grown across passes)
        # so the search window is re-centred and re-sized on every iteration.
        cur_box = [xmin, ymin, xmax, ymax]
        scan_len = (xmax - xmin) if horizontal else (ymax - ymin)
        if scan_len <= 0:
            return cur_box, 0

        # Look a generous distance past each side; the height/quiet-zone tests
        # below stop the extra context pulling in anything that is not a bar.
        pad_scan = max(int(scan_len * search_factor), 1)
        if horizontal:
            region, (scan_origin, _, _, _) = extract_region(page_image, cur_box, xpadding=pad_scan, ypadding=0)
        else:
            region, (_, scan_origin, _, _) = extract_region(page_image, cur_box, xpadding=0, ypadding=pad_scan)

        gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY) if region.ndim == 3 else region
        # Bar-axis size of the region: a true bar spans (nearly) all of it.
        bar_dim = gray.shape[0] if horizontal else gray.shape[1]

        # Bars are dark; invert so they become the foreground for labelling.
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        num, _, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
        if num < 2:
            return cur_box, 0

        if horizontal:
            pos_idx, size_idx, perp_idx = cv2.CC_STAT_LEFT, cv2.CC_STAT_WIDTH, cv2.CC_STAT_HEIGHT
        else:
            pos_idx, size_idx, perp_idx = cv2.CC_STAT_TOP, cv2.CC_STAT_HEIGHT, cv2.CC_STAT_WIDTH

        # Every component as (scan_start, scan_end, perp_len, scan_width) in page
        # coordinates along the scan axis, ordered along it.
        comps = []
        for i in range(1, num):
            start = int(stats[i, pos_idx]) + scan_origin
            length = int(stats[i, size_idx])
            comps.append((start, start + length, int(stats[i, perp_idx]), length))
        comps.sort(key=lambda c: c[0])

        orig_lo = xmin if horizontal else ymin
        orig_hi = xmax if horizontal else ymax

        # Anchor on the bars already inside the box to learn this symbol's bar
        # length and narrow-bar width. The true scan axis finds many full-length
        # bars here; the wrong axis sees the bars side-on (perp length == bar
        # width) and finds essentially none, which is how the axis is chosen.
        in_box = [c for c in comps if orig_lo <= (c[0] + c[1]) / 2 <= orig_hi and c[2] >= height_tol * bar_dim]
        if not in_box:
            return cur_box, 0

        ref_len = float(np.median([c[2] for c in in_box]))
        box_widths = np.sort(np.array([c[3] for c in in_box], dtype=np.float32))
        if box_widths.size >= 2 and (box_widths.max() - box_widths.min()) >= 1:
            narrow_width, _ = _cluster_bar_widths(box_widths)
        else:
            narrow_width = float(box_widths.min())
        narrow_width = max(narrow_width, 1.0)
        gap_threshold = gap_factor * narrow_width

        # Bar candidates anywhere in the searched strip: full-length and thin
        # enough to be a bar (a wide solid block is not a bar and is excluded).
        max_bar_width = max(narrow_width * 6, bar_dim)
        bars = [c for c in comps if c[2] >= height_tol * ref_len and c[3] <= max_bar_width]

        centers = [(c[0] + c[1]) / 2 for c in bars]
        seed = [i for i, c in enumerate(centers) if orig_lo <= c <= orig_hi]
        if not seed:
            return cur_box, 0
        left_i, right_i = min(seed), max(seed)

        # Walk outward, absorbing the next bar while the gap to it is sub-quiet-zone.
        while left_i > 0 and (bars[left_i][0] - bars[left_i - 1][1]) <= gap_threshold:
            left_i -= 1
        while right_i < len(bars) - 1 and (bars[right_i + 1][0] - bars[right_i][1]) <= gap_threshold:
            right_i += 1

        # Only ever grow the box; keep the bar-axis (height) extent untouched.
        new_lo = min(orig_lo, bars[left_i][0])
        new_hi = max(orig_hi, bars[right_i][1])
        if horizontal:
            return [int(new_lo), ymin, int(new_hi), ymax], len(in_box)
        return [xmin, int(new_lo), xmax, int(new_hi)], len(in_box)

    if orientation is not None:
        horizontal = orientation in [0, 180]
    else:
        # Orientation unknown: a clipped box can end up taller than wide, so the
        # aspect ratio is unreliable. Try one pass on each axis and keep
        # whichever anchored on more full-length bars (the true scan axis).
        _, h_anchor = _correct_axis(True)
        _, v_anchor = _correct_axis(False)
        horizontal = h_anchor >= v_anchor

    # Iteratively grow along the chosen axis. A badly-clipped detection box can
    # be much smaller than the whole symbol - smaller even than one search
    # window - so a single pass may stop at the window edge while bars continue
    # beyond it. Re-searching from the grown box widens the window each pass
    # until the box stops changing (the full symbol is covered). Bounded so a
    # pathological image can never loop forever.
    for _ in range(8):
        box, _anchor = _correct_axis(horizontal)
        if box == [xmin, ymin, xmax, ymax]:
            break
        xmin, ymin, xmax, ymax = box
    return [xmin, ymin, xmax, ymax]

def check_cell_size(data_matrix, min_run=2):
    """
    Estimate the module/cell size of a binary-like data matrix using run-length analysis.

    Methodology (Option 1):
    - Convert the matrix to a binary representation.
    - Compute horizontal and vertical run lengths of equal values.
    - Use the most frequent run length (mode) as the dominant cell size.
    - Return a robust estimate (median of runs near the dominant length).

    Args:
        data_matrix (np.ndarray or list): 2D matrix containing module values.
        min_run (int): Minimum run length to consider as a potential cell/module.

    Returns:
        float | None: Estimated cell size in pixels. None if not enough structure is found.
    """
    arr = np.asarray(data_matrix)
    if arr.ndim != 2 or arr.size == 0:
        return None

    # Normalize to uint8 for robust thresholding.
    arr = arr.astype(np.float32)
    arr_min, arr_max = float(arr.min()), float(arr.max())
    if arr_max - arr_min < 1e-6:
        return None

    norm = ((arr - arr_min) / (arr_max - arr_min) * 255).astype(np.uint8)

    # If already binary-like, keep that. Otherwise use Otsu thresholding.
    unique_vals = np.unique(norm)
    if unique_vals.size <= 2:
        binary = (norm > unique_vals.min()).astype(np.uint8)
    else:
        _, binary = cv2.threshold(norm, 0, 1, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    def _collect_run_lengths(mat):
        runs = []

        # Horizontal runs
        for row in mat:
            run_len = 1
            for i in range(1, row.shape[0]):
                if row[i] == row[i - 1]:
                    run_len += 1
                else:
                    if run_len >= min_run:
                        runs.append(run_len)
                    run_len = 1
            if run_len >= min_run:
                runs.append(run_len)

        # Vertical runs
        for col in mat.T:
            run_len = 1
            for i in range(1, col.shape[0]):
                if col[i] == col[i - 1]:
                    run_len += 1
                else:
                    if run_len >= min_run:
                        runs.append(run_len)
                    run_len = 1
            if run_len >= min_run:
                runs.append(run_len)

        return runs

    run_lengths = _collect_run_lengths(binary)
    if not run_lengths:
        return None

    run_lengths = np.array(run_lengths, dtype=np.int32)

    # Dominant run length via histogram mode.
    counts = np.bincount(run_lengths)
    if counts.size <= 1:
        return None
    dominant = int(np.argmax(counts[1:]) + 1)

    # Robust final estimate: median of runs around dominant (+/-1 px).
    near = run_lengths[np.abs(run_lengths - dominant) <= 1]
    if near.size == 0:
        near = run_lengths

    return float(np.median(near))


# ---------------------------------------------------------------------------
# ISO grade tables  (ISO/IEC 15415 / 15416)
#
# Each metric entry is a dict with:
#   "inverted" (bool): True when a *lower* raw value is better (e.g. defects).
#   "bands"   (list of tuples): ordered from best (grade 4) to worst grade.
#
# Tuple format  (low, high, base_grade, span):
#   Regular  (inverted=False): matches low ≤ value < high.
#     Top band: high=None → value ≥ low → flat base_grade.
#   Inverted (inverted=True):  matches low < value ≤ high.
#     Top band: low=None  → value ≤ high → flat base_grade.
#
# Sub-grade interpolation within a band (when span is not None):
#   Regular : sub = (value - low) / span * 0.9
#   Inverted: sub = (high - value) / span * 0.9
#   → bottom of band ⇒ X.0, near top ⇒ X.9
#
# Values that fall below/above all defined bands return 0.0.
# ---------------------------------------------------------------------------
_GRADE_TABLES: dict[str, dict] = {
    # --- Decodability (1D, ISO/IEC 15416) ---
    "decodability": {
        "inverted": False,
        "bands": [
            (0.62, None, 4, None),   # ≥ 0.62          → 4.0
            (0.50, 0.62, 3, 0.12),   # [0.50, 0.62)    → 3.0 – 3.9
            (0.37, 0.50, 2, 0.13),   # [0.37, 0.50)    → 2.0 – 2.9
            (0.25, 0.37, 1, 0.12),   # [0.25, 0.37)    → 1.0 – 1.9
            (0.20, 0.25, 0, 0.05),   # [0.20, 0.25)    → 0.0 – 0.9
        ],
    },
    # --- Intensity Ratio (lower = better; only grade-4 and grade-0 defined) ---
    "intensity_ratio": {
        "inverted": True,
        "bands": [
            (None, 0.50, 4, None),   # ≤ 0.50 → 4.0;  > 0.50 → 0.0
        ],
    },
    # --- Quiet Zone ---
    # Quiet-zone checks return a normalized ratio where 1.0 means the minimum
    # required quiet zone is met. Anything below 1.0 is an automatic failure.
    "quiet_zone": {
        "inverted": False,
        "bands": [
            (1.00, None, 4, None),   # ≥ 1.00 → 4.0;  < 1.00 → 0.0 / F
        ],
    },
    # --- Uniformity ---
    # Uniformity checks return a normalized ratio where 1.0 means the minimum
    # required uniformity is met. Anything below 1.0 is an automatic failure.
    "uniformity": {
        "inverted": False,
        "bands": [
            (1.00, None, 4, None),   # ≥ 1.00 → 4.0;  < 1.00 → 0.0 / F
        ],
    },    
    # --- Decode ---
    # Decode wether or not the code was decoded successfully.
    # Decode checks return 4.0 for successful decode and 0.0 for failure.
    "decode": {
        "inverted": False,
        "bands": [
            (1.00, None, 4, None),   # ≥ 1.00 → 4.0;  < 1.00 → 0.0 / F
        ],
    },
    # --- HRI (Human-Readable Interpretation) ---
    # Whether the decoded value's human-readable text was found near the code.
    # Returns 4.0 (A) when found, 0.0 (F) otherwise.
    "HRI": {
        "inverted": False,
        "bands": [
            (1.00, None, 4, None),   # ≥ 1.00 → 4.0 (A);  < 1.00 → 0.0 (F)
        ],
    },
    # --- Symbol Contrast ---
    "symbol_contrast": {
        "inverted": False,
        "bands": [
            (0.70, None, 4, None),   # ≥ 0.70          → 4.0
            (0.55, 0.70, 3, 0.15),   # [0.55, 0.70)    → 3.0 – 3.9
            (0.40, 0.55, 2, 0.15),   # [0.40, 0.55)    → 2.0 – 2.9
            (0.20, 0.40, 1, 0.20),   # [0.20, 0.40)    → 1.0 – 1.9
            (0.15, 0.20, 0, 0.05),   # [0.15, 0.20)    → 0.0 – 0.9
        ],
    },
    # --- Minimum Edge Contrast (only grade-4 and grade-0 defined) ---
    "min_edge_contrast": {
        "inverted": False,
        "bands": [
            (0.15, None, 4, None),   # ≥ 0.15 → 4.0;  < 0.15 → 0.0
        ],
    },
    # --- Modulation ---
    "modulation": {
        "inverted": False,
        "bands": [
            (0.70, None, 4, None),   # ≥ 0.70          → 4.0
            (0.60, 0.70, 3, 0.10),   # [0.60, 0.70)    → 3.0 – 3.9
            (0.50, 0.60, 2, 0.10),   # [0.50, 0.60)    → 2.0 – 2.9
            (0.40, 0.50, 1, 0.10),   # [0.40, 0.50)    → 1.0 – 1.9
            (0.30, 0.40, 0, 0.10),   # [0.30, 0.40)    → 0.0 – 0.9
        ],
    },
    # --- Defects (lower = better) ---
    "defects": {
        "inverted": True,
        "bands": [
            (None, 0.15, 4, None),   # ≤ 0.15          → 4.0
            (0.15, 0.20, 3, 0.05),   # (0.15, 0.20]    → 3.0 – 3.9
            (0.20, 0.25, 2, 0.05),   # (0.20, 0.25]    → 2.0 – 2.9
            (0.25, 0.30, 1, 0.05),   # (0.25, 0.30]    → 1.0 – 1.9
        ],                           # > 0.30           → 0.0
    },
    # --- Sharpness (Data Matrix, higher = sharper transitions) ---
    "sharpness": {
        "inverted": False,
        "bands": [
            (0.90, None, 4, None),   # ≥ 0.90          → 4.0
            (0.80, 0.90, 3, 0.10),   # [0.80, 0.90)    → 3.0 – 3.9
            (0.70, 0.80, 2, 0.10),   # [0.70, 0.80)    → 2.0 – 2.9
            (0.60, 0.70, 1, 0.10),   # [0.60, 0.70)    → 1.0 – 1.9
            (0.25, 0.60, 0, 0.35),   # [0.25, 0.60)    → 0.0 – 0.9
        ],
    },
    # --- Narrow Bar Width in mm (≥ 0.25 mm → grade 4, < 0.25 mm → grade 0) ---
    "narrow_bar_width": {
        "inverted": False,
        "bands": [
            (0.25, None, 4, None),   # ≥ 0.25 mm → 4.0;  < 0.25 mm → 0.0 / F
        ],
    },
}

def _numeric_to_alpha(numeric_grade: float) -> str:
    """Convert a numeric ISO grade (0.0–4.0) to its alphabetic equivalent."""
    if numeric_grade >= 3.5:
        return "A"
    elif numeric_grade >= 2.5:
        return "B"
    elif numeric_grade >= 1.5:
        return "C"
    elif numeric_grade >= 0.5:
        return "D"
    else:
        return "F"

def value_to_grade(value: float, metric: str) -> tuple[float, str] | tuple[None, None]:
    """
    Convert a raw metric value to an ISO 4–0 numeric grade and its alphabetic
    equivalent using the appropriate lookup table for the given metric.

    Within each grade band the sub-grade is linearly interpolated so that the
    bottom of the band maps to X.0 and the top maps to X.9.  For *inverted*
    metrics (lower raw value = better) the direction is reversed inside the band.

    Alphabetic grade mapping:
        3.5 – 4.0 → A
        2.5 – 3.5 → B
        1.5 – 2.5 → C
        0.5 – 1.5 → D
        below 0.5 → F

    Args:
        value  (float): Raw metric score.
        metric (str):   Metric name key matching a key in ``_GRADE_TABLES``
                        (e.g. ``"symbol_contrast"``, ``"defects"``).

    Returns:
        tuple[float, str]: ``(numeric_grade, alpha_grade)`` where numeric_grade
                           is in [0.0, 4.0] and alpha_grade is one of A/B/C/D/F.
        tuple[None, None]: If the metric name is unknown.

    Example:
        >>> value_to_grade(0.58, "decodability")
        (3.6, 'A')
        >>> value_to_grade(0.18, "defects")
        (3.36, 'A')
        >>> value_to_grade(0.99, "unknown_metric")
        (None, None)
    """
    config = _GRADE_TABLES.get(metric)
    if config is None:
        return None, None  # unknown metric

    inverted: bool = config["inverted"]
    bands: list[tuple] = config["bands"]

    numeric: float | None = None

    for low, high, base, span in bands:
        if inverted:
            if low is None:
                # Top band: value ≤ high → flat grade
                if value <= high:
                    numeric = float(base)
                    break
            else:
                # Band: low < value ≤ high
                if low < value <= high:
                    if span:
                        sub = (high - value) / span * 0.9
                        numeric = round(base + sub, 2)
                    else:
                        numeric = float(base)
                    break
        else:
            if high is None:
                # Top band: value ≥ low → flat grade
                if value >= low:
                    numeric = float(base)
                    break
            else:
                # Band: low ≤ value < high
                if low <= value < high:
                    if span:
                        sub = (value - low) / span * 0.9
                        numeric = round(base + sub, 2)
                    else:
                        numeric = float(base)
                    break

    # Value outside all defined bands → grade 0.0
    if numeric is None:
        numeric = 0.0

    return f"{numeric:.1f}", _numeric_to_alpha(numeric)

def _round_toward_worse(value, metric, decimals=1):
    """
    Round a metric value toward its *worse* grade so that display rounding can
    never inflate the grade actually earned.

    Plain ``round`` can push a value across a band boundary (e.g. a uniformity of
    0.9948 rounds to 1.0 and wrongly passes the ``>= 1.00`` band). Rounding toward
    the worse grade avoids this while keeping the displayed value consistent with
    the awarded grade.

    Non-inverted metrics (higher = better) are floored; inverted metrics
    (lower = better, e.g. ``intensity_ratio``) are ceiled. Metrics with no grade
    table fall back to plain rounding, since their rounding direction is cosmetic.
    """
    config = _GRADE_TABLES.get(metric)
    factor = 10 ** decimals
    if config is None:
        return round(value, decimals)
    if config["inverted"]:
        return math.ceil(value * factor) / factor
    return math.floor(value * factor) / factor

def check_decode(decoded_data):
    """
    Check if barcode/datamatrix was successfully decoded.
    Returns score 1.0 if data exists, 0.0 otherwise.
    """
    return 1.0 if decoded_data else 0.0

def _add_decoded_hri_metrics(metrics, decoded_data, hri_score):
    """
    Add the info-only ``decoded`` entry and (when an HRI check was performed) the
    graded ``HRI`` entry to an already-graded ``metrics`` dict.

    - ``decoded``: the raw decoded value, ungraded (grade None) so it is displayed
      but does not affect the overall grade.
    - ``HRI``: A (found) / F (not found), only added when ``hri_score`` is not None
      (i.e. ``text_data`` was supplied to the detector). It participates in the
      overall grade like any other graded metric.
    """
    decoded_str = str(decoded_data) if decoded_data else "None"
    if hri_score is not None:
        metrics['HRI'] = [decoded_str, *value_to_grade(hri_score, "HRI")]
    return metrics

def grade_barcode(page_image, bbox, decoded_data=None, barcode_type=None, pixels_to_mm=None, orientation=0, hri_score=None):
    """
    Comprehensive barcode grading function.
    Expects grayscale page_image.
    
    Args:
        page_image: Full page image (grayscale)
        bbox: Bounding box of barcode [xmin, ymin, xmax, ymax]
        decoded_data: Decoded data string (if available)
        barcode_type: Type of barcode (optional)
        pixels_to_mm: Conversion factor from pixels to millimeters (optional).
        hri_score: 1.0 if the human-readable text (HRI) was found near the code,
            0.0 if not, or None to skip the HRI metric entirely.
    
    Returns:
        dict: Dictionary with individual metric scores and overall grade
    """
    code_type = 'barcode'
    # page_image is color (BGR); use a grayscale copy for the pixel-level metrics
    # and keep the color image for the quiet-zone check so colored die lines can
    # be removed.
    gray = cv2.cvtColor(page_image, cv2.COLOR_BGR2GRAY)

    min_intensity, max_intensity, symbol_contrast = check_contrast(gray, bbox)
    wide_width, narrow_width, ratio, bars = check_bar_width(gray, bbox, code_type, orientation=orientation)
    min_edge_contrast = check_min_edge_contrast(gray, bbox, code_type, orientation=orientation, bars=bars)
    # Convert bar widths from pixels to mm if conversion factor is available
    narrow_bar_width_mm = narrow_width * pixels_to_mm if pixels_to_mm and narrow_width else None
    wide_bar_width_mm = wide_width * pixels_to_mm if pixels_to_mm and wide_width else None
    qz_l, qz_r = check_quiet_zone(page_image, bbox, code_type, barcode_type=barcode_type, narrow_bar_width_mm=narrow_bar_width_mm, pixels_to_mm=pixels_to_mm, orientation=orientation)
    
    # Grade each quiet zone side individually, take the worst
    qz_l_grade = value_to_grade(qz_l, "quiet_zone") if qz_l is not None else (None, None)
    qz_r_grade = value_to_grade(qz_r, "quiet_zone") if qz_r is not None else (None, None)
    # Pick the worse (minimum) grade; if one side is None, use the other
    qz_grades = [g for g in [qz_l_grade, qz_r_grade] if g[0] is not None]
    if qz_grades:
        qz_min_grade = min(qz_grades, key=lambda g: g[0])
    else:
        qz_min_grade = (None, None)
    # Format quiet zone value string showing both sides as percentages
    qz_l_pct = f"{qz_l * 100:.0f}%" if qz_l is not None else "N/A"
    qz_r_pct = f"{qz_r * 100:.0f}%" if qz_r is not None else "N/A"
    qz_value_str = f"L:{qz_l_pct} R:{qz_r_pct}"

    metrics = {
        'decode': check_decode(decoded_data),
        'symbol_contrast': symbol_contrast,
        'min_intensity': min_intensity,
        'max_intensity': max_intensity,
        'intensity_ratio': min_intensity/(max_intensity + 1e-6),
        # 'magnification': check_magnification(page_image, bbox, code_type),
        'min_edge_contrast': min_edge_contrast,
        'modulation': min_edge_contrast / symbol_contrast if symbol_contrast > 0 else 0,
        'uniformity': check_uniformity(gray, bbox, code_type, orientation=orientation),
        'data_structure': check_data_structure(gray, bbox, code_type),
        'narrow_bar_width': narrow_bar_width_mm,
        'wide_bar_width': wide_bar_width_mm,
        'wide_narrow_ratio': ratio,
    }

    # Grade all standard metrics
    graded_metrics = {}
    for k, v in metrics.items():
        if v is None:
            continue
        if isinstance(v, (int, float)) and k in ('narrow_bar_width', 'wide_bar_width'):
            v = _round_toward_worse(v, k, 2)  # Round toward worse grade so display can't inflate it
            value_str = f"{v:.2f}"
        elif isinstance(v, (int, float)):
            v = _round_toward_worse(v, k, 1)  # Round toward worse grade so display can't inflate it
            value_str = f"{v:.1f}"
        else:
            value_str = str(v)
        graded_metrics[k] = [value_str, *value_to_grade(v, k)]
    metrics = graded_metrics

    # Insert quiet zone as a pre-graded entry (value is the formatted string, grade is the min of both sides)
    metrics['quiet_zone'] = [qz_value_str, *qz_min_grade]

    # Info-only decoded value and (optional) HRI grade
    _add_decoded_hri_metrics(metrics, decoded_data, hri_score)

    applicable_metrics = [float(v[1]) for v in metrics.values() if v[1] is not None]
    general_grade = _numeric_to_alpha(np.min(applicable_metrics)) if applicable_metrics else "F"

    return general_grade, metrics

def grade_datamatrix(page_image, bbox, dims, decoded_data=None, barcode_type=None, pixels_to_mm=None, orientation=0, hri_score=None):
    """
    Datamatrix-specific grading function.
    Expects grayscale page_image.
    
    Args:
        page_image: Full page image (grayscale)
        bbox: Bounding box of datamatrix [xmin, ymin, xmax, ymax]
        decoded_data: Decoded data string (if available)
        barcode_type: Type of barcode (optional)
        pixels_to_mm: Conversion factor from pixels to millimeters (optional).
        orientation: Orientation of the code (degrees)
        dims: Datamatrix dimensions e.g. ['14', '14'] (optional)
    
    Returns:
        tuple: (general_grade, metrics) same structure as grade_barcode
    """
    # Ensure image is grayscale
    if len(page_image.shape) == 3:
        page_image = cv2.cvtColor(page_image, cv2.COLOR_BGR2GRAY)

    min_intensity, max_intensity, symbol_contrast = check_contrast(page_image, bbox)

    # Calculate cell size from bbox and dims
    bbox_width = bbox[2] - bbox[0]
    bbox_height = bbox[3] - bbox[1]
    n_cols = int(dims[0])
    n_rows = int(dims[1])
    cell_size_px = np.mean([bbox_width / n_cols, bbox_height / n_rows])
    if pixels_to_mm:
        cell_size_mm = cell_size_px * pixels_to_mm

    # Per-module modulation
    mod_grid = check_datamatrix_modulation(
        page_image, bbox, n_rows, n_cols,
        min_intensity=min_intensity * 255, max_intensity=max_intensity * 255,
    )

    # Quiet zone (all 4 sides)
    qz_result = check_quiet_zone(page_image, bbox, 'datamatrix', pixels_to_mm=pixels_to_mm, cell_size_mm=cell_size_mm)
    qz_l, qz_r, qz_t, qz_b = qz_result

    # Grade each quiet zone side: pass (A) or fail (F)
    sides = {'L': qz_l, 'R': qz_r, 'T': qz_t, 'B': qz_b}
    qz_parts = []
    qz_all_grades = []
    for label, val in sides.items():
        if val is not None:
            grade_num, grade_alpha = value_to_grade(val, "quiet_zone")
            qz_parts.append(f"{label}:{grade_alpha}")
            qz_all_grades.append((grade_num, grade_alpha))
        else:
            qz_parts.append(f"{label}:N/A")
    qz_value_str = ", ".join(qz_parts)

    # Worst quiet zone grade
    qz_valid = [g for g in qz_all_grades if g[0] is not None]
    qz_min_grade = min(qz_valid, key=lambda g: float(g[0])) if qz_valid else (None, None)

    metrics = {
        'decode': check_decode(decoded_data),
        'symbol_contrast': symbol_contrast,
        'min_intensity': min_intensity,
        'max_intensity': max_intensity,
        'intensity_ratio': min_intensity / (max_intensity + 1e-6),
        'sharpness': check_datamatrix_sharpness(page_image, bbox, min_intensity, max_intensity),
        'uniformity': check_datamatrix_uniformity(page_image, bbox, dims),
        'columns': n_cols,
        'rows': n_rows,
    }

    # Grade all standard metrics
    graded_metrics = {}
    for k, v in metrics.items():
        if v is None:
            continue
        if isinstance(v, (int, float)):
            v = _round_toward_worse(v, k, 1)  # Round toward worse grade so display can't inflate it
            value_str = f"{v:.1f}"
        else:
            value_str = str(v)
        graded_metrics[k] = [value_str, *value_to_grade(v, k)]
    metrics = graded_metrics

    # Insert quiet zone as a pre-graded entry
    metrics['quiet_zone'] = [qz_value_str, *qz_min_grade]

    # Insert cell size as info-only metric (no grade)
    metrics['cell_size'] = [f"{cell_size_mm:.2f}", None, None]

    # Info-only decoded value and (optional) HRI grade
    _add_decoded_hri_metrics(metrics, decoded_data, hri_score)

    applicable_metrics = [float(v[1]) for v in metrics.values() if v[1] is not None]
    general_grade = _numeric_to_alpha(np.min(applicable_metrics)) if applicable_metrics else "F"

    return general_grade, metrics

if __name__ == "__main__":
    # --- Configure these for testing ---
    image_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\VISION\barcode_grading\3_to_original_errors.png"
    # print(self.barcode) copied and pasted from debug mode at the end of decode_barcodes in process_pdf.py, to use as test cases for grading function
    barcodes = [{'type': 'barcode', 'bbox': [np.int64(2572), np.int64(824), np.int64(3053), np.int64(933)], 'source': 'image', 'decoded': '01299999999999992000'}, {'type': 'barcode', 'bbox': [np.int64(2519), np.int64(995), np.int64(3095), np.int64(1104)], 'source': 'image', 'decoded': '1799122210MMMMMM1'}, {'type': 'datamatrix', 'bbox': [np.int64(2350), np.int64(2339), np.int64(2452), np.int64(2440)], 'source': 'image', 'decoded': '012999999999999920001799122210MMMMMM1'}, {'type': 'datamatrix', 'bbox': [np.int64(1450), np.int64(1076), np.int64(1574), np.int64(1200)], 'source': 'image', 'decoded': '012999999999999920001799122210MMMMMM1'}, {'type': 'datamatrix', 'bbox': [np.int64(1829), np.int64(2243), np.int64(1913), np.int64(2327)], 'source': 'image', 'decoded': 'MMMMMM1'}]
    
    # ACUVUE
    # image_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\VISION\Acuvue\page_images\1_to_original.png"
    # barcodes = [{'type': 'barcode', 'bbox': [np.int64(4586), np.int64(1393), np.int64(4873), np.int64(1532)], 'source': 'image', 'decoded': '31205099'}, {'type': 'barcode', 'bbox': [np.int64(4586), np.int64(3208), np.int64(4873), np.int64(3348)], 'source': 'image', 'decoded': '31205099'}, {'type': 'barcode', 'bbox': [np.int64(5100), np.int64(2433), np.int64(5389), np.int64(2573)], 'source': 'image', 'decoded': '31205099'}, {'type': 'barcode', 'bbox': [np.int64(5101), np.int64(617), np.int64(5388), np.int64(756)], 'source': 'image', 'decoded': '31205099'}, {'type': 'barcode', 'bbox': [np.int64(6020), np.int64(2570), np.int64(6541), np.int64(2625)], 'source': 'image', 'decoded': False}, {'type': 'barcode', 'bbox': [np.int64(6017), np.int64(2870), np.int64(6522), np.int64(2924)], 'source': 'image', 'decoded': False}, {'type': 'barcode', 'bbox': [np.int64(6092), np.int64(2668), np.int64(6475), np.int64(2718)], 'source': 'image', 'decoded': False}, {'type': 'barcode', 'bbox': [np.int64(6023), np.int64(2967), np.int64(6479), np.int64(2996)], 'source': 'image', 'decoded': False}, {'type': 'datamatrix', 'bbox': [np.int64(6419), np.int64(2207), np.int64(6553), np.int64(2340)], 'source': 'image', 'decoded': '31205099'}]
    
    # ------------------------------------

    image = cv2.imread(image_path)  # Keep BGR so colored die lines can be removed from the quiet zone
    # image = cv2.GaussianBlur(image, (3, 3), 0)
    if image is None:
        print(f"Could not load image from: {image_path}")
    else:
        print(f"Image loaded: {image.shape}")
        for i, barcode in enumerate(barcodes):
            bbox = barcode['bbox']
            code_type = barcode['type']
            print(f"\n--- Grading bbox {i}: {bbox} ---")
            pad = 20
            pixels_to_mm = 2.54/300*10  # Example conversion factor for 300 DPI
            detected_codes = detect_barcode_datamatrix(image, bbox=bbox, btype=code_type, pixels_to_mm=pixels_to_mm)