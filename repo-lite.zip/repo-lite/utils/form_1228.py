from __future__ import annotations

from pathlib import Path
from typing import Dict
import numpy as np
import json
import random
import re
from  scipy.optimize import linear_sum_assignment
from collections import Counter

import pdfplumber
import fitz  # PyMuPDF
import cv2


class InputFileError(Exception):
    pass


def _sanitize_field_value(value: str) -> str:
    """
    Clean a text-field value extracted from the form.

    Form fields are drawn as underscore fill-lines (e.g. '____'). When the
    user's typed text touches the line, the extracted word can come back with
    underscores fused to it (e.g. '___1___'), which then leaks into symbol
    names like 'N_PC____1___'. This strips those stray underscores while
    preserving the actual entry.
    """
    if not value:
        return ""
    # Remove tokens that are purely underscores and strip stray underscores
    # (leading/trailing and internal runs) from each remaining token.
    tokens = []
    for tok in value.split():
        if re.fullmatch(r'_+', tok):
            continue
        # Collapse internal underscore runs, then trim leading/trailing ones.
        tok = re.sub(r'_+', '_', tok).strip('_')
        if tok:
            tokens.append(tok)
    return " ".join(tokens).strip()


def show_img(img, resize=False, t=False):
    tmp_img = img.copy()
    # Make tmp_img smaller
    if resize:
        tmp_img = cv2.resize(tmp_img, (int(tmp_img.shape[1] * resize), int(tmp_img.shape[0] * resize)))
    title = t if t else "title"
    cv2.imshow(title, tmp_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def is_checked(img: bytes, inner_margin: float = 0.45, white_threshold: int = 127, white_ratio: float = 0.95) -> bool:
    """
    Crop the inner region of the checkbox (excluding outer margin on all sides).
    If the inner region is almost entirely white -> unchecked.
    Any significant dark content -> checked.
    """
    arr = np.frombuffer(img, dtype=np.uint8)
    gray = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)
    if gray is None or gray.size == 0:
        return False

    h, w = gray.shape
    my = max(1, int(h * inner_margin))
    mx = max(1, int(w * inner_margin))
    inner = gray[my : h - my, mx : w - mx]

    if inner.size == 0:
        return False

    white_pixels = np.sum(inner >= white_threshold)
    ratio = white_pixels / inner.size
    return ratio < white_ratio


def _text_to_right_of_rect(
    words,
    rect: fitz.Rect,
    right_gap: float = 4.0,
    max_right_distance: float = 220.0,
    y_tolerance: float = 6.0,
    other_checkboxes: list = None,
) -> str:
    """
    Collect text words that are to the right of rect and roughly aligned vertically.
    Stop when encountering another checkbox boundary.
    """
    row = []
    cy = (rect.y0 + rect.y1) / 2.0
    
    # Find the nearest checkbox to the right (if any)
    max_x = rect.x1 + max_right_distance
    if other_checkboxes:
        for other_rect in other_checkboxes:
            if abs(other_rect.y0-rect.y0) < 5 and other_rect.x0 > rect.x1 + right_gap:
                max_x = min(max_x, other_rect.x0 - right_gap)

    for w in words:
        wx0, wy0, wx1, wy1, text, *_ = w
        wcy = (wy0 + wy1) / 2.0

        if wx0 < rect.x1 + right_gap:
            continue
        if wx0 >= max_x:
            continue
        if abs(wcy - cy) > max(y_tolerance, rect.height * 0.9):
            continue

        row.append((wx0, text))

    row.sort(key=lambda t: t[0])
    return " ".join(t for _, t in row).strip()
                           

def _pixmap_to_bgr(pix: fitz.Pixmap):
    if pix.alpha:
        pix = fitz.Pixmap(pix, 0)
    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, pix.n)
    if pix.n == 1:
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)
    if pix.n == 3:
        return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
    return arr


def _render_rect_crop(page: fitz.Page, rect: fitz.Rect, zoom: float = 5.0, pad: float = 1.5):
    clip = fitz.Rect(rect.x0 - pad, rect.y0 - pad, rect.x1 + pad, rect.y1 + pad)
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), clip=clip, alpha=False)
    return _pixmap_to_bgr(pix), pix.tobytes("png")


def _rect_iou(a: fitz.Rect, b: fitz.Rect) -> float:
    inter = a & b
    if inter.is_empty:
        return 0.0
    inter_area = inter.width * inter.height
    union_area = (a.width * a.height) + (b.width * b.height) - inter_area
    return inter_area / union_area if union_area > 0 else 0.0


def _dedupe_rects(rects, iou_threshold: float = 0.4):
    """
    Remove near-duplicate overlapping rectangles.
    Keeps the first rect after top-to-bottom, left-to-right sorting.
    """
    sorted_rects = sorted(rects, key=lambda r: (round(r.y0, 2), round(r.x0, 2), round(r.width * r.height, 2)))
    kept = []

    for rect in sorted_rects:
        if any(_rect_iou(rect, existing) >= iou_threshold for existing in kept):
            continue
        kept.append(rect)

    return kept


def _word_rect_iou(word_rect: fitz.Rect, field_rect: fitz.Rect) -> float:
    """Calculate how much of the word overlaps with the field (intersection / word area)."""
    inter = word_rect & field_rect
    if inter.is_empty:
        return 0.0
    word_area = word_rect.width * word_rect.height
    if word_area == 0:
        return 0.0
    return (inter.width * inter.height) / word_area

def extract_first_page_table(pdf_path: str) -> list[dict]:
    """Extract the table from the bottom of the first page of a PDF."""
    with pdfplumber.open(pdf_path) as pdf:
        first_page = pdf.pages[0]
        
        # Extract all tables from the first page
        tables = first_page.extract_tables()
        
        if not tables:
            print("No tables found on the first page.")
            return []
        
        # Take the last table (bottom of the page)
        table = tables[-1]
        
        # Use first row as headers
        headers = [str(h).strip() if h else f"col_{i}" for i, h in enumerate(table[0])]
        headers = ['SKU', 'Label', 'IFU', 'Carton', 'Regulatory']

        # Build list of dicts
        records = []
        for row in table[1:]:
            if all([v in ['', ' ', 'N/A', 'NA', 'na'] for v in row]):
                continue
            record = {headers[i]: (str(cell).strip() if cell else "") for i, cell in enumerate(row)}
            records.append(record)
        
        return records

def _extract_comment_fields(page: fitz.Page, words: list, zoom: float = 3.0, white_threshold: int = 220, shrink: float = 0) -> list:
    """
    Detect comment text fields in table cells below "N/A - No Comments" or "Comments" text.
    """
    comment_fields = []

    lines = page.get_text("dict")["blocks"]
    na_locations = []

    for block in lines:
        for line in block.get("lines", []):
            line_text = "".join(span["text"] for span in line["spans"]).strip()
            if (line_text in ("N/A - No Comments", "Comments") and line['spans'][0]['color']!=-1) or line_text.endswith('(found in MDM):'): # Second condition avoids matchin white "Comments" table header
                bbox = line["bbox"]  # (x0, y0, x1, y1)
                na_locations.append(bbox)

    if not na_locations:
        return comment_fields

    # Render the page as a grayscale image for pixel scanning
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img_gray = cv2.cvtColor(_pixmap_to_bgr(pix), cv2.COLOR_BGR2GRAY)
    img_h, img_w = img_gray.shape

    for (tx0, ty0, tx1, ty1) in na_locations:
        # The top of the comment box is the bottom of the "N/A - No Comments" text
        top = int(ty1 * zoom) + 1

        # Reference horizontal line at `top` row
        # Scan right from text_x1 to find right boundary (non-white pixel)
        ref_x_start = int(tx0 * zoom)
        ref_x_end = int(tx1 * zoom)

        # Find right boundary
        right = ref_x_end - 5
        for x in range(right, min(img_w, right + int(300 * zoom))):
            if img_gray[min(top, img_h - 1), x] < white_threshold:
                right = x - 1
                break
        else:
            right = ref_x_end

        # Find left boundary
        left = ref_x_start + 5
        for x in range(left, max(0, left - int(100 * zoom)), -1):
            if img_gray[min(top, img_h - 1), x] < white_threshold:
                left = x + 1
                break
        else:
            left = ref_x_start

        # Find bottom boundary: move the horizontal line down until a non-white row
        bottom = top 
        for row in range(top + 1, min(img_h, top + int(500 * zoom))):
            line_pixels = img_gray[row, left:right]
            if line_pixels.size == 0:
                break
            if np.min(line_pixels) < white_threshold:
                bottom = row
                break
        else:
            bottom = top + 1 + 2 * shrink

        # Convert back to PDF coordinates and shrink
        pdf_left = left / zoom + shrink
        pdf_top = top / zoom + shrink
        pdf_right = right / zoom - shrink
        pdf_bottom = bottom / zoom - shrink

        if pdf_right <= pdf_left or pdf_bottom <= pdf_top:
            continue

        # Extract any text already in this region
        field_rect = fitz.Rect(pdf_left, pdf_top, pdf_right, pdf_bottom)
        value_parts = []
        for w in words:
            wx0, wy0, wx1, wy1, text, *_ = w
            word_r = fitz.Rect(wx0, wy0, wx1, wy1)
            if _word_rect_iou(word_r, field_rect) > 0.5:
                stripped = text.strip()
                if stripped and not re.match(r'^_+$', stripped):
                    value_parts.append((wx0, wy0, stripped))
        # Sort by y then x
        value_parts.sort(key=lambda t: (round(t[1], 1), t[0]))
        value = _sanitize_field_value(" ".join(t for _, _, t in value_parts).strip())

        comment_fields.append({
            "label": "Comments",
            "value": value,
            "page": page.number + 1,
            "x0": pdf_left,
            "y0": pdf_top,
            "x1": pdf_right,
            "y1": pdf_bottom,
        })

    return comment_fields


def _extract_value_for_rect(page: fitz.Page, words: list, x0: float, y0: float, x1: float, y1: float) -> str:
    """Extract non-underscore text words that overlap with the given bbox."""
    field_rect = fitz.Rect(x0, y0, x1, y1)
    value_parts = []
    for w in words:
        wx0, wy0, wx1, wy1, text, *_ = w
        stripped = text.strip()
        if not stripped or re.match(r'^_+$', stripped):
            continue
        word_r = fitz.Rect(wx0, wy0, wx1, wy1)
        if _word_rect_iou(word_r, field_rect) > 0.5:
            value_parts.append((wx0, wy0, stripped))
    value_parts.sort(key=lambda t: (round(t[1], 1), t[0]))
    return _sanitize_field_value(" ".join(t for _, _, t in value_parts).strip())


def _extract_text_fields(page: fitz.Page, words: list, min_underscore_len: int = 3) -> list:
    """
    Detect text fields defined by underscore sequences on the page.
    Returns list of dicts with keys: label, value, page, x0, y0, x1, y1
    """
    text_fields = []
    # Find words that are primarily underscores (at least min_underscore_len)
    underscore_words = []
    for w in words:
        wx0, wy0, wx1, wy1, text, *_ = w
        stripped = text.strip()
        if len(stripped) >= min_underscore_len and re.match(r'^_+$', stripped):
            underscore_words.append((wx0, wy0, wx1, wy1, stripped))

    # Merge consecutive underscore words on the same line into single fields
    if not underscore_words:
        return text_fields

    # Sort by y then x
    underscore_words.sort(key=lambda u: (round(u[1], 1), u[0]))

    # For each merged underscore region, find the label (text to the left) and value (text on top)
    for ux0, uy0, ux1, uy1, _ in underscore_words:
        field_rect = fitz.Rect(ux0, uy0 - 2, ux1, uy1 + 1)  # slight vertical padding for value detection

        # Label: text immediately to the left on the same line
        label_parts = []
        cy = (uy0 + uy1) / 2.0
        for w in words:
            wx0, wy0_w, wx1_w, wy1_w, text, *_ = w
            wcy = (wy0_w + wy1_w) / 2.0
            stripped = text.strip()
            if re.match(r'^_+$', stripped):
                continue
            if wx1_w <= ux0 + 2 and wx0 >= ux0 - 200 and abs(wcy - cy) < 8:
                label_parts.append((wx0, stripped))
        label_parts.sort(key=lambda t: t[0])
        label = " ".join(t for _, t in label_parts).strip() if label_parts else ""

        # Value: non-underscore text overlapping the field rect (written on the line)
        value_parts = []
        for w in words:
            wx0, wy0_w, wx1_w, wy1_w, text, *_ = w
            stripped = text.strip()
            if re.match(r'^_+$', stripped):
                continue
            word_r = fitz.Rect(wx0, wy0_w, wx1_w, wy1_w)
            if _word_rect_iou(word_r, field_rect) > 0.55:
                value_parts.append((wx0, stripped))
        value_parts.sort(key=lambda t: t[0])
        value = _sanitize_field_value(" ".join(t for _, t in value_parts).strip())

        text_fields.append({
            "label": label if label else f"page_{page.number + 1}_text_field",
            "value": value,
            "page": page.number + 1,
            "x0": ux0,
            "y0": uy0,
            "x1": ux1,
            "y1": uy1,
        })

    return text_fields


def extract_image_checkboxes_with_text(
    pdf_source,
    form_rev: str,
    min_side: float = 5.0,
    max_side: float = 13.0,
    square_tolerance: float = 0.15,
    right_gap: float = 1.0,
    max_right_distance: float = 220.0,
    debug_show: bool = False,
    debug_zoom: float = 5.0,
    json_ids: bool = False,
) -> Dict[int, dict]:
    """
    Detect checkbox-like vector drawings and text fields, read text to the right,
    and return {unique_id: {label, checked, page, x0, y0, x1, y1}}.
    Checkboxes start at ID 1, text fields start at ID 1000.
    The form revision (e.g. "AA") is provided by the caller.

    pdf_source can be a file path (str/Path), bytes, or a BytesIO object.
    """
    if isinstance(pdf_source, (str, Path)):
        path = Path(pdf_source)
        if not path.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_source}")
        doc = fitz.open(path)
    elif isinstance(pdf_source, bytes):
        doc = fitz.open(stream=pdf_source, filetype="pdf")
    else:
        doc = fitz.open(stream=pdf_source.read(), filetype="pdf")

    results: Dict[int, dict] = {}
    seen_keys: Dict[str, int] = {}
    unique_id = 1
    text_field_id = 1000

    with doc:
        for page in doc:
            words = page.get_text("words") or []
            drawings = page.get_drawings() or []

            # --- Checkboxes ---
            checkbox_rects = []
            for drawing in drawings:
                rect = drawing.get("rect")
                if not rect:
                    continue
                items = drawing.get("items", [])
                has_rect_cmd = any(it and it[0] in {"re", "qu"} for it in items)
                if not has_rect_cmd:
                    continue
                w, h = rect.width, rect.height
                if h == 0:
                    continue
                aspect = w / h
                if (
                    min_side <= w <= max_side
                    and min_side <= h <= max_side
                    and (1.0 - square_tolerance) <= aspect <= (1.0 + square_tolerance)
                ):
                    checkbox_rects.append(rect)

            checkbox_rects = _dedupe_rects(checkbox_rects)

            for rect in checkbox_rects:
                crop_img, crop_png = _render_rect_crop(page, rect, zoom=debug_zoom)
                if debug_show and crop_img is not None and unique_id in [180, 181, 182]:
                    show_img(crop_img, t=f"ID {unique_id} - Page {page.number + 1}")

                label = _text_to_right_of_rect(
                    words, rect,
                    right_gap=right_gap,
                    max_right_distance=max_right_distance,
                    other_checkboxes=checkbox_rects,
                )
                if not label:
                    label = f"page_{page.number + 1}_vec_checkbox"

                seen_keys[label] = seen_keys.get(label, 0) + 1
                display_label = label if seen_keys[label] == 1 else f"{label}__{seen_keys[label]}"

                results[unique_id] = {
                    "label": display_label,
                    "checked": is_checked(crop_png),
                    "page": page.number + 1,
                    "x0": rect.x0,
                    "y0": rect.y0,
                    "x1": rect.x1,
                    "y1": rect.y1,
                    "type": "checkbox",
                }
                unique_id += 1

            # --- Text Fields (underscore-based) ---
            text_fields = _extract_text_fields(page, words)
            for tf in text_fields:
                tf["type"] = "text_field"
                results[text_field_id] = tf
                text_field_id += 1

            # --- Comment Text Fields (table cell below "N/A - No Comments") ---
            comment_fields = _extract_comment_fields(page, words)
            for cf in comment_fields:
                cf["type"] = "text_field"
                results[text_field_id] = cf
                text_field_id += 1

        if json_ids:
            rev_dir = Path(__file__).parent / "form_1228_templates" / f"rev_{form_rev}"
            json_ids_path = str(rev_dir / "form_1228_checkboxes.json")
            if not Path(json_ids_path).exists():
                raise InputFileError(f"The FORM-1228 Revision {form_rev} is not supported.")
            ref = _load_reference_ids(json_ids_path)

            # --- Align physical pages to the reference template pages ---
            # Overflow ("extra") pages are created when content is too long and spills
            # onto a following page. These pages contain no checkboxes and no text
            # fields, so they can be safely ignored. Every page that does contain form
            # content is mapped, in order, onto the reference template's pages so the
            # position-based ID matching below lines up correctly.
            ref_pages = sorted({r["page"] for r in ref})
            content_pages = sorted({v["page"] for v in results.values()})
            all_pages = list(range(1, doc.page_count + 1))
            ignored_pages = [p for p in all_pages if p not in content_pages]

            if len(content_pages) != len(ref_pages):
                raise InputFileError(
                    f"FORM-1228 (Revision {form_rev}) could not be reconciled to the template: "
                    f"expected {len(ref_pages)} content page(s) but found {len(content_pages)}. "
                    f"Pages ignored as empty (no checkboxes or fields): {ignored_pages}."
                )

            if ignored_pages:
                print(
                    f"[FORM-1228] Ignoring {len(ignored_pages)} extra page(s) with no "
                    f"checkboxes or fields: {ignored_pages}"
                )

            # Physical page -> reference page (and inverse for re-extraction)
            phys_to_ref = dict(zip(content_pages, ref_pages))
            ref_to_phys = {rp: cp for cp, rp in phys_to_ref.items()}
            for v in results.values():
                v["page"] = phys_to_ref[v["page"]]

            # Split results into checkboxes and text fields
            cb_results = {k: v for k, v in results.items() if v.get("type") == "checkbox"}
            tf_results = {k: v for k, v in results.items() if v.get("type") == "text_field"}
            
            cb_results = _assign_ids_from_reference(cb_results, [r for r in ref if r["id"] < 1000])
            
            # Assign text field IDs from reference if available
            tf_refs = [r for r in ref if r["id"] >= 1000]
            if tf_refs:
                tf_results = _assign_textfield_ids_from_reference(tf_results, tf_refs)

            # Fail if the form cannot be reconciled to the template (i.e. not every
            # checkbox/field in the template was found, or unexpected extras appeared).
            _validate_reconciliation(cb_results, tf_results, ref, form_rev)

            # Re-extract text values using the final (possibly translated) bboxes.
            # Note: tf["page"] now holds the *reference* page number, so map back to
            # the physical page in the document to read the correct text.
            for tf_id, tf in tf_results.items():
                phys = ref_to_phys.get(tf["page"])
                if phys is None:
                    continue
                page = doc[phys - 1]
                words = page.get_text("words") or []
                tf["value"] = _extract_value_for_rect(page, words, tf["x0"], tf["y0"], tf["x1"], tf["y1"])

            results = {**cb_results, **tf_results}
            results = dict(sorted(results.items()))

    return results


def _validate_reconciliation(
    cb_results: Dict[int, dict],
    tf_results: Dict[int, dict],
    ref: list,
    form_rev: str,
) -> None:
    """
    Ensure the detected checkboxes/fields can be fully reconciled to the reference
    template. Raises InputFileError if the form is in a format that cannot be
    matched to the template, i.e. any of the following:
      - a template checkbox was not found in the form,
      - the form contains an unexpected checkbox not present in the template.

    Missing text fields are tolerated (users routinely delete the underscore
    placeholders when filling a field in). Unexpected/extra text fields are also
    tolerated: they are typically user-entered values in "Other: ____" style
    placeholders that are not part of the template. Such fields are dropped (with a
    warning) rather than causing a failure, so only checkboxes are matched strictly.
    """
    ref_cb_ids = {r["id"] for r in ref if r["id"] < 1000}
    ref_tf_ids = {r["id"] for r in ref if r["id"] >= 1000}

    detected_cb_ids = set(cb_results.keys())
    detected_tf_ids = set(tf_results.keys())

    missing_cb = ref_cb_ids - detected_cb_ids
    extra_cb = detected_cb_ids - ref_cb_ids
    extra_tf = detected_tf_ids - ref_tf_ids

    problems = []
    if missing_cb:
        problems.append(
            f"{len(missing_cb)} template checkbox(es) not found in the form "
            f"(ids: {sorted(missing_cb)})"
        )
    if extra_cb:
        problems.append(
            f"{len(extra_cb)} unexpected checkbox(es) detected that do not match the template"
        )
    if extra_tf:
        # Unexpected text fields are tolerated: these are typically user-entered
        # values written into "Other: ____" style placeholders that don't exist in
        # the template. Drop them so they don't propagate, and warn instead of
        # failing the whole reconciliation.
        for _id in sorted(extra_tf):
            dropped = tf_results.pop(_id, None)
            print(
                f"[FORM-1228] Ignoring unexpected text field (id={_id}) not present "
                f"in the template: {dropped.get('label') if dropped else ''!r}"
            )

    if problems:
        raise InputFileError(
            f"FORM-1228 (Revision {form_rev}) could not be reconciled to the template: "
            + "; ".join(problems)
            + "."
        )


def _assign_textfield_ids_from_reference(results: Dict[int, dict], ref_entries: list, threshold: float = 80.0) -> Dict[int, dict]:
    """Reassign text field IDs based on globally optimal matching to reference JSON.
    Matches using the midpoint of the top edge of each bbox via linear_sum_assignment.
    For reference entries with no match (e.g. underscores deleted by user), inserts
    a placeholder entry using the reference bbox directly.
    """
    remapped = {}

    pages = set(tf["page"] for tf in results.values()) | set(r["page"] for r in ref_entries)

    for page_num in pages:
        page_tfs = [(k, v) for k, v in results.items() if v["page"] == page_num]
        page_refs = [r for r in ref_entries if r["page"] == page_num]

        if not page_refs:
            for k, tf in page_tfs:
                fallback = max((r["id"] for r in ref_entries), default=1000) + 1
                while fallback in remapped:
                    fallback += 1
                remapped[fallback] = tf
            continue

        if not page_tfs:
            # No detections on this page — insert all refs as placeholders
            for ref in page_refs:
                b = ref["bbox"]
                remapped[ref["id"]] = {
                    "label": "Comments",
                    "value": "",
                    "page": page_num,
                    "x0": b[0], "y0": b[1], "x1": b[2], "y1": b[3],
                    "type": "text_field",
                }
            continue

        n, m = len(page_tfs), len(page_refs)
        cost = np.full((n, m), fill_value=1e9)
        for i, (_, tf) in enumerate(page_tfs):
            tx = tf["x0"]
            ty = tf["y0"]
            for j, ref in enumerate(page_refs):
                b = ref["bbox"]
                rx = b[0]
                ry = b[1]
                cost[i, j] = ((tx - rx) ** 2 + (ty - ry) ** 2) ** 0.5

        row_ind, col_ind = linear_sum_assignment(cost)

        # As with checkboxes, if the page has exactly as many detected text fields
        # as the template expects, trust the optimal assignment in full (fields may
        # have shifted with content reflow). Otherwise enforce the distance threshold.
        exact_count = (n == m)

        matched_ref_indices = set()
        matched_tf_indices = set()
        for i, j in zip(row_ind, col_ind):
            if exact_count or cost[i, j] <= threshold:
                ref = page_refs[j]
                b = ref["bbox"]
                tf = page_tfs[i][1]
                ref_w = b[2] - b[0]
                ref_h = b[3] - b[1]
                # Translate reference shape to detected top-left corner
                translated = dict(tf)
                translated["x0"] = tf["x0"]
                translated["y0"] = tf["y0"]
                translated["x1"] = tf["x0"] + ref_w
                translated["y1"] = tf["y0"] + ref_h
                remapped[ref["id"]] = translated
                matched_ref_indices.add(j)
                matched_tf_indices.add(i)

        # Unmatched detections get fallback IDs
        for i, (_, tf) in enumerate(page_tfs):
            if i not in matched_tf_indices:
                fallback = max((r["id"] for r in ref_entries), default=1000) + 1
                while fallback in remapped:
                    fallback += 1
                remapped[fallback] = tf

        # Unmatched references get placeholder entries with reference bbox
        for j, ref in enumerate(page_refs):
            if j not in matched_ref_indices:
                b = ref["bbox"]
                remapped[ref["id"]] = {
                    "label": "Comments",
                    "value": "",
                    "page": page_num,
                    "x0": b[0], "y0": b[1], "x1": b[2], "y1": b[3],
                    "type": "text_field",
                }

    return dict(sorted(remapped.items()))

def checkboxes_vs_format(checkboxes_path, format_path):
    with open(checkboxes_path, 'r') as f:
        checkboxes = json.load(f)
    with open(format_path, 'r') as f:
        fmt = json.load(f)

    checkbox_ids = {cb['id'] for cb in checkboxes}

    format_ids = []
    for field in fmt['fields']:
        for option in field['options']:
            format_ids.append(option['id'])

    # Also collect text field IDs stored as integer values in sections
    for section in fmt.get('sections', []):
        for k, v in section.items():
            if k.startswith('text_'):
                format_ids.append(v)

    format_id_counts = Counter(format_ids)

    # IDs used more than once in format
    duplicates = {id_: count for id_, count in format_id_counts.items() if count > 1}
    if duplicates:
        print("⚠️  IDs used more than once in format:")
        for id_, count in sorted(duplicates.items()):
            print(f"   ID {id_} appears {count} times")
    else:
        print("✅ No duplicate IDs in format.")

    # Format IDs that don't exist in checkboxes
    format_id_set = set(format_ids)
    nonexistent = format_id_set - checkbox_ids
    if nonexistent:
        print(f"\n❌ Format references IDs not in checkboxes: {sorted(nonexistent)}")
    else:
        print("✅ All format IDs exist in checkboxes.")

    # Checkbox IDs not used in format
    unused = checkbox_ids - format_id_set
    if unused:
        print(f"\n⚠️  Checkbox IDs not used in format: {sorted(unused)}")
    else:
        print("✅ All checkbox IDs are used in format.")

def _load_reference_ids(json_path: str) -> list:
    with open(json_path, "r") as f:
        return json.load(f)


def _assign_ids_from_reference(results: Dict[int, dict], ref_entries: list, threshold: float = 65.0) -> Dict[int, dict]:
    """Reassign IDs based on globally optimal matching to reference JSON by page + position.
    Uses the Hungarian algorithm to minimize total distance across all pairs."""
    remapped = {}

    # Group detected checkboxes and references by page
    pages = set(cb["page"] for cb in results.values()) | set(r["page"] for r in ref_entries)

    for page_num in pages:
        page_cbs = [(k, v) for k, v in results.items() if v["page"] == page_num]
        page_refs = [r for r in ref_entries if r["page"] == page_num]

        if not page_cbs or not page_refs:
            # No match possible; use fallback IDs
            for k, cb in page_cbs:
                fallback = max((r["id"] for r in ref_entries), default=0) + 1
                while fallback in remapped:
                    fallback += 1
                remapped[fallback] = cb
            continue

        # Build cost matrix: rows = detected, cols = reference
        n, m = len(page_cbs), len(page_refs)
        cost = np.full((n, m), fill_value=1e9)
        for i, (_, cb) in enumerate(page_cbs):
            cx = (cb["x0"] + cb["x1"]) / 2.0
            cy = (cb["y0"] + cb["y1"]) / 2.0
            for j, ref in enumerate(page_refs):
                dx = ref["pos"][0] - cx
                dy = ref["pos"][1] - cy
                cost[i, j] = (dx * dx + dy * dy) ** 0.5

        row_ind, col_ind = linear_sum_assignment(cost)

        # When the page has exactly as many detected checkboxes as the template
        # expects, the optimal assignment is trusted in full (every box is present,
        # it may simply have shifted due to content reflow). The distance threshold
        # is only enforced when the counts differ, so a genuinely missing or extra
        # checkbox is surfaced as an unmatched pair for reconciliation to catch.
        exact_count = (n == m)

        matched_cb_indices = set()
        for i, j in zip(row_ind, col_ind):
            if exact_count or cost[i, j] <= threshold:
                ref_id = page_refs[j]["id"]
                cb_key, cb = page_cbs[i]
                remapped[ref_id] = cb
                matched_cb_indices.add(i)

        # Fallback for unmatched detections
        for i, (_, cb) in enumerate(page_cbs):
            if i not in matched_cb_indices:
                fallback = max((r["id"] for r in ref_entries), default=0) + 1
                while fallback in remapped:
                    fallback += 1
                remapped[fallback] = cb

    return dict(sorted(remapped.items()))


def save_annotated_pages(
    pdf_path: str,
    checkboxes: Dict[int, dict],
    output_dir: str,
    zoom: float = 2.0,
    checked_color: tuple = (0, 200, 0),
    unchecked_color: tuple = (0, 0, 220),
    textfield_color: tuple = (200, 150, 0),
) -> None:
    """
    Render each page with colored bounding boxes and IDs drawn on checkboxes/text fields.
    Green = checked, Red = unchecked, Teal = text field. Saves one PNG per page to output_dir.
    """
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    pages_used = {cb["page"] for cb in checkboxes.values()}

    with fitz.open(pdf_path) as doc:
        for page_num in sorted(pages_used):
            page = doc[page_num - 1]
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            img = _pixmap_to_bgr(pix)

            for cb_id, cb in checkboxes.items():
                if cb["page"] != page_num:
                    continue

                is_tf = cb.get("type") == "text_field"
                if is_tf:
                    color = textfield_color
                else:
                    color = checked_color if cb["checked"] else unchecked_color

                x0 = int(cb["x0"] * zoom)
                y0 = int(cb["y0"] * zoom)
                x1 = int(cb["x1"] * zoom)
                y1 = int(cb["y1"] * zoom)

                cv2.rectangle(img, (x0, y0), (x1, y1), color, 2)

                font = cv2.FONT_HERSHEY_SIMPLEX
                font_scale = 0.55
                text = str(cb_id)
                if is_tf and cb.get("value"):
                    text += f": {cb['value']}"
                (tw, th), _ = cv2.getTextSize(text, font, font_scale, 1)
                cv2.rectangle(img, (x0, y0 - th - 3), (x0 + tw + 2, y0), color, -1)
                cv2.putText(img, text, (x0 + 1, y0 - 2), font, font_scale, (255, 255, 255), 1, cv2.LINE_AA)

            out_file = out_path / f"page_{page_num:03d}_annotated.png"
            cv2.imwrite(str(out_file), img)
            print(f"Saved: {out_file}")


def save_field_annotated_pages(
    pdf_path: str,
    checkboxes: Dict[int, dict],
    format_path: str,
    output_dir: str,
    zoom: float = 2.0,
) -> None:
    """
    Render each page with field-level annotations from the format JSON.
    Each field gets a unique random color. A bounding box surrounds all
    checkboxes in that field, dots mark each checkbox, and the field key is shown.
    """
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    with open(format_path, "r") as f:
        fmt = json.load(f)

    fields = fmt.get("fields", [])
    sections = fmt.get("sections", [])

    # Build a mapping from field key -> section key
    field_to_section = {}
    for section in sections:
        for k, v in section.items():
            if k == "key":
                continue
            if isinstance(v, str):
                field_to_section[v] = section["key"]

    # Generate stable random colors per field key
    rng = random.Random(42)
    field_colors = {}
    for field in fields:
        key = field["key"]
        if key not in field_colors:
            field_colors[key] = (rng.randint(40, 255), rng.randint(40, 255), rng.randint(40, 255))

    # Determine which pages are needed
    pages_used = set()
    for field in fields:
        for opt in field.get("options", []):
            if opt["id"] in checkboxes:
                pages_used.add(checkboxes[opt["id"]]["page"])

    with fitz.open(pdf_path) as doc:
        for page_num in sorted(pages_used):
            page = doc[page_num - 1]
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            img = _pixmap_to_bgr(pix)

            for field in fields:
                # Collect checkbox positions on this page for this field
                pts = []
                for opt in field.get("options", []):
                    cb = checkboxes.get(opt["id"])
                    if cb and cb["page"] == page_num:
                        pts.append(cb)

                if not pts:
                    continue

                color = field_colors[field["key"]]
                pad = 8

                # Bounding box around all checkboxes in field
                fx0 = int(min(p["x0"] for p in pts) * zoom) - pad
                fy0 = int(min(p["y0"] for p in pts) * zoom) - pad
                fx1 = int(max(p["x1"] for p in pts) * zoom) + pad
                fy1 = int(max(p["y1"] for p in pts) * zoom) + pad

                cv2.rectangle(img, (fx0, fy0), (fx1, fy1), color, 2)

                # Dot at each checkbox center
                for p in pts:
                    cx = int((p["x0"] + p["x1"]) / 2 * zoom)
                    cy = int((p["y0"] + p["y1"]) / 2 * zoom)
                    cv2.circle(img, (cx, cy), 4, color, -1)

                # Field key label (top)
                font = cv2.FONT_HERSHEY_SIMPLEX
                font_scale = 0.4
                text = field["key"]
                (tw, th), _ = cv2.getTextSize(text, font, font_scale, 1)
                label_y = max(fy0 - 4, th + 2)
                cv2.rectangle(img, (fx0, label_y - th - 2), (fx0 + tw + 4, label_y + 2), color, -1)
                cv2.putText(img, text, (fx0 + 2, label_y), font, font_scale, (255, 255, 255), 1, cv2.LINE_AA)

                # Section name label (bottom)
                section_name = field_to_section.get(field["key"], "")
                if section_name:
                    sec_text = f"[{section_name}]"
                    (stw, sth), _ = cv2.getTextSize(sec_text, font, font_scale, 1)
                    sec_y = fy1 + sth + 4
                    cv2.rectangle(img, (fx0, sec_y - sth - 2), (fx0 + stw + 4, sec_y + 2), color, -1)
                    cv2.putText(img, sec_text, (fx0 + 2, sec_y), font, font_scale, (255, 255, 255), 1, cv2.LINE_AA)

            out_file = out_path / f"page_{page_num:03d}_fields.png"
            cv2.imwrite(str(out_file), img)
            print(f"Saved: {out_file}")


def checkboxes_to_sections(
    checkboxes: Dict[int, dict],
    form_rev: str,
) -> Dict[str, Dict[str, list]]:
    """
    Convert raw checkbox results into a section/field structure.
    Returns: {"section_name": {"field_name": ["label1", ...], ...}, ...}
    """
    format_path = str(Path(__file__).parent / "form_1228_templates" / f"rev_{form_rev}" / "form_1228_format.json")
    if not Path(format_path).exists():
        raise InputFileError(f"The FORM-1228 Revision {form_rev} is not supported.")

    with open(format_path, "r") as f:
        fmt = json.load(f)

    # Build field key -> list of checked labels
    field_checked = {}
    for field in fmt.get("fields", []):
        labels = []
        for opt in field.get("options", []):
            cb = checkboxes.get(opt["id"])
            if cb and cb["checked"]:
                labels.append(opt["label"])
        field_checked[field["key"]] = labels

    # Map into sections
    result = {}
    for section in fmt.get("sections", []):
        section_key = section["key"]
        section_data = {}
        for attr, field_key in section.items():
            if attr == "key":                                                                               
                continue
            elif attr.startswith("field_"):                                                                                      
                name = attr.removeprefix("field_")
                section_data[name] = field_checked.get(field_key, [])
            elif attr.startswith("text_"):
                name = attr.removeprefix("text_")
                section_data[name] = checkboxes.get(field_key).get("value")
            else: # fixed_symbols, subproduct_symbols, etc.
                section_data[attr] = section.get(attr, [])
        result[section_key] = section_data

    return result


def get_form_data(pdf_source, form_rev: str) -> Dict[str, Dict[str, list]]:
    """
    Driver function: extract checkboxes from a FORM-1228 PDF and return
    the structured sections. The form revision (e.g. "AA") is provided by
    the caller.
    Accepts a file path (str/Path) or a BytesIO/bytes object.
    """
    checkboxes = extract_image_checkboxes_with_text(pdf_source, form_rev, json_ids=True)
    structured = checkboxes_to_sections(checkboxes, form_rev)
    return structured


if __name__ == "__main__":
    sample_pdf = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\EP_CARDIO\form sample\FORM-1228_Nuvision_V2_Translations_Updated_03-10-2026 - signed.pdf"
    # REV AA
    sample_pdf = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\EP_CARDIO\samples\TRUPULSE\FORM-1228_Rev J - signed.pdf"
    # sample_pdf = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\EP_CARDIO\form_templates\FORM-1228_REV Y.pdf"
    sample_pdf = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\EP_CARDIO\form_templates\FORM-1228_REV AA.pdf"
    output_dir = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\EP_CARDIO\form_output"

    form_rev = "AA"
    checkboxes = extract_image_checkboxes_with_text(sample_pdf, form_rev, debug_show=False, json_ids=True)

    print(f"\nRevision: {form_rev}")
    print(f"Total checkboxes found: {sum(1 for cb in checkboxes.values() if cb.get('type') == 'checkbox')}")
    print(f"Total text fields found: {sum(1 for cb in checkboxes.values() if cb.get('type') == 'text_field')}")
    print(f"Checked:   {sum(1 for cb in checkboxes.values() if cb.get('type') == 'checkbox' and cb['checked'])}")
    print(f"Unchecked: {sum(1 for cb in checkboxes.values() if cb.get('type') == 'checkbox' and not cb['checked'])}")
    print()
    for cb_id, cb in checkboxes.items():
        if cb.get("type") == "text_field":
            print(f"[{cb_id:>4}] TF  page={cb['page']}  ({cb['x0']:.1f},{cb['y0']:.1f})-({cb['x1']:.1f},{cb['y1']:.1f})  {cb['label']} = \"{cb.get('value', '')}\"")
        else:
            status = "X" if cb["checked"] else "■"
            print(f"[{cb_id:>4}] {status}  page={cb['page']}  ({cb['x0']:.1f},{cb['y0']:.1f})-({cb['x1']:.1f},{cb['y1']:.1f})  {cb['label']}")

    json_output = []
    for cb_id, cb in checkboxes.items():
        if cb.get("type") == "text_field":
            json_output.append({
                "page": cb["page"],
                "id": cb_id,
                "bbox": [round(cb["x0"], 2), round(cb["y0"], 2), round(cb["x1"], 2), round(cb["y1"], 2)],
                "type": "text_field",
            })
        else:
            json_output.append({
                "page": cb["page"],
                "id": cb_id,
                "pos": [round((cb["x0"] + cb["x1"]) / 2, 2), round((cb["y0"] + cb["y1"]) / 2, 2)],
                "type": "checkbox",
            })
    json_file = Path(output_dir) / "checkboxes.json"
    with open(json_file, "w") as f:
        json.dump(json_output, f, indent=2)
    print(f"Saved: {json_file}")

    save_annotated_pages(sample_pdf, checkboxes, output_dir)

    format_json = str(Path(__file__).parent / "form_1228_templates" / f"rev_{form_rev}" / "form_1228_format.json")
    save_field_annotated_pages(sample_pdf, checkboxes, format_json, output_dir)

    structured = checkboxes_to_sections(checkboxes, form_rev)
    structured_file = Path(output_dir) / "structured_output.json"
    with open(structured_file, "w") as f:
        json.dump(structured, f, indent=2)
    print(f"Saved: {structured_file}")

    table_data = extract_first_page_table(sample_pdf)
    print(json.dumps(table_data, indent=2))

    chk_json = str(Path(__file__).parent / "form_1228_templates" / f"rev_{form_rev}" / "form_1228_checkboxes.json")
    checkboxes_vs_format(chk_json, format_json)