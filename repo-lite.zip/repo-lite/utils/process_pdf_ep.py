import os
from io import BytesIO
import numpy as np
from pathlib import Path
import sys
import re

import cv2
import fitz

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 

from process_pdf import ProcessPDF, ProcessPage, ComparePages
from utils.form_1228 import get_form_data
from utils.utils import Timer, make_json_serializable, split_pdf, validations_append
from utils.blob_storage import write_img, read_pdf, read_file, read_docx
from utils.data import load_manufacturer_address_db
from utils.spatial import is_next_line, find_next_line, expand_bboxes, bbox_inside_bbox_soft


def _parse_humidity_limits(text):
    """
    Parse a free-form humidity-limits text into the matching HUMID limit symbol name.

    The form text has no fixed format (e.g. "10% to 90%", "10 to 90", "10 90"), so we
    just pull the numeric values out and build "LIMIT_HUMID_<lo>_<hi>" (ordered low->high)
    to match how the detector names humidity limit symbols.
    Returns None when fewer than two numbers are present.
    """
    if not text:
        return None
    nums = re.findall(r'\d+\.?\d*', str(text))
    if len(nums) < 2:
        return None
    lo, hi = sorted(nums[:2], key=float)
    return f"LIMIT_HUMID_{lo}_{hi}"


def _parse_pressure_limits(text):
    """
    Parse a free-form atmospheric-pressure-limits text into the matching LIMIT_PRESSURE
    symbol name.

    Like humidity, the form text has no fixed format (e.g. "50 kPa to 106 kPa",
    "500 to 1060 hPa", "50 106"); we just pull the numeric values out, order them low->high
    and build "LIMIT_PRESSURE_<lo>_<hi>" to match how the detector names pressure symbols.
    Returns None when fewer than two numbers are present.
    """
    if not text:
        return None
    nums = re.findall(r'\d+\.?\d*', str(text))
    if len(nums) < 2:
        return None
    lo, hi = sorted(nums[:2], key=float)
    return f"LIMIT_PRESSURE_{lo}_{hi}"


# Human-friendly section titles shown in the UI. Keys are the internal section
# names used to build the 'form_1228' response; values are the display labels.
# Sections missing from this map fall back to a title-cased version of the key.
SECTION_DISPLAY_NAMES = {
    'language_selection': 'Language Selection',
    'gtin': 'GTIN',
    'regulatory_mark': 'CE Mark',
    'corporate_logo': 'Corporate Logo',
    'ec_eu_rep': 'EC/EU Representative',
    'legal_manufacturer': 'Legal Manufacturer',
    'mandatory_symbols': 'Mandatory Symbols',
    'ablation_catheters': 'Ablation and Mapping Catheters',
    'ultrasound_catheters': 'Ultrasound Catheters',
    'vizigo_sheath': 'VIAIGO Sheath',
    'tubing': 'Tubing',
    'preface_sheath': 'Preface Sheath',
    'sterile_cables': 'Sterile Cables',
    'nonsterile_cables': 'Non-Sterile Cables',
    'pumps': 'Pumps',
    'surpoint_epu': 'SURPOINT EPU',
    'generators': 'Generators',
    'regulatory_mark_2': 'Regulatory Mark',
    'manufactured': 'Manufactured',
    'additional_symbols': 'Additional Symbols',
    'optional_symbols': 'Optional Symbols',
}


def section_display_name(name):
    """Return the UI-friendly title for an internal section name, falling back
    to a title-cased version of the key when it is not in SECTION_DISPLAY_NAMES."""
    return SECTION_DISPLAY_NAMES.get(name, (name or '').replace('_', ' ').title())


class ProcessPDF_EP(ProcessPDF):
    def __init__(self, from_path, to_path, form_1288_path, output_folder, document_type, business_unit, mode="local"):
        self.timer = Timer()

        # Placeholder for docx redline and annotations
        self.redline_doc = None
        self.docx_annotations = None
        self.business_unit = business_unit # SURGERY, EP, VISION

        # Execution without form file if not provided
        if not form_1288_path:
            self.formless = True
        else:
            self.formless = False

        # Form data is loaded lazily once the revision is known.
        # form_rev is set externally (e.g. from the UI request) before processing.
        self.form_source = None
        self.form_data = None
        self.form_rev = None

        self.mode = mode
        if mode=='local':
            if to_path:

                # From
                self.from_doc = fitz.open(from_path)

                # To
                self.to_doc = fitz.open(to_path)

            else: # No to_path provided, split the pdf on the fly
                self.from_doc, self.to_doc = split_pdf(from_path)
            if not self.formless:
                # Store the form source; loaded later once form_rev is known
                self.form_source = form_1288_path
            
        elif mode=='blob':
            # From
            if Path(from_path).suffix.lower() == ".docx":
                self.from_doc, self.redline_doc, self.docx_annotations = read_docx(from_path)
            elif Path(from_path).suffix.lower() == ".pdf":
                self.from_doc = read_pdf(from_path)

            # To
            if Path(to_path).suffix.lower() == ".docx":
                self.to_doc, _, _ = read_docx(to_path) # Future should not have revisions
            elif Path(to_path).suffix.lower() == ".pdf":
                self.to_doc = read_pdf(to_path)

            # Form
            if not self.formless:
                # Store the form source; loaded later once form_rev is known
                self.form_source = BytesIO(read_file(form_1288_path))

        # # Load stationary data
        self.load_data()

        # Clean "Sample" watermarks
        for page in self.to_doc:
            for xref in page.get_contents():
                stream = self.to_doc.xref_stream(xref).replace(b'Sample', b'')
                self.to_doc.update_stream(xref, stream)
        for page in self.from_doc:
            for xref in page.get_contents():
                stream = self.from_doc.xref_stream(xref).replace(b'Sample', b'')
                self.from_doc.update_stream(xref, stream)

        # How many pages to process, for debugging
        self.pages = False
        self.startpage = 1

        # Specific pages to process
        self.page_lists = (None, None) # (to_page_list, from_page_list), 1-based indexing

        # Method to use for detecting needle point symbols
        self.np_symbol_method = 'YOLO' # TM for template matching, or YOLO. TM is no longer supported
        self.yolo_weights = "best.pt" # Weights to use if np_symbol_method is YOLO

        # Use OCR on each page
        self.ocr = True

        self.document_type = document_type # Pre-Printed, Thunderbird, IFU comparison or IFU translation

        # Preprinted document. Used to trigger the extraction of RMC
        self.preprinted = document_type=="Pre-Printed" 
        self.ifu_comp = document_type=="IFU comparison" 

        # Store the brand name. Used to determine if code should keep looking for the brand
        self.brand_name = None

        # Bounds for the upper right label when there is a multilabel on the page. False means no multilabel
        self.upper_right_bbox = False

        # Store all detected fonts for debugging
        self.detected_fonts = set([])

        # Create output folder
        if not os.path.exists(output_folder) and self.mode=='local':
            os.makedirs(output_folder)
        self.output_folder = output_folder


        # A dict to return as a response for the API
        self.response = {'pages':[], 'success':True, 
                         "output_folder" : output_folder}

        self.timer.append("ProcessPDF init")

    def load_data(self):
        # Load manufacturer address db
        manu_path = "data/manufacturer_database_ep.csv"
        self.manufacturer_address_db = load_manufacturer_address_db(os.path.join(ROOT_DIR, manu_path))

    def load_form(self):
        # Parse the FORM-1228 using the revision provided from the UI (self.form_rev)
        self.form_data = get_form_data(self.form_source, self.form_rev)

class ProcessPage_EP(ProcessPage):
    def __init__(self, page, page_type="to"):
        super().__init__(page, page_type)
        self.ccn = None # TODO temporary fix to avoid exception in collect_response
    
    def process(self):
        if self.page_type=="from":
            if not self.process_pdf.docx_annotations:
                self.extract_annotations()
            else:
                if self.process_pdf.redline_doc:
                    redline_page = self.process_pdf.redline_doc.load_page(self.page_num)
                    orig_pix = redline_page.get_pixmap(matrix=self.mat)
                    image = np.frombuffer(orig_pix.samples, dtype=np.uint8).reshape(orig_pix.height, orig_pix.width, orig_pix.n)
                    self.images["annotations"] = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                self.annotations = [a for a in self.process_pdf.docx_annotations if a["page"]==self.page_num+1]
        else:
            self.annotations = []
        self.process_pdf.timer.append("extract_annotations")
        self.read_page(self.page)
        self.process_pdf.timer.append("read_page")  
        self.detect_grid()
        self.process_pdf.timer.append("detect_grid")  
        if self.process_pdf.ocr:
            self.run_ocr()
            self.process_pdf.timer.append("run_ocr")
        if self.process_pdf.np_symbol_method == 'YOLO':
            # Symbols that never appear in EP labels and should be ignored
            ignore_symbols = ['NEEDLE']
            self.symbols_yolo(ignore_symbols=ignore_symbols)
            self.process_pdf.timer.append("symbols_yolo") 
        if self.process_pdf.ocr:
            self.cleanup_ocr()
            self.process_pdf.timer.append("cleanup_ocr")
        self.find_addresses()
        self.process_pdf.timer.append("find_addresses")  
        self.find_translations()
        self.process_pdf.timer.append("find_translations")  
        self.decode_barcodes()
        self.process_pdf.timer.append("decode_barcodes")  
        self.validate_barcodes()
        self.process_pdf.timer.append("validate_barcodes")  
        self.form_output = {} # Per-section form_1228 validation results (populated below)
        if not self.process_pdf.formless:
            if self.process_pdf.form_data is None:
                self.process_pdf.load_form()
            self.validate_form()
            self.process_pdf.timer.append("validate_form")
        pass # For debugging breakpoints

    def find_translations(self):
        """
        Detect translation blocks and the languages contained in them.

        Detection starts from a known list of language identifiers
        (KNOWN_LANGUAGES). All the lines of a block are gathered, ordered
        top-to-bottom and joined into a single string, from which the
        {language: text} pairs are extracted.

        Two layout quirks are handled:
        - An identifier may be split across a line break ('zh-' + 'cn:').
        - The last identifier of a block may sit at the end of a line, leaving
          its translated text on the following line, which then holds no
          identifier of its own. That trailing line is still collected.

        Result is stored in self.translation_data as a list of:
            {'languages': {'en': 'Ultrasound Catheter', ...},
             'bbox': [...], 'validations': []}
        """
        # Known translation language identifiers. Expand this list as needed.
        # Note: 'zh-cn' is a single identifier even though it may be split across
        # two lines in the PDF (e.g. 'zh-' ending one line and 'cn:' starting the next).
        KNOWN_LANGUAGES = [
            'en', 'bg', 'id', 'cs', 'da', 'de', 'el', 'es', 'et', 'fi', 'fr',
            'hr', 'hu', 'it', 'ko', 'lt', 'lv', 'nl', 'no', 'pl', 'pt', 'ro',
            'ru', 'sr', 'sk', 'sl', 'sv', 'tr', 'zh-cn', 'uk', 'pt-pt',
            'ja', 'kk', 'pt-br', 'uk', 'zh-tw', 'mk']


        languages = []

        # Build a regex that only matches known identifiers, optionally followed
        # by whitespace before the colon (e.g. 'ru :'). Longest identifiers first
        # so 'zh-cn' wins over any shorter prefix.
        ids = sorted((re.escape(l) for l in KNOWN_LANGUAGES), key=len, reverse=True)
        lang_pattern = re.compile(r'\b(' + '|'.join(ids) + r')\s*:', re.IGNORECASE)

        def n_identifiers(text):
            return len(lang_pattern.findall(text))

        def is_seed(element):
            # A line confident enough to start a block (holds several identifiers)
            return n_identifiers(element['text']) >= 2

        def is_line(element):
            # A line that may extend a block (holds at least one identifier)
            return n_identifiers(element['text']) >= 1

        def has_en(element):
            # Every translation block's first (top) line holds the 'en' identifier,
            # so it anchors the start of the block.
            return bool(re.search(r'\ben\s*:', element['text'], re.IGNORECASE))

        def is_below(a, b):
            # True when line a is directly below line b (a is the next line after b).
            # is_next_line(x, y, mode='bottom') is True when y is the line directly
            # below x, so to test "a is below b" we pass (b, a).
            return is_next_line(b, a, mode='bottom', gap_thresh=20)

        def vertical_overlap(a, b):
            # True when boxes a and b share vertical extent (i.e. sit on the same
            # visual line). Used to gather the pieces of a line that has been split
            # into several boxes.
            ay0, ay1 = a['bbox'][1], a['bbox'][3]
            by0, by1 = b['bbox'][1], b['bbox'][3]
            return ay0 < by1 and by0 < ay1

        def collect_row(anchor_idx):
            # A single visual line of a translation block may be split into several
            # boxes laid out left-to-right. This happens when non-Latin scripts
            # (Japanese, Chinese, Korean, ...) are typeset in a different font and
            # therefore land in their own box, breaking the line into pieces:
            #   '... / ko: ' | '뒤 널 수직' | ' / lt: ... / nl: ...'
            # Starting from the left-anchored piece, chain rightward through boxes
            # that vertically overlap and are horizontally adjacent, so the whole
            # line (identifiers and their translated values) is captured in order.
            row = [anchor_idx]
            visited.add(anchor_idx)
            curr = self.text_data[anchor_idx]
            while True:
                best_j, best_x = None, np.inf
                for j, other in enumerate(self.text_data):
                    if j in visited:
                        continue
                    if not vertical_overlap(curr, other):
                        continue
                    gap = other['bbox'][0] - curr['bbox'][2]
                    # Adjacent piece to the right (small gap; allow tiny overlap).
                    if -20 < gap < 50 and other['bbox'][0] >= curr['bbox'][0]:
                        if other['bbox'][0] < best_x:
                            best_j, best_x = j, other['bbox'][0]
                if best_j is None:
                    break
                row.append(best_j)
                visited.add(best_j)
                curr = self.text_data[best_j]
            return row

        translation_data = []
        all_match_idxs = []
        visited = set()

        for i, element in enumerate(self.text_data):
            # A block starts at its top line: a seed that holds the 'en' identifier.
            if i in visited or not is_seed(element) or not has_en(element):
                continue

            # Walk down from the top line, collecting block lines in reading order.
            # is_below(other, curr) -> other is the line directly below curr.
            # Passing the arguments the other way round (is_below(curr, other))
            # matches lines ABOVE curr, which silently reverses the block.
            #
            # Every line directly below the current one is part of the block,
            # whether or not it carries a language identifier of its own. A line
            # may hold no identifier because a value wraps onto it, or because OCR
            # misread the identifier's colon (e.g. 'ru:' -> 'ru.'), dropping it
            # from the identifier count. Requiring an identifier here would skip
            # such a middle line and silently jump over it to the next identifier
            # line below. is_below already enforces same-column, directly-adjacent
            # lines, so text in other columns (e.g. the WARNING/AVISO notice) is
            # not swept in.
            block_idxs = [i]
            visited.add(i)
            moved = True
            while moved:
                moved = False
                curr = self.text_data[block_idxs[-1]]
                for j, other in enumerate(self.text_data):
                    if j in visited:
                        continue
                    if is_below(other, curr):
                        block_idxs.append(j)
                        visited.add(j)
                        moved = True
                        break


            # block_idxs holds the left-anchored line of each row, top-to-bottom.
            # Each of those rows may be split into several boxes (e.g. by a CJK
            # value in a different font), so expand every anchor into its full row,
            # left-to-right, to build the true reading order.
            ordered_idxs = []
            for anchor in block_idxs:
                ordered_idxs.extend(collect_row(anchor))

            # Concatenate the block into a single string, re-joining identifiers
            # split across lines (e.g. 'zh-' + 'cn:' -> 'zh-cn:')
            block_text = ''
            bbox = [np.inf, np.inf, -np.inf, -np.inf]
            for idx in ordered_idxs:
                t = self.text_data[idx]['text']
                if block_text.endswith('-'):  # e.g. 'zh-' + 'cn: ...' -> 'zh-cn: ...'
                    block_text += t.lstrip()
                else:
                    block_text += ' ' + t
                bbox = expand_bboxes(bbox, self.text_data[idx]['bbox'])

            # Parse the languages and their text (value = text up to the next identifier)
            languages = {}
            ms = list(lang_pattern.finditer(block_text))
            for n, m in enumerate(ms):
                lang = m.group(1).lower()
                start = m.end()
                end = ms[n + 1].start() if n + 1 < len(ms) else len(block_text)
                value = block_text[start:end].strip().strip('/').strip()
                languages[lang] = value

            translation_data.append({
                'languages': languages,
                'bbox': bbox,
                'validations': []
            })
            all_match_idxs.extend(ordered_idxs)

        # Remove the detected lines from text_data
        for del_i in sorted(set(all_match_idxs), reverse=True):
            del self.text_data[del_i]

        # Flag any leftover boxes inside a detected block so they are not
        # later treated as generic text
        for item in translation_data:
            for element in self.text_data:
                if bbox_inside_bbox_soft(element['bbox'], item['bbox']):
                    validations_append(element, 'translation_error')

        self.translation_data = translation_data

    def validate_form(self):
        # Detected symbols on this (future) label. A physical symbol may satisfy
        # more than one section (e.g. EC_REP appears in both ec_eu_rep and
        # regulatory_mark_2), so matches are not consumed across sections.
        symbol_data = self.symbol_data
        self.form_output = {}
        form_output = self.form_output
        form_data = self.process_pdf.form_data
        missing_symbols = []

        # Symbols whose name carries a trailing quantity/variant suffix, e.g.
        # 'PIN_CONNECTOR_25', 'STACK_LIMIT_12', 'CURVE_TYPE_D'. For these the base
        # can be present while the suffix (quantity / variant) is wrong, which is
        # reported as an 'incorrect_*' error rather than a plain 'missing_*' one.
        QUANT_BASES = ['PIN_CONNECTOR', 'PCB_CONNECTOR', 'CURVE_TYPE', 'STACK_LIMIT', 'N_PC']

        def split_quant(name):
            """Split a symbol name into (base, suffix) for quantitative symbols
            (e.g. 'PIN_CONNECTOR_25' -> ('PIN_CONNECTOR', '25')). Returns
            (None, None) for a plain symbol."""
            name = name or ''
            for base in QUANT_BASES:
                if name == base:
                    return base, ''
                if name.startswith(base + '_'):
                    return base, name[len(base) + 1:]
            return None, None

        def incorrect_error(base):
            # CURVE_TYPE variant mismatch -> 'incorrect_CURVE_TYPE'; quantity
            # mismatches (pins, stacking, ...) -> 'incorrect_qty_<BASE>'.
            if base == 'CURVE_TYPE':
                return 'incorrect_CURVE_TYPE'
            return f'incorrect_qty_{base}'

        def init_section(name, status=True):
            """Create (once) the per-section output holder used to build the
            'form_1228' response entry: expected values, errors and the bboxes
            (with Match/Mismatch status) of the relevant label elements. Every
            section also carries the free-text 'comments' captured from the form
            (empty string when the section has no comment field or it is blank)."""
            comments = form_data.get(name, {}).get('comments') or ''
            form_output.setdefault(name, {'name': section_display_name(name), 'status': status, 'expected': [], 'errors': [], 'boxes': [], 'comments': comments})
            return form_output[name]

        def add_box(out, bbox, status):
            out['boxes'].append({'bbox': bbox, 'status': status})

        def find_symbol(pred):
            for i, s in enumerate(symbol_data):
                if pred(s):
                    return i
            return None

        def find_symbols(pred):
            """Like find_symbol but returns every matching index so that
            duplicate occurrences of the same symbol are all boxed."""
            return [i for i, s in enumerate(symbol_data) if pred(s)]

        def number_right_of(sym_bbox, expected):
            """True when a text box to the right of a symbol holds the expected number
            (e.g. ELECTRODES_EA '4', SPACING_mm '1-7-4 mm'). Comparison keeps digits and
            dashes only, dropping units/spaces so '1-7-4 mm' matches '1-7-4'."""
            def norm(s):
                s = re.sub(r'(?i)mm', '', str(s or ''))
                return re.sub(r'[^0-9\-]', '', s)
            expected_norm = norm(expected)
            if not expected_norm:
                return None  # nothing to compare against
            found, _ = find_next_line({'bbox': sym_bbox}, self.text_data, thresh=25, mode='right')
            return bool(found) and norm(found['text']) == expected_norm

        def check_symbols(section_symbols, number_checks=None):
            number_checks = number_checks or {}
            out = form_output[section_name]
            for sym in section_symbols:
                out['expected'].append(sym)
                base, _ = split_quant(sym)
                # Exact match (plain symbol, or quantitative symbol with the
                # correct suffix) -> Match box.
                idxs = find_symbols(lambda s, sym=sym: s['symbol_name'] == sym)
                if idxs:
                    for idx in idxs:
                        add_box(out, symbol_data[idx]['bbox'], 'Match')
                    # Some symbols carry a number to their right that must match the form
                    # (ELECTRODES_EA, SPACING_mm on rev AA). Verify it on every occurrence.
                    if sym in number_checks:
                        for idx in idxs:
                            ok = number_right_of(symbol_data[idx]['bbox'], number_checks[sym])
                            if ok is False:
                                out['status'] = False
                                out['errors'].append(f'incorrect_number_{sym}')
                    continue
                # Quantitative symbol whose base is present but suffix differs
                # -> incorrect quantity/variant (Mismatch box + specific error).
                if base is not None:
                    idx = find_symbol(lambda s, base=base: split_quant(s['symbol_name'])[0] == base)
                    if idx is not None:
                        add_box(out, symbol_data[idx]['bbox'], 'Mismatch')
                        out['status'] = False
                        out['errors'].append(incorrect_error(base))
                        continue
                # Not found at all -> missing symbol (no box to draw).
                out['status'] = False
                out.setdefault('missing_symbols', []).append(sym)
                out['errors'].append(f'missing_symbol_{sym}')
                missing_symbols.append(sym)

        def symbol_left_of(sym_bbox, addr_bbox, orientation=0):
            """True when a symbol sits to the reading-"left" of an address block.

            "Left" is relative to the text's reading direction, so it maps to a different
            page direction for each orientation (the address carries this orientation from
            find_addresses):
                0   -> symbol to the left  (smaller x), vertical overlap
                90  -> symbol above        (smaller y), horizontal overlap
                180 -> symbol to the right (larger x),  vertical overlap
                270 -> symbol below        (larger y),  horizontal overlap
            The symbol center must be past the address' reading-start edge (small tolerance
            into the block) and overlap the block on the perpendicular axis."""
            sx1, sy1, sx2, sy2 = sym_bbox
            ax1, ay1, ax2, ay2 = addr_bbox
            sym_cx = (sx1 + sx2) / 2
            sym_cy = (sy1 + sy2) / 2
            aw = ax2 - ax1
            ah = ay2 - ay1
            tol = 0.2  # allow the symbol center to sit slightly inside the block
            horizontal_overlap = min(sx2, ax2) - max(sx1, ax1) > 0
            vertical_overlap = min(sy2, ay2) - max(sy1, ay1) > 0
            if orientation == 90:
                return sym_cy <= ay1 + ah * tol and horizontal_overlap
            if orientation == 180:
                return sym_cx >= ax2 - aw * tol and vertical_overlap
            if orientation == 270:
                return sym_cy >= ay2 - ah * tol and horizontal_overlap
            # Default / upright (orientation == 0)
            return sym_cx <= ax1 + aw * tol and vertical_overlap

        def check_addresses(section_addresses, required_symbol=None):
            out = form_output[section_name]
            for form_address in section_addresses:
                out['expected'].append(form_address)
                matches = [a for a in self.address_data if a['name'] == form_address]
                if not matches:
                    out['status'] = False
                    out.setdefault('missing_symbols', []).append(form_address)
                    out['errors'].append(f'missing_address_{form_address}')
                    missing_symbols.append(form_address)
                else:
                    for m in matches:
                        ignored_errors = ['address_space_error', 'address_db_data_error', 'fontsize_small_error'] 
                        has_error = any('error' in v and v not in ignored_errors for v in m.get('validations', []))
                        add_box(out, m['bbox'], 'Mismatch' if has_error else 'Match')
                        if has_error:
                            out['status'] = False
                            out['errors'].append(f'address_error_{form_address}')
                # The address must be accompanied by its symbol (EC_REP/EU_REP,
                # MANUFACTURER, ...) placed to the left of the address block.
                if required_symbol:
                    out['expected'].append(required_symbol)
                    if matches:
                        idxs = find_symbols(lambda s, sym=required_symbol, ms=matches:
                                            s['symbol_name'] == sym
                                            and any(symbol_left_of(s['bbox'], m['bbox'], m.get('orientation', 0)) for m in ms))
                    else:
                        idxs = find_symbols(lambda s, sym=required_symbol: s['symbol_name'] == sym)
                    if idxs:
                        for idx in idxs:
                            add_box(out, symbol_data[idx]['bbox'], 'Match')
                    else:
                        out['status'] = False
                        out.setdefault('missing_symbols', []).append(required_symbol)
                        out['errors'].append(f'missing_symbol_{required_symbol}')
                        missing_symbols.append(required_symbol)

        def process_gtin_input(text: str) -> dict:
            """
            Parse a GTIN text field into a dict of {identifier: gtin}.
            
            Handles:
            - Single GTIN with no identifier: '10846835026566' -> {'': '10846835026566'}
            - Multiple labeled GTINs: 'L-1423-02-S-12: 10846835026566 L-1426-02-S-12: 10846835026559'
            -> {'L-1423-02-S-12': '10846835026566', 'L-1426-02-S-12': '10846835026559'}
            """
            import re
            text = (text or '').strip()
            if not text:
                return None

            # Match pairs of <identifier>: <gtin>
            # Identifier: anything that is not a colon or whitespace
            # GTIN: sequence of digits
            pairs = re.findall(r'(\S+?)\s*:\s*(\d+)', text)
            if pairs:
                for identifier, gtin in pairs:
                    for t in self.text_data:
                        if identifier in t['text']:
                            return gtin

            # Fallback: single bare GTIN (digits only, possibly with spaces stripped)
            bare = re.fullmatch(r'\d+', text.strip())
            if bare:
                return text.strip()
            
            return None

        # P2 Language selection
        section_name = 'language_selection'
        section = form_data[section_name]
        languages = []
        std_lan = [ "en", "es", "id", "no", "sl", "bg", "et", "it", 
                    "pl", "sr", "cs", "fi", "ko", "pt", "sv", "da", 
                    "fr", "lt", "ro", "tr", "de", "hr", "lv", "ru", 
                    "uk", "el", "hu", "nl", "sk", "zh-cn"]
        
        if 'All Standard Languages' in section['main']:
            languages.extend(std_lan)
        elif 'Specific Languages' in section['main']:
            languages.extend(section['standard_languages'])
        languages.extend(section['optional_languages'])
        
        out = init_section(section_name)
        out['expected'].extend(languages)
        # Every translation block must contain all the expected languages. A block
        # missing any expected language is a Mismatch, so each block is checked
        # individually (rather than pooling the languages across all blocks).
        all_missing = set()
        for trans in self.translation_data:
            present = set(trans['languages'].keys())
            block_missing = [lang for lang in languages if lang not in present]  # TODO handle pt-br & pt-pt
            add_box(out, trans['bbox'], 'Mismatch' if block_missing else 'Match')
            all_missing.update(block_missing)
        for lang in languages:  # keep expected order in the reported errors
            if lang in all_missing:
                out['status'] = False
                out.setdefault('missing_symbols', []).append(lang)
                out['errors'].append(f'missing_language_{lang}')
                missing_symbols.append(lang)
        
        # P4 ePIL
        # not implemented because of lack of samples tat are not N/A

        # P4 GTIN verification in codes
        section_name = 'gtin'
        section = form_data[section_name]
        gtin = process_gtin_input(section['gtins'])
        out = init_section(section_name)
        if 'N/A' not in section['type']: # If GTIN is applicable
            for code_type in section['type']:
                # Expected string shown in the UI, e.g. '10846835033588_DATAMATRIX'
                expected_str = f"{gtin}_{code_type.upper()}" if gtin else code_type.upper()
                out['expected'].append(expected_str)
                matches = [b for b in self.barcodes
                           if b['type'] == code_type and gtin and gtin in (b['decoded'] or '')]
                if matches:
                    for m in matches:
                        add_box(out, m['bbox'], 'Match')
                else:
                    out['status'] = False
                    out['errors'].append(f'missing_{code_type.upper()}')

        # P5 UKCA and CE Mark      
        section_name = 'regulatory_mark'
        section = form_data[section_name]
        section_main = section['main']
        unmarked_options = ['US', 'CANADA', 'OUS', 'N/A', 'Not CE Marked']
        marks = []
        for option in section_main:
            if option not in unmarked_options:
                if option == 'CE_OEM':
                    option = 'CE_' + section['ce_oem_nb']
                elif option == 'UKCA_OEM':
                    option = 'UKCA_' + section['ukca_oem_nb']
                marks.append(option)            
        init_section(section_name)
        check_symbols(marks)

        # P7 Corp. Logo
        section_name = 'corporate_logo'
        section = form_data[section_name]
        logos = list(section['main'])
        section_symbols = []
        
        for logo in logos:
            if logo not in ['OEM']: # Ignore OEM as there is no logo to check for it
                section_symbols.append(logo)

        init_section(section_name)
        check_symbols(section_symbols)

        # P6 EC/EU Representative
        section_name = 'ec_eu_rep'
        section = form_data[section_name]
        if 'Label' in section['label_ifu'] and 'N/A' not in section['main']:
            init_section(section_name)
            addresses = ['EU Representative']
            # The form selects EC_REP or EU_REP; that symbol must sit left of the address.
            rep_symbol = next((s for s in section['main'] if s in ('EC_REP', 'EU_REP')), None)
            check_addresses(addresses, required_symbol=rep_symbol)

        # P7 Legal Manufacturer
        section_name = 'legal_manufacturer'
        section = form_data[section_name]
        if 'Label' in section['label_ifu']:
            init_section(section_name)
            addresses = (op for op in section['main'] if op not in ['User Manual / IFU', 'Other'])
            # The MANUFACTURER symbol must sit to the left of the address block.
            check_addresses(addresses, required_symbol='MANUFACTURER')

        # P8 MANDATORY SYMBOLS
        section_name = 'mandatory_symbols'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        
        for temp in section['temp']:
            if temp not in ['Other', 'N/A to IFUs']:
                section_symbols.append(temp)

        if section['n_pc']:
            sym = 'N_PC_' + section['n_pc'] 
            section_symbols.append(sym)

        init_section(section_name)
        check_symbols(section_symbols)

        # P9 Ablation and Mapping Catheters
        section_name = 'ablation_catheters'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:
            for sym in section['connector_symbol']:
                if sym in ['PIN_CONNECTOR', 'PCB_CONNECTOR']:
                    if sym == 'PIN_CONNECTOR':
                        sym = 'PIN_CONNECTOR_' + section['pin_qty'] 
                    section_symbols.append(sym)

            if section['curve_type']:
                sym = 'CURVE_TYPE_' + section['curve_type']
                section_symbols.append(sym)

            init_section(section_name)
            # On rev AA the ELECTRODES_EA and SPACING_mm symbols carry a number to their
            # right (electrode count / spacing) that must match the form's text fields.
            number_checks = {}
            if self.process_pdf.form_rev == 'AA':
                number_checks = {
                    'ELECTRODES_EA': section.get('electrodes_ea'),
                    'SPACING_mm': section.get('spacing_mm'),
                }
            check_symbols(section_symbols, number_checks=number_checks)


        # P10 Ultrasound Catheters
        section_name = 'ultrasound_catheters'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:
            humid_sym = _parse_humidity_limits(section.get('humidity_limits'))
            if humid_sym:
                section_symbols.append(humid_sym)
            init_section(section_name)
            check_symbols(section_symbols)

        # P10 VIZIGO Sheath
        section_name = 'vizigo_sheath'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:
            if section['pin_qty']:
                sym = 'PIN_CONNECTOR_' + section['pin_qty'] 
                section_symbols.append(sym)
            init_section(section_name)
            check_symbols(section_symbols)

        # P11 Tubing
        section_name = 'tubing'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:
            init_section(section_name)
            check_symbols(section_symbols)

        # P11 Preface Sheath
        section_name = 'preface_sheath'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        
        section_symbols.extend(section['symbols']) # Append selectable symbols: ANTERIOR, POSTERIOR, etc.

        if section['use']:
            init_section(section_name)
            check_symbols(section_symbols)
        
        # P12 Sterile Cables
        section_name = 'sterile_cables'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:            
            if section['pin_qty']:
                sym = 'PIN_CONNECTOR_' + section['pin_qty'] 
                section_symbols.append(sym)
            init_section(section_name)
            check_symbols(section_symbols)

        # P12 Non-Sterile Cables and Patches
        section_name = 'nonsterile_cables'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:
            if section['pin_qty']:
                sym = 'PIN_CONNECTOR_' + section['pin_qty'] 
                section_symbols.append(sym)
            humid_sym = _parse_humidity_limits(section.get('humidity_limits'))
            if humid_sym:
                section_symbols.append(humid_sym)
            init_section(section_name)
            check_symbols(section_symbols)

        # P13 Pumps
        section_name = 'pumps'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:
            if section['stacking_number']:
                sym = 'STACK_LIMIT_' + section['stacking_number'] 
                section_symbols.append(sym)
            humid_sym = _parse_humidity_limits(section.get('humidity_limits'))
            if humid_sym:
                section_symbols.append(humid_sym)
            pressure_sym = _parse_pressure_limits(section.get('pressure_limits'))
            if pressure_sym:
                section_symbols.append(pressure_sym)
            init_section(section_name)
            check_symbols(section_symbols)

        # P13 SURPOINT EPU
        section_name = 'surpoint_epu'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        if section['use']:
            init_section(section_name)
            check_symbols(section_symbols)

        # P14 Generators
        section_name = 'generators'
        section = form_data[section_name]
        section_symbols = list(section['fixed_symbols'])
        # Append selectable symbols
        section_symbols.extend(section['pedal_symbol']) 
        section_symbols.extend(section['on_off_symbol']) 
        # if trupulse:
        #     section_symbols.extend(['0003 - Alternating Current', 'IP21']) 
        # if NGEN_GENERATOR:
        #     section_symbols.extend(['F', 'INDIF_ELECTRODE']) 
        if section['use']:
            humid_sym = _parse_humidity_limits(section.get('humidity_limits'))
            if humid_sym:
                section_symbols.append(humid_sym)
            pressure_sym = _parse_pressure_limits(section.get('pressure_limits'))
            if pressure_sym:
                section_symbols.append(pressure_sym)
            init_section(section_name)
            check_symbols(section_symbols)

        # P16 REGULATORY
        section_name = 'regulatory_mark_2'
        section = form_data[section_name]
        section_symbols = []
        if 'MDR' in section['type']:
            section_symbols.extend(section['mdr'])
        if 'UKCA' in section['type']:
            section_symbols.append('GB_REP')
        init_section(section_name)
        check_symbols(section_symbols)

        # P16 MANUFACTURED
        section_name = 'manufactured'
        section = form_data[section_name]
        section_symbols = list(section['symbols'])
        init_section(section_name)
        check_symbols(section_symbols)

        # P17 Addtional Symbols
        section_name = 'additional_symbols'
        section = form_data[section_name]
        section_symbols = list(section['symbols'])
        # Rev AA adds a China RoHS selection (additional_symbols_china_rohs). Append the
        # selected symbol; for the plain 'CHINA_ROHS' option the environmental-protection-use
        # period number lives in a text field and is appended to the symbol name
        # (e.g. 'CHINA_ROHS' + '25' -> 'CHINA_ROHS_25').
        for china_rohs in section.get('china_rohs', []):
            if china_rohs == 'CHINA_ROHS':
                number = re.sub(r'\D', '', section.get('china_rohs_number') or '')
                if number:
                    china_rohs = 'CHINA_ROHS_' + number
            section_symbols.append(china_rohs)
        init_section(section_name)
        check_symbols(section_symbols)

        # P18 Optional Symbols
        section_name = 'optional_symbols'
        section = form_data[section_name]
        section_symbols = list(section['symbols'])
        if 'OD_USE' in section_symbols: # OD_USE is not a symbol, but if that box is marked, the symbol comes in another field
            section_symbols.remove('OD_USE') 
            section_symbols.extend(section['od_symbols'])
        init_section(section_name)
        check_symbols(section_symbols)

        

class ComparePages_EP(ComparePages):
    def __init__(self, from_page, to_page):
        super().__init__(from_page, to_page)

    def compare(self):
        #self.compare_dimensions() # Disabled as per business requirement
        self.auto_align()
        self.process_pdf.timer.append("auto_align")
        self.compare_images('original')
        self.process_pdf.timer.append("compare_images")
        self.compare_images('no_text')
        self.process_pdf.timer.append("compare_images")
        self.compare_symbols()
        self.process_pdf.timer.append("compare_symbols")
        self.compare_barcodes()
        self.process_pdf.timer.append("compare_barcodes")
        self.compare_generic_text()
        self.process_pdf.timer.append("compare_generic_text")
        # self.compare_translations()
        # self.process_pdf.timer.append("compare_translations")
        self.compare_addresses()
        self.process_pdf.timer.append("compare_addresses")
        self.collect_response()
        self.process_pdf.timer.append("collect_response")
        self.draw_changes()
        self.process_pdf.timer.append("draw_changes")
        pass # For debugging breakpoints
    
    
    def collect_response(self):
        response = {}

        response["success"] = True
        response["error_message"] = ''


        response["CCN"] = {"from":'Page'+str(self.to_page.page_num + 1),
                           "to":'Page'+str(self.to_page.page_num + 1)}
        
        response["page_num"] = self.to_page.page_num + 1

        # Symbol comparison
        response["symbol_comparison"] = self.symbol_comparison

        # Barcode comparison
        response["barcode_comparison"] = self.barcode_comparison
        
        # Text comparison
        response["text_comparison"] = self.text_comparison

        # # Translation comparison
        # response["translation_comparison"] = self.translation_comparison

        # # Address comparison
        response["address_comparison"] = self.address_comparison

        # Form 1228 validation (section-level table + boxes to draw on the label)
        form_output = getattr(self.to_page, 'form_output', None) or {}
        form_1228 = []
        for section_name, data in form_output.items():
            form_1228.append({
                'section_name': data.get('name', ''),
                'expected': data.get('expected', []),
                'errors': data.get('errors', []),
                'status': 'Match' if data.get('status', True) else 'Mismatch',
                'boxes': data.get('boxes', []),
                'comments': data.get('comments', ''),
            })
        response["form_1228"] = form_1228

        if self.from_page.annotations:
            response['annotations'] = self.from_page.annotations

        self.response = make_json_serializable(response)
