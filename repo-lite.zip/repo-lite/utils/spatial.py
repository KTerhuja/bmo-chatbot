import cv2
import numpy as np
from scipy.spatial import distance
from scipy.optimize import minimize

def match_points(set1, set2, dist_thresh=1400, moved_thresh=60, method='distance'):
    """
    This tries to match pairs of points from one set to the other.
    method:
    -distance: calculate the distance for all combinations and start making pairs from the shortest one.
    -translation_continuous: Same as above, but first find the optimal translation to overlap the points,
        this is to avoid "swapping" pairs when they are translated between labels
    -translation_discrete: Same as above, but only consider translations that overlap one pair perfectly.
        This is also to avoid swapping but works best for when the number of points is different between sets

    dist_thresh: pairs separated more than this will not be considered (will be added/deleted)
    moved_thresh: pairs separated more thna this will be "Moved"

    returns:

    matches: list of pairs of indices for the matches (Same/Moved)
    removed: list of non-matches in set1 
    added: list of non-matches in set2
    moved: indices of the matches returned list that are moved (based on moved_thresh)
    """
    if not set1 and not set2:
        return [], [], [], []
    elif not set1:
        return [], [], list(range(len(set2))), []
    elif not set2:
        return [], list(range(len(set1))), [], []

    points1 = np.array(set1)
    points2 = np.array(set2)

    if method == 'distance':
        # Use original simple distance-based matching
        dist_matrix = distance.cdist(points1, points2, 'euclidean')
        dist_matrix[dist_matrix > dist_thresh] = np.inf
    elif method == 'translation_continuous':
        # Find points that are within dist_thresh of any point in the other set
        initial_dist = distance.cdist(points1, points2, 'euclidean')
        valid_points1 = np.any(initial_dist <= dist_thresh, axis=1)
        valid_points2 = np.any(initial_dist <= dist_thresh, axis=0)
        
        # Only optimize translation for valid points
        opt_points1 = points1[valid_points1]
        opt_points2 = points2[valid_points2]
        
        if len(opt_points1) > 0 and len(opt_points2) > 0:
            def objective(translation):
                translated_points = opt_points2 + translation.reshape(1, 2)
                distances = distance.cdist(opt_points1, translated_points, 'euclidean')
                min_distances = np.minimum(distances, dist_thresh)
                return np.sum(min_distances**2) + 0.5 * np.sum(translation**2)

            # Find optimal translation
            result = minimize(objective, np.zeros(2), method='Nelder-Mead')
            optimal_translation = result.x
            
            # Apply translation to all points in set2
            translated_points2 = points2 + optimal_translation.reshape(1, 2)
        else:
            translated_points2 = points2

        # Calculate final distance matrix
        dist_matrix = distance.cdist(points1, translated_points2, 'euclidean')
        dist_matrix[dist_matrix > dist_thresh] = np.inf

    elif method == 'translation_discrete':
        # Find points that are within dist_thresh of any point in the other set
        initial_dist = distance.cdist(points1, points2, 'euclidean')
        valid_points1 = np.any(initial_dist <= dist_thresh, axis=1)
        valid_points2 = np.any(initial_dist <= dist_thresh, axis=0)
        
        # Only optimize translation for valid points
        opt_points1 = points1[valid_points1]
        opt_points2 = points2[valid_points2]

        if len(opt_points1) > 0 and len(opt_points2) > 0:
            axis = 1 if len(opt_points1) < len(opt_points2) else 0
            best_fit = np.inf
            for p1 in opt_points1:
                for p2 in opt_points2:
                    translation = p1 - p2
                    # Apply translation to all points in set2
                    translated_points2 = points2 + translation.reshape(1, 2)                
                    distances = distance.cdist(opt_points1, translated_points2, 'euclidean')
                    # min_distances_sum = np.sum(np.minimum(distances, dist_thresh))
                    min_distances_sum = np.sum(np.min(distances, axis=axis))# + np.linalg.norm(translation)
                    if min_distances_sum < best_fit:
                        best_fit = min_distances_sum
                        optimal_translation = translation
            translated_points2 = points2 + optimal_translation.reshape(1, 2)
        else:
            translated_points2 = points2

        # Calculate final distance matrix
        dist_matrix = distance.cdist(points1, translated_points2, 'euclidean')
        dist_matrix[dist_matrix > dist_thresh] = np.inf

    # Perform matching
    matches = []
    moved = []
    working_matrix = dist_matrix.copy()

    while np.min(working_matrix) < np.inf:
        i, j = np.unravel_index(np.argmin(working_matrix, axis=None), working_matrix.shape)
        matches.append((i, j))
        # Calculate movement using original points
        original_dist = distance.euclidean(points1[i], points2[j])
        moved.append(original_dist > moved_thresh)
        working_matrix[i,:] = np.inf
        working_matrix[:,j] = np.inf

    removed = set(range(len(set1))).difference([m[0] for m in matches])
    added = set(range(len(set2))).difference([m[1] for m in matches])

    return matches, removed, added, moved

def auto_align_pages(from_image, to_image, scale=1.0, coarse_scale=0.25,
                     max_shift_frac=0.3, canny_thresh=(50, 150), edge_dilate=1,
                     refine_radius=None):
    """
    Estimate the global translation that best aligns ``to_image`` onto
    ``from_image`` and return it as an alignment vector.

    Why this is needed
    ------------------
    Down the pipeline every element movement is measured by directly subtracting
    a ``to`` page coordinate from a ``from`` page coordinate, i.e. the two pages
    are implicitly aligned by their top-left corner (the pixmap origin). When the
    current and future artwork are not perfectly registered inside the page - or
    when the two pages have slightly different dimensions - this top-left
    assumption shifts *every* element and inflates the measured movement. The
    vector returned here is added to every ``to`` coordinate so that distances are
    measured between truly corresponding positions.

    Approach (edge-based, zero-padded, coarse-to-fine GLOBAL cross-correlation)
    --------------------------------------------------------------------------
    Three ideas make this robust on real labels:

    * EDGES, not fill. The score is computed on Canny *edges* (outlines) rather
      than on filled-in content. A solid block then only contributes its outline,
      so large filled shapes can't dominate the match - what we really care about
      is that the outlines line up.
    * ZERO-PADDING / slide out of bounds. ``from`` is padded with a zero border of
      ``max_shift`` pixels and the *full* ``to`` edge map is slid across it with
      ``cv2.matchTemplate``. Nothing is cropped off ``to``; when it slides past the
      border it simply overlaps the zero padding (which matches nothing). This
      removes the previous "is the leftover margin big enough?" limitation - the
      whole image can shift by up to ``max_shift`` either way without losing the
      border/frame content that anchors the match.
    * ONLY MATCHING CONTENT counts. We use raw cross-correlation of the binary edge
      maps (``TM_CCORR``), whose value at a given offset is simply the number of
      *coincident* edge pixels. Edges that exist in only one page (content outside
      the label, elements present in one image only, mis-registered extras) have no
      counterpart to coincide with, so they contribute nothing and cannot pull the
      result - only shared structure is optimised, and the dominant shared
      structure (the label itself) wins.

    The score surface on sharp, high-contrast labels is very bumpy (many local
    maxima), so we evaluate *every* offset in the window rather than hill-climbing
    from (0, 0) (which would get stuck and wrongly report "already aligned"):
    a cheap GLOBAL search on a heavily down-scaled copy (``coarse_scale``) finds the
    basin, then a small GLOBAL search at the working resolution (``scale``) makes it
    pixel-accurate. The window is kept local (``max_shift_frac`` of the page) so a
    grid of repeated labels cannot reach and snap onto a neighbouring label.

    Args:
        from_image:   BGR or grayscale image of the ``from`` (current) page.
        to_image:     BGR or grayscale image of the ``to`` (future) page.
        scale:        Down-scale factor for the fine pass. ``1.0`` uses the same
                      resolution already used elsewhere in the pipeline. Lower it
                      (e.g. 0.5) to trade accuracy for speed. Exposed as a
                      parameter so the impact of different scales can be evaluated.
        coarse_scale: Extra down-scale applied on top of ``scale`` for the initial
                      global pass. Set to ``None`` (or 1.0) to skip the coarse pass
                      and search globally straight at the working resolution.
        max_shift_frac: Maximum search shift on each axis as a fraction of the
                      page size. Keeps the search local.
        canny_thresh: (low, high) hysteresis thresholds for the Canny edge detector.
        edge_dilate:  Dilate the edges by this many pixels before matching. A small
                      dilation (1px) gives the correlation a little slack so nearly
                      coincident outlines still register, broadening the peak and
                      making it robust to sub-pixel / round-off misregistration.
        refine_radius: Half-window (in working-scale px) for the fine refine pass.
                      Defaults to enough to cover the coarse quantisation error.

    Returns:
        (dx, dy): Integer alignment vector expressed in the *input* image pixels
                  (the same units as element centers/bboxes). Add it to a ``to``
                  page coordinate to bring it into the ``from`` page frame:
                  ``aligned_to_center = (to_center[0] + dx, to_center[1] + dy)``.
                  Returns ``(0, 0)`` when no alignment can be computed or when an
                  image is missing.
    """
    if from_image is None or to_image is None:
        return (0, 0)

    def edge_mask(image, s):
        """Down-scale and return a float32 binary Canny-edge (outline) map."""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
        if s != 1.0:
            gray = cv2.resize(gray, (0, 0), fx=s, fy=s, interpolation=cv2.INTER_AREA)
        edges = cv2.Canny(gray, canny_thresh[0], canny_thresh[1])
        if edge_dilate:
            k = np.ones((2 * edge_dilate + 1, 2 * edge_dilate + 1), np.uint8)
            edges = cv2.dilate(edges, k)
        return (edges > 0).astype(np.float32)

    def global_shift(a, b, max_shift):
        """
        GLOBAL best integer shift (ox, oy) that aligns ``b`` onto ``a``, found by
        sliding the *full* ``b`` edge map across a zero-padded ``a`` and taking the
        offset with the most coincident edges (raw ``TM_CCORR``). Exhaustive, so it
        cannot be trapped by local maxima; edges present in only one image
        contribute nothing, so only shared structure is optimised.

        Convention: ``a[y, x]`` corresponds to ``b[y - oy, x - ox]`` - i.e. add
        (ox, oy) to a 'to' coordinate to bring it into the 'from' frame. Returns
        ((ox, oy), score) where score is the fraction of the sparser edge set that
        coincides (0..1).
        """
        m = int(max_shift)
        if m < 1 or a.sum() == 0 or b.sum() == 0:
            return (0, 0), 0.0
        # Pad 'a' with a zero border so the full 'b' template can slide +/- m past
        # a's edges. Content sliding out of bounds overlaps the zero padding and
        # matches nothing (no false peaks), and nothing is cropped off 'b'.
        a_pad = cv2.copyMakeBorder(a, m, m, m, m, cv2.BORDER_CONSTANT, value=0)
        if b.shape[0] > a_pad.shape[0] or b.shape[1] > a_pad.shape[1]:
            return (0, 0), 0.0
        # Raw cross-correlation of the binary edge maps == count of coincident
        # edge pixels at each offset. Only shared structure contributes.
        result = cv2.matchTemplate(a_pad, b, cv2.TM_CCORR)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)  # max_loc = (tx, ty)
        if max_val <= 0:
            return (0, 0), 0.0
        denom = min(float(a.sum()), float(b.sum())) or 1.0
        return (max_loc[0] - m, max_loc[1] - m), float(max_val) / denom

    # --- Coarse pass: GLOBAL search on a heavily down-scaled edge map ------------
    cs = scale * coarse_scale if (coarse_scale and coarse_scale != 1.0) else scale
    a_c = edge_mask(from_image, cs)
    b_c = edge_mask(to_image, cs)
    max_shift_c = int(round(max_shift_frac * min(a_c.shape)))
    coarse_offset, _ = global_shift(a_c, b_c, max_shift_c)
    # Bring the coarse offset up to the working scale as a warm start.
    offset = (int(round(coarse_offset[0] * scale / cs)),
              int(round(coarse_offset[1] * scale / cs)))

    # --- Fine pass: small GLOBAL search at the working resolution ----------------
    # Pre-translate b by the coarse estimate (zero border, no wraparound) so the
    # remaining shift is tiny, then search a small window globally around it.
    a_f = edge_mask(from_image, scale)
    b_f = edge_mask(to_image, scale)
    if refine_radius is None:
        # Enough to cover the coarse quantisation error (one coarse px) plus slack.
        refine_radius = int(np.ceil(scale / cs)) + 2 if cs else 4
    Mt = np.float32([[1, 0, offset[0]], [0, 1, offset[1]]])
    b_shift = cv2.warpAffine(b_f, Mt, (b_f.shape[1], b_f.shape[0]),
                             flags=cv2.INTER_NEAREST, borderValue=0)
    delta, _ = global_shift(a_f, b_shift, refine_radius)
    offset = (offset[0] + delta[0], offset[1] + delta[1])

    # Convert from working-scale pixels back to input-image pixels.
    return (int(round(offset[0] / scale)), int(round(offset[1] / scale)))

def align_center(center, alignment_vector):
    """
    Map a 'to' page center into the 'from' page frame using the alignment vector
    returned by auto_align_pages. Adds the (dx, dy) offset so distances are measured
    between truly corresponding positions instead of relying on the top-left corner.
    """
    dx, dy = alignment_vector
    return (center[0] + dx, center[1] + dy)

def align_bbox(bbox, alignment_vector):
    """
    Map a 'to' page bbox into the 'from' page frame for distance metrics only.
    The stored bbox is left untouched so drawing still uses the real position.
    """
    dx, dy = alignment_vector
    return [bbox[0] + dx, bbox[1] + dy, bbox[2] + dx, bbox[3] + dy]

def percent_distance(bbox_from, bbox_to):
    from_width = bbox_from[2] - bbox_from[0]
    from_height = bbox_from[3] - bbox_from[1]
    max_dim = max(from_width, from_height)

    center_from = [(bbox_from[0] + bbox_from[2])/2, (bbox_from[1] + bbox_from[3])/2]
    center_to = [(bbox_to[0] + bbox_to[2])/2, (bbox_to[1] + bbox_to[3])/2]

    dx = center_to[0] - center_from[0]
    dy = center_to[1] - center_from[1]
    distance = (dx**2 + dy**2)**0.5

    return distance / max_dim * 100

# Calculate circular distance for Hue
def circular_distance(a, b, modulo=180):  # HSV Hue range is 0-179 in OpenCV
    direct_diff = abs(int(a) - int(b))
    wrapped_diff = modulo - direct_diff
    return min(direct_diff, wrapped_diff)

def bbox_center(bbox):
    center_x = (bbox[0] + bbox[2]) // 2
    center_y = (bbox[1] + bbox[3]) // 2
    return (center_x, center_y)

def find_neighbor(element, elements, distance_threshold):
    min_distance = np.inf
    closest = None
    for other_element in elements:
        if element == other_element:
            continue
        bbox = element['bbox']
        i_bbox = other_element['bbox']
        distance = bbox_distance(bbox, i_bbox)
        if distance < distance_threshold and distance < min_distance:
            min_distance = min(min_distance, distance)
            closest = other_element
    return closest

def is_next_line(element1, element2, thresh=10, mode='bottom', gap_thresh=None):
    """
    Determine if a box is the next line of another.
    Based on the gap between the two boxes (in the direction of the orientation) and the
    alignment on the 'left' of the text
    Mode: where is the next line expected? 
        'bottom' expects the next line to be under the first line,
        'right' expects the next line to be on the right
    """
    def rot(i, j): # Cycle through indices for different orientations. E.g. index 3 + 2 --> index 1
        return(i+j+1)%4-1
    
    bbox1 = element1['bbox']
    bbox2 = element2['bbox']

    if bbox1 == bbox2:
        return False # Not the next line, it's just the same element
    
    j = [0, 90, 180, 270].index(element1['orientation'])
    i = ['bottom', 'left', 'top', 'right'].index(mode)

    j += i # Increase index to account for mode

    alignment = bbox1[rot(0, j)] - bbox2[rot(0, j)] # Alignment of the lines (left side of the line on 'bottom' mode)
    gap = (bbox1[rot(3, j)] - bbox2[rot(1, j)])#*sign
    gap_thresh = thresh if gap_thresh == None else gap_thresh
    if  abs(gap)<gap_thresh and abs(alignment) < thresh:
            return True
    return False
    
def find_next_line(element1, elements, thresh=10, mode='bottom'):
    if 'orientation' not in element1.keys():
        element1['orientation'] = 0 # Add default oriantation (mainly for bug aroud OD detected symbols missing this) 
    for i, r_el in enumerate(elements):
        if is_next_line(element1, r_el, thresh=thresh, mode=mode):
            return r_el, i
    return False, False

def find_element_inside_bbox(bbox, elements):
    """
    Find elements inside a bbox, if any.
    Useful for detecting OCR text inside symbols for further classification/validation
    """
    for i, r_el in enumerate(elements):
        if bbox_inside_bbox(r_el['bbox'], bbox):
            return r_el
    return False

def find_element_inside_bbox_soft(bbox, elements):
    """
    Find elements inside a bbox, if any.
    Useful for detecting OCR text inside symbols for further classification/validation
    """
    for i, r_el in enumerate(elements):
        if bbox_inside_bbox_soft(r_el['bbox'], bbox):
            return r_el
    return False

def bbox_distance(bbox1, bbox2, min_orthogonal=False):
    """
    Calculate minimum distance between two bounding boxes.
    
    Args:
        bbox1: List [xmin, ymin, xmax, ymax] of first box
        bbox2: List [xmin, ymin, xmax, ymax] of second box
        min_orthogonal: Only calculate vertical/horizontal distance even if there is no overlap
        
    Returns:
        float: Minimum distance between boxes. Returns 0 if boxes overlap.
    """
    # Check for overlap in x
    x_overlap = bbox1[2] >= bbox2[0] and bbox2[2] >= bbox1[0]
    # Check for overlap in y
    y_overlap = bbox1[3] >= bbox2[1] and bbox2[3] >= bbox1[1]
    
    # If boxes overlap in both dimensions, return 0
    if x_overlap and y_overlap:
        return 0
    
    # If minimum orthogonal only required return vertical/horizontal distance
    if min_orthogonal:
        return min(abs(bbox1[2] - bbox2[0]), abs(bbox2[2] - bbox1[0]),
                   abs(bbox1[3] - bbox2[1]), abs(bbox2[3] - bbox1[1]))
    
    # If boxes overlap in y but not x, calculate horizontal distance
    if y_overlap:
        return min(abs(bbox1[2] - bbox2[0]), abs(bbox2[2] - bbox1[0]))
        
    # If boxes overlap in x but not y, calculate vertical distance
    if x_overlap:
        return min(abs(bbox1[3] - bbox2[1]), abs(bbox2[3] - bbox1[1]))

    # No overlap in either dimension - calculate diagonal distance between corners
    dx = min(abs(bbox1[2] - bbox2[0]), abs(bbox2[2] - bbox1[0]))
    dy = min(abs(bbox1[3] - bbox2[1]), abs(bbox2[3] - bbox1[1]))
    return (dx**2 + dy**2)**0.5

def join_rects(rect1, rect2):
    """
    Join two rectangles into a single bounding rectangle.
    
    Args:
        rect1: List [x, y, w, h] of first rectangle
        rect2: List [x, y, w, h] of second rectangle
        
    Returns:
        List [x, y, w, h] of bounding rectangle
    """
    if rect2[0]==None:
        return rect1[0], rect1[1], rect1[2], rect1[3]
    if rect1[0]==None:
        return rect2[0], rect2[1], rect2[2], rect2[3]
    # Find extremes
    x = min(rect1[0], rect2[0])
    y = min(rect1[1], rect2[1])
    
    # Find rightmost and bottommost points
    right = max(rect1[0] + rect1[2], rect2[0] + rect2[2])
    bottom = max(rect1[1] + rect1[3], rect2[1] + rect2[3])
    
    # Calculate width and height
    w = right - x
    h = bottom - y
    
    return x, y, w, h

def expand_bboxes(bbox1, bbox2):
    expanded_box = [0,0,0,0]
    expanded_box[0] = min(bbox1[0], bbox2[0])
    expanded_box[1] = min(bbox1[1], bbox2[1])
    expanded_box[2] = max(bbox1[2], bbox2[2])
    expanded_box[3] = max(bbox1[3], bbox2[3])
    return expanded_box

def merge_elements(element1, element2):
    merged = {}
    merged["bbox"] = expand_bboxes(element1['bbox'], element2['bbox'])
    merged["text"] = element1['text'] + element2['text']
    return merged

def draw_dist_pct(image, item, from_to=None):
    try:
        dist = item['distance_cm']
        if not from_to:
            bbox = item['bbox']
        elif from_to == 'from':
            bbox = item['from_bbox']
        elif from_to == 'to':
            bbox = item['to_bbox']
        cv2.putText(image, str(round(dist))+'%', 
                    (bbox[2]+4, int((bbox[3]+bbox[1])/2) + 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, .8, (255,255,255), 3, cv2.LINE_AA)
        cv2.putText(image, str(round(dist))+'%', 
                    (bbox[2]+4, int((bbox[3]+bbox[1])/2) + 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, .8, (0,0,0), 2, cv2.LINE_AA)

    except KeyError: # For added and deleted objects
        pass
    return image

def nearest_neighbors(point, elements, n):
    """
    Find the n closest elements to the given point based on bounding box distance.
    
    Args:
        point: Coordinates of point
        elements: List of dictionaries, each containing a 'bbox' key
        n: Number of nearest neighbors to find
        
    Returns:
        List of the n closest elements sorted by distance
    """
    distances = []
    
    for other_element in elements:
           
        # Calculate distance between bounding boxes
        dist = distance.euclidean(point, other_element['center'])
        distances.append((dist, other_element))
    
    # Sort by distance and take the n closest
    distances.sort(key=lambda x: x[0])
    return [elem for _, elem in distances[:n]]

def orientation_neighbors(point, elements):
    n = 3
    nn = nearest_neighbors(point, elements, n)
    orientations = [neigh['orientation'] for neigh in nn]
    return max(set(orientations), key=orientations.count) # Mode

def bbox_inside_bbox(bbox1, bbox2):
    """
    Is bbox1 inside bbox2?
    """
    return bbox1[0]>=bbox2[0] and bbox1[1]>=bbox2[1] and bbox1[2]<=bbox2[2] and bbox1[3]<=bbox2[3]

def bbox_inside_bbox_soft(bbox1, bbox2):
    """
    Is bbox1 inside bbox2? but this will allow for the bbox to be not entirely inside, but mostly inside
    """
    if bbox_inside_bbox(bbox1, bbox2): # Check not necessary but marginally faster since this will be more common
        return True
    
    inter = intersection(bbox1, bbox2)
    area1 = (bbox1[2]-bbox1[0])*(bbox1[3]-bbox1[1])
    area2 = (bbox2[2]-bbox2[0])*(bbox2[3]-bbox2[1])
    outside = area1 - inter # Part that is outside the box (if any)

    # First condition: If the protruding area is considerably 
    # smaller than the "big" symbol, then it is considered to be inside of it

    # Second condition: The bbox must be mostly inside, this is to avoid 
    # slightly overlapping boxes but very different in size to return true
    return outside/area2 < .12 and outside/area1 < .3


def intersection(bbox1, bbox2):
    """
    Compute the intersection area of two bounding boxes.
    Each bbox is in the format (xmin, ymin, xmax, ymax).
    """
    inter_xmin = max(bbox1[0], bbox2[0])
    inter_ymin = max(bbox1[1], bbox2[1])
    inter_xmax = min(bbox1[2], bbox2[2])
    inter_ymax = min(bbox1[3], bbox2[3])

    inter_width = max(0, inter_xmax - inter_xmin)
    inter_height = max(0, inter_ymax - inter_ymin)

    return inter_width * inter_height

def get_counts(elements, by_orientation=False):
    # Calculate repeats by content. When by_orientation is True the key also
    # includes the element orientation, so that e.g. an upright "LOT" and an
    # upside-down "LOT" are counted as two different items.
    text_counts = {}
    for e in elements:
        key = (e['text'], e.get('orientation', 0)) if by_orientation else e['text']
        text_counts[key] = text_counts.get(key, 0) + 1
    return text_counts

def counts_div_by_n(counts, n, label_items=None):
    total = len(counts) if not label_items else len(label_items)
    texts = []
    divisible = 0
    for t, c in counts.items():
        if c%n==0:
            divisible += 1
            texts.append(t)
    non_divisible = (total - divisible)/n # Non divisibles normalized by the amount of labels

    return divisible/(divisible + non_divisible) > 0.92, texts

def _reference_label_signature(elements, anchor_texts):
    """
    Build an orientation-aware signature for a *single* physical label.

    Returns a list of (text, orientation) pairs, one per anchor text, read off
    one real label found by spatial clustering: starting from a seed element we
    pick, for every anchor text, the element closest to that seed. Because every
    label on the page is just a translated (and possibly rotated) copy of this
    one, this signature - together with its four 90 degree rotations - describes
    every label variant present. A label may legitimately contain elements at
    several different orientations, which is why we capture a per-anchor
    orientation instead of assuming a single one.
    """
    if not anchor_texts:
        return []
    anchor_texts = list(anchor_texts)
    # Seed: first element belonging to the first anchor text.
    seed = next((e for e in elements if e['text'] == anchor_texts[0]), None)
    if seed is None:
        return []
    sx, sy = seed['center']
    signature = []
    for li in anchor_texts:
        candidates = [e for e in elements if e['text'] == li]
        nearest = min(candidates, key=lambda e: (e['center'][0] - sx) ** 2 + (e['center'][1] - sy) ** 2)
        signature.append((li, nearest.get('orientation', 0)))
    return signature


def how_many_labels(elements, label_items=None):
    if not elements:
        if label_items:
            return 0
        return 0, []

    # Initial detection (no label_items yet): find the repeating anchor texts by
    # text content, then build an orientation-aware reference signature for one
    # physical label, which callers pass back in as ``label_items``.
    if not label_items:
        initial_counts = get_counts(elements)
        mult = 0 # Number of repeated labels
        texts = []
        for n in range(1,13): # Max labels is 12, increase this number if to low
            count_div, t = counts_div_by_n(initial_counts, n)
            if count_div:
                mult = n
                texts = t
        return mult, _reference_label_signature(elements, texts)

    # Per-side count. ``label_items`` is the reference signature: a list of
    # (text, orientation) pairs describing one label. A neighbouring label can be
    # that same label rotated by a multiple of 90 degrees (e.g. an upside-down
    # column). For every global rotation we rotate the whole reference signature
    # and count how many complete copies are present, then sum over rotations.
    # This way the elements of a rotated label cannot substitute for the missing
    # elements of a differently-rotated one, so a sweep line slicing through the
    # middle of a row of labels no longer looks like a clean break (which is what
    # happened when counting by text alone).
    oriented_counts = get_counts(elements, by_orientation=True)
    complete_sets = 0
    for r in (0, 90, 180, 270):
        complete_sets += min(oriented_counts.get((text, (o + r) % 360), 0) for (text, o) in label_items)
    return complete_sets

def find_breaks_line(elements, dim, extent=None):
    """
    Sweep a line across ``elements`` (sorted along ``dim``) and return the
    coordinates where the page splits cleanly into whole labels.

    ``extent`` is the page size along ``dim`` (page width for dim=0, page height
    for dim=1). When given, a break that spans a range is snapped to a logical,
    equally spaced grid line - a fraction n/m of the page for m in 1..4 (i.e.
    1/2, 1/3, 2/3, 1/4, 3/4) - selected from the label-count split at that break
    (see ``choose_break``). This prevents the cut from being biased toward one
    side when the text used to detect it sits off-center within the label (e.g.
    only a couple of text elements clustered near the right edge): the plain
    range midpoint would land between those texts and clip symbols near the label
    border, whereas the page fraction lands on the true label boundary. Falls
    back to the range midpoint when no logical line qualifies (or ``extent`` is
    not provided).
    """
    n_labels, label_items = how_many_labels(elements)
    elements = sorted(elements, key=lambda x: x['center'][dim])

    # Candidate grid lines: fractions n/m of the page (m in 1..4, 1 <= n < m),
    # de-duplicated (e.g. 2/4 == 1/2), expressed in pixels along ``dim``.
    logical_lines = []
    if extent:
        fracs = sorted({n / m for m in range(1, 4) for n in range(1, m)})
        logical_lines = [f * extent for f in fracs]

    side_a = []
    side_b = elements[:]
    breaks = []
    moving_line = 0
    line_increment = 30
    in_break = False

    def choose_break(start, end, labels_a):
        """Return the break coordinate for a valid range [start, end].

        The break splits the grid into ``labels_a`` vs ``n_labels - labels_a``
        labels, so on a regular grid the true boundary lies at that fraction of
        the page: ``(labels_a / n_labels) * extent``. When a logical grid line
        (a fraction n/m of the page, m in 1..4) coincides with that split we snap
        to it, landing on the real label boundary. The range midpoint is instead
        biased toward whichever side the detecting text sits on (e.g. only a
        couple of text elements clustered near the right edge), which would place
        the cut off-center and clip symbols near the label border. Falls back to
        the midpoint when the split does not line up with a logical line
        (irregular grid, m > 4, or ``extent`` not provided)."""
        midpoint = start + (end - start) / 2
        if logical_lines and n_labels:
            target = (labels_a / n_labels) * extent
            nearest = min(logical_lines, key=lambda ln: abs(ln - target))
            if abs(nearest - target) <= line_increment:
                return int(nearest)
        return int(midpoint)

    while len(side_b) > 0:
        # side_b is sorted along ``dim``; move every element that is now behind
        # the sweep line from the front of side_b to side_a. Using pop(0) in a
        # while-loop (instead of iterating over side_b and calling remove())
        while side_b and side_b[0]['center'][dim] < moving_line:
            side_a.append(side_b.pop(0))
        n_labels_a = how_many_labels(side_a, label_items)
        n_labels_b = how_many_labels(side_b, label_items)
        if n_labels_a + n_labels_b == n_labels and n_labels_a!=0 and n_labels_b!=0:
            if not in_break:
                break_start = moving_line
                break_labels_a = n_labels_a # constant across the range; sets the split fraction
                in_break = True
        else:
            if in_break:
                breaks.append(choose_break(break_start, moving_line - line_increment, break_labels_a))
                in_break = False
        moving_line += line_increment
    return breaks

def direction(element1, element2, mode=None):
    """
    Return the general direction element2 is in relative to element1,
    accounting for element1's orientation.
    Returns one of: 'right', 'left', 'bottom', 'top'.
    """
    c1 = bbox_center(element1['bbox'])
    c2 = bbox_center(element2['bbox'])
    dx = c2[0] - c1[0]
    dy = c2[1] - c1[1]

    # Rotate (dx, dy) into element1's local frame by applying -orientation
    angle = -np.radians(element1.get('orientation', 0))
    cos_a = round(np.cos(angle))
    sin_a = round(np.sin(angle))
    local_x = cos_a * dx - sin_a * dy
    local_y = sin_a * dx + cos_a * dy

    if (not mode and abs(local_x) >= abs(local_y)) or mode == 'horizontal':
        return 'right' if local_x >= 0 else 'left'
    else: # mode == 'vertical'
        return 'bottom' if local_y >= 0 else 'top'
    
def find_neighbor_direction(element1, elements, thresh=15, mode='bottom'):
    """
    Find the neighboring element in a specified direction within a threshold distance.
    """
    if mode in ['bottom', 'top']:
        dirmode = 'vertical'
    else:
        dirmode = 'horizontal'
    if 'orientation' not in element1.keys():
        element1['orientation'] = 0 # Add default oriantation (mainly for bug aroud OD detected symbols missing this) 
    for i, r_el in enumerate(elements):
        if bbox_distance(element1['bbox'], r_el['bbox']) < thresh:
                if direction(element1, r_el, mode=dirmode) == mode:
                    return r_el, i
    return False, False


if __name__ == "__main__":
    # Quick manual test for auto_align_pages on a known-misaligned label pair.
    # Run with:  python utils/spatial.py
    import os
    import time

    from_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\VISION\Acuvue\page_images\1_from_no_text.png"
    to_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\VISION\Acuvue\page_images\1_to_no_text.png"

    # from_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\VISION\Moist\page_images\1_from_original.png"
    # to_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\VISION\Moist\page_images\1_to_original.png"

    from_image = cv2.imread(from_path)
    to_image = cv2.imread(to_path)
    if from_image is None or to_image is None:
        raise FileNotFoundError("Could not load the test images - check the paths.")

    # Pages can differ slightly in size; crop both to the common region so the
    # top-left-corner (baseline) comparison is well defined.
    h = min(from_image.shape[0], to_image.shape[0])
    w = min(from_image.shape[1], to_image.shape[1])
    from_image = from_image[:h, :w]
    to_image = to_image[:h, :w]
    print(f"Loaded images at {w}x{h}")

    def ink_overlay(a, b, vec):
        """
        Visualise alignment: 'from' ink in red, 'to' ink (shifted by vec) in blue,
        overlapping ink in black. Good alignment -> mostly black where content is
        shared, with red/blue only on genuinely added/removed elements.
        """
        dx, dy = vec
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        b_shift = cv2.warpAffine(b, M, (b.shape[1], b.shape[0]),
                                 flags=cv2.INTER_NEAREST, borderValue=(255, 255, 255))
        a_ink = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY) < 240
        b_ink = cv2.cvtColor(b_shift, cv2.COLOR_BGR2GRAY) < 240
        canvas = np.full_like(a, 255)
        canvas[a_ink] = (0, 0, 255)       # from ink -> red
        canvas[b_ink] = (255, 0, 0)       # to ink   -> blue
        canvas[a_ink & b_ink] = (0, 0, 0)  # shared   -> black
        return canvas

    def residual_pixels(a, b, vec):
        """Count of non-overlapping ink pixels (lower = better alignment)."""
        dx, dy = vec
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        b_shift = cv2.warpAffine(b, M, (b.shape[1], b.shape[0]),
                                 flags=cv2.INTER_NEAREST, borderValue=(255, 255, 255))
        a_ink = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY) < 240
        b_ink = cv2.cvtColor(b_shift, cv2.COLOR_BGR2GRAY) < 240
        return int(np.count_nonzero(a_ink ^ b_ink))

    def _edges(img):
        return cv2.Canny(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), 50, 150) > 0

    def edge_overlay(a, b, vec):
        """
        Visualise what the matcher actually optimises: 'from' edges in red,
        'to' edges (shifted by vec) in blue, coincident edges in black. Good
        alignment -> outlines turn black where structure is shared.
        """
        dx, dy = vec
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        b_shift = cv2.warpAffine(b, M, (b.shape[1], b.shape[0]),
                                 flags=cv2.INTER_NEAREST, borderValue=(255, 255, 255))
        a_e = _edges(a)
        b_e = _edges(b_shift)
        canvas = np.full_like(a, 255)
        canvas[a_e] = (0, 0, 255)        # from edges -> red
        canvas[b_e] = (255, 0, 0)        # to edges   -> blue
        canvas[a_e & b_e] = (0, 0, 0)    # coincident -> black
        return canvas

    def edge_match_pct(a, b, vec):
        """Fraction of the sparser edge set that coincides (higher = better)."""
        dx, dy = vec
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        b_shift = cv2.warpAffine(b, M, (b.shape[1], b.shape[0]),
                                 flags=cv2.INTER_NEAREST, borderValue=(255, 255, 255))
        a_e = _edges(a)
        b_e = _edges(b_shift)
        denom = min(int(a_e.sum()), int(b_e.sum())) or 1
        return 100.0 * int(np.count_nonzero(a_e & b_e)) / denom

    # Evaluate the effect of different working scales (speed vs accuracy).
    print("\nscale |     vector     |   time   | edge match % | residual ink")
    print("------+----------------+----------+--------------+-------------")
    baseline_res = residual_pixels(from_image, to_image, (0, 0))
    baseline_edge = edge_match_pct(from_image, to_image, (0, 0))
    print(f"{'base':<5} | {str((0, 0)):<14} | {'':>6}   | {baseline_edge:>10.1f}%  | {baseline_res:>8}")
    best_vec = (0, 0)
    for scale in (1.0, 0.5, 0.25, 0.125):
        t0 = time.time()
        vec = auto_align_pages(from_image, to_image, scale=scale)
        dt = (time.time() - t0) * 1000
        res = residual_pixels(from_image, to_image, vec)
        epct = edge_match_pct(from_image, to_image, vec)
        print(f"{scale:<5} | {str(vec):<14} | {dt:6.0f}ms | {epct:>10.1f}%  | {res:>8}")
        if scale == 1.0:
            best_vec = vec

    # Save before/after overlays (both ink and edge views) for visual inspection.
    out_dir = os.path.dirname(from_path)
    overlays = {
        "align_overlay_before.png": ink_overlay(from_image, to_image, (0, 0)),
        "align_overlay_after.png": ink_overlay(from_image, to_image, best_vec),
        "align_edges_before.png": edge_overlay(from_image, to_image, (0, 0)),
        "align_edges_after.png": edge_overlay(from_image, to_image, best_vec),
    }
    print(f"\nFull-resolution alignment vector (to->from): {best_vec}")
    print("Saved overlays:")
    for name, img in overlays.items():
        path = os.path.join(out_dir, name)
        cv2.imwrite(path, img)
        print(f"  {path}")
