import os
from io import BytesIO
import numpy as np
from pathlib import Path
import sys

import cv2
import fitz

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 

from process_pdf import ProcessPDF, ProcessPage, ComparePages
from utils.form_1228 import get_form_data
from utils.utils import Timer, make_json_serializable, split_pdf
from utils.blob_storage import write_img, read_pdf, read_file, read_docx
from utils.data import load_manufacturer_address_db

class ProcessPDF_VISION(ProcessPDF):
    def __init__(self, from_path, to_path, tad_path, output_folder, document_type, business_unit, mode="local"):
        self.timer = Timer()

        # Placeholder for docx redline and annotations
        self.redline_doc = None
        self.docx_annotations = None
        self.business_unit = business_unit # SURGERY, EP, VISION

        self.mode = mode
        if mode=='local':
            if to_path:

                # From
                self.from_doc = fitz.open(from_path)

                # To
                self.to_doc = fitz.open(to_path)

            else: # No to_path provided, split the pdf on the fly
                self.from_doc, self.to_doc = split_pdf(from_path)
            
        elif mode=='blob':
            # From
            if Path(from_path).suffix.lower() == ".docx":
                self.from_doc, self.redline_doc, self.docx_annotations = read_docx(from_path)
            elif Path(from_path).suffix.lower() == ".pdf":
                self.from_doc = read_pdf(from_path)

            # To
            if Path(to_path).suffix.lower() == ".docx":
                self.to_doc, _, _ = read_docx(to_path) # Future should not have revisions
            elif Path(to_path).suffix.lower() == ".pdf":
                self.to_doc = read_pdf(to_path)

        # # Load stationary data
        self.load_data()

        # Clean "Sample" watermarks
        for page in self.to_doc:
            for xref in page.get_contents():
                stream = self.to_doc.xref_stream(xref).replace(b'Sample', b'')
                self.to_doc.update_stream(xref, stream)
        for page in self.from_doc:
            for xref in page.get_contents():
                stream = self.from_doc.xref_stream(xref).replace(b'Sample', b'')
                self.from_doc.update_stream(xref, stream)

        # How many pages to process, for debugging
        self.pages = False
        self.startpage = 1

        # Specific pages to process
        self.page_lists = (None, None) # (to_page_list, from_page_list), 1-based indexing

        # Method to use for detecting needle point symbols
        self.np_symbol_method = 'YOLO' # TM for template matching, or YOLO. TM is no longer supported
        self.yolo_weights = "best.pt" # Weights to use if np_symbol_method is YOLO

        # Use OCR on each page
        self.ocr = True

        self.document_type = document_type # Pre-Printed, Thunderbird, IFU comparison or IFU translation

        # Preprinted document. Used to trigger the extraction of RMC
        self.preprinted = document_type=="Pre-Printed" 
        self.ifu_comp = document_type=="IFU comparison" 

        # Store the brand name. Used to determine if code should keep looking for the brand
        self.brand_name = None

        # Bounds for the upper right label when there is a multilabel on the page. False means no multilabel
        self.upper_right_bbox = False

        # Store all detected fonts for debugging
        self.detected_fonts = set([])

        # Create output folder
        if not os.path.exists(output_folder) and self.mode=='local':
            os.makedirs(output_folder)
        self.output_folder = output_folder


        # A dict to return as a response for the API
        self.response = {'pages':[], 'success':True, 
                         "output_folder" : output_folder}

        self.timer.append("ProcessPDF init")

    def load_data(self):
        # Load manufacturer address db
        # manu_path = "data/manufacturer_database_ep.csv"
        # self.manufacturer_address_db = load_manufacturer_address_db(os.path.join(ROOT_DIR, manu_path))
        pass

class ProcessPage_VISION(ProcessPage):
    def __init__(self, page, page_type="to"):
        super().__init__(page, page_type)
        self.ccn = None # TODO temporary fix to avoid exception in collect_response
    
    def process(self):
        if self.page_type=="from":
            if not self.process_pdf.docx_annotations:
                self.extract_annotations()
            else:
                if self.process_pdf.redline_doc:
                    redline_page = self.process_pdf.redline_doc.load_page(self.page_num)
                    orig_pix = redline_page.get_pixmap(matrix=self.mat)
                    image = np.frombuffer(orig_pix.samples, dtype=np.uint8).reshape(orig_pix.height, orig_pix.width, orig_pix.n)
                    self.images["annotations"] = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                self.annotations = [a for a in self.process_pdf.docx_annotations if a["page"]==self.page_num+1]
        else:
            self.annotations = []
        self.process_pdf.timer.append("extract_annotations")
        self.read_page(self.page)
        self.process_pdf.timer.append("read_page")  
        self.detect_grid()
        self.process_pdf.timer.append("detect_grid")  
        if self.process_pdf.ocr:
            self.run_ocr()
            self.process_pdf.timer.append("run_ocr")
        if self.process_pdf.np_symbol_method == 'YOLO':
            # Symbols that never appear in VISION labels and should be ignored
            ignore_symbols = ['NEEDLE']
            self.symbols_yolo(ignore_symbols=ignore_symbols)
            self.process_pdf.timer.append("symbols_yolo") 
        if self.process_pdf.ocr:
            self.cleanup_ocr()
            self.process_pdf.timer.append("cleanup_ocr")
        # self.find_addresses()
        # self.process_pdf.timer.append("find_addresses")  
        # self.find_translations()
        # self.process_pdf.timer.append("find_translations")  
        self.decode_barcodes()
        self.process_pdf.timer.append("decode_barcodes")  
        self.validate_barcodes()
        self.process_pdf.timer.append("validate_barcodes")  
        pass # For debugging breakpoints        

class ComparePages_VISION(ComparePages):
    def __init__(self, from_page, to_page):
        super().__init__(from_page, to_page)

    def compare(self):
        #self.compare_dimensions() # Disabled as per business requirement
        self.auto_align()
        self.process_pdf.timer.append("auto_align")
        self.compare_images('original')
        self.process_pdf.timer.append("compare_images")
        self.compare_images('no_text')
        self.process_pdf.timer.append("compare_images")
        self.compare_symbols()
        self.process_pdf.timer.append("compare_symbols")
        self.compare_barcodes()
        self.process_pdf.timer.append("compare_barcodes")
        self.compare_generic_text()
        self.process_pdf.timer.append("compare_generic_text")
        # self.compare_translations()
        # self.process_pdf.timer.append("compare_translations")
        # self.compare_addresses()
        # self.process_pdf.timer.append("compare_addresses")
        self.collect_response()
        self.process_pdf.timer.append("collect_response")
        self.draw_changes()
        self.process_pdf.timer.append("draw_changes")
        pass # For debugging breakpoints
    
    
    def collect_response(self):
        response = {}

        response["success"] = True
        response["error_message"] = ''


        response["CCN"] = {"from":'Page'+str(self.to_page.page_num + 1),
                           "to":'Page'+str(self.to_page.page_num + 1)}
        
        response["page_num"] = self.to_page.page_num + 1

        # Symbol comparison
        response["symbol_comparison"] = self.symbol_comparison

        # Barcode comparison
        response["barcode_comparison"] = self.barcode_comparison
        
        # Text comparison
        response["text_comparison"] = self.text_comparison

        # # Translation comparison
        # response["translation_comparison"] = self.translation_comparison

        # # Address comparison
        # response["address_comparison"] = self.address_comparison

        if self.from_page.annotations:
            response['annotations'] = self.from_page.annotations

        self.response = make_json_serializable(response)
