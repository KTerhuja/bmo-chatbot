import base64
import sys
import cv2
import math
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeResult, AnalyzeDocumentRequest
from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent.absolute() # path to repo
sys.path.append(str(ROOT_DIR)) 
from utils.color import  get_text_color
from utils.spatial import bbox_center

def run_document_intelligence_pdf(pdf_page_bytes, cm_per_pixel, image):
    """
    Run  document intelligence for OCR but using the pdf file as input, instead of an image.

    Args:
    pdf_page_bytes: Bytes of the page or doc to run
    cm_per_pixel: Constant to convert the inches values to pixels consistent with the rest of the pipeline
    image: The image of the page, used to determine the color of the text, (because it is not returned by azure)
    """
    text_data = []
    key = 'qqlzgJNuY5HCL3oKikQVRylMhH9vKbSkEHgYzTf7LGkBRejOOoAlJQQJ99AKACYeBjFXJ3w3AAALACOG4G6v'
    endpoint = 'https://mdocrformrecognizer.cognitiveservices.azure.com/'

    client = DocumentIntelligenceClient(
        endpoint=endpoint, credential=AzureKeyCredential(key)
    )
    
    base64_encoded_pdf = base64.b64encode(pdf_page_bytes).decode("utf-8")

    analyze_request = {
            "base64Source": base64_encoded_pdf
        }

    poller = client.begin_analyze_document(
            "prebuilt-layout", body=analyze_request
        )

    # Wait for the result to complete
    result = poller.result()

    # The single-character filter guards against the OCR service hallucinating text out of
    # label outlines/graphics, which happens mostly on images with no real text. When the
    # page DOES contain substantial (multi-character) text, those hallucinations are far
    # less likely, so we keep legitimate single-character elements (e.g. a lone 'D').
    has_real_text = any(
        len(l['content'].strip()) > 1 and any(c.isalnum() for c in l['content'])
        for l in result.pages[0].lines
    )

    for line in result.pages[0].lines:
        text = line['content']
        if ((len(text) == 1 and not has_real_text) or # Discard single char detections (only when no real text)
            all(not c.isalnum() for c in text)): # Discard detections that are only symbols
            continue
        
        polygon = [round(p*2.54/cm_per_pixel) for p in line.polygon] # convert inches to pixels
        bbox, orientation = calculate_bbox_orientation(polygon)
        text_color, _ = get_text_color(image[bbox[1]:bbox[3], bbox[0]:bbox[2]])
        text_data.append({
            "text": line['content'],
            "bbox": bbox,
            "center": bbox_center(bbox),
            "font": 'OCR_text',
            "size" : 0,
            "color" : text_color,
            "orientation": orientation
        })


    return text_data

def run_document_intelligence(image):
    text_data = []

    key = 'qqlzgJNuY5HCL3oKikQVRylMhH9vKbSkEHgYzTf7LGkBRejOOoAlJQQJ99AKACYeBjFXJ3w3AAALACOG4G6v'
    endpoint = 'https://mdocrformrecognizer.cognitiveservices.azure.com/'

    # Scale down if exceeding azure limit of 10,000 pixels
    h, w = image.shape[:2]
    if h >= 10000 or w >= 10000:
        scale = 10000 / max(h, w)
        image = cv2.resize(image, (0,0), fx=scale, fy=scale)
    else:
        scale = 1
    
    # Encode image as JPEG in memory
    _, buffer = cv2.imencode('.jpg', image)

    # Convert buffer to base64
    img_base64 = base64.b64encode(buffer).decode('utf-8')

    client = DocumentIntelligenceClient(
        endpoint=endpoint, credential=AzureKeyCredential(key)
    )
    
    
    analyze_request = {
            "base64Source": img_base64
        }
    
    poller = client.begin_analyze_document(
            "prebuilt-layout", body=analyze_request
        )
    
    # Wait for the result to complete
    result = poller.result()

    # The single-character filter guards against the OCR service hallucinating text out of
    # label outlines/graphics, which happens mostly on images with no real text. When the
    # page DOES contain substantial (multi-character) text, those hallucinations are far
    # less likely, so we keep legitimate single-character elements (e.g. a lone 'D').
    has_real_text = any(
        len(l['content'].strip()) > 1 and any(c.isalnum() for c in l['content'])
        for l in result.pages[0].lines
    )

    for line in result.pages[0].lines:
        text = line['content']
        if ((len(text) == 1 and not has_real_text) or # Discard single char detections (only when no real text)
            all(not c.isalnum() for c in text)): # Discard detections that are only symbols
            continue
        # polygon = [round(p/scale) for p in line.polygon] # Rescale back to original
        bbox, orientation = calculate_bbox_orientation(line.polygon)
        pad = 10 # Pad the bbox to ensure we capture the text color, as the OCR polygon may be tight
        bbox_c = [max(0, bbox[0]-pad), max(0, bbox[1]-pad), min(image.shape[1], bbox[2]+pad), min(image.shape[0], bbox[3]+pad)]
        text_color, _ = get_text_color(image[bbox_c[1]:bbox_c[3], bbox_c[0]:bbox_c[2]])
        bbox = [round(p/scale) for p in bbox] # Rescale back to original
        text_data.append({
            "text": line['content'],
            "bbox": bbox,
            "center": bbox_center(bbox),
            "font": 'OCR_text',
            "size" : None,
            "color" : text_color,
            "orientation": orientation
        })


    return text_data

def calculate_bbox_orientation(polygon):
    """
    Based on the polygon returned by document intelligence, we can infer the orientation of the text.
    The polygon returns coordinates for top-left, top-right, bottom-right, and bottom-left points.
    Only top-left and bottom-right will be used
    """

    # Top-left to top-right vector
    dx = polygon[2] - polygon[0]
    dy = polygon[3] - polygon[1]
    angle = math.degrees(math.atan2(dy, dx)) 
    orientation = round(angle / 90) * 90 % 360

    xs = [int(polygon[i]) for i in range(0, len(polygon), 2)]
    ys = [int(polygon[i]) for i in range(1, len(polygon), 2)]

    bbox = (min(xs), min(ys), max(xs), max(ys))
    return bbox, orientation

if __name__ == "__main__":
    pdf_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\demo10p\ethibond_CURRENT_demo10p.pdf"
    image_path = r"C:\Users\MRuiz39\OneDrive - JNJ\Documents\Smartreader\output_ethibond\page_images\4_from_original.png"

    image = cv2.imread(image_path)

    run_document_intelligence(image)