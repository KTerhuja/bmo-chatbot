SLS =  {"0000" : False,
        "0020" : False,
        "0023" : "N_PC",
        "0025" : "LIMIT_HUMID",
        "0028" : "PHONE",
        "002F" : "PEEL2",
        #0030-003F Numbers and temperature units
        "0040" : "NO_REUSE",
        "0041" : "NO_RESTERILIZE",
        "0042" : "BIOHAZARD",
        "0043" : "PKG_DMG",
        "0044" : "EC_REP",
        "0045" : "CE",
        #0046 F
        "0047" : "PCT",
        "0048" : "MANUFACTURER",
        "0049" : "IFU",
        "004A" : "TEMP_UP",
        "004B" : "TEMP_LO",
        "004C" : "TEMP",
        "004D" : "TEMP_25",
        "004E" : "TEMP_30",
        "004F" : "TEMP_25_77",
        "0050" : "TEMP_30_86",
        "0051" : "KEEP_COOL",
        "0052" : "KEEP_DRY",
        "0053" : "CONT_MED",
        "0054" : "CONT_BLOOD",
        "0055" : "CONT_HAZ",
        "0056" : "CONT_ANIMAL",
        "0057" : "CONT_HUMAN",
        "0058" : "CONT_LATEX",
        "0059" : "CONT_PHT",
        "005A" : "CONT_PHT_DEHP",
        "0061" : "SB_OUT",
        "0062" : "SB_IN",
        "0063" : "SB_SINGLE",
        "0064" : "SB_DOUBLE",
        "0065" : "MD",
        "0066" : "STERILE_R",
        "0067" : "STERILE_EO",
        "0068" : "STERILE_TEMP",
        "0069" : "NON_STERILE",
        "006A" : "MR_TRIANGLE",
        "006B" : "CAUTION",
        "006C" : "STERILE_R",
        "006D" : "STERILE_EO",
        "006E" : "STERILE_TEMP",
        "006F" : "MR_UNSAFE",
        "0070" : "MR_SAFE_BL",
        "0071" : "MR_SAFE",
        "0072" : "RX_ONLY",
        "0073" : "LOT",
        "0074" : "REF",
        "0075" : "UDI",
        "0076" : "REF",
        "0077" : "SN",
        "0078" : "NON_PYRO",
        "0079" : "MANUFACTURING_DATE",
        "007A" : "EXPIRY",
        "2021" : "STERILE_TEMP",
        "00C1" : "PLED_SQ_FIRM_TH",
        "00C2" : "NEEDLES",
        "00C3" : "PEEL",
        }

ESL =  {"0000" : False,
        "0020" : False,
        "0024" : "EC_REP",
        "0025" : "STERILE_R",
        "0026" : "STERILE_EO",
        "0028" : "STERILE_R",
        "0029" : "STERILE_EO",
        "0041" : "NO_RESTERILIZE",
        "0042" : "BIOHAZARD",
        "0043" : "PKG_DMG",
        "0044" : "EC_REP",
        "0049" : "IFU",
        "004A" : "TEMP_UP",
        "004B" : "TEMP_LO",
        "004C" : "TEMP",
        "004D" : "TEMP_25",
        "004E" : "TEMP_30",
        "0050" : "N_PC",
        "0051" : "MANUFACTURER",
        "0052" : "MANUFACTURING_DATE",
        "0053" : "MANUFACTURER",
        "0054" : "MANUFACTURING_DATE",
        "0055" : "NEEDLES",
        "0056" : "KEEP_DRY",
        "0057" : "KEEP_COOL",
        "0058" : "CONT_LATEX",
        "005A" : "REF",
        "0064" : "NO_REUSE",
        "0065" : "CE",
        "0066" : "STERILE_R",
        "0067" : "STERILE_EO",
        "0068" : "CAUTION",
        "006C" : "STERILE_R",
        "006D" : "STERILE_EO",
        "006F" : "RX_ONLY",
        "0070" : "PEEL",
        "0071" : "NON_STERILE",
        "0072" : "MR_TRIANGLE",
        "0073" : "LOT",
        "0074" : "REF",
        "0075" : "SN",
        "0076" : "TEMP_25_77",
        "0077" : "TEMP_30_86",
        "0078" : "PCT",
        "0079" : "NON_PYRO",
        "007A" : "EXPIRY",
        "00C1" : "PLED_SQ_FIRM_TH",
        }

SEL = {"0000" : False,
       "0020" : False,
    "002B" : "#+",
    "002D" : "#ETHICON",
    "002E" : "#ETHICON",
    "0042" : "#ETHICON™",
    "0045" : "#ETHICON",
    "0047" : "#JOHNSON",
    "0048" : "#JOHNSON",
    "0049" : "#INTL",
    "004A" : "#JOHNSON",
    "004B" : "#JOHNSON",
    "004C" : "#INTL",
    "004D" : "#MULTIPASS™",
    "004E" : "#MULTIPASS™ NEEDLES",
    "0050" : "#PLUS",
    "0053" : "#STRATAFIX",
    "0054" : "#ETHICON™",
    "0056" : "#ETHIBOND",
    "0058" : "#EXCEL™",
    "0061" : "#ABSOLOK™",
    "0062" : "#ETHICON™",
    "0065" : "#ETHICON",
    "0074" : "#ETHICON™",
    "0076" : "#VALVEKIT™"
    }

SLG = {
    "0025" : "ETHILOCK",
    "002B" : "NP_CESR+",

    #"0040" : "UNK1" #todo IDENTIFY

    "0042": "NP_BP", 
    "0043": "NP_CEC", 
    "0044": "NP_BPE", 
    "0045": "NP_BPD", 

    "0047": "NP_CESR", 
    "0048": "NP_CESC", 
    "0049": "NP_CESCP",

    "004B": "PLED_SQ_FIRM", 
    "004C": "PLED_SQ_FIRM_TH", 
    "004D": "PLED_RD_FIRM", 
    "004E": "PLED_RD_FIRM_TH", 

    "0050": "NP_CEPR", 
    "0051": "NP_CEPC",
    "0052": "NP_CER", 
    "0053": "NP_TC", 
    "0054": "NP_TP", 
    "0055": "NP_CEUC", 

    "0058": "NP_TPP", 

    "0063": "NP_TC", 

    "006B": "PLED_SQ_SOFT", 
    "006C": "PLED_SQ_SOFT_TH", 
    "006D": "PLED_RD_SOFT", 
    "006E": "PLED_RD_SOFT_TH",

    #"0072" : "", # SOME KIND OF TAPERPOINT

    "0074": "NP_TR"
}

SLP = {
    "0020": False,
    "0023": "N_UNITS",
    "0024": "2BEADS2COLLARS",
    "0025": "2BEADS3COLLARS",
    "0026": "2_LOCKING_BUTTONS",

    "0028": "NEEDLES",
    "0029": "PEEL",

    "002F": "TEAR",

    "0040": "ANTIBACTERIAL",

    "0041": "SA_DYED_UNCOATED_MONOFILAMENT_NONABSORBABLE",
    "0042": "SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE",
    "0043": "SA_DYED_COATED_MONOFILAMENT_NONABSORBABLE",
    "0044": "SA_DYED_COATED_MONOFILAMENT_ABSORBABLE",
    "0045": "SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDUNI",

    "0047": "SA_DYED_UNCOATED_BRAIDED_NONABSORBABLE",
    "0048": "SA_DYED_UNCOATED_BRAIDED_ABSORBABLE",
    "0049": "SA_DYED_COATED_BRAIDED_NONABSORBABLE",
    "004A": "SA_DYED_COATED_BRAIDED_ABSORBABLE",
    "004B": "SA_DYED_UNCOATED_TWISTED_NONABSORBABLE",
    "004C": "SA_DYED_UNCOATED_TWISTED_ABSORBABLE",
    "004D": "SA_DYED_COATED_TWISTED_NONABSORBABLE",
    "004E": "SA_DYED_COATED_TWISTED_ABSORBABLE",
    "004F": "SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDBI",

    "0050": "CR_2",
    "0051": "CR_3",
    "0052": "CR_4",
    "0053": "CR_5",
    "0054": "CR_6",
    "0056": "CR_8",
    "0059": "CR",

    "0061": "SA_UNDYED_UNCOATED_MONOFILAMENT_NONABSORBABLE",
    "0062": "SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE", #
    "0063": "SA_UNDYED_COATED_MONOFILAMENT_NONABSORBABLE", #
    "0064": "SA_UNDYED_COATED_MONOFILAMENT_ABSORBABLE", #
    "0065": "SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDUNI", #

    "0067": "SA_UNDYED_UNCOATED_BRAIDED_NONABSORBABLE", #
    "0068": "SA_UNDYED_UNCOATED_BRAIDED_ABSORBABLE", #
    "0069": "SA_UNDYED_COATED_BRAIDED_NONABSORBABLE",
    "006A": "SA_UNDYED_COATED_BRAIDED_ABSORBABLE",
    "006B": "SA_UNDYED_UNCOATED_TWISTED_NONABSORBABLE",
    "006C": "SA_UNDYED_UNCOATED_TWISTED_ABSORBABLE", #
    "006D": "SA_UNDYED_COATED_TWISTED_NONABSORBABLE",
    "006E": "SA_UNDYED_COATED_TWISTED_ABSORBABLE", #
    "006F": "SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDBI",

    "0070": "MS_2",
    "0071": "MS_3",
    "0072": "MS_4",
    "0073": "MS_5",
    "0074": "MS_6",
    "0075": "MS_7",
    "0076": "MS_8",
    "0077": "MS_10",

    "007D": "MS_12"
}

ECTM2 = {"0020" : False,
         "0021" : "M_2",
         "0022" : "M_4",
         "0023" : "M_6",
         "0024" : "M_8",
         "0025" : "M_10",
         "0026" : "CR_4",
         "0027" : "CR_8",
         "0028" : "MS_10",
         "0029" : "MS_2",
         "002A" : "MS_4",
         "002B" : "MS_6",
         "002C" : "1_1",
         "002D" : "#ETHICON",
         "002E" : "#ETHICON",
         "002F" : "#ETHICON",
         "003A" : "M_3",
         "003B" : "M_5",
         "003D" : "M_7",
         "003F" : "M_12",
         "0040" : "PEEL",
         "0041" : "CR_2",
         "0042" : "CR_3",
         "0043" : "CR_5",
         "0044" : "CR_6",
         "0045" : "EC_REP",
         "0047" : "#JOHNSON",
         "0048" : "#JOHNSON",
         "0049" : "#INTL",
         "004A" : "#JOHNSON",
         "004B" : "#JOHNSON",
         "004C" : "#INTL",
         "004D" : "#MULTIPASS™",
         "004E" : "#MULTIPASS™ NEEDLES",
         "004F" : "MS_3",
         "0050" : "MS_5",
         "0051" : "MS_7",
         "0052" : "MS_8",
         "0053" : "MANUFACTURER",
         "0054" : "MS_12",
         "0055" : "#ETHIBOND",
         "0056" : "#ETHIBOND",
         #"0057" : "UNK1",
         "0058" : "#EXCEL™",
         "0059" : "BLACK_FIN_NOZZLE",
         #"005A" : "UNK2",
         "005B" : "2_LOCKING_BUTTONS",
         "005C" : "2BEADS2COLLARS",
         "005D" : "2BEADS3COLLARS",
         "0061" : "#ABSOLOK™",
         "0064" : "NO_REUSE",
         "0065" : "CE",
         "0066" : "STERILE_R",
         "0067" : "STERILE_EO",
         "0068" : "CAUTION",
         "0069" : "LOT",
         "006A" : "STERILE_R",
         "006B" : "STERILE_EO",
         "006C" : "STERILE_R",
         "006D" : "STERILE_EO",
         "006E" : "CAUTION",
         "006F" : "NO_REUSE",
         "0070" : "N_UNITS",
         "0073" : "LOT",
         #"0074" : "UNK3", # sOME KIND OF ARROW
         #"0075" : "", # SOME KIND OF TAPERPOINT
         "0076" : "#VALVEKIT",
         #"0077" : "UNK1",
         "0079" : "GRUNE_PUNKT",
         "007A" : "EXPIRY",
         "007B" : "EXPIRY",
         "007C" : "#MULTIPASS™ NEEDLES",
            }

ECTB = {}

symbol_map = {'SymbolsLibraryStandard' : SLS,
                'EthiconSymbolsLibrary' : ESL,
                'SymbolsEthiconLogos' : SEL,
                'SymbolsLibraryGraphics' : SLG,
                'SymbolsLibraryProprietar' : SLP,
                'EthiconCorporateTM2' : ECTM2, 
                'EthiconCorporateTB' : ECTB,# To be implemented
                'SymbolMT' : {},
                'EthiconCorporateUS' : {}

                }

SYMBOL_FONTS = symbol_map.keys()

def decode_symbol(char, font):
    """
    Decode a symbol character based on the font.
    """    

    
    # Suture Attributes notes:
    # DYE_COATING_CONSTRUCTION_ABSORBABILITY_BARBED

    # DYE: UNDYED, DYED
    # COATING: COATED, UNACOATED
    # CONSTRUCTION: MONOFILAMENT, BRAIDED, TWISTED
    # ABSORBABILITY: ABSORBABLE, NONABSORBABLE
    # BARBED: BARBEDUNI, BARBEDBI

    # special_prefixes: 
    # "NP" : "NEEDLE_POINT"
    # "PLED" : "PLEDGET"
    # "SA" : "SUTURE_ATTRIBUTES"
    
    hex_char = format(ord(char), '04x').upper() # Convert the character to a 4-digit hex string

    try:
        font_map = symbol_map[font]
        symbol_name = font_map[hex_char]
        symbol_type = "Normal"
        if symbol_name and symbol_name[0] == "#":
            symbol_name = symbol_name[1:]
            symbol_type = "Literal"
    except KeyError:
        symbol_name = font+hex_char
        symbol_type = "Unknown"

    return symbol_name, symbol_type

def get_symbol_business_name(symbol_name):
    """
    Will return the business name if it is in name_map
    If it is empty or not in name map, it will return symbol_name
    """
    business_name = name_map.get(symbol_name, symbol_name)
    if business_name=='':
        return symbol_name
    return business_name

### NAME MAP
# This maps the internal names to business names
# new_symbols() will check if there are any symbols not present in the name_map
# print_empty_namemap() was used to create a value-less dict to start this map
# The comments after each entry refers to the status of inclusion of the symbol in the Object Detection model
name_map = {'1_1': '',
            '2BEADS2COLLARS': '2 Beads 2 Collars',
            '2BEADS3COLLARS': '2 Beads 3 Collars',
            '2_LOCKING_BUTTONS': '2 Locking Buttons',
            'NO_RESTERILIZE': 'Do Not Resterilize',#
            'ANTIBACTERIAL': 'Antibacterial',#
            'BIOHAZARD': 'Biological risks',#
            'BLACK_FIN_NOZZLE': 'Black Plastic Slide Fin w Black Plastic Nozzle',#
            'IFU': 'Consult instruction for use I book',#
            'CE': 'CE',#
            'CONT_ANIMAL': 'Contains biological material of animal origin',#
            'CONT_BLOOD': 'Contains blood products',#
            'CONT_HAZ': 'Contains hazardous substances',#
            'CONT_HUMAN': 'Contains biological material of human origin',#
            'CONT_MED': 'Contains a medicinal substance',#
            'CR_X': 'Control Release',
            'CR_2': 'Control Release 2',# Will be covered by CR_X
            'CR_3': 'Control Release 3',# Will be covered by CR_X
            'CR_4': 'Control Release 4',# Will be covered by CR_X
            'CR_5': 'Control Release 5',# Will be covered by CR_X
            'CR_6': 'Control Release 6',# Will be covered by CR_X
            'CR_8': 'Control Release 8',# Will be covered by CR_X
            'EC_REP': 'EC REP',#
            'EU_REP': 'EU REP',#
            'ETHILOCK': 'Ethilock Fixierclips',#
            'EXPIRY': 'Use by date',#
            'GRUNE_PUNKT': '',
            'KEEP_COOL': 'Keep away from sunlight or heat',#
            'KEEP_DRY': 'Keep Dry',#
            'CONT_LATEX': 'latex',#
            'LIMIT_HUMID': 'Humidity limitation',#
            'LOT': 'LOT',#
            'M_2': '',
            'M_3': '',
            'M_4': '',
            'M_5': '',
            'M_6': '',
            'M_7': '',
            'M_8': '',
            'M_10': '',
            'M_12': '',
            'MANUFACTURER': 'Manufacturer',#
            'MANUFACTURING_DATE': 'Date of Manufacture',#
            'MD': 'Medical Device',#
            'MR_SAFE_BL': '',
            'MR_SAFE': 'MR Safe open',#
            'MR_TRIANGLE': 'MR Conditional',#
            'MR_UNSAFE': 'MR Unsafe',#
            'MS_X': 'Multi-Strand',#
            'MS_10': 'Multi-Strand 10',# Will be covered by MS_X
            'MS_12': 'Multi-Strand 12',# Will be covered by MS_X
            'MS_2': 'Multi-Strand 2',# Will be covered by MS_X
            'MS_3': 'Multi-Strand 3',# Will be covered by MS_X
            'MS_4': 'Multi-Strand 4',# Will be covered by MS_X
            'MS_5': 'Multi-Strand 5',# Will be covered by MS_X
            'MS_6': 'Multi-Strand 6',# Will be covered by MS_X
            'MS_7': 'Multi-Strand 7',# Will be covered by MS_X
            'MS_8': 'Multi-Strand 8',# Will be covered by MS_X
            'NEEDLES': 'Needle',#Excluded due to similarity to needle profiles, but there is a rule to redirect some of the NEEDLE detections to this symbol
            'NON_PYRO': 'Non-pyrogenic',#
            'NON_STERILE': 'Non Sterile',#
            'NO_REUSE': 'Do not re-use',#
            'NP_BP': 'Blunt Point',#
            'NP_CEC': 'Conventional Cutting',#
            'NP_CER': 'Reverse Cutting',#Not included as it has a reversible version
            'NP_BPE': 'ETHIGUARD BPE Point',#
            'NP_BPD': 'ETHIGUARD BPD Point',#
            'NP_CEPC': 'Prime Conventional Cutting',#
            'NP_CEPR': 'Prime Reverse Cutting',#Not included as it has a reversible version
            'NP_CESC': 'Conventional Spatula',#
            'NP_CESCP': 'Center Point Spatula',#
            'NP_CESR+': 'Cutting Edge Spatula Reverse Plus',#
            'NP_CESR': 'Reverse Spatula',#Not included as it has a reversible version
            'NP_CEUC': '',#
            'NP_CEUR': 'CS ULTIMA reverse',#Not included as it has a reversible version
            'NP_TC': 'TAPERCUT',#
            'NP_fTC': 'TAPERCUT (old version)',#
            'NP_TCC': 'CC Needle',#
            'NP_TP': 'Taperpoint',#
            'NP_TPP': 'Taperpoint Plus',#
            'NP_TR': 'Trocar point',#
            'N_PC': 'Packaging Unit',#
            'N_UNITS': 'Quantity sachet',#
            'PCT': 'PCT',#
            'PEEL': 'Peel-Lift-Open Here',#
            'PEEL2': 'Open Here',#
            'PHONE': 'Telephone',#
            'CONT_PHT': 'PHT',#
            'CONT_PHT_DEHP': 'Contains or presence of phthalate',#
            'PKG_DMG': 'Packaging damaged',#
            'PLED_RD_FIRM': 'Pierced firm round cornered pledget',#
            'PLED_RD_FIRM_TH': 'Firm round corner - Needlestack suture',#
            'PLED_RD_SOFT': 'Pierced soft round cornered pledget',#
            'PLED_RD_SOFT_TH': 'Soft round corner - Needlestack suture',#
            'PLED_SQ_FIRM': 'Pierced firm square cornered pledget',#
            'PLED_SQ_FIRM_TH': 'Firm square corner - Needlestack suture',#
            'PLED_SQ_SOFT': 'Pierced soft square cornered pledget',#
            'PLED_SQ_SOFT_TH': 'Soft square corner - Needlestack suture',#
            'REF': 'REF',# BOX_SYMBOLS
            'RX_ONLY': 'RX Only Horizontal',#
            'SA_DYED_COATED_BRAIDED_ABSORBABLE': 'Dyed_Abs_Braided_Coated',#
            'SA_DYED_COATED_BRAIDED_NONABSORBABLE': 'Dyed_NonAbs_Braided_Coated',#
            'SA_DYED_COATED_MONOFILAMENT_ABSORBABLE': 'Dyed_Abs_Mono_Coated',#
            'SA_DYED_COATED_MONOFILAMENT_NONABSORBABLE': 'Dyed_NonAbs_Mono_Coated',#
            'SA_DYED_COATED_TWISTED_ABSORBABLE': 'Dyed_Abs_Twisted_Coated',#
            'SA_DYED_COATED_TWISTED_NONABSORBABLE': 'Dyed_NonAbs_Twisted_Coated',#
            'SA_DYED_UNCOATED_BRAIDED_ABSORBABLE': 'Dyed_Abs_Braided',#
            'SA_DYED_UNCOATED_BRAIDED_NONABSORBABLE': 'Dyed_NonAbs_Braided',#
            'SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE': 'Dyed_Abs_Mono',#
            'SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDBI': 'Dyed Bidirectional Barbs Absorbable Device',#
            'SA_DYED_UNCOATED_MONOFILAMENT_NONABSORBABLE_BARBEDBI': 'Dyed Bidirectional Barbs Non Absorbable',#
            'SA_DYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDUNI': 'Anchored_Dyed_Abs_Mono',#
            'SA_DYED_UNCOATED_MONOFILAMENT_NONABSORBABLE_BARBEDUNI': 'Dyed Unidirectional Barbs Non Absorbable',#
            'SA_DYED_UNCOATED_MONOFILAMENT_NONABSORBABLE': 'Dyed_NonAbs_Mono',#
            'SA_DYED_UNCOATED_TWISTED_ABSORBABLE': 'Dyed_Abs_Twisted',#
            'SA_DYED_UNCOATED_TWISTED_NONABSORBABLE': 'Dyed_NonAbs_Twisted',#
            'SA_UNDYED_COATED_BRAIDED_ABSORBABLE': 'Undyed_Abs_Braided_Coated',#
            'SA_UNDYED_COATED_BRAIDED_NONABSORBABLE': 'Undyed_NonAbs_Braided_Coated',#
            'SA_UNDYED_COATED_MONOFILAMENT_ABSORBABLE': 'Undyed_Abs_Mono_Coated',#
            'SA_UNDYED_COATED_MONOFILAMENT_NONABSORBABLE': 'Undyed_NonAbs_Mono_Coated',#
            'SA_UNDYED_COATED_TWISTED_ABSORBABLE': 'Undyed_Abs_Twisted_Coated',#
            'SA_UNDYED_COATED_TWISTED_NONABSORBABLE': 'Undyed_NonAbs_Twisted_Coated',#
            'SA_UNDYED_UNCOATED_BRAIDED_ABSORBABLE': 'Undyed_Abs_Braided',#
            'SA_UNDYED_UNCOATED_BRAIDED_NONABSORBABLE': 'Undyed_NonAbs_Braided',#
            'SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE': 'Undyed_Abs_Mono',#
            'SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDBI': 'Undyed-Bidirectional Barbs Absorbable Device',#
            'SA_UNDYED_UNCOATED_MONOFILAMENT_ABSORBABLE_BARBEDUNI': 'Anchored_Undyed_Abs_Mono',#
            'SA_UNDYED_UNCOATED_MONOFILAMENT_NONABSORBABLE': 'Undyed_NonAbs_Mono',#
            'SA_UNDYED_UNCOATED_TWISTED_ABSORBABLE': 'Undyed_Abs_Twisted',#
            'SA_UNDYED_UNCOATED_TWISTED_NONABSORBABLE': 'Undyed_NonAbs_Twisted',#
            'SB_DOUBLE': 'Double sterile barrier system',#
            'SB_IN': 'Single sterile barrier system_protective packaging outside',#
            'SB_OUT': 'Single sterile barrier system_protective packaging inside',#
            'SB_SINGLE': 'Sterile barrier system-Single barrier',#
            'SN': 'SN',# BOX_SYMBOLS
            'STERILE_EO': 'STERILE EO wide',# BOX_SYMBOLS
            'STERILE_R': 'STERILE R wide',# BOX_SYMBOLS
            'STERILE_TEMP': 'STERILE Steam or Heat wide',# BOX_SYMBOLS (SPECIAL CASE)
            'TEAR': 'TEAR HERE',#
            'TEMP': 'Temperature limit',#
            'TEMP_25': '',# Only TEMP symbol incuded, the number text is to be picked up by OCR
            'TEMP_25_77': '',# Only TEMP symbol incuded, the number text is to be picked up by OCR
            'TEMP_30': '',# Only TEMP symbol incuded, the number text is to be picked up by OCR
            'TEMP_30_86': '',# Only TEMP symbol incuded, the number text is to be picked up by OCR
            'TEMP_LO': 'Temperature lower limit',#
            'TEMP_UP': 'Temperature upper limit',#
            'CAUTION': 'Caution',#
            'UDI': 'Identifier',# BOX_SYMBOLS

            'USA_REP' : 'USA REP',

            # Brand logos (detected via OCR-triggered template matching, see find_logos)
            'LOGO_BIOSENSE_WEBSTER': 'Biosense Webster Logo',
            'LOGO_JOHNSON_JOHNSON': 'Johnson & Johnson Logo',

            }

# These symbols are text inside a rectangle. They might be grouped in one class (BOX_SYM) for object detection. 
# OCR extracted text is used to determine which one it actually is.
BOX_SYMBOLS = ['EC_REP', 'EU_REP',
               'GB_REP', 'UK_REP',
               'CH_REP',
               'LOT',
               'MR_SAFE',
               'MD',
               'REF', 'QTY', 
               'SN',
               'STERILE_EO',
               'STERILE_R',
               'STERILE_TEMP',
               "UDI",
               'CONTENTS', 'OD', 'ID', 'RADIOPAQUE', 'NON_PYRO',
               'ANTERIOR', 'POSTERIOR', 'MULTIPURPOSE', 'MULTIPURPOSE_SHORT',
               'REF_US', 'F',
               'MANUFACTURED_IRELAND', 'Assembled in Germany', 'MANUFACTURED_SINGAPORE', 'MANUFACTURED_ISRAEL', 'ASSEMBLED_MEXICO', 'MANUFACTURED_SOUTH KOREA', 'Assembled in USA', 'ASSEMBLED_COSTA RICA',
               'C3', 'US', 'RMT', 'MAX GW', 'WW', 'JP', 'XP',
               'Ø',
               'SMALL_CURVE', 'MEDIUM_CURVE', 'LARGE_CURVE',
               'SPACING_mm', 'ELECTRODES_EA'
              ]
TEXT_SYMBOLS = ['IP23', 'IPX8', 'IP21']
DARK_BOX_SYMBOLS = ['ST', 'SF', 'ST SF', 'TC', 'NAV', 'NON NAV', 'DE STSF', '4mm', '8mm', 'OTW']
CURVE_TYPE_SYMBOLS = ['D', 'F', 'XR']
def print_empty_namemap():
    symbol_names=[]
    for font, smap in symbol_map.items():
        for hex, symbol_name in smap.items():
            if symbol_name: # Exclude non-printables (False)
                if not symbol_name.startswith('#'): #Exclude literal symbol logos
                    symbol_names.append(symbol_name)
    symbol_names = list(set(symbol_names))
    symbol_names.sort()
    print(dict(zip(symbol_names,['']*len(symbol_names))))

def new_symbols():
    """
    Check for new symbols that are not in the name_map
    """
    missing_symbols=[]
    for font, smap in symbol_map.items():
        for hex, symbol_name in smap.items():
            if symbol_name and symbol_name not in name_map.keys(): # Exclude non-printables (False)
                if not symbol_name.startswith('#'): #Exclude literal symbol logos
                    missing_symbols.append(symbol_name)
    missing_symbols = list(set(missing_symbols))
    missing_symbols.sort()
    print(missing_symbols)

if  __name__ == "__main__":
    new_symbols()
